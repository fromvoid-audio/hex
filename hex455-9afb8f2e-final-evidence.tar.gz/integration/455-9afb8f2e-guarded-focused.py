import pathlib,importlib.util,sys
root=pathlib.Path.cwd();spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('provider',('cargo','test','-p','hex-devices','compressor::tests','--locked','--','--nocapture')),m.Step('compressor-ui',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','compressor_','--locked','--','--nocapture')),m.Step('retained-auto-pan-ab',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','auto_pan_generic_ab_','--locked','--','--nocapture')))
r=m.LocalCiRunner(root,mode='component',run_id='455-9afb8f2e-guarded-focused',adopt_target=True,min_free_bytes=2*1024**3,steps=steps);sys.exit(r.run())
