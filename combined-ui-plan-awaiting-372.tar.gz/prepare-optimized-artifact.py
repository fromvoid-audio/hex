"""Coordinator-only invocation of the existing nonactivating release helper."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', required=True, help='qualified actual main merge checkout')
p.add_argument('--candidate', required=True, help='commit in original full CI report')
p.add_argument('--ci-report', type=Path, required=True)
a = p.parse_args()
root = Path.cwd()
head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if head != a.source or len(a.source) != 40 or len(a.candidate) != 40:
    raise SystemExit('requires exact qualified source and full report candidate')
if sys.platform != 'darwin':
    raise SystemExit('this handoff is for the coordinator-dispatched managed Mac')
spec=importlib.util.spec_from_file_location('cohort_delivery',root/'scripts/hex-test-build.py')
d=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=d
spec.loader.exec_module(d)
runner=d.ci.LocalCiRunner(root)
d.validate_ci(a.ci_report,runner,a.candidate)
with d.optimized_artifact(runner,adopt=False) as (binary,ownership):
    d.validate_ci(a.ci_report,runner,a.candidate)
    target=runner.output_dir/'optimized-artifact-only'
    target.mkdir()
    copied=target/'hex'
    shutil.copy2(binary,copied)
    if d.sha(copied) != ownership['artifact']['sha256']:
        raise SystemExit('copied artifact hash mismatch')
    result=dict(source=head,candidate=a.candidate,
        tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
        ci_report=str(a.ci_report),ci_report_sha256=d.sha(a.ci_report),
        executable=str(copied),executable_sha256=d.sha(copied),
        native_bundle_signed=False,installed=False,launched=False)
    (target/'artifact-only.json').write_text(json.dumps(result,indent=2)+'\n')
d.write_json(target/'release-ownership.json',ownership)
print(json.dumps(result,indent=2))
