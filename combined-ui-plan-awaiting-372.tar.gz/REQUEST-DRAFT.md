# Combined optimized Hex UI cohort — awaiting PR372 qualification/actual merge

This is a coordination draft, not permission to start a Mac job or replace an app.
The coordinator dispatches existing verifier01a149f8-d4e8-7c91-82b9-5bdea69929a0
serially. No new implementation PR, infrastructure or completed-issue change.

## Pin and evidence prerequisites

PR372 is currently OPEN at504d9b3cfe7658b366c01c12bd6de232c3d320c8, tree
57ba6db29f5e1a9edde2be6a88b6adef22211fea. Its required full20 is reported running;
neither eligibility, merge nor native acceptance is established yet.
After its owner reports final PASS/review and GitHub actually reports merged,
fetch and pin that actual main merge commit, record its full source/tree, verify
the reviewed head is ancestral and every included cohort head is ancestral.
Freeze there; later unrelated main changes do not require another main chase.

Reuse the original full report ONLY if the actual merge has the same complete
tree/content digest and verified candidate ancestry under docs/test-builds.md.
Otherwise run the existing python3 scripts/local-ci.py once on the clean pinned
changed tree (cloud-suitable). Require full mode, all20 correct commands passed,
exit0, clean unchanged start/end digest, stale=false. Preserve original report
bytes, SHA256 and every stage log. Old7a6595b7 or old372 reports do not cover a
different combined tree. No hosted CI or repeat unchanged broad validation.

Includes: merged launcher359/364/368 and signing355, resize330, browser384/385/386,
processed-waveform388, lower-handle free-default383, BPM/Shift/live-preview387,
Command-T375, fixture-only381; final372 only after its actual merge. Also enumerate
ancestral UI344/348, coherent-current-format350 and sampler-kernel296 as provenance, without claiming
native acceptance. Preserve earlier ancestral delivery manifest revisions.
Exclude unfinished EQ spectrum349, tuning351/352/353, native373/389, full sampler goal,
track rename376, range377, paste378 and border335 unless separately requalified
and deliberately added to a later candidate. They do not block this cohort. PR296 is an already merged/ancestral kernel prerequisite, not the full sampler device or native acceptance; do not exclude its actual source ancestry.

## Phase A: nonactivating Mac verification/build request

Verify existing clean pinned checkout/toolchain, source/tree/digest/report and
included heads, process inventory, active build/target lock and disk headroom.
The last installed-source audit1879e018 is historical; discover current source,
receipt/hash and process state read-only. Hex may remain open for checks that do
not publish an app. Do not touch user profile/media/TCC/keychain configuration.

If repository-required full exact-source checks have already passed and the tree
matches, do not demand broad Mac full20 merely to repeat portable geometry tests.
For the remaining actual native signing fixture, separately schedule the documented
test command only with coordinator authorization to use the configured signing key:

    HEX_TEST_SIGNING_IDENTITY=4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E python3 -m unittest discover -s scripts/tests -p test_hex_test_build.py

It uses temporary fixtures, not the installed app. Record actual native signed
fixture pass/skips/failures; keychain interaction, if any, belongs to the user.
Do not change keychain access/settings or infer fixture PASS from Linux skips.

For a build with NO installation while Hex is open, use the existing documented
scripts/hex-test-build.py optimized_artifact(runner, adopt=False) helper; it uses
the target ownership lock, exact source guard and Cargo release JSON artifact.
After this draft is bound to a qualified immutable source/report, use a bounded
invocation of that existing helper to copy the yielded executable inside the
guard to ignored artifacts and record its hash/ownership; no app assembly,
signing, installation or launch. A loose artifact is not a delivered app.
Supported bounded invocation (after qualification):

    python3 <extracted-plan>/prepare-optimized-artifact.py --source <pinned-main-merge> --candidate <original-report-commit> --ci-report <original-report.json>

The companion script delegates to that existing helper; syntax reviewed only in
cloud, never executed here. It does not claim native runtime acceptance.
Do not use raw Cargo to bypass ownership. Do not auto-adopt an unknown/pending
target; report that state for bounded owner-approved recovery.

## Phase B: separately coordinated signed stable-path installation

Only after current app-state readback and the user's normal save/quit, with no
other launcher/build and the coordinator's explicit dispatch, run:

    sh scripts/bundle-macos.sh --ci-report <verified-original-report.json> --candidate <original-report-commit> --included <included-test-revisions.json> --checklist <USER-TEST.md>

The --candidate value MUST be the original full report commit. When reusing
head CI for an identical-tree merge, checkout stays at the pinned actual merge
and --candidate stays at the checked PR head; validate_ci verifies tree/ancestry.
Never rewrite the original report commit or pass a different report candidate.
This is the supported optimized BUILD AND INSTALL command, not a dry run.
It may reuse the valid release compilation through existing tooling. Never call
build/activate/recover merely to stage. Preserve stable org.portalsurfer.hex.dev,
/Users/portalsurfer/dev/hex/artifacts/hex.app, executable Contents/MacOS/hex,
certificate4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E/teamDKTKQ8U5T8.
Retain full receipt/source digest, release log, executable SHA256, signature and
designated requirement, seal and original report. No forcequit/revision-named
review apps/profile/media mutation. Disk activation is not a running build.
After successful authorized installation the user may use ./launch --open.
Plain ./launch always fetches/builds latest main without tests and can change
the candidate; --test opts into full checks. Preserve those accepted defaults.

## Focused user acceptance (actual running-source/receipt required)

Use a disposable current-format project, original sample copies and an unaffected
control. Alpha history migration is not required; no conversion/deletion of files.

1. Browser: stable audition waveform/hover and progress; click early/middle/late
   waveform positions for audible bounded seek/progress; double-click sample
   results without accidental track insertion; deliberate drag insertion works.
2. Ordinary waveform edges: affected/control stereo samples, raw/Warp on/off and
   processed-Warp-off, crop/partial/loop sources, wide/close zoom and offscreen
   reveal. Continuous left/right resize retains visible peaks and unchanged
   interior landmarks instead of disappearing or redistributing them.
3. Both lower handles: free motion by default, Command snap opt-in, stationary
   modifier press/release matches final release. Correct crop/fade preview and
   one Undo/Redo; no timing/selection regression. Record bounded held-drag capture.
4. Sample BPM/Shift: source60/project120 two-second->one-second example, fractional
   and invalid input/cancel, both Shift edges, live remap before release including
   stationary Shift, trimmed/looped/marker/autoscroll cases. Escape/focus/stale
   cancel restores preview without history; release gives one Undo/Redo. Playback,
   seek/export duration, pitch/attacks/loop seams need user listening evidence.
5. Track sizing: shared header-left width and individual bottom heights, existing
   minima/maxima, empty/pinned main, controls/sends, row/lane/ruler/overview/frame
   alignment, mixed-height scroll/keyboard, final outside release and Escape/
   focus/window cancellation. Resizing itself adds no project dirty/Undo change.
6. Command-T: editor-focused new track through existing action; text/numeric/search
   focus must preserve normal input and not unexpectedly create tracks. Record
   selection/scroll result and existing Undo behavior; no shortcut redesign.

Prior spinner user acceptance stands; no repeated broad spinner gate. Native
signing fixture, installed/running source and physical waveform/browser/resize/
shortcut acceptance remain pending until actual evidence. Sample-folder permission
and audible real WAV preview across normal identical-executable --open relaunch
remain a distinct user-driven acceptance; no TCC reset/broad permission/keychain
or profile changes, no permission-persistence claim from signing alone.

## Transport

Use the existing private Git evidence-only immutable ref route: original reports,
all logs, included/excluded manifest, source/tree/merge proof and finite checklist
in tar.gz, with exact bytes/SHA256 and per-file hash manifest, remote readback.
Never checkout/build/merge the evidence ref. Fetch and verify into new temporary
storage, reject links/absolute/.. archive members and verify each regular file.
Pulse note records immutable ref/commit/archive/bytecount/SHA256 and recovery
commands. No opaque Pulse payloads or inaccessible-cloud-path-only handoff.
