Pinned327 UI/EQ cohort qualification and finite coordinator Mac request.
Actual source327ebe98d575061f4d16f3db894aea5b624b86b4/tree1c2b67f8a20430ecd7a8a0857f65d471a5ee2872.
Supported original20/20 report reuse from ancestor8e507b689d8dcaaca26dec5082319c5fff27949a; original report bytes untouched.
Read supporting/MAC-REQUEST.md BEFORE any local execution. No Mac dispatch/install authority inferred.
Full original UI evidence/failures retained (129 payload hashes verified); original EQ evidence761 payload hashes verified and retained in nested original-eq-evidence.tar.gz.
No new cloud tests/build/source edits/primary permission changes.
Never checkout/build/merge evidence ref.
