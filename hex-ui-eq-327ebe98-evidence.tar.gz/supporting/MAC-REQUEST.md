# Pinned UI/EQ cohort: coordinator serial Mac request

Actual checkout/source:327ebe98d575061f4d16f3db894aea5b624b86b4.
Complete tree:1c2b67f8a20430ecd7a8a0857f65d471a5ee2872.
Original full20 report candidate:8e507b689d8dcaaca26dec5082319c5fff27949a.
Original report:ui/pr335/full20/summary.json, SHA256
74baee444085284c6cd77f9425618f3843e92ec61ae709509d5265b04fbd1d61.
20/20 passed811.503s, clean/unchanged/stale=false. This is the ORIGINAL PR-head
report, not a relabeled/new run on327. The ancestor's complete tree is identical;
the current repository validate_ci actually passed on the clean pinned checkout.
No redundant cloud full20 was run. qualification-proof.json records that reuse.

## Reproducible source and permissions, before checks/builds

Use only the existing coordinator-owned serial Mac verifier and managed toolchain.
No cloud dispatch. Installed dfa21f5a/build3751944026 at
/Users/portalsurfer/dev/hex/artifacts/hex.app remains UNTOUCHED by this request's
source/check phase. Re-read current app/process/build/lock/ownership state; no
historical audit establishes current state. Preserve primary/unpublished work.

Fresh isolated checkout must reproduce the ACTUAL full-report inputs:
1837 tracked files, zero untracked inputs, all materialized bytes equal Git blobs,
launch permissions0700/execute mask64, all other execute masks0. Digest:
bd380bbdede8cca820f2f9b5b11c48020571fd71bfd2028ec68abcf18d9a8f48.
Canonical Git0755 launch would instead yield
a0d4e709bb67f78d70be83c4ab65dc7ea766c158596a46162a60b8a0c14caa25.
The difference is documented, never normalized in the guard/report. Create a NEW
task-owned source worktree with explicit checkout umask, not chmod of any primary
or existing checkout (choose an absent task-owned path):

    git fetch origin 327ebe98d575061f4d16f3db894aea5b624b86b4
    (umask 077; git worktree add --detach <new-isolated-source-path> 327ebe98d575061f4d16f3db894aea5b624b86b4)

Before consuming CI, verify HEAD/tree/clean status and every entry in source-inputs.json
(path/order/bytes/SHA/Git mode/actual execute mask), then call the actual repository
validate_ci with the unchanged original report and candidate8e507b68. Stop/report
any difference; no silent chmod, report rewrite, guard patch or bypass. Fresh worktree
creation applies umask only to those new files; primary checkout modes stay intact.

Included42 ancestral heads preserve the entire installed cohort and add349/373/
376/377/378/335. Open sampler-resource389, tuning editor352/MTS353 are EXCLUDED.
Do not wait for them or absorb later main. Spinner2760 and EQ gestures2729 remain
user accepted; do not repeat their signoffs as gates. Alpha historical migration
is out of scope; disposable current-format projects only, no user-file conversion.

## Finite native qualification and artifact preparation (no installation)

EQ owner's original supporting/EQ-NATIVE-REQUEST.md requests the Mac matrix once
on this pinned cohort. Reuse a genuinely identical existing Mac full report if
one is supplied; otherwise, after coordinator dispatch run the existing matrix:

    python3 scripts/local-ci.py

Keep original report/all20logs, source/digest/start/end/stale state, actual skips,
hardware/toolchain and failures. Do not relabel the Linux report as Mac evidence.
This explicit native EQ follow-up is separate from the valid reused cloud source
qualification; no source change or second cloud pipeline is requested.

If preparing an optimized artifact while the installed app is retained, use the
existing documented optimized_artifact helper through the SAME reviewed helper
included in supporting/prepare-optimized-artifact.py. It is not an installer:

    python3 <evidence>/supporting/prepare-optimized-artifact.py \
      --source 327ebe98d575061f4d16f3db894aea5b624b86b4 \
      --candidate 8e507b689d8dcaaca26dec5082319c5fff27949a \
      --ci-report <evidence>/ui/pr335/full20/summary.json

If using the newly completed Mac full report instead, --candidate MUST equal its
actual report commit327ebe98, and --ci-report must be that unchanged Mac report.
Do not mix identities. Enforce valid READY target owner before invocation; unknown/
pending/malformed or removed/renamed-package refusal is a bounded blocker, no
automatic adoption/recovery. The guard may selectively clean owned release products
on a valid handoff; it cannot install an app. No concurrent raw Cargo/launcher job.
Use immutable isolated checkout. artifact-only.json is created before guard exit;
accept only overall exit0, final ownership.state=ready/source.commit327/source
digestbd380 plus actual executable hash. No helper/source changes.

After ready release ownership is bound to THIS source, run EQ's bounded maximum
profile serially under sole target/build ownership, not alongside another Cargo
job or release handoff:

    cargo test -p hex-audio --release --lib --features allocation-probe profile_project_spectrum_maximum --locked -- --ignored --nocapture

This exact ignored probe has fixed workloads0/32/128/256 tracks, seven trials
each (first two warmups),16 capture blocks/trial and bounded worker turns. Record
raw output/outliers, hardware/rate/buffer/workload and original report. It profiles
ProjectCapture/ProjectWorker, not driver/DSP/GPU deadlines. Current known payload
26319856 bytes; old historical profile26319848 predates the pending-return slot.
No test/profile failure or unavailable command is silently treated as passed.

Return source/tree/modes/digest, original/new report hashes and logs, per-case result,
native artifact hash/ready ownership, profile evidence and unchanged installed-app
audit. No app launch/quit, signing, keychain/TCC/profile/media changes are part of
this phase. Mark physical/listening cases pending until an actual approved build
is running. Read original UI/EQ finite requests included as supporting evidence.

## Later delivery/manual phase: separately coordinated

The supported command below BUILDS AND INSTALLS. It is NOT authorized merely by
this source/check handoff. Only after coordinator scheduling, fresh app-state
check, no competing launcher/build and user normal save/quit if running:

    sh scripts/bundle-macos.sh \
      --ci-report <evidence>/ui/pr335/full20/summary.json \
      --candidate 8e507b689d8dcaaca26dec5082319c5fff27949a \
      --included <evidence>/supporting/included-test-revisions.json \
      --checklist <evidence>/supporting/USER-TEST.md

Checkout stays pinned327; report candidate stays8e for supported identical-tree
reuse. Alternatively consume the actual same-source Mac full report with matching
--candidate327 after all its stages pass. Preserve stable org.portalsurfer.hex.dev,
artifacts/hex.app at the configured primary path, DeveloperID certificate
4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E/teamDKTKQ8U5T8, full seal/signature/receipt
and executable hashes. No forcequit, second review app, primary mode changes or
unsaved loss. Installed dfa must not be replaced/launched now. After a separately
authorized successful installation user may use ./launch --open; plain ./launch
fetches/builds later main and is a different candidate. Tests remain opt-in --test.

USER-TEST.md covers new rename/range/paste/border/save-reopen/EQ signals and finite
limits. Native acceptance, GPU/input/listening/deadlines and sample-access real WAV
preview across identical-executable normal --open relaunch remain separate. Merge,
source qualification and disk installation prove none of those human outcomes.
