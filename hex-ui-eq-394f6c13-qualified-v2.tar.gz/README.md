# V2 merged394 / checked98 handoff

Source qualification PASS; physical/native user acceptance and all optimized
artifact/profile/install/activation work remain PENDING/unauthorized here.

Chosen source394f6c130bb87fe5c8c49cfd82f4c52cb6049533 has the identical complete
tree/digest of original checked98b644301fa762f7ef3b6120e16f85469ae602c8 and valid
ancestry. It is not a fresh394 CI run. source-identity.json records actual
repository guard acceptance on original recovered cloud98 report plus1837-input
mode ledger. included-test-revisions.json preserves all44 canonical heads,
including393head98 (not mergeSHA);352/353/389 remain excluded.

qualification.json distinguishes original cloud evidence actually recovered and
hashed here from Mac20/20 PASS authenticated by coordinator/Pulse20935. The actual
Mac original report/logs remain at their stated Mac-local paths, are NOT in this
packet, and must pass local read-only original-SHA/guard verification before any
build. No report bytes or labels were changed. MAC-REQUEST.md gives that concrete
check and later coordinator-only artifact/profile/PhaseB commands with source394,
candidate98 and ACTUAL passed Mac98 report. No full20 rerun or source fix requested.

prepare-optimized-artifact.py is the exact unchanged2001byte native-reviewed
generic helper (SHA f94d8eab...), copied verbatim for convenience, not new code.
All original cloud98 report/log bytes are under cloud98/. The nested immutable
original-stack-final-evidence.tar.gz retains source-owner392/393 failures,
supplements/reports and scoped history; its old pending-native request is
historical. This V2 qualification and MAC-REQUEST govern the updated mapping.
Old pendingv1 ba53473a, prior3276c897a37, failedMac704ef84c and installeddfa remain
unaltered. No tests/builds/source/helper/guard/report edits or Mac/app actions.

Verify archive bytes/SHA before safe extraction into NEW temporary storage:
unique regular relative members, no links/absolute/.. paths; then verify every
file-manifest bytecount/SHA. Never checkout/build/merge the evidence-only ref.
