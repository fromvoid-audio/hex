# V2: qualified98 reports mapped to actual merged394

Chosen optimized build checkout/source:
394f6c130bb87fe5c8c49cfd82f4c52cb6049533.
Original report/CLI candidate stays:
98b644301fa762f7ef3b6120e16f85469ae602c8.
Both complete trees:c8e93e2c431f0ac21de8cbb6a3258fc34dd3ac72.
Physical digest:e105f71fcb486dfff1c172b19598c14c2032e61bdd64443ee123c9bc0d58cad6.

Source qualification is now PASS: original cloud98 full20 bytes/logs recovered and
verified, actual repository validate_ci accepted them on clean394. Exact98 native
full20 PASS is recorded by coordinator and Pulse2787note20935 (default stackUNSET,
jobs2,656s,exit0/full/stale=false/clean unchanged). The native original report is
STILL MAC-LOCAL; its bytes/logs are not in this cloud packet. Do not claim a new
394 CI run or rewrite any original98 report. No full20 rerun is requested.

## 1. Read-only native-original guard check before any build

Coordinator alone dispatches existing sole verifier
01a149f8-d4e8-7c91-82b9-5bdea69929a0. No cloud-triggered Mac job. The current
lane is reported idle; re-read source/app/process/build/target/READY-owner state.
Installed app remains reporteddfa21f5a/build3751944026, not this candidate. No
GUI/screenshot/unlock/quit/launch/install is requested now.

Preserve old98 checkout/report and primary work/modes. Create a NEW absent
task-owned isolated394 source under explicit checkout umask:

    git fetch origin 394f6c130bb87fe5c8c49cfd82f4c52cb6049533
    (umask 077; git worktree add --detach <NEW-ISOLATED394-SOURCE> 394f6c130bb87fe5c8c49cfd82f4c52cb6049533)

Compare all1837 source-inputs.json records and clean HEAD/tree. launch must be
0700/execute64, others execute0; canonical0755 would give DIFFERENT20d68dde...
digest. No chmod of an existing/primary checkout, report rewrite, guard changes
or normalization. Do not fetch moving main. Source98/394 helper/guard code is
identical; the unchanged generic helper2001bytes is included verbatim:
SHA256f94d8eab81d891b52cac3dedb7d0cd3a96b852ecf108fd34a9f8ba3169d2d98c.

From NEW clean394 source, verify ACTUAL native report SHA and call the existing
repository guard. This is read-only evidence validation, not a test/build:

```sh
python3 - <<'PY'
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='394f6c130bb87fe5c8c49cfd82f4c52cb6049533'
report=Path('/Users/portalsurfer/Documents/Codex/2026-10-17/yield-serial-mac-verification/work/hex-393-full/source/artifacts/local-ci/20261017T194705Z-93e5ce6a/summary.json')
assert hashlib.sha256(report.read_bytes()).hexdigest()=='55cae340d5b9548961eb769129ace85ca15f8778c6c0894e496b97e32d636bdd'
spec=importlib.util.spec_from_file_location('delivery_guard',root/'scripts/hex-test-build.py')
d=importlib.util.module_from_spec(spec); sys.modules[spec.name]=d; spec.loader.exec_module(d)
runner=d.ci.LocalCiRunner(root)
d.validate_ci(report,runner,'98b644301fa762f7ef3b6120e16f85469ae602c8')
assert runner.summary['start_tree']['commit']=='394f6c130bb87fe5c8c49cfd82f4c52cb6049533'
assert runner.summary['start_tree']['content_sha256']=='e105f71fcb486dfff1c172b19598c14c2032e61bdd64443ee123c9bc0d58cad6'
print(json.dumps({'native_original_guard_passed':True,'source':runner.summary['start_tree']},indent=2))
PY
```

Record real output/exit and original20native logs. If guard refuses source/head/
tree/report/modes, STOP and report the actual reason. Do not patch guard/report or
fall back to older327/335 reports. If a legitimate restriction only permits98,
coordinator may deliberately choose qualified98 and document that source; no
silent source swap. Actual different tree requires separate qualification.

## 2. Future single optimized artifact, then ignored profile

Only AFTER the native-original guard passes and coordinator explicitly schedules
this phase, with immutable source and valid READY release ownership/no competing
Cargo/launcher job, from clean394:

```sh
python3 <VERIFIED-V2-PACKET>/prepare-optimized-artifact.py \
  --source 394f6c130bb87fe5c8c49cfd82f4c52cb6049533 \
  --candidate 98b644301fa762f7ef3b6120e16f85469ae602c8 \
  --ci-report /Users/portalsurfer/Documents/Codex/2026-10-17/yield-serial-mac-verification/work/hex-393-full/source/artifacts/local-ci/20261017T194705Z-93e5ce6a/summary.json
```

This unchanged helper uses repository optimized_artifact(adopt=False), not build/
activate/recover/installer. Valid handoff may selectively clean owned release
products and write ready ownership. Unknown/pending/malformed/package-scope refusal
is a blocker, no auto-adopt/recovery. Accept only overall exit0, final ownerREADY,
ownership.source.commit394/digeste105 and actual copied executable hash. The
artifact-only.json/early--source check precedes final guard completion; it alone
is not success. Return command/log/ready-owner/executable hash and unchanged app
audit. No signing/install/app launch is part of artifact-only preparation.

Then SAME ready-owned source/serial slot, no concurrent Cargo/release handoff:

```sh
cargo test -p hex-audio --release --lib --features allocation-probe profile_project_spectrum_maximum --locked -- --ignored --nocapture
```

The ignored profile is STILL PENDING (full20 did not run it):0/32/128/256 selected
tracks,7trials each/2warmups/16captureblocks/bounded worker turns. Preserve raw
results/outliers/hardware/rate/buffer/workload. Accurate payload26419596B and
32MiB FACTORY-owned cap exclude caller UI copies and total process/UI memory.
This measures capture/worker, not physical CoreAudio/DSP/GPU deadlines. Preserve
failures and stop rather than changing source/stack/test workload.

## 3. Later stable signing/install: separate authorization

NO INSTALL/ACTIVATION IS AUTHORIZED BY THIS PACKET. User-away/screenshot-cancelled
state stands. Installeddfa app, signing identity, settings/media and READY owner
must remain untouched by metadata/read-only preparation. Only after fresh actual
app-state audit, no competing workload, explicit coordinator scheduling and user
normal save/quit if required, from chosen394:

```sh
sh scripts/bundle-macos.sh \
  --ci-report /Users/portalsurfer/Documents/Codex/2026-10-17/yield-serial-mac-verification/work/hex-393-full/source/artifacts/local-ci/20261017T194705Z-93e5ce6a/summary.json \
  --candidate 98b644301fa762f7ef3b6120e16f85469ae602c8 \
  --included <VERIFIED-V2-PACKET>/included-test-revisions.json \
  --checklist <VERIFIED-V2-PACKET>/USER-TEST.md
```

This BUILDS AND INSTALLS, not a dry run. Same valid source/report mapping lets
Cargo reuse the artifact through existing guards; no new receipt relabel. Retain
stable org.portalsurfer.hex.dev at /Users/portalsurfer/dev/hex/artifacts/hex.app,
configured certificate4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E/teamDKTKQ8U5T8,
full seal/signature/receipt and actual executable hashes. No forcequit, duplicate
app identity, source/primary chmod, keychain/TCC/profile/media changes or unsaved
loss. No app action is performed in this cloud task.

USER-TEST.md preserves rename/range/paste/borders/EQ349/normalfade/Warp/browser/
BPM/Shift/Undo/disposable-save checks; spinner2760/EQ2729 signoffs stand.392/393
stack cases are automated and passed, not new human gates. GUI/GPU/listening/
real WAV access and IDENTICAL-binary normal--open relaunch remain OPEN. Use
--open only after later authorized delivery; default ./launch fetch/builds newer
main without tests and is not identical-binary evidence; --test remains opt-in.
