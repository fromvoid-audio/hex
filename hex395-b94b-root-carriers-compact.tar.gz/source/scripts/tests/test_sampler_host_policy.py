"""Finite source-boundary sensitivity; no compiler/admission claim."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location(
    'sampler_host_policy', Path(__file__).resolve().parents[1] / 'sampler_host_policy.py')
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
violations = policy.violations


class SamplerHostPolicyTests(unittest.TestCase):
    def test_actual_file_owner_is_allowed(self):
        self.assertEqual(violations(
            'crates/hex-session/src/service/main_control_file.rs',
            "impl<'a> hex_engine::sampler_host_fields::FileSlotsFields<'a> for Reserved<'a> {}"), [])

    def test_foreign_module_in_same_crate_is_refused(self):
        self.assertTrue(violations('crates/hex-session/src/random.rs',
                                   'use hex_engine::sampler_host_fields as fields;'))

    def test_foreign_crate_and_aliased_import_are_refused(self):
        for text in ['use hex_engine::sampler_host_fields::{BodyRef as X};',
                     'let body = hex_engine::sampler_host_fields::BodyRef::of(&x);',
                     'impl FileSlotsFields for Wrong {}']:
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', text))

    def test_indirect_producer_accessor_callsite_is_checked(self):
        self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs',
                                   'let fields = staged.sampler_fields_on_control()?;'))

    def test_carrier_producers_are_exact_four_in_owning_module(self):
        path = 'crates/hex-audio/src/native_callback_owner/registered.rs'
        body = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, body), [])
        self.assertTrue(violations(path, body + '\nimpl CarrierPayload for Other {}'))
        self.assertTrue(violations(path, body.replace('impl CarrierPayload for ClientEndpoints', 'impl CarrierPayload for Other')))
        self.assertTrue(violations('crates/hex-audio/src/foreign.rs', 'impl CarrierPayload for Other {}'))

    def test_other_architecture_source_is_unchanged(self):
        self.assertEqual(violations('crates/hex-ui/src/arbitrary.rs',
                                    'use hex_engine::Frame;'), [])


if __name__ == '__main__':
    unittest.main()
