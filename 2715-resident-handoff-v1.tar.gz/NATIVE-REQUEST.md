# Checks-only request: Resident track-header volume

Source82adfad380cbf29eca9fa64c7ef68dd33c239fe5; treec21959e31bc8f57a82c5bd9a82834ef68148c187. PR331 remains OPEN/unmerged; dedicated merger owns actual integration/full CI/merge. No app packaging/replacement/launch/quit or OS/device permission action is requested. Root owns serial dispatch; this packet dispatches nothing.

Use the existing managed Mac verifier and legitimate isolated target/checkouts. Materialize this exact source under umask077: sourceguard hashes executable bits, and cloud launch is0700 while Git mode100755. Require all1884tracked bytes and execbits against source-inputs-final.json and actual guard aggregateb025ca69d4b41dc76f04acc966c354279535198cd00631d3cc87114c8632bc9e. Do not normalize primary modes or edit guards/reports. Evidence refs must NEVER be built. Use normal native stack/environment, not cloud16MiB flags.

Finite changed-component selectors (selectors must match these cardinalities; retain original stdout/stderr and exit status):

```sh
cargo test -p hex-session --test track_gain_gesture --locked -- --nocapture
# 7 tests: PCM/history/cancel/invalid/delete/automation/save/return/backlog and worker profile
cargo test -p hex-ui --features ui-test-support editor::track_gain::tests --locked
# 4 rendered input/geometry/mode/text tests
cargo test -p hex-ui --features ui-test-support header_volume_begin_obeys --locked
# 1 recording admission race
cargo test -p hex-widgets compact_slider_fits_header_slot --locked
# 1 compact widget geometry/capture/cancel/text regression
cargo test -p hex-audio --features allocation-probe --test track_gain_allocations --locked
cargo test -p hex-audio --release --features allocation-probe --test track_gain_allocations --locked
# 3 tests each: Arrangement analytic/mutable plus launched Session analytic+mutable
```

No full Mac/optimized app build is inferred. Callback probes use128-frame blocks and896rendered frames per case; zero total/net allocations and exact inherited-runtime PCM are bounded headless claims. Physical/native GPU/input/listening, long playback/dropouts and input-to-AUDIOAPPLIED latency/terminal/backlog remain open. The worker profile is24instruments/192authored notes/64accepted updates with1ms event polling; it measures worker roundtrip only.

When the user and coordinator schedule manual acceptance on a qualified optimized app, follow docs/track-header-volume.md: mixed audio/MIDI/Hydra/Operator, held0→positive/positive→0/unity/max, stable intendedtrack, post-fader return once, mute/balance, sustained-note/Session continuity, oneUndo/Redo and Escape/latest-canonical Cancel, dB textEnter/Escape, save/reopen, automation and record fences, narrow/wide+short/tall bounds/selection/resize/textfocus. VerifiedStreaming must retain working +/-; audible live slider there remains OPEN2792/PR398. No user acceptance is claimed.
