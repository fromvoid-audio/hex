# bounded review-return native request, root single lane only

source abd84dfb9ff40c48760ab4b2c7ed72cff3b4e5d0
tree c7f7e3b3c88f76d76a8d682551969b010f7308cd

cargo test -p hex-ui --features ui-test-support --locked editor::loop_selection_ui_test::loop_review_ -- --nocapture

Expect exactly 2 positive, 0 failed, 0 ignored. Capture actual filtered cardinality, exit, default native stack, raw stdout/stderr and SHA256. Checks only: no app build/install/launch/quit/unlock/UI. Session test uses real worker-created Session MIDI, canonical cell-selection entry point (not an actual mouse cell click), actual mode toolbar and actual cmd-l/plain-l; requires empty Arrangement selection no-op/no stale error, preserved project/selection. Controlled retained-editor-focus test begins real valid browser-audio/native-device payloads through the production begin methods, then actual cmd-l/plain-l, requires no queue/edit and payload preserved. Does NOT prove an ordinary browser-row click retains editor focus. Original 5a Command-L native2 is older behavior only and must finish unchanged; no unchanged broad suite/native full20 repeat. Physical keyboard/focus/drop/display/optimized combined app/save-reopen/listening remains OPEN/root-owned. Merger owns final actual candidate full20 and merge.
