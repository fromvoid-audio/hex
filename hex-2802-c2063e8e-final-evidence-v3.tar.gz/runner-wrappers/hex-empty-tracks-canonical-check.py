import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-empty-tracks');s=importlib.util.spec_from_file_location('empty_tracks_focused',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('empty-model',('cargo','test','-p','hex-project','--test','empty_track_creation','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('empty-worker',('cargo','test','-p','hex-session','--test','empty_track_creation','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('empty-storage',('cargo','test','-p','hex-storage','--test','empty_track_creation','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('track-keyboard',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','track_keyboard_ui_test::','--','--nocapture'),uses_cargo_target=True),
 m.Step('owning-clippy',('cargo','clippy','-p','hex-project','-p','hex-storage','-p','hex-session','--all-targets','--locked','--','-D','warnings'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
