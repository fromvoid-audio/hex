import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-empty-tracks');s=importlib.util.spec_from_file_location('empty_tracks_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
steps=(m.Step('project-existing',('cargo','test','-p','hex-project','--no-fail-fast','--locked','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
