import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-empty-tracks');s=importlib.util.spec_from_file_location('empty_four_return_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
names=['arrangement_bank_ignores_notes_outside_the_emitted_source_window','session_bank_ignores_notes_outside_the_emitted_source_window','compile_refuses_pitch_at_or_above_project_nyquist','absent_and_bypassed_instruments_keep_midi_extent_and_preview']
steps=tuple(m.Step('previous-failure-'+str(i+1),('cargo','test','-p','hex-engine','--test','midi_compile','--locked',name,'--','--exact','--nocapture'),uses_cargo_target=True) for i,name in enumerate(names))+(m.Step('engine-midi-compile',('cargo','test','-p','hex-engine','--test','midi_compile','--locked','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
