import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-empty-tracks');s=importlib.util.spec_from_file_location('empty_tracks_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
unused_steps=(m.Step('empty-track-model',('cargo','test','-p','hex-project','--test','empty_track_creation','--locked','--','--nocapture'),uses_cargo_target=True),m.Step('empty-track-worker',('cargo','test','-p','hex-session','--test','empty_track_creation','--locked','--','--nocapture'),uses_cargo_target=True))
steps=(unused_steps[1],)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
