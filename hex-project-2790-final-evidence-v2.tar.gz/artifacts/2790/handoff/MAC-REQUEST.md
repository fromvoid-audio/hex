# Pulse2790 / PR396 — finite changed-behavior portability checks

Current frozen CODE candidate756f7f25c92ed1dca84676e7bb9424497ab03509,
tree448f74556fcf5b348f6105a9cab920e544afda7f, digest
fa338ea28032a4f0e6cb6fa7c4caefefe6a7ee7ba65065a145d17253bb97a337.
This stacks unchanged Browser340/38a91b57 including Header345/7ffabbdd over
Command-D367 and BPM336. Original full cloud run20261018T134432Z-98ad279f is
terminalPASS20/20, exit0/full/cleanstart=end/stale=false; qualification.json
records its original receipt identity.
Prior2472, daf55 andab2 full20 reports retain their original identities; interrupted404
is historical partial evidence. Never relabel these reports as current-tree CI.

The following finite native checks ALREADY PASSED on earlier CODEdaf55e5c2ed0c3a2933172a872689d28462c2b83,
tree1f3cf49bf5af86b96eeca271bbc1d10162315bf0, digest01879992040c646eed17db5fd6994940d9b0249ba8d047f4d81c2f8f5a185632.
Coordinator independently read/hash-checked the native report (Pulse2790/23555).
Native report SHA2561705acf60d181ceedbb28e81fb0af273823979bf923cc85d5a20e247bcecb064;
manifest SHA2561ad83957d61d0766fce354e6c5be8a8d41bde0194faa7b6cfd5c4313ca4f2542.
Original native report/log bytes remain Mac-local; cloud packet contains the reported
Pulse provenance only, not a claim to have downloaded those bytes. Two commands exited0,
4Project+1Session passed, zero failed/ignored/filtered. All four focused code/test/docs
files are byte-identical through the later integrations. Do not repeat unchanged
native selectors or call this current combined-tree full native qualification.
The immutable earlier request archive remains atcd44b83d97174a780a58a9a829d1517648a27e61.
Never build evidence refs. Dedicated integration/merge chat now owns final tree
qualification and merge; implementation chat will not chase main or self-merge.

No additional Mac execution is a source merge gate for this portable model fix.
Completed native selector record (do not dispatch another run solely for this handoff):

    cargo test -p hex-project --test prepared_batch_routing --locked
    cargo test -p hex-session --test prepared_batch_routing --locked

Expected:4 public Project cases and1 Session test covering both invalid batches,
no private-field construction. Audio case starts with ReturnR1→R2 and typed
R2→trackT, then batches sendT→R1. MIDI case removes a destination instrument with
its incoming route retained. Both reject before invoking the caller's prepare
callback, preserve speculative IDs and both history stacks. Valid-final audio
and MIDI batches may pass through transient invalid states, prepare once and
retain one-step Undo/Redo; a no-op retains redo. Existing command-local checks
and single-transition refusals remain intact.

The Session fixture compiles an initial valid nonsilent MIDI graph through actual
Session/Engine preparation, retains its prepared Arc and compares the next64PCM
frames against uninterrupted128-frame output after both refusals. It does not
establish physical audio-device/GPU/deadline/listening acceptance. It does not
implement or substitute for cloud4's private Engine borrowed validator/Sampler
resource/compiler/custody work. No Sampler installation is included.

Save actual command/exit/source/tree/dirty-state/target identity and test counts.
Stop and relay a real failure; no source/report/guard edits or repeated broad
unchanged suites. No GUI, user save/quit, app build/package/install/launch/restart,
TCC/keychain/profile/media/database/security changes are requested. User away;
installed7fe4f48f95a23123981f41bdc4fa934f3d3d091b remains untouched.

This change adds no routing-batch UI. Do not invent a manual gesture to reproduce
an unexposed API. For the later coordinator-owned optimized cohort delivery,
existing ordinary playback/routing/import/one-stepUndoRedo listening acceptance
remains separate; no new broad native/user approval gate is created here.
