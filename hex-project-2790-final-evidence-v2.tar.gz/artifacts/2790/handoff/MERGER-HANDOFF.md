# Project2790 / canonical PR396 — integration handoff

Implementation owner remains this chat. Final integration/prospective-tree CI and
GitHub merge owner is cloud3, chat01a149d1-3232-76d1-b08a-05f3ca89906d,
per explicit root direction18October2026. No merge was in flight at that change.
No additional implementation assignment is included in this packet. Source checks complete; PR is marked ready for review, still unmerged. PORTALSURFER requested review; no external approval fabricated.

Canonical PR: https://github.com/PORTALSURFER/hex/pull/396
Canonical branch: pulse/task-2790-g1-330583183172
Frozen published source:756f7f25c92ed1dca84676e7bb9424497ab03509
Tree:448f74556fcf5b348f6105a9cab920e544afda7f
Materialized sourceguard:fa338ea28032a4f0e6cb6fa7c4caefefe6a7ee7ba65065a145d17253bb97a337
Source input manifest:1876 files, new umask077 checkout; launch0700/execute-mask64,
others execute-mask0. Never chmod the primary checkout to match a report.

This candidate temporarily stacks Browser340 published38a91b57713259b72fd303d7b761ae49c1859803,
which includes actual merged Header345/7ffabbdd0023e167af314253225740e9cfd125d3
and reviewedc027c018. Command-D367/150776 and BPM336/5bd4220d are ancestral.
All dependency non-todo files remain byte-identical to Browser38. Relative to38,
our complete change is five files/377 additions. Own production fix is one call
in hex-project/history.rs to the existing playable-route validator after all batch
commands and asset validation, before history reservation/prepare/publication.
Single-transition behavior and command-local admission stay unchanged. No new
private Engine validator, Sampler/compiler/resource/custody/schema/migration edits.
Do not merge Browser's source through396 before its canonical PR is integrated.
Merger verifies actual prerequisites/current prospective tree against qualified tree;
any new tree/semantic conflict needs actual qualification, never receipt relabel.

Both public counterexamples genuinely failed before repair. New public model4
cover audio combined-cycle refusal, removed MIDI destination instrument refusal,
valid-final transient audio/no-op redo and valid-final transient MIDI. Refusals
preserve Project/allocator IDs/both history stacks and call preparation zero times.
New Session1 covers both refusals using real compilation/prepared Arc retention and
continuing nonsilent PCM versus an uninterrupted128-frame oracle. Full targeted
Project suite259, existing Session Return6 and strict Project/Session Clippy passed.
Original failing/partial evidence is retained. Four tracked production/test/docs
files are identical acrossdaf55→ab2→756; todo also preserves dependency entries.

The current full run is20261018T134432Z-98ad279f. It terminally PASSED all20, exit0/full/cleanstart=end/stale=false;
qualification.json and its original summary/logs provide the exact receipt.
Earlier full runs2472/daf55/ab2 passed20/20 on their original identities.404 run
was deliberately interrupted before changing source after publication identity
recovery; it is NOT a pass. historical-runs.json retains individual identities.
No hosted CI, stale/partial reports or fabricated approvals qualify merging.

PORTALSURFER is assigned and individually requested for review. Final own diff
self-review found no unresolved correctness issue; GitHub submitted reviews were
empty when inspected. Do not describe this as independent approval. Source owner
will repair actual findings returned by merger. No new native gate is invented.

Native changed-model5 already PASSED on EARLIERdaf55e5c only (Pulse2790note23555),
not current combined-source full native CI. Coordinator independently read/hash
checked native report1705acf60d181ceedbb28e81fb0af273823979bf923cc85d5a20e247bcecb064.
Its raw report/logs remain Mac-local. Cloud packet includes reported note evidence
and hashes only. Exact commands: cargo test -p hex-project --test prepared_batch_routing --locked
(4passed) and cargo test -p hex-session --test prepared_batch_routing --locked
(1passed); zero failed/ignored/filtered. Do not repeat unchanged selectors solely
for handoff or claim physical/audio-device/UI/listening/real-time acceptance.
No app packaging/install/launch/quit/TCC/keychain/profile/media/database action.
Installed7fe remains unchanged; no Sampler installed. Root owns sole Mac queue
and future optimized build/delivery. Native physical acceptance remains separate.

Evidence refs contain archive/metadata only and must never be built or merged.
Original code candidate and original CI source identity remain explicit even if
merger later produces an identical-tree merge commit.
