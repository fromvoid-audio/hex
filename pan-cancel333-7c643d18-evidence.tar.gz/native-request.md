# finite changed cancellation checks: root sole Mac lane only
Source 7c643d18204d60d6e2acdbbe07a5ad6864ffbcec
Tree 871aba2380486674e8802f1722acc8fd7f06b27c
Checks only, default stack, no app/GUI/unlock/backend/user-file operations.
cargo test -p hex-ui --features ui-test-support --locked does_not_resurrect_hidden_pan_after_project_growth -- --nocapture
Expect exactly TWO positive tests, zero ignored/failures. Both tests exercise audio AND MIDI: real rendered edge capture + controlled edgepan, actual Escape or actual independent Gain worker revision, release canceled payload, actual unrelated far MIDI insertion grows project; viewport stays canonically clamped and original metadata remains intact. Record raw cargo output, count/exit/default-stack/source/tree/dirty/sha. Existing private bounded fixture starts disposable sample/browser/recent/theme paths before worker startup and retains RAII guard.
Do not repeat unchanged original333 native5 or403 native6. This new source has NO native qualification yet. Physical both-edge resize/cancel/later-growth/zoom waveform acceptance remains root-owned and OPEN. Merger owns actual combined tree full20/review/integration/merge. No self dispatch.
