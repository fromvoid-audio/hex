from pathlib import Path
import json,re,subprocess,hashlib
r=Path('/workspace/hex-integration-clip-local-resize');run=r/'artifacts/local-ci/462-8f92567b-guarded-focused';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']=='8f92567b6c18f6b97d9cff1ddde9a5005377e492' and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and not s['dirty'] and s['start_tree']==s['end_tree']
assert len(s['steps'])==2 and all(t['status']=='passed' and t['exit_code']==0 for t in s['steps']) and not Path('/proc/1474772').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
counts=[]
for t,expected in zip(s['steps'],[22,2]):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(r/t['log']).read_text(errors='replace'));assert rows==[(str(expected),'0','0')],rows;counts.append(expected)
p={'head':s['commit'],'source':s['source_identity']['content_sha256'],'all2passed':True,'counts':counts,'unique_tests':sum(counts),'ignored':0,'duration_seconds':s['duration_seconds'],'summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest()};assert p['source']=='2811d070b935410cead7a85a7badc1532a48f407b052d1f728d12d81f6a3e475'
(r/'artifacts/integration/462-8f92567b-focused-gate.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2))
