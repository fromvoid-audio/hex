import pathlib,importlib.util,sys
root=pathlib.Path.cwd();spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=tuple(m.Step(label,argv) for label,argv in [('all current resize release and lane paint controls', ('cargo', 'test', '-p', 'hex-ui', '--features', 'ui-test-support', '--locked', '--lib', 'resize_release_tests::', '--', '--nocapture')), ('original completed clip-border controls', ('cargo', 'test', '-p', 'hex-ui', '--features', 'ui-test-support', '--locked', '--lib', 'clip_border_ui_test::', '--', '--nocapture'))])
r=m.LocalCiRunner(root,mode='component',run_id=sys.argv[1],adopt_target=True,min_free_bytes=2*1024**3,steps=steps);sys.exit(r.run())
