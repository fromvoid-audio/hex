# PR450 finite root-owned native request
Exact sourcef49c9a5450257b4dd0d3b7427080ceaebb884790/treea0a949a9256840e8b3ae37df4e8a531a7f6f849e.

    cargo test -p hex-ui --features ui-test-support --lib editor::waveform::waveform_header_ui_test:: -- --nocapture

Expect EXACT3uniquePASS0ignored: actual ordinary/selected/looped painter plus
cropped viewport;8normal/Shift×both-edge×loop-state preview/realworker/oneUndo
conditions; header-only/tiny-body canvas geometry/masks at4heights. The two
EditorView cases retain RAII unique browser/sample/recent/theme paths before
workers and use actual offline Service import/peaks; tiny canvas-only case uses
explicit deterministic bipolar peaks and no filesystem/browser worker.
Default native stack/private target. No app/OS audio/physical input/permissions.
This is targeted component proof only, not full21 or final prospective/native GPU
qualification. Root schedules; no native job is dispatched by this packet.

User-present optimized observations OPEN: titles readable and waveform strictly
below them during both-edge normal/Shift/fade/loop interactions, selection all4
edges and future rounded bottoms preserved, clipped viewport/zoom, tiny/header-only
row after431 integration, header grabs/rename/focus, worker release and Undo.
Source450 does not import pending432color/445rounded-loop UI or deliver an app.
