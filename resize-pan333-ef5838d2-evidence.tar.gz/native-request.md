# bounded native request — coordinator's single lane only

Exact source ef5838d252240be1cad642aecbdcb3d95de517f6
Exact tree 98991a37d6eb5ddc40d0f77039cc02a7a518a8da

Checks-only/locked desktop; no app delivery/install/launch/quit/unlock/GUI:

cargo test -p hex-ui --features ui-test-support --locked editor::drag_autoscroll::resize_pan_tests:: -- --nocapture

Expect EXACTLY5 positive /0fail/0ignored; record actual filtered count(defaultcloud730), cargoexit, default native stack and raw report. Actual Service worker/history+GPUI windows+rendered mouse events+controlled stationary tick times. Cases cover zoomed audio/MIDI left/right, stop on leaving edge, one UndoRedo; fitted right beyond original display horizon; Escape/stale generation plus pointer reentry and no later tick/drop edit; zero-left/exhausted source bounds; Command stationary snap inversion and Shift stretch preview/release agreement. Original fitted fail and old zoomed pass are separate evidence, not a claim all edgepan was missing. Canonical model limits still apply.

Only if a concrete cancellation integration concern: cargo test -p hex-ui --features ui-test-support --locked editor::clip_drag_ui_test::shift_edge_stretch -- --nocapture (exact2). Those2 and trimunit6 already pass cloud; no unchanged fullnative suites/FULL20 repeat requested.

Root-owned optimized PHYSICAL checklist in docs/resize-edge-pan.md: verify candidate provenance, both edge bands/held pointer beyond old fitted view, leftzero, source/minimum limits, return inside or outside zone, release/Escape/focus loss, no timer continuation, actual pointer capture/geometry/waveform, Command/Shift and oneUndoRedo/source windows. Lower fade controls/other gestures unchanged. CLI does not prove physical keyboard/mouse/display/GPU/audio/listening, optimized app or delivery. Installed7fe unchanged. Merger owns final actual prospective-tree required FULL20/review/integration/merge; source1 gain/source5 grid/L patches are independent and absent unless already in pinned intake mainff00. Never checkout/build/merge evidence refs.
