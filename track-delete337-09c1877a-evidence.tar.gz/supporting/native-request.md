# pulse2721 / pr337 — bounded native request

Source integration candidate 09c1877a82b8c47ce0502078c049ff6f6060e6a8
Tree 87ca600d1e0216c0c7bfe9bb700ab3a66d3d7f18
Earlier frozen b73c0ed981879799c86389fcafed37cc98b51688 is retained separately; current integration includes Tempo336 main5bd4220d plus published header345 c027c018, browser340 686888c9 and routing396 ab2e042c.
Cloud exact09c full20 PASSED723.060s, clean unchanged/stale=false. Original summary20261018T133307Z-5a84aaf7 SHA256904e6ddebce33786441cbeee2eea9992d6bb5a3ae37d89ab9f792cbc28782065. This evidence-only archive retains both original b73 and integrated09c receipts. Merger cloud3 owns final integration/prospective CI/GitHub merge; native acceptance remains coordinator-owned.

Coordinator's single Mac lane only; no app launch/quit/install/unlock needed for CLI.
Use isolated checks-only source at this exact candidate or a verified identical tree,
ordinary supported native toolchain/default stack (do not introduce stack overrides):

    cargo test -p hex-project --locked --lib remove_tracks_ -- --nocapture
    cargo test -p hex-ui --features ui-test-support --locked header_backspace_ -- --nocapture

Expect exact 2 selected/2 pass/0 failed/0 ignored for each command:
- edit::track_remove_tests::remove_tracks_preserves_survivors_cleans_references_and_undo_restores_everything
- edit::track_remove_tests::remove_tracks_invalid_selection_is_atomic_and_preserves_redo
- editor::track_name::delete_tests::header_backspace_removes_selected_tracks_and_restores_contents_in_one_undo
- editor::track_name::delete_tests::header_backspace_respects_clip_rename_browser_and_empty_selection

Capture actual HEAD/tree, toolchain, exact commands, exit codes/cardinalities and raw logs. GPUI tests create disposable test windows/events; they are simulated input tests, not physical GUI acceptance or the installed optimized app. No repeat unchanged full native20 requested.

Deferred user-present optimized input checklist (coordinator delivery owns source qualification/install):
1. Disposable project with audio/MIDI clips, device chain and Session cells/routes. Select one ordinary track header, Backspace; exactly that track disappears. One Undo restores contents/devices/routes; Redo removes it.
2. Cmd/Shift-select several headers, Backspace; precisely explicit selection removed in one Undo. Unselected tracks and Main/Returns preserved; no orphan highlights/focus. Undo restores tracks without silently selecting them.
3. Cmd-toggle the focused header out of selection, Backspace: no deletion. With no object/track focus or Main/Return selected: no regular track deletion.
4. Click clip header then Backspace: existing clip delete; MIDI note/Session delete retain ownership. Browser, track/clip rename and numeric fields: Backspace edits text, never removes tracks; Escape cancels draft. Track-header Cmd-R still renames.
5. While clip-edge/fade or track-height/width drag is active, Backspace does not delete a track; cancel/release safely, then normal header deletion works.
6. Save/reopen the disposable project after delete/Undo; no invalid references or missing restored content. Preserve user files and installed-app state until separately authorized.

No listening, physical callback/GPU deadline or broad Live-parity claim follows from these checks.
