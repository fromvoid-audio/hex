"""Finite source-boundary sensitivity; no compiler/admission claim."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location(
    'sampler_host_policy', Path(__file__).resolve().parents[1] / 'sampler_host_policy.py')
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
violations = policy.violations


class SamplerHostPolicyTests(unittest.TestCase):
    def test_float_box_schema_has_exact_analyzer_producers_without_other_host_authority(self):
        for path in ['crates/hex-audio/src/spectrum.rs', 'crates/hex-audio/src/spectrum_worker/native.rs']:
            source = (Path(__file__).resolve().parents[2] / path).read_text()
            self.assertEqual(violations(path, source), [])
            for other in ['NativeFields', 'FamilyFields', 'SharedMetadataRef', 'OriginalSamplerNativeHost']:
                self.assertTrue(violations(path, source + '\nuse hex_engine::sampler_host_fields::{' + other + ', NativeSpectrumCoreFields};'))
        path = 'crates/hex-audio/src/spectrum_worker/native.rs'
        actual = (Path(__file__).resolve().parents[2] / path).read_text()
        for expression in ['SharedMetadataRef::of(&arbitrary)',
                           'SharedMetadataRef::constructor_bytes::<Foreign>()',
                           'hex_engine::sampler_host_fields::SharedMetadataRef::constructor_bytes::<AtomicBool>()']:
            self.assertTrue(violations(path, actual + '\n' + expression))
        for path in ['crates/hex-ui/src/foreign.rs', 'crates/hex-audio/src/prepared.rs', 'crates/hex-engine/src/foreign.rs']:
            self.assertTrue(violations(path, 'SpectrumFloatBoxRef'))

    def test_captured_spectrum_authority_is_exact_and_join_and_drop_order_is_mandatory(self):
        root = Path(__file__).resolve().parents[2]
        worker_path = 'crates/hex-audio/src/spectrum_worker.rs'
        worker = (root / worker_path).read_text()
        self.assertEqual(violations(worker_path, worker), [])
        for original, changed in [
                ('drop(payload)', 'drop(None::<()>)'),
                ('ReaperPhase::Complete || self.join.is_some()', 'ReaperPhase::Ready || self.join.is_some()'),
                ('drop(self.captured_join.take())', 'drop(None::<()>)'),
                ('match join.join()', 'match Ok::<(), Box<dyn std::any::Any + Send>>(())')]:
            self.assertTrue(violations(worker_path, worker.replace(original, changed)))
        self.assertTrue(violations(worker_path, worker.replace('captured.record_capture_failure();', 'captured.payload.as_ref().expect("new runtime panic");')))
        self.assertTrue(violations(worker_path, worker.replace('drop(payload);', 'drop(payload); self.lease.as_ref().expect("destructor panic");')))
        path = 'crates/hex-audio/src/lifecycle.rs'
        actual = (root / path).read_text()
        self.assertEqual(violations(path, actual), [])
        self.assertTrue(violations(path, actual.replace('.finalize_captured_frame_on_control(native)', '.omitted(native)')))
        for path in ['crates/hex-audio/src/random.rs', 'crates/hex-session/src/resource_plan/original_sampler.rs',
                     'crates/hex-engine/src/sampler_host_fields/foreign.rs']:
            for name in ['NativeSpectrumJoinLease', 'pair_actual_capture_on_control', 'finalize_actual_join_on_control', 'spawn_worker_with_parent']:
                self.assertTrue(violations(path, name))
        self.assertTrue(violations('crates/hex-audio/src/spectrum_worker/native.rs', 'finalize_actual_join_on_control'))
        self.assertTrue(violations('crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs', 'x.finish_spectrum_capture_on_control()'))

    def test_spectrum_endpoint_fields_are_checked_before_carrier_bodies(self):
        root = Path(__file__).resolve().parents[2]
        for path, required in [
            ('crates/hex-audio/src/prepared.rs', 'root.matches_spectrum_capture(self.spectrum_capture.as_ref())'),
            ('crates/hex-audio/src/prepared/endpoints.rs', 'root.matches_spectrum_reader(self.spectrum_reader.as_ref())')]:
            source = (root / path).read_text()
            self.assertEqual(violations(path, source), [])
            self.assertTrue(violations(path, source.replace(required, 'true')))
        self.assertTrue(violations('crates/hex-audio/src/spectrum_worker/native.rs', 'pair_actual_fresh_ring_on_control'))

    def test_native_selected_operations_have_one_actual_private_facade(self):
        path = 'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source + '\nimpl OriginalSamplerNativeHost for Foreign {}'))
        for other in ['crates/hex-session/src/resource_plan/original_sampler.rs',
                      'crates/hex-audio/src/prepared.rs',
                      'crates/hex-engine/src/foreign.rs']:
            self.assertTrue(violations(other, 'OriginalSamplerNativeHost'))
        self.assertTrue(violations('crates/hex-engine/src/sampler_host_fields/original_driver.rs',
                                   'impl OriginalSamplerNativeHost for Foreign {}'))

    def test_private_constructor_stages_never_become_external_approvals(self):
        for name in ['inspect_original_sampler_revision_with_writers_on_control',
                     'construct_original_sampler_revision_with_writers_on_control']:
            for path in ['crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
                         'crates/hex-session/src/resource_plan/original_sampler.rs',
                         'crates/hex-engine/src/foreign.rs']:
                self.assertTrue(violations(path, name))
            self.assertEqual(violations('crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs', name), [])

    def test_candidate_constructor_stages_remain_engine_internal(self):
        for name in ['OriginalSamplerConstruction',
                     'inspect_original_sampler_with_writers_on_control',
                     'construct_original_sampler_with_writers_on_control',
                     'original_sampler_compiler_reservation',
                     'finish_original_sampler_runtime_on_control']:
            self.assertEqual(violations(
                'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs', name), [])
            for path in ['crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
                         'crates/hex-session/src/resource_plan/original_sampler.rs',
                         'crates/hex-engine/src/foreign.rs']:
                self.assertTrue(violations(path, name))

    def test_constructor_seal_inspection_stays_inside_existing_engine_custody(self):
        for name in ['OriginalSamplerSealInspection',
                     'inspect_sampler_constructor_with_inventory_on_control',
                     'install_sampler_constructor_inspection_on_control']:
            self.assertEqual(violations('crates/hex-engine/src/audio_candidate/storage.rs', name), [])
            for path in ['crates/hex-engine/src/foreign.rs',
                         'crates/hex-session/src/resource_plan/original_sampler.rs',
                         'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs']:
                self.assertTrue(violations(path, name))

    def test_original_sampler_writers_have_exact_producer_and_consumer_modules(self):
        for name in ['OriginalSamplerTransaction', 'OriginalSamplerSessionLoan',
                     'original_sampler_session_loan_on_control',
                     'original_sampler_transaction_on_control',
                     'original_sampler_writer_on_control']:
            self.assertTrue(violations('crates/hex-session/src/arbitrary.rs', name))
            self.assertTrue(violations('crates/hex-audio/src/prepared.rs', name))
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', name))
        path = 'crates/hex-session/src/resource_plan/original_sampler.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source + '\nfn extra() { context.original_sampler_transaction_on_control(); }'))
        self.assertTrue(violations(path, source + '\nimpl OriginalSamplerTransaction {}'))

    def test_original_sampler_resident_fields_have_one_actual_session_producer(self):
        for path in ['crates/hex-ui/src/random.rs', 'crates/hex-session/src/random.rs',
                     'crates/hex-audio/src/prepared.rs']:
            self.assertTrue(violations(path, 'OriginalSamplerResidentFields'))
        path = 'crates/hex-session/src/resource_plan/original_sampler.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source + '\nimpl OriginalSamplerResidentFields for Foreign {}'))
        self.assertTrue(violations('crates/hex-engine/src/sampler_host_fields/resident.rs',
                                   'impl OriginalSamplerResidentFields for Foreign {}'))

    def test_closed_original_constructor_readers_do_not_enable_other_engine_modules(self):
        for path in [
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs',
            'crates/hex-engine/src/audio_candidate/preparation_operations.rs',
            'crates/hex-engine/src/audio_candidate/storage.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs',
        ]:
            self.assertEqual(violations(path, 'hex_engine::sampler_host_fields::OriginalSamplerResidentFields'), [])
            self.assertTrue(violations(path, 'impl OriginalSamplerResidentFields for Foreign {}'))
        self.assertTrue(violations('crates/hex-engine/src/foreign.rs', 'hex_engine::sampler_host_fields::OriginalSamplerResidentFields'))

    def test_event_metadata_projection_has_one_owning_session_adapter(self):
        for name in ['EventMetadataFields', 'EventReasonFields', 'EventBatchFailureFields',
                     'TuningLibraryMetadataPayload', 'TuningSlotMetadataFields',
                     'event_metadata_fields_on_control']:
            for path in ['crates/hex-ui/src/arbitrary.rs',
                         'crates/hex-session/src/snapshot_exports/storage.rs',
                         'crates/hex-audio/src/prepared.rs']:
                self.assertTrue(violations(path, name))
            self.assertEqual(violations('crates/hex-session/src/service/event_fields.rs', name), [])

    def test_actual_file_owner_is_allowed(self):
        self.assertEqual(violations(
            'crates/hex-session/src/service/main_control_file.rs',
            "impl<'a> hex_engine::sampler_host_fields::FileSlotsFields<'a> for Reserved<'a> {}"), [])

    def test_foreign_module_in_same_crate_is_refused(self):
        self.assertTrue(violations('crates/hex-session/src/random.rs',
                                   'use hex_engine::sampler_host_fields as fields;'))

    def test_foreign_crate_and_aliased_import_are_refused(self):
        for text in ['use hex_engine::sampler_host_fields::{BodyRef as X};',
                     'let body = hex_engine::sampler_host_fields::BodyRef::of(&x);',
                     'impl FileSlotsFields for Wrong {}']:
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', text))

    def test_indirect_producer_accessor_callsite_is_checked(self):
        self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs',
                                   'let fields = staged.sampler_fields_on_control()?;'))

    def test_export_result_children_require_exact_audited_producer(self):
        for name in ['FamilyExportResultFields', 'ExportResultPayloadFields',
                     'ExportResultOutcomeFields',
                     'borrow_sampler_export_result_fields_on_control']:
            self.assertTrue(violations('crates/hex-session/src/arbitrary.rs', name))
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', name))
            self.assertEqual(violations(
                'crates/hex-session/src/snapshot_exports/native_export_results.rs', name), [])

    def test_journal_storage_borrow_requires_audited_actual_owner(self):
        for name in ['JournalFields', 'journal_storage_fields_on_control']:
            self.assertTrue(violations('crates/hex-storage/src/arbitrary.rs', name))
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', name))
        self.assertEqual(violations('crates/hex-storage/src/journal.rs',
                                    'journal_storage_fields_on_control'), [])

    def test_file_token_observation_and_document_bridge_are_exact_audited_sources(self):
        for name in ['FileTokenStorageObservation', 'file_token_storage_on_control',
                     'borrowed_file_token_arc_field_on_control', 'DocumentTokenFields',
                     'borrow_sampler_document_fields_on_control']:
            self.assertTrue(violations('crates/hex-storage/src/arbitrary.rs', name))
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', name))
        root = Path(__file__).resolve().parents[2]
        for path in ['crates/hex-storage/src/files.rs', 'crates/hex-storage/src/replacement.rs']:
            source = (root / path).read_text()
            self.assertEqual(violations(path, source), [])
            self.assertTrue(violations(path, source + '\nfn bad() { FileToken(arbitrary); }'))
        self.assertTrue(violations('crates/hex-session/src/arbitrary.rs', 'FileToken(arbitrary)'))
        self.assertTrue(violations('crates/hex-audio/src/prepared.rs',
                                   'token.file_token_storage_on_control()'))
        path = 'crates/hex-session/src/service/worker_roots.rs'
        source = (root / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace(
            'let observation = token.file_token_storage_on_control();',
            'let observation = foreign.file_token_storage_on_control();', 1)))

    def test_carrier_producers_are_exact_four_in_owning_module(self):
        path = 'crates/hex-audio/src/native_callback_owner/registered.rs'
        body = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, body), [])
        self.assertTrue(violations(path, body + '\nimpl CarrierPayload for Other {}'))
        self.assertTrue(violations(path, body.replace('impl CarrierPayload for ClientEndpoints', 'impl CarrierPayload for Other')))
        self.assertTrue(violations('crates/hex-audio/src/foreign.rs', 'impl CarrierPayload for Other {}'))

    def test_root_field_producers_require_audited_owning_module(self):
        for name in ['NativeRootFieldRegistration', 'NativeRootFieldLease',
                     'borrow_sampler_native_root_fields_on_control']:
            self.assertTrue(violations('crates/hex-audio/src/foreign.rs', name))
            self.assertEqual(violations('crates/hex-audio/src/candidate_custody/root_fields.rs', name), [])

    def test_actual_both_input_check_precedes_all_carrier_births(self):
        path = 'crates/hex-audio/src/native_callback_owner.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace('!callback.matches_constructor_channel_fields_on_control(&root)', 'false')))
        self.assertTrue(violations(path, source.replace('!control.matches_constructor_channel_fields_on_control(&root)', 'false')))

    def test_worker_resident_and_native_status_roles_are_required(self):
        path = 'crates/hex-audio/src/native_callback_owner/registered.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace('self.matches_constructor_worker_fields_on_control(root)', 'true')))
        self.assertTrue(violations(path, source.replace('status_owner::NATIVE_ERROR', 'status_owner::NATIVE_DATA')))

    def test_other_architecture_source_is_unchanged(self):
        self.assertEqual(violations('crates/hex-ui/src/arbitrary.rs',
                                    'use hex_engine::Frame;'), [])

    def test_spectrum_static_quotes_do_not_authorize_borrowed_producers(self):
        path = 'crates/hex-audio/src/spectrum_worker/native.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source + '\nimpl NativeFields for Arbitrary {}'))
        self.assertTrue(violations(path, source + '\nSharedMetadataRef::of(&arbitrary)'))
        self.assertTrue(violations('crates/hex-ui/src/random.rs',
                                   'SharedMetadataRef::constructor_bytes::<T>()'))

    def test_final_native_completion_stays_after_actual_parent_join(self):
        path = 'crates/hex-audio/src/lifecycle.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace('advance_shutdown_on_control()', 'request_stop()')))
        self.assertTrue(violations(path, source.replace('preflight_native_worker_birth(', 'omitted_preflight(')))
        self.assertTrue(violations(path, source + '\nfn bypass() { x.finish_root_after_native_fields_on_control(); }'))
        self.assertTrue(violations('crates/hex-audio/src/random.rs',
                                   'x.finish_root_after_native_fields_on_control()'))


if __name__ == '__main__':
    unittest.main()
