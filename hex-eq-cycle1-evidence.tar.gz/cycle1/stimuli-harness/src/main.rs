use hex_devices::eq::{self, EqState, Node, NodeId, NodeKind};
use hex_lattice::{NativeDeviceDefinition, NativeProcessorRuntime};
use std::f64::consts::TAU;
fn metrics(frames: &[[f32;2]]) -> (f64,f64,f64) {
    let peak=frames.iter().flatten().map(|x| f64::from(x.abs())).fold(0.0,f64::max);
    let rms=(frames.iter().flatten().map(|x| f64::from(*x).powi(2)).sum::<f64>()/(frames.len()*2) as f64).sqrt();
    let step=frames.windows(2).flat_map(|w| (0..2).map(move |c| f64::from((w[1][c]-w[0][c]).abs()))).fold(0.0,f64::max);
    (peak,rms,step)
}
fn main() {
    println!("stimulus,filter,frames,peak,rms,max_sample_step,partition_max_difference,antiphase_max_sum");
    for (label,kind,freq,gain) in [("bell",NodeKind::Bell,1000.0,12.0),("notch",NodeKind::Notch,1000.0,0.0),("lowcut",NodeKind::LowCut,80.0,0.0),("highshelf",NodeKind::HighShelf,5000.0,-12.0)] {
        let mut state=EqState::default();let mut node=Node::new(NodeId::new(1).unwrap(),freq,gain,0).unwrap();node.kind=kind;node.q=0.70710677;node.slope=1;state.add(node).unwrap();
        let encoded=state.encode().unwrap();
        let prepared=eq::EQ_DEFINITION.prepare_processor(&encoded,&hex_lattice::DevicePreparationContext{sample_rate:48000,tuning:&hex_lattice::TuningTable::default(),resources:&hex_lattice::EMPTY_DEVICE_RESOURCES}).unwrap().unwrap();
        for stimulus in ["bass55hz","bin_tone937_5hz","nonbin1000hz","sweep20to18000hz","seeded_noise","drum_transient"] {
            let mut seed=0x12345678_u32;let mut phase=0.0_f64;
            let input:Vec<_>=(0..65536).map(|i| {
                let t=i as f64/48000.0;
                let x=match stimulus {
                    "bass55hz"=>0.1*(TAU*55.0*t).sin(),
                    "bin_tone937_5hz"=>0.1*(TAU*937.5*t).sin(),
                    "nonbin1000hz"=>0.1*(TAU*1000.0*t).sin(),
                    "sweep20to18000hz"=>{let hz=20.0*900.0_f64.powf(i as f64/65535.0);phase+=TAU*hz/48000.0;0.1*phase.sin()},
                    "seeded_noise"=>{seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;0.1*(2.0*f64::from(seed)/f64::from(u32::MAX)-1.0)},
                    _=>0.2*(-t*35.0).exp()*(TAU*(65.0*t+90.0*t*t)).sin(),
                } as f32;[x,-x]
            }).collect();
            let mut whole=input.clone();let mut split=input;let mut a=prepared.create_runtime();let mut b=prepared.create_runtime();
            a.process_block(&mut whole,&hex_lattice::EMPTY_DEVICE_RESOURCES);
            let mut offset=0;for n in [1,7,31,64,257,3,128].into_iter().cycle() {if offset==split.len(){break}let end=(offset+n).min(split.len());b.process_block(&mut split[offset..end],&hex_lattice::EMPTY_DEVICE_RESOURCES);offset=end;}
            assert!(whole.iter().flatten().all(|x|x.is_finite()));
            let difference=whole.iter().zip(&split).flat_map(|(a,b)|(0..2).map(move|c|(a[c]-b[c]).abs())).fold(0.0_f32,f32::max);assert_eq!(difference,0.0);
            let anti=whole.iter().map(|f|(f[0]+f[1]).abs()).fold(0.0_f32,f32::max);assert_eq!(anti,0.0);
            let (peak,rms,step)=metrics(&whole);println!("{stimulus},{label},{},{peak},{rms},{step},{difference},{anti}",whole.len());
        }
    }
}
