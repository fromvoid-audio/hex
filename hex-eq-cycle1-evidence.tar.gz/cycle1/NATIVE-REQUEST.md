# Cycle1 finite coordinator request (pending cloud full20)

Candidate a821ccc69ab089aaf671ada680c8361dd740ba8f, tree cd87b7071214a4f00a1aa705d7b0bdd6070b63bd. Canonical PR390/Pulse2784. This source is distinct from fully Mac-qualified98/c8e93. Preserve current installeddfa and coordinator artifact lane; this does not dispatch a Mac job or request immediate replacement. Cloud full20 run20261017T200312Z-caaba4a6 PASSED20/20, full/stale=false/clean unchanged digest934d9e1d4d349fd661d3ff93239b027ede0856ce08b754166aa4fd53c6a9e966, summarySHA96fb5c667aa33e9245c3649c8b3bd5b3cf0adbf0a86e21ab7f02667135ce7a1c. Actualmerged0632d5f9218bd47febabd25f2d32a0f58b77c974 has verified identicaltreecd87b707; exacthead receipt is not a separately run mergecommit CI.

Later coordinator-owned serial checks on concrete chosen source: record actual materialization blobs/modes, clean head/tree/digest before/after, Rust/macOS/target/env. With normal Mac RUST_MIN_STACK unset, use a legitimate private target and retain raw logs/executable hashes:

- cargo test -p hex-ui --features ui-test-support --locked eq_panel::response::tests -- --nocapture : three passes, original-notch/all64banks-ratebounds/disabledclamp.
- cargo test -p hex-devices --lib --locked eq8::flexible::tests::plotted_response_matches_actual_impulse_transform_across_shapes_rates_and_extremes -- --exact --nocapture : one pass,504queries, tail criterion, original tolerances unchanged.
- Full required python3 scripts/local-ci.py on actual chosen integration source where repository guards require it; never relabel98fullMac receipt as new390qualification.

No GUI/save/quit/user interaction is needed for CLI checks. No stack override, ignore, budget/timeout weakening or concurrent target use.

After exact optimized cohort is legitimately built through repository-owned delivery (separately authorized by coordinator, save/quit if app running), GUI needs user/serial desktop lane: one disposable project, 48kHz1kHz notch/Q18, visible authored curve reaches -24dB display floor at1kHz rather than ~-6.7dB, switch stereo/LR/MS/selected bank,64bands/disabledband and low-rate20kHz authored clamp; resize880x540 and1500x650, numeric entry, Undo/Redo/save/reopen values. Log source/build/exe/steps/tasktime/misclicks/screenshots; user listening and further8-step docs/eq-quality-cycle1.md session remain explicit. Existing accepted2729gesture/spinner signoffs stay accepted; this is targeted changed-source verification, no new approval gate. No full ProQ4sonic/physicaldeadline claim.
