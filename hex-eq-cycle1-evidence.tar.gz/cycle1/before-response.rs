//! Control-side authored response sampling; no live/audio ownership.
use super::*;

pub(super) fn curves(
    authored: &NativeDeviceState,
    _state: &EqState,
    rate: u32,
) -> Option<[Vec<[f32; 2]>; 2]> {
    let upper = (rate as f32 * 0.49).min(20000.0);
    let frequencies: Vec<_> = (0..96)
        .map(|i| 20.0 * ((upper / 20.0).ln() * i as f32 / 95.0).exp())
        .collect();
    let response =
        hex_engine::native_effect_frequency_response(authored, rate, &frequencies).ok()??;
    Some(std::array::from_fn(|channel| {
        response
            .iter()
            .enumerate()
            .map(|(i, m)| {
                [
                    i as f32 / 95.0,
                    ((m[channel].max(0.00001).log10() * 20.0 + 24.0) / 48.0).clamp(0.0, 1.0),
                ]
            })
            .collect()
    }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn authored_notch_curve_preserves_actual_center_depth() {
        let mut state = EqState::default();
        let mut node = Node::new(NodeId::new(1).unwrap(), 1000.0, 0.0, 0).unwrap();
        node.kind = eq::NodeKind::Notch;
        node.q = 18.0;
        state.add(node).unwrap();
        let authored = state.encode().unwrap();
        let actual = hex_engine::native_effect_frequency_response(&authored, 48000, &[1000.0])
            .unwrap()
            .unwrap();
        assert!(actual[0][0] < 0.00001, "production notch has a deep center");
        let [primary, secondary] = curves(&authored, &state, 48000).unwrap();
        let model = ResponseGraphModel {
            primary,
            secondary,
            analyzer: None,
            input_analyzer: None,
            nodes: vec![],
        };
        model.validate().unwrap();
        let minimum = model.primary.iter().map(|p| p[1]).fold(1.0_f32, f32::min);
        assert!(
            minimum < 0.001,
            "rendered notch must reach its -24db display floor; normalized minimum={minimum}"
        );
        let x = (1000.0_f32 / 20.0).ln() / (20000.0_f32 / 20.0).ln();
        assert!(
            model
                .primary
                .iter()
                .any(|p| (p[0] - x).abs() < 0.000001 && p[1] < 0.001),
            "the notch belongs at its actual log-frequency coordinate"
        );
    }
}
