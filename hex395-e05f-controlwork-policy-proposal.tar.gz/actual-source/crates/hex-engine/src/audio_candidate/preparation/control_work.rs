//! Productive control-side Main rendering in the SAME preparation custodian.
//! No runtime owner escapes; a completed block remains until its exact ACK.
use super::*;

/// Nonowning correlation for one actual retained output block, never a receipt.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AudioCandidateControlBlock {
    runtime: AudioCandidateIdentity,
    sequence: u64,
    offset: u64,
    frames: usize,
}
impl AudioCandidateControlBlock {
    pub fn sequence(self) -> u64 { self.sequence }
    pub fn offset(self) -> u64 { self.offset }
    pub fn frames(self) -> usize { self.frames }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AudioCandidateControlProgress {
    Block(AudioCandidateControlBlock),
    Complete,
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum Phase { Working, Complete, Refused, StepPending, DropPending, Proof, AnchorsRetiring, Disposed, Failed }
pub(super) struct ControlWork {
    runtime: ClaimedAudioCandidateRuntime,
    anchors: [Option<AudioCandidateAnchors>; 1],
    proof: Option<AudioCandidateRuntimeDisposed>,
    first_panic: Option<Box<dyn Any + Send>>,
    phase: Phase,
    total: u64,
    offset: u64,
    sequence: u64,
    started: bool,
    output: [crate::Frame; 256],
    pending: Option<AudioCandidateControlBlock>,
}
impl ControlWork {
    fn new(runtime: ClaimedAudioCandidateRuntime, anchors: AudioCandidateAnchors, total: u64) -> Self {
        Self { runtime, anchors: [Some(anchors)], proof: None, first_panic: None,
            phase: Phase::Working, total, offset: 0, sequence: 1, started: false,
            output: [[0.0; 2]; 256], pending: None }
    }
    pub(super) fn failed_incomplete(&self) -> bool {
        matches!(self.phase, Phase::StepPending | Phase::DropPending | Phase::Failed)
    }
    fn step(&mut self) -> Result<AudioCandidateControlProgress, AudioStorageError> {
        if let Some(block) = self.pending { return Ok(AudioCandidateControlProgress::Block(block)); }
        if self.phase == Phase::Complete { return Ok(AudioCandidateControlProgress::Complete); }
        if self.phase != Phase::Working { return Err(AudioStorageError::UnknownStorage); }
        let remaining = self.total.checked_sub(self.offset).ok_or(AudioStorageError::SourceMismatch)?;
        if remaining == 0 { self.phase = Phase::Complete; return Ok(AudioCandidateControlProgress::Complete); }
        self.sequence.checked_add(1).ok_or(AudioStorageError::Overflow)?;
        let frames = remaining.min(256) as usize;
        self.phase = Phase::StepPending;
        let result = catch_unwind(AssertUnwindSafe(|| {
            if !self.started {
                self.runtime.apply_action(crate::PlaybackAction::Transport(crate::PlaybackCommand::Play))
                    .map_err(|_| AudioStorageError::SourceMismatch)?;
                self.started = true;
            }
            self.runtime.render(&mut self.output[..frames]).map_err(|_| AudioStorageError::UnknownStorage)
        }));
        match result {
            Ok(Ok(())) => {
                let block = AudioCandidateControlBlock { runtime: self.runtime.identity(),
                    sequence: self.sequence, offset: self.offset, frames };
                self.pending = Some(block);
                self.phase = Phase::Working;
                Ok(AudioCandidateControlProgress::Block(block))
            }
            Ok(Err(reason)) => { self.phase = Phase::Refused; Err(reason) }
            Err(payload) => { self.first_panic = Some(payload); self.phase = Phase::Failed; Err(AudioStorageError::UnknownStorage) }
        }
    }
    fn copy(&self, expected: AudioCandidateControlBlock, output: &mut [crate::Frame; 256]) -> Result<(), AudioStorageError> {
        if self.phase != Phase::Working || self.pending != Some(expected) {
            return Err(AudioStorageError::SourceMismatch);
        }
        output.copy_from_slice(&self.output);
        Ok(())
    }
    fn acknowledge(&mut self, expected: AudioCandidateControlBlock) -> Result<(), AudioStorageError> {
        if self.phase != Phase::Working || self.pending != Some(expected) {
            return Err(AudioStorageError::SourceMismatch);
        }
        let offset = self.offset.checked_add(expected.frames as u64).ok_or(AudioStorageError::Overflow)?;
        let sequence = self.sequence.checked_add(1).ok_or(AudioStorageError::Overflow)?;
        if offset > self.total { return Err(AudioStorageError::SourceMismatch); }
        self.offset = offset;
        self.sequence = sequence;
        self.pending = None;
        if offset == self.total { self.phase = Phase::Complete; }
        Ok(())
    }
    pub(super) fn cleanup_on_control(&mut self) -> Result<(), AudioStorageError> {
        if self.phase == Phase::Disposed { return Ok(()); }
        if self.failed_incomplete() { return Err(AudioStorageError::UnknownStorage); }
        if matches!(self.phase, Phase::Working | Phase::Complete | Phase::Refused) {
            self.phase = Phase::DropPending;
            self.proof = match self.runtime.dispose_on_control() {
                Ok(proof) => Some(proof),
                Err(reason) => { self.phase = Phase::Failed; return Err(reason); }
            };
            self.phase = Phase::Proof;
        }
        if self.phase == Phase::Proof {
            if let Err(reason) = self.proof.as_ref().ok_or(AudioStorageError::UnknownStorage)?
                .record_anchor_cells_on_control(&mut self.anchors) {
                self.phase = Phase::Failed;
                return Err(reason);
            }
            self.phase = Phase::AnchorsRetiring;
        }
        if self.phase != Phase::AnchorsRetiring { return Err(AudioStorageError::UnknownStorage); }
        self.anchors[0].as_mut().ok_or(AudioStorageError::UnknownStorage)?.finish_disposal_on_control()?;
        self.phase = Phase::Disposed;
        drop(self.anchors[0].take());
        drop(self.proof.take());
        Ok(())
    }
}
impl AudioCandidatePreparation {
    pub(super) fn begin_main_control_work_on_control(&mut self, frames: u64) -> Result<(), AudioStorageError> {
        if self.failed_incomplete() || self.cleaning || self.complete || self.control_work.is_some()
            || self.owner.as_ref().is_none_or(|owner| owner.inner.constructor_data.is_none()) {
            return Err(AudioStorageError::SourceMismatch);
        }
        // Existing split validates and allocates its actual wrapper while the
        // original owner remains in this persistent cell. Only fixed moves
        // occur between transfer and installing both new destinations here.
        let split = self.preallocate_publication_split_on_control()?;
        let (runtime, anchors) = split.transfer_on_control()?;
        self.control_work = Some(ControlWork::new(runtime, anchors, frames));
        Ok(())
    }
    pub(super) fn step_main_control_work_on_control(&mut self) -> Result<AudioCandidateControlProgress, AudioStorageError> {
        self.control_work.as_mut().ok_or(AudioStorageError::SourceMismatch)?.step()
    }
    pub(super) fn copy_main_control_block_on_control(&self, block: AudioCandidateControlBlock, output: &mut [crate::Frame; 256]) -> Result<(), AudioStorageError> {
        self.control_work.as_ref().ok_or(AudioStorageError::SourceMismatch)?.copy(block, output)
    }
    pub(super) fn acknowledge_main_control_block_on_control(&mut self, block: AudioCandidateControlBlock) -> Result<(), AudioStorageError> {
        self.control_work.as_mut().ok_or(AudioStorageError::SourceMismatch)?.acknowledge(block)
    }
}
