import importlib.util
import pathlib
import sys

root = pathlib.Path('/workspace/hex-integration-workspace-view')
spec = importlib.util.spec_from_file_location('hex_local_ci', root / 'scripts/local-ci.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
runner = module.LocalCiRunner(
    root,
    mode='component',
    run_id='419-458-c385fb5c-guarded-focused',
    adopt_target=True,
    min_free_bytes=2 * 1024 * 1024 * 1024,
    steps=(
        module.Step('format', ('cargo', 'fmt', '--all', '--', '--check')),
        module.Step('gpui-cache-handoff', ('python3', str(root / 'artifacts/integration/419-458-c385fb5c-gpui-cache-handoff.py')), uses_cargo_target=True),
        module.Step('workspace-three-returns', (
            'cargo', 'test', '-p', 'hex-ui', '--features',
            'ui-test-support', '--lib', '--locked', 'workspace_three_returns_', '--', '--nocapture',
        )),
    ),
)
result = runner.run()
print('FOCUSED_ONLY_SUMMARY', runner.summary_path)
raise SystemExit(result)
