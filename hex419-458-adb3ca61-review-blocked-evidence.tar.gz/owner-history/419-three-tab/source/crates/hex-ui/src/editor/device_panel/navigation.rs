//! View-only horizontal navigation shared by track and return device rails.
use super::*;
use gpui::{
    MouseDownEvent, MouseMoveEvent, MouseUpEvent, ScrollHandle, ScrollWheelEvent, canvas, fill,
    point, size,
};

#[derive(Default)]
pub(in crate::editor) struct Navigation {
    pub(super) scroll: ScrollHandle,
    gesture: Option<Gesture>,
    identity: Option<(u64, DevicePanelOwner)>,
    mode: Option<super::super::EditorMode>,
    overview_bounds: Option<Bounds<Pixels>>,
    toggle_bounds: Option<Bounds<Pixels>>,
}

struct Gesture {
    button: MouseButton,
    pointer_x: f32,
    offset: f32,
    scale: f32,
}

impl Navigation {
    pub(in crate::editor) fn is_active(&self) -> bool {
        self.gesture.is_some()
    }

    pub(in crate::editor) fn cancel(&mut self) -> bool {
        self.gesture.take().is_some()
    }

    fn sync(
        &mut self,
        generation: u64,
        owner: Option<DevicePanelOwner>,
        mode: super::super::EditorMode,
    ) {
        let identity = owner.map(|owner| (generation, owner));
        if self.identity != identity {
            self.identity = identity;
            self.scroll = ScrollHandle::new();
            self.cancel();
        }
        if self.mode != Some(mode) {
            self.mode = Some(mode);
            self.cancel();
        }
    }

    fn set_offset(&self, offset: f32) {
        let max = f32::from(self.scroll.max_offset().width).max(0.0);
        if offset.is_finite() {
            self.scroll
                .set_offset(point(px(offset.clamp(-max, 0.0)), px(0.0)));
        }
    }

    fn update(&mut self, pointer_x: f32) -> bool {
        let Some(gesture) = &self.gesture else {
            return false;
        };
        self.set_offset(gesture.offset + (pointer_x - gesture.pointer_x) * gesture.scale);
        true
    }
}

/// Navigation owns the single scroll instance; windowing holds an alias to it.
/// Bind before capturing viewport observations or reconciling card geometry.
pub(super) fn sync_rail_scroll(view: &mut EditorView) {
    view.device_panel
        .navigation
        .sync(view.project_generation, view.device_panel.owner, view.mode);
    view.device_panel.chain_window.scroll = view.device_panel.navigation.scroll.clone();
}

pub(super) fn rail(view: &mut EditorView, chain: Stateful<Div>) -> Stateful<Div> {
    sync_rail_scroll(view);
    chain.track_scroll(&view.device_panel.navigation.scroll)
}

pub(in crate::editor) fn bottom_bar(
    view: &mut EditorView,
    cx: &mut Context<EditorView>,
) -> Stateful<Div> {
    let open = view.clip_view_open && view.device_panel_active;
    // While open, the finalized device owner is authoritative (a draft can defer a switch).
    let owner = if open {
        view.device_panel.owner
    } else {
        view.focused_return
            .map(DevicePanelOwner::Return)
            .or_else(|| view.selected_track.map(DevicePanelOwner::Track))
    };
    view.device_panel
        .navigation
        .sync(view.project_generation, owner, view.mode);
    if !open {
        view.device_panel.navigation.cancel();
    }
    let mut cards = Vec::new();
    if let Some(state) = &view.state {
        match owner {
            Some(DevicePanelOwner::Track(id)) => {
                if let Some(track) = state.project.track(id) {
                    for node in track.ordered_device_chain() {
                        let (device, class) = match node {
                            hex_project::TrackDeviceRef::Instrument(device) => {
                                (device, NativeDeviceClass::Instrument)
                            }
                            hex_project::TrackDeviceRef::Effect(device) => {
                                (device, NativeDeviceClass::Effect)
                            }
                        };
                        cards.push((
                            device_card_width(class, device.state().type_id()),
                            device.id(),
                        ));
                    }
                }
            }
            Some(DevicePanelOwner::Return(id)) => {
                if let Some(track) = state
                    .project
                    .return_tracks()
                    .iter()
                    .find(|track| track.id() == id)
                {
                    cards.extend(track.devices().iter().map(|device| {
                        (
                            device_card_width(NativeDeviceClass::Effect, device.state().type_id()),
                            device.id(),
                        )
                    }));
                }
            }
            None => {}
        }
    }
    let entity = cx.entity();
    let scroll = view.device_panel.navigation.scroll.clone();
    let selected = view.device_panel.selected_device;
    let overview = div()
        .id("device-chain-overview")
        .debug_selector(|| "device-chain-overview".into())
        .w(px(154.0))
        .h(px(16.0))
        .flex_shrink_0()
        .relative()
        .bg(rgb(theme::color(theme::PaletteRole::Background)))
        .cursor(gpui::CursorStyle::PointingHand)
        .tooltip(|_, cx| {
            cx.new(|_| super::super::transport::MiniTooltip {
                description:
                    "device chain · middle-drag devices · drag focus frame or click to scroll"
                        .into(),
            })
            .into()
        })
        .child(
            canvas(
                |_, _, _| (),
                move |bounds, _, window, cx| {
                    entity.update(cx, |view, _| {
                        view.device_panel.navigation.overview_bounds = Some(bounds)
                    });
                    let width = f32::from(bounds.size.width);
                    let height = f32::from(bounds.size.height);
                    let visible = f32::from(scroll.bounds().size.width).max(0.0);
                    let total = (visible + f32::from(scroll.max_offset().width)).max(1.0);
                    let card_total = cards
                        .iter()
                        .map(|(width, _)| width + DEVICE_CHAIN_PADDING)
                        .sum::<f32>()
                        + DEVICE_CHAIN_PADDING
                        + 40.0;
                    let total = if open { total } else { card_total.max(1.0) };
                    let mut x = DEVICE_CHAIN_PADDING;
                    for (card_width, id) in &cards {
                        let left = x / total * width;
                        let miniature_width = (card_width / total * width - 1.0)
                            .max(1.0)
                            .min((width - left).max(0.0));
                        let color = rgb(theme::color(if selected == Some(*id) {
                            theme::PaletteRole::Primary
                        } else {
                            theme::PaletteRole::Raised
                        }));
                        window.paint_quad(fill(
                            Bounds::new(
                                point(bounds.origin.x + px(left), bounds.origin.y + px(2.0)),
                                size(px(miniature_width), px(height - 4.0)),
                            ),
                            color,
                        ));
                        window.paint_quad(fill(
                            Bounds::new(
                                point(bounds.origin.x + px(left), bounds.origin.y + px(2.0)),
                                size(px(miniature_width), px(3.0)),
                            ),
                            rgb(theme::color(theme::PaletteRole::Muted)),
                        ));
                        x += card_width + DEVICE_CHAIN_PADDING;
                    }
                    let (left, focus_width) =
                        focus_frame(f32::from(scroll.offset().x), visible, total, width);
                    if open && !cards.is_empty() {
                        for (x, y, w, h) in [
                            (left, 0.0, focus_width, 1.0),
                            (left, height - 1.0, focus_width, 1.0),
                            (left, 0.0, 1.0, height),
                            (left + focus_width - 1.0, 0.0, 1.0, height),
                        ] {
                            window.paint_quad(fill(
                                Bounds::new(
                                    point(bounds.origin.x + px(x), bounds.origin.y + px(y)),
                                    size(px(w), px(h)),
                                ),
                                rgb(theme::color(theme::PaletteRole::Text)),
                            ));
                        }
                    }
                    let move_entity = entity.clone();
                    window.on_mouse_event(move |event: &MouseMoveEvent, phase, window, cx| {
                        if !phase.capture() {
                            return;
                        }
                        let moved =
                            move_entity.update(cx, |view, _| {
                                let navigation = &mut view.device_panel.navigation;
                                if navigation.gesture.as_ref().is_some_and(|gesture| {
                                    event.pressed_button != Some(gesture.button)
                                }) {
                                    return navigation.cancel();
                                }
                                navigation.update(f32::from(event.position.x))
                            });
                        if moved {
                            cx.stop_propagation();
                            window.refresh();
                        }
                    });
                    let up_entity = entity.clone();
                    window.on_mouse_event(move |event: &MouseUpEvent, phase, window, cx| {
                        if !phase.capture() {
                            return;
                        }
                        let ended = up_entity.update(cx, |view, _| {
                            let navigation = &mut view.device_panel.navigation;
                            if navigation
                                .gesture
                                .as_ref()
                                .is_some_and(|gesture| gesture.button == event.button)
                            {
                                navigation.update(f32::from(event.position.x));
                                navigation.cancel()
                            } else {
                                false
                            }
                        });
                        if ended {
                            cx.stop_propagation();
                            window.refresh();
                        }
                    });
                    let wheel_entity = entity.clone();
                    window.on_mouse_event(move |event: &ScrollWheelEvent, phase, window, cx| {
                        if !phase.capture() || !open || !bounds.contains(&event.position) {
                            return;
                        }
                        let delta = event.delta.pixel_delta(px(24.0));
                        wheel_entity.update(cx, |view, _| {
                            let navigation = &view.device_panel.navigation;
                            let delta = if delta.x != px(0.0) { delta.x } else { delta.y };
                            navigation.set_offset(f32::from(navigation.scroll.offset().x + delta));
                        });
                        cx.stop_propagation();
                        window.refresh();
                    });
                },
            )
            .size_full(),
        );
    let measure_entity = cx.entity();
    div()
        .id("device-chain-bottom-bar")
        .relative()
        .flex()
        .items_center()
        .gap(px(4.0))
        .flex_shrink_0()
        .child(overview)
        .child(
            div()
                .id("device-panel-bottom-toggle")
                .debug_selector(|| "device-panel-bottom-toggle".into())
                .size(px(18.0))
                .flex()
                .items_center()
                .justify_center()
                .cursor_pointer()
                .text_color(rgb(theme::color(if open {
                    theme::PaletteRole::Primary
                } else {
                    theme::PaletteRole::Muted
                })))
                .tooltip(move |_, cx| {
                    cx.new(|_| super::super::transport::MiniTooltip {
                        description: if open {
                            "hide device panel"
                        } else {
                            "show device panel"
                        }
                        .into(),
                    })
                    .into()
                })
                .child(theme::text(if open { "⌄" } else { "⌃" }))
                .on_click(cx.listener(move |view, _, window, cx| {
                    if open {
                        if !finalize_controls(view, cx) {
                            cx.notify();
                            return;
                        }
                        view.clip_view_open = false;
                    } else {
                        view.cancel_midi_note_gesture();
                        view.device_panel_active = true;
                        view.clip_view_open = true;
                    }
                    view.device_panel.navigation.cancel();
                    view.focus.focus(window);
                    if let Some(audio) = view.audio.as_mut() {
                        let _ = audio.control.audition_cancel();
                    }
                    clear_eq8_audition_gesture_flags(view);
                    cx.notify();
                })),
        )
        .child(
            canvas(
                |_, _, _| (),
                move |bounds, _, _, cx| {
                    measure_entity.update(cx, |view, _| {
                        view.device_panel.navigation.toggle_bounds = Some(Bounds::new(
                            point(bounds.right() - px(18.0), bounds.center().y - px(9.0)),
                            size(px(18.0), px(18.0)),
                        ));
                    });
                },
            )
            .absolute()
            .size_full(),
        )
}

/// Root capture runs before numeric fields' outside-down/blur handlers.
pub(in crate::editor) fn capture_pointer_down(
    view: &mut EditorView,
    event: &MouseDownEvent,
    cx: &mut Context<EditorView>,
) {
    if view.context_menu.is_some() || view.theme_settings.open {
        return;
    }
    let open = view.clip_view_open && view.device_panel_active;
    if open
        && event.button == MouseButton::Left
        && view
            .device_panel
            .navigation
            .toggle_bounds
            .is_some_and(|bounds| bounds.contains(&event.position))
        && !finalize_controls(view, cx)
    {
        cx.stop_propagation();
        cx.notify();
        return;
    }
    if !open {
        return;
    }
    let navigation = &mut view.device_panel.navigation;
    let scale = if event.button == MouseButton::Middle
        && navigation.scroll.bounds().contains(&event.position)
    {
        1.0
    } else if event.button == MouseButton::Left {
        let Some(bounds) = navigation
            .overview_bounds
            .filter(|bounds| bounds.contains(&event.position))
        else {
            return;
        };
        let width = f32::from(bounds.size.width);
        if width <= 0.0 {
            return;
        }
        let visible = f32::from(navigation.scroll.bounds().size.width).max(0.0);
        let total = (visible + f32::from(navigation.scroll.max_offset().width)).max(1.0);
        let (left, focus_width) = focus_frame(
            f32::from(navigation.scroll.offset().x),
            visible,
            total,
            width,
        );
        let pointer = f32::from(event.position.x - bounds.origin.x);
        if pointer < left || pointer > left + focus_width {
            navigation.set_offset(-(pointer - focus_width / 2.0) / width * total);
        }
        -total / width
    } else {
        return;
    };
    navigation.gesture = Some(Gesture {
        button: event.button,
        pointer_x: f32::from(event.position.x),
        offset: f32::from(navigation.scroll.offset().x),
        scale,
    });
    cx.stop_propagation();
    cx.notify();
}

fn focus_frame(offset: f32, visible: f32, total: f32, width: f32) -> (f32, f32) {
    let total = total.max(1.0);
    let focus_width = (visible / total * width).clamp(1.0, width.max(1.0));
    (
        (-offset / total * width).clamp(0.0, (width - focus_width).max(0.0)),
        focus_width,
    )
}
