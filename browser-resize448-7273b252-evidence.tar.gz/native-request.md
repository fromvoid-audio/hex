# bounded browser-release verification

Canonical Pulse2846 / PR448. Source6 owns source repair; cloud3 owns final prospective-tree qualification and merge. Root alone may dispatch Mac checks. This packet does not authorize launching, replacing, quitting or interacting with the user's app.

Use the final immutable source/tree from handoff.json, in a private checks checkout. Keep default native stack and existing bounded filesystem fixture startup. This work does not need an OS audio adapter, device permissions, user media or an unlocked desktop.

Run one command:

    cargo test -p hex-ui --features ui-test-support --lib editor::trim::resize_release_tests::browser_ -- --nocapture

Expected: exactly FOUR unique tests PASS, zero failed, zero ignored. A selector with zero or fewer matches is not green.

1. browser_release_commits_last_shown_audio_resize_after_actual_child_routing: four actual rendered audio conditions (left/right, ordinary/Shift), picker and audition waveform children, held browser entry and direct fast release, last preview retained, actual canonical worker ack, one Undo/Redo. Held browser coordinates must not continue edge-pan.
2. browser_release_commits_last_shown_midi_resize_with_one_history_step: both MIDI edges over both browser children (four conditions), exact start/length/source cursor and retained notes, one pending command, actual ack, one Undo/Redo.
3. browser_resize_release_still_cancels_escape_stale_generation_and_foreign_focus: four legitimate cancellation conditions (Escape, stale generation, foreign focus and canonical view switch), no resize submission, pending owner or project change. Foreign-focus case is a controlled focus transfer, not a claim about ordinary Mac clicks.
4. browser_resize_stationary_command_preview_and_release_use_the_last_timeline_point: ordinary and Shift audio with Command held or released at mouse-up (four conditions); stationary modifiers over browser change actual timeline preview and canonical commit agrees, one Undo.

Report actual cargo exit, all four names/counts, diagnostic rows and raw report SHA256. Retain failures. Source and installed app preservation must be recorded independently; do not relabel cloud checks or old333/403 native results as this source.

Physical acceptance remains open: on a separately qualified optimized candidate, resize user audio/MIDI over browser picker/results/preview, both edges, Shift Warp and current snapping modifier, release fast or while held, verify stable visible waveform/extent and exactly one Undo/Redo, no audition/import/ghost, no timer after release/cancel. User-present screen/audio interaction is root-owned and is not part of this headless request.
