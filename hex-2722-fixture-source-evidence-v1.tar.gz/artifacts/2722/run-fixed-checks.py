import pathlib,subprocess,json,hashlib,time,os
out=pathlib.Path('artifacts/2722');cfg=json.loads((out/'run-fixed-config.json').read_text());env=os.environ.copy();env['CARGO_TARGET_DIR']=cfg['target'];records=[]
for name,argv in cfg['checks']:
 assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==cfg['source'];assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all']).strip();print('RUNNING',name,flush=True);start=time.monotonic();p=out/(name+'.log')
 with p.open('wb') as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all']).strip();record=dict(name=name,source=cfg['source'],tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}']).decode().strip(),argv=argv,target=cfg['target'],exit_code=r.returncode,duration_seconds=round(time.monotonic()-start,3),log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_clean_unchanged=True);records.append(record);(out/'fixed-checks.json').write_text(json.dumps(records,indent=2)+'\n');print('FINISHED',json.dumps(record),flush=True)
