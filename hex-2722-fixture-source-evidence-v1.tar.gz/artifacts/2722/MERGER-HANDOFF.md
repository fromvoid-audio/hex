# Pulse2722 / canonical PR338 — focused existing-fix handoff

CODE: b34a522ebbe754da00934fa9c405e75133f17dc1
TREE: 60b5479328205706cfd6bdeab7913f78ea8ef784
Branch: pulse/task-2722-g1-d58c01491de4
PR: https://github.com/PORTALSURFER/hex/pull/338
Baseline: pinned current-main75a82e9a3187ca04e89699c1bd15ad7c836b38b4

Root requested reuse of the already-published self-contained fix from Sampler395.
Original be23d80a6723fd729cfcec93a44e06e5a3df6b88 changes only the example/test
and matching todo entry. Cherry-pick -x retained its original author/date and
explicit provenance. The fixture blob8c6bbc663a9cd2e4a6a09ca134338c6fb7ab7b27
is identical to both originalbe23 and frozen Samplerb54c645d. Canonical intake
and history retained; no duplicate PR or independently invented patch. Only todo
append conflicted: preserve main content plus exact original8-line entry.
Own diff2files/30insertions. No Engine/Sampler production/API/schema/resource/
compiler/custody changes and no dependency on full Sampler work.

Main actual original reproducer exits101 with E0004 for omitted Expression.
Frozen repaired CODE above passed:
1. cargo test -p hex-engine --example playback_stack --features instrument-test-support --locked mutable_instrument::tests::note_only_stack_probe_refuses_expression_before_state_changes -- --exact --nocapture
   Actual1passed/0failed/0ignored/0filtered, exit0. Log SHA256
   b12e7ad81faf166b9dda6b6bac01ad9adcd227100ad6c66dd2f7664d006123ec.
2. cargo clippy -p hex-engine --all-targets --features instrument-test-support --locked -- -D warnings
   Actual exit0. Log SHA256
   5d4f4cb358d504a7b75bee250e889463086b166542d8294d9cd1acfc81c35fff.
Clean source stayed unchanged; fresh private target. fixed-checks.json retains
commands/source/tree/target/duration/log hashes. source-identity.json is metadata
from the repository digest algorithm, NOT a fullCI receipt.

Before canonical extraction, the SAME original fix was independently checked on
frozen Samplerb54c645d/tree217365fc: example Clippy, focused test1 and original
all-target feature Clippy passed in a fresh private target. Initial Clippy
attempts using shared old-worktree cache failed with missing build-env/dependency
symbols; their original logs are retained. Fresh private target passed unchanged
source. No guard/source/report workaround, no unrelated production repair.

Explicit Expression -> InvalidEventBatch preflight refusal defines the fixture's
note-only supported domain. Original NoteOn/Off admission, process_block, voices,
release/history/stack/PCM code are unchanged. Focused test observes refusal and
quiescence. Final own diff reviewed, no unresolved finding; no independent external
approval fabricated. PORTALSURFER assigned and individually requested for review.

Source implementation/targeted checks complete, PR ready for review but UNMERGED.
Dedicated merger chat01a149d1-3232-76d1-b08a-05f3ca89906d owns final full required
localCI/current prospective-tree qualification/integration/actual merge proof.
Do not relabel targeted checks as full20 or claim main delivery. Return genuine
semantic/source failures to source owner. No more main chasing/self-merge here.

No Mac/app/backend/GUI/user-data/security/profile/TCC/keychain/install/launch/quit
operation requested or performed. This verification-only fixture needs no new
physical-listening gate. If coordinator genuinely needs platform portability for
this changed example, the exact single-test selector above is finite; only root
may dispatch sole Mac lane. No headless test claims physical stack/audio acceptance.

All evidence refs are archive/metadata only: never build, merge or checkout them
as code. Original logs/failures/source identities and previous396 evidence remain
unchanged. No unpublished tracked work is left in this source checkout.
