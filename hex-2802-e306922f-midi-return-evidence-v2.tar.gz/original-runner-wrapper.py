import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-empty-tracks');s=importlib.util.spec_from_file_location('empty_tracks_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
steps=(m.Step('engine-original-case',('cargo','test','-p','hex-engine','--test','midi_compile','--locked','instrument_render_is_partition_seek_pause_and_stop_invariant','--','--nocapture'),uses_cargo_target=True),m.Step('engine-midi-compile',('cargo','test','-p','hex-engine','--test','midi_compile','--locked','--','--nocapture'),uses_cargo_target=True))
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
