import pathlib,subprocess,hashlib,json,os,difflib
root=pathlib.Path('/workspace/hex-workspace-tab-489');base='26300395343e74ad19fb09247167b4fa44ae4b49'
def before(p):return subprocess.check_output(['git','show',base+':'+p],cwd=root)
changes=subprocess.check_output(['git','diff',base,'--name-only'],cwd=root,text=True).splitlines();overrides={p:before(p) for p in changes};overrides['crates/hex-session/src/device_comparison.rs']=(root/'crates/hex-session/src/device_comparison.rs').read_bytes();test='crates/hex-engine/src/signal_graph/tests.rs';overrides[test]=pathlib.Path('/workspace/scratch/484-latency-original-tests.rs').read_bytes();integration='crates/hex-session/tests/device_comparison.rs';s=(root/integration).read_text();s=s[:s.index('#[test]\nfn main_comparison_switch_copy_both_directions_roundtrip')].rstrip()+'\n';overrides[integration]=s.encode()
d=hashlib.sha256()
for rel in sorted(x for x in subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0') if x):
 p=root/os.fsdecode(rel);d.update(len(rel).to_bytes(8,'big'));d.update(rel)
 if p.is_symlink():d.update(b'symlink\0');d.update(os.fsencode(os.readlink(p)))
 else:d.update(b'file\0');d.update(overrides.get(os.fsdecode(rel),p.read_bytes()));d.update(str(p.lstat().st_mode&0o111).encode())
expected=json.load(open(root/'artifacts/local-ci/20261020T070857Z-13e3a4fe/summary.json'))['source_identity']['content_sha256'];assert d.hexdigest()==expected,(d.hexdigest(),expected)
patch=''.join(''.join(difflib.unified_diff(before(p).decode().splitlines(True),(overrides.get(p,(root/p).read_bytes())).decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in changes)
pathlib.Path('/workspace/scratch/484-latency-baseline-exact.patch').write_text(patch);pathlib.Path('/workspace/scratch/484-latency-original-tests.rs').write_bytes(overrides[test]);print(json.dumps({'exact_source_digest':expected,'patch_bytes':len(patch.encode())}))
