import importlib.util,pathlib,sys,json
root=pathlib.Path('/workspace/hex-workspace-tab-489');spec=importlib.util.spec_from_file_location('ci484final',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=[m.Step('architecture',('python3','scripts/check-architecture.py')),m.Step('ui-style',('python3','scripts/check-ui-style.py')),m.Step('gpui-patch',('python3','scripts/check-gpui-patch.py')),m.Step('dependency-provenance',('python3','scripts/check-dependency-patches.py')),m.Step('device-layout',('python3','scripts/check-device-layout.py')),m.Step('format',('cargo','fmt','--all','--check')),m.Step('diff',('git','diff','--check')),
m.Step('latency-and-pre-main-controls',('cargo','test','-p','hex-engine','--lib','--locked','signal_graph::tests::','--','--nocapture')),
m.Step('comparison-saved-open',('cargo','test','-p','hex-session','--test','device_comparison','--locked','--','--nocapture'))]
for i,s in enumerate(json.load(open('/workspace/scratch/484-original-functional-steps.json'))):
 steps.append(m.Step('original-main-'+str(i+1),tuple(s['argv'])))
raise SystemExit(m.LocalCiRunner(root=root,mode='quick',steps=tuple(steps)).run())
