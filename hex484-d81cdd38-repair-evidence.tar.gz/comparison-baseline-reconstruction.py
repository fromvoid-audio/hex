import pathlib,subprocess,hashlib,json,os,difflib,tempfile
root=pathlib.Path('/workspace/hex-workspace-tab-489');base='26300395343e74ad19fb09247167b4fa44ae4b49'
def before(p):return subprocess.check_output(['git','show',base+':'+p],cwd=root)
changes=subprocess.check_output(['git','diff',base,'--name-only'],cwd=root,text=True).splitlines();overrides={p:before(p) for p in changes}
p='crates/hex-session/src/device_comparison.rs';s=(root/p).read_text();s=s.replace('        .chain(project.main_devices())\n','').replace('            .chain(snapshot.main_devices.iter_mut())\n','').replace('            .chain(from.main_devices())\n','')
a=s.index('        assert_eq!(\n            copy.project(),\n            &source,');b=s.index('    #[test]\n    fn comparison_metadata_classification',a)
s=s[:a]+'''        assert!(metadata_pair(&source, copy.project()).unwrap(), "initial same-audio bank creation is a typed copy");
        copy.execute(Command::SetDeviceBypass { device, bypassed: true }).unwrap();
        assert!(!metadata_pair(&source, copy.project()).unwrap(), "bypass must not be stripped");
    }

'''+s[b:]
with tempfile.TemporaryDirectory(prefix='hex-484-baseline-') as d:
 tmp=pathlib.Path(d)/'baseline.rs';tmp.write_text(s);subprocess.run(['/workspace/.hex-tools/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024',str(tmp)],check=True);overrides[p]=tmp.read_bytes()
p='crates/hex-session/tests/device_comparison.rs';s=(root/p).read_text();s=s[:s.index('#[test]\nfn main_comparison_switch_copy_both_directions_roundtrip')].rstrip()+'\n';overrides[p]=s.encode()
d=hashlib.sha256()
for rel in sorted(x for x in subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0') if x):
 f=root/os.fsdecode(rel);d.update(len(rel).to_bytes(8,'big'));d.update(rel)
 if f.is_symlink():d.update(b'symlink\0');d.update(os.fsencode(os.readlink(f)))
 else:d.update(b'file\0');d.update(overrides.get(os.fsdecode(rel),f.read_bytes()));d.update(str(f.lstat().st_mode&0o111).encode())
expected=json.load(open(root/'artifacts/local-ci/20261020T070347Z-c8af65ea/summary.json'))['source_identity']['content_sha256'];assert d.hexdigest()==expected,(d.hexdigest(),expected)
patch=''.join(''.join(difflib.unified_diff(before(p).decode().splitlines(True),overrides[p].decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in changes)
pathlib.Path('/workspace/scratch/484-comparison-baseline-exact.patch').write_text(patch);print(json.dumps({'exact_source_digest':expected,'patch_bytes':len(patch.encode())}))
