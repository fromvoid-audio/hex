# PR448 repair: finite coordinator-owned native request

Exact source62c642b82e9b2a6ba4900ae437eeaa41c038e900
Tree0f1a060af4fb966444e7ef23d952853d2cbd624e
Parentdf96218884c9ce7fa5687dc6c5e4cbf16c9a7588 (retains merged414).

Use the sole native lane, private configured target/cache and default native stack:

    cargo test -p hex-ui --features ui-test-support --lib editor::trim::resize_release_tests::browser_ -- --nocapture

Expected EXACTLY9 unique tests, zero failures/ignored/zero-match;24 internal
conditions: original4 browser tests/16 conditions plus two actual other-track
refusals, two existing detail/browser focus admissions, two verified neutral-region
cancellations, and two original(464,214) browser commits. The nine fixtures create
RAII disposable browser/sample/recent/theme paths BEFORE EditorView workers and
use the actual offline Service. No OS audio adapter, current app, permissions,
physical input or user media is needed. The older clip_drag_ui_test fixture uses
an ambient constructor and is deliberately NOT in this native selector; its exact
unchanged cancellation assertions pass in the cloud at a corrected neutral point.

Verify printed actual browser bounds/membership and hovered target, canonical
worker result, no residual capture/PendingTrim, original-point one Undo/Redo,
stationary modifiers, Escape/stale/view/foreign-focus cancellation. MIDI ordinary
focus admission already passed pre-repair; explicit edge focus is hardening.
Do not relabel original7273 native4 as this source's evidence or call this full21.

Physical optimized acceptance remains open: resize both edges, normal/Shift where
supported, enter picker/results/audition/browser background, release; last valid
preview remains with one Undo/Redo and no audition/import. Different Arrangement
track and genuine nonbrowser neutral release cancel. Check source/minimum bounds,
snap modifier transitions, zoom/pan/waveform stability and no post-cancel timer.
Root owns scheduling/delivery. This packet does not dispatch native or app work.
