"""Audited sampler-host producer boundary, not Rust hostile-client sealing.

These public internal borrowed projections are only constructed/implemented in
reviewed owning modules. Engine, rather than a producer callback, traverses the
finite schema. This check preserves the independent Cargo dependency checks.
"""
import re


EXACT = {
    'crates/hex-engine/src/audio_storage/native_root_fields.rs',
    'crates/hex-audio/src/candidate_custody/root_fields.rs',
    'crates/hex-engine/src/audio_storage/native_status.rs',
    'crates/hex-engine/src/audio_storage/native_resident.rs',
    'crates/hex-audio/src/prepared/resident_forwarding.rs',
    'crates/hex-audio/src/native_callback_owner/registered.rs',
    'crates/hex-audio/src/prepared/resident_forwarding/tests.rs',
    'crates/hex-audio/src/prepared/status_owner.rs',
    'crates/hex-audio/src/prepared/status_owner/tests.rs',
    'crates/hex-audio/src/prepared/endpoints.rs',
    'crates/hex-audio/src/gain_recording/tests.rs',
    'crates/hex-engine/src/audio_storage/native_atomic_signal.rs',
    'crates/hex-engine/src/audio_storage/native_atomic_signal/tests.rs',
    'crates/hex-audio/src/native_callback_owner/atomic_signal.rs',
    'crates/hex-audio/src/sample_preview.rs',
    'crates/hex-audio/src/gain_recording.rs',
    'crates/hex-audio/src/spectrum_target.rs',
    'crates/hex-audio/src/processor_audition.rs',
    'crates/hex-engine/src/audio_storage/native_carrier.rs',
    'crates/hex-engine/src/audio_storage/native_fixed_ring.rs',
    'crates/hex-audio/src/native_callback_owner/ring_storage/transport.rs',
    'crates/hex-audio/src/prepared.rs',
    'crates/hex-audio/src/native_callback_owner.rs',
    'crates/hex-audio/src/native_callback_owner/storage_tests.rs',
    'crates/hex-audio/src/native_callback_owner/ring_storage/registered_tests.rs',
    'crates/hex-engine/src/audio_candidate/claimed.rs',
    'crates/hex-engine/src/audio_candidate/groups.rs',  # actual constructor archive owns the wrapper counterpart
    'crates/hex-engine/src/audio_storage/native_state.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/native_host/tests.rs',
    'crates/hex-audio/src/candidate_custody.rs',
    'crates/hex-audio/src/candidate_custody/eligible/pages.rs',
    'crates/hex-audio/src/candidate_custody/eligible.rs',
    'crates/hex-audio/src/prepared/factory.rs',
    'crates/hex-audio/src/prepared/factory/tests.rs',
    'crates/hex-audio/src/candidate_custody/eligible/native_birth_tests.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/tests.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/disposal.rs',
    'crates/hex-session/src/service/worker_roots.rs',
    'crates/hex-project/src/time_range.rs',
    'crates/hex-engine/src/lib.rs',
    'crates/hex-engine/src/midi_preview.rs',
    'crates/hex-engine/src/gain_envelope.rs',
    'crates/hex-session/src/snapshot_exports/storage.rs',
    'crates/hex-session/src/snapshot_exports/native_transport.rs',
    'crates/hex-session/src/snapshot_exports/native_transport/tests.rs',
    'crates/hex-session/src/snapshot_exports/native_requests.rs',
    'crates/hex-media/src/waveform.rs',
    'crates/hex-media/src/waveform/shared_storage_tests.rs',
    'crates/hex-engine/src/audio_storage.rs',
    'crates/hex-engine/src/sampler_host_fields.rs',
    'crates/hex-export/src/staged_file.rs',
    'crates/hex-export/src/publication.rs',
    'crates/hex-export/src/buffered_file.rs',
    'crates/hex-session/src/service/main_control_file.rs',
    'crates/hex-session/src/service/canonical_audio_source.rs',
    'crates/hex-session/src/service/main_control_file/tests.rs',
}
# Whole subtrees are restricted to the new Engine schema itself, not arbitrary
# modules in an approved crate. New production producers require explicit review.
PREFIXES = ('crates/hex-engine/src/sampler_host_fields/',)
NAMES = re.compile(r'\b(?:matches_constructor_worker_fields_on_control|matches_actual_field_role_on_control|matches_constructor_channel_fields_on_control|matches_live_endpoint_on_control|NativeRootFieldRegistration|NativeRootFieldLease|borrow_sampler_native_root_fields_on_control|ResidentArchive|ResidentHandle|NativeResidentFields|NativeResidentRegistration|NativeResidentFieldLease|StatusArchive|StatusHandle|NativeStatusRegistration|NativeStatusFieldLease|NativeStatusFields|atomic_signal|NativeAtomicSignal|NativeAtomicSignalRegistration|registered_prepared_ring|NativePreparedProducer|NativePreparedConsumer|native_prepared_ring|NativeFixedRingFields|NativeFixedRingLease|NativeFixedRingRegistration|NativeCarrierStorageRegistration|NativeCarrierStorageLease|borrow_sampler_worker_fields_on_control|track_buffer_on_control|FamilySnapshotFields|FamilyCompiledRecordFields|FamilyCompiledFields|FamilyRequestPayload|FamilyRequestFields|FamilyRequestRecords|borrow_sampler_family_fields_on_control|borrow_sampler_family_requests_on_control|borrow_sampler_family_compiled_on_control|SnapshotViewFields|SnapshotViewPayload|CapturedSourcePayload|borrow_sampler_snapshot_children_fields_on_control|borrow_sampler_snapshot_view_fields_on_control|WaveformFields|WaveformPayload|WaveformLevelsRef|WaveformSamples|borrow_sampler_waveform_fields_on_control|sampler_host_fields|BodyRef|VecRef|SharedMetadataRef|SamplerWorkerFields|CapturedSourceFields|FamilyFields|FileSlotsFields|NativeFields|sampler_fields_on_control|borrow_sampler_file_slots_fields_on_control|borrow_sampler_captured_source_fields_on_control)\b')


def violations(path: str, source: str) -> list[str]:
    if path == 'crates/hex-audio/src/native_callback_owner.rs':
        start = source.find('pub(crate) fn reserve_native_worker(')
        end = source.find('fn reserve_carriers(', start)
        worker = source[start:end] if start >= 0 and end > start else ''
        required = ['registered::validate_birth_limits(&root)?;',
                    '!control.matches_constructor_channel_fields_on_control(&root)',
                    '!callback.matches_constructor_channel_fields_on_control(&root)',
                    'control.reserve_worker_endpoints(reader)?']
        positions = [worker.find(text) for text in required]
        if any(position < 0 for position in positions) or positions != sorted(positions):
            return [f'{path}: both actual prepared queue inputs must be checked before ANY carrier birth']
    carrier_module = 'crates/hex-audio/src/native_callback_owner/registered.rs'
    if re.search(r'\bCarrierPayload\b', source):
        if path != carrier_module:
            return [f'{path}: carrier construction trait belongs only to its four concrete producers']
        types = re.findall(r'impl CarrierPayload for (\w+)', source)
        if types != ['NativeCallbackOwner', 'ErrorCallbackOwner', 'ClientEndpoints', 'PublicationControl']:
            return [f'{path}: carrier construction requires exactly four concrete original types']
        required = ['self.matches_constructor_worker_fields_on_control(root)',
                    'root.matches_status_field(&self.status, crate::prepared::status_owner::NATIVE_DATA)',
                    'root.matches_status_field(&self.status, crate::prepared::status_owner::NATIVE_ERROR)']
        if any(text not in source for text in required):
            return [f'{path}: actual worker Resident and native Status field roles must be checked before carrier birth']
    if not NAMES.search(source):
        return []
    if path in EXACT or path.startswith(PREFIXES):
        return []
    return [f'{path}: sampler-host projections require a declared audited owning module']


def repository_violations(root):
    from custody_mutex_policy import repository_violations as custody_mutex_violations
    result = custody_mutex_violations(root)
    for path in sorted((root / 'crates').rglob('*.rs')):
        result.extend(violations(path.relative_to(root).as_posix(), path.read_text()))
    return result
