"""Finite source-boundary sensitivity; no compiler/admission claim."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location(
    'sampler_host_policy', Path(__file__).resolve().parents[1] / 'sampler_host_policy.py')
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
violations = policy.violations


class SamplerHostPolicyTests(unittest.TestCase):
    def test_actual_file_owner_is_allowed(self):
        self.assertEqual(violations(
            'crates/hex-session/src/service/main_control_file.rs',
            "impl<'a> hex_engine::sampler_host_fields::FileSlotsFields<'a> for Reserved<'a> {}"), [])

    def test_foreign_module_in_same_crate_is_refused(self):
        self.assertTrue(violations('crates/hex-session/src/random.rs',
                                   'use hex_engine::sampler_host_fields as fields;'))

    def test_foreign_crate_and_aliased_import_are_refused(self):
        for text in ['use hex_engine::sampler_host_fields::{BodyRef as X};',
                     'let body = hex_engine::sampler_host_fields::BodyRef::of(&x);',
                     'impl FileSlotsFields for Wrong {}']:
            self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs', text))

    def test_indirect_producer_accessor_callsite_is_checked(self):
        self.assertTrue(violations('crates/hex-ui/src/arbitrary.rs',
                                   'let fields = staged.sampler_fields_on_control()?;'))

    def test_carrier_producers_are_exact_four_in_owning_module(self):
        path = 'crates/hex-audio/src/native_callback_owner/registered.rs'
        body = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, body), [])
        self.assertTrue(violations(path, body + '\nimpl CarrierPayload for Other {}'))
        self.assertTrue(violations(path, body.replace('impl CarrierPayload for ClientEndpoints', 'impl CarrierPayload for Other')))
        self.assertTrue(violations('crates/hex-audio/src/foreign.rs', 'impl CarrierPayload for Other {}'))

    def test_root_field_producers_require_audited_owning_module(self):
        for name in ['NativeRootFieldRegistration', 'NativeRootFieldLease',
                     'borrow_sampler_native_root_fields_on_control']:
            self.assertTrue(violations('crates/hex-audio/src/foreign.rs', name))
            self.assertEqual(violations('crates/hex-audio/src/candidate_custody/root_fields.rs', name), [])

    def test_actual_both_input_check_precedes_all_carrier_births(self):
        path = 'crates/hex-audio/src/native_callback_owner.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace('!callback.matches_constructor_channel_fields_on_control(&root)', 'false')))
        self.assertTrue(violations(path, source.replace('!control.matches_constructor_channel_fields_on_control(&root)', 'false')))

    def test_worker_resident_and_native_status_roles_are_required(self):
        path = 'crates/hex-audio/src/native_callback_owner/registered.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace('self.matches_constructor_worker_fields_on_control(root)', 'true')))
        self.assertTrue(violations(path, source.replace('status_owner::NATIVE_ERROR', 'status_owner::NATIVE_DATA')))

    def test_other_architecture_source_is_unchanged(self):
        self.assertEqual(violations('crates/hex-ui/src/arbitrary.rs',
                                    'use hex_engine::Frame;'), [])

    def test_spectrum_static_quotes_do_not_authorize_borrowed_producers(self):
        path = 'crates/hex-audio/src/spectrum_worker/native.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source + '\nimpl NativeFields for Arbitrary {}'))
        self.assertTrue(violations(path, source + '\nSharedMetadataRef::of(&arbitrary)'))
        self.assertTrue(violations('crates/hex-ui/src/random.rs',
                                   'SharedMetadataRef::constructor_bytes::<T>()'))

    def test_final_native_completion_stays_after_actual_parent_join(self):
        path = 'crates/hex-audio/src/lifecycle.rs'
        source = (Path(__file__).resolve().parents[2] / path).read_text()
        self.assertEqual(violations(path, source), [])
        self.assertTrue(violations(path, source.replace('advance_shutdown_on_control()', 'request_stop()')))
        self.assertTrue(violations(path, source.replace('preflight_native_worker_birth(', 'omitted_preflight(')))
        self.assertTrue(violations(path, source + '\nfn bypass() { x.finish_root_after_native_fields_on_control(); }'))
        self.assertTrue(violations('crates/hex-audio/src/random.rs',
                                   'x.finish_root_after_native_fields_on_control()'))


if __name__ == '__main__':
    unittest.main()
