# Coordinator-only finite changed-component request

Source6e826f19a05809ed0d904890addf2132eedc0518/tree1fc5dc97d32ef58e01b383558ed7580017de6a1f. Never build evidence ref. New isolated source checkout, disposable bounded test dirs, coordinator's existing private legitimate target. No app/GUI input, launcher/build/install/signals/provider/config/credentials changes. No inference.

System Python3.9 changed adapter primitives: ONE invocation with these nine actual selectors (0skip expected):

```sh
/usr/bin/python3 -m unittest -v \
 scripts.tests.test_changelog.ChangelogTests.test_explicit_followup_base_cannot_skip_or_overlap_covered_history \
 scripts.tests.test_changelog.ChangelogTests.test_history_independently_refuses_a_gap_or_overlap \
 scripts.tests.test_changelog.ChangelogTests.test_git_diff_is_capped_during_read_not_after_communicate \
 scripts.tests.test_changelog.ChangelogTests.test_import_requires_integer_exit_and_attempts_not_boolean_aliases \
 scripts.tests.test_changelog.ChangelogTests.test_successful_concurrent_publisher_cannot_be_overwritten_by_stale_model \
 scripts.tests.test_changelog.ChangelogTests.test_publication_lock_contention_preserves_successful_notes_and_source \
 scripts.tests.test_changelog.ChangelogTests.test_real_multiprocess_publishers_through_root_alias_preserve_first_success \
 scripts.tests.test_changelog.ChangelogTests.test_git_pipe_overflow_failure_and_interrupt_reap_child_with_bounded_stderr \
 scripts.tests.test_changelog.ChangelogTests.test_export_and_import_cannot_append_a_gap_despite_valid_result_evidence
```

One genuinely changed GPUI component (retained disposable browser fixture BEFORE workers):

```sh
cargo test -p hex-ui --features ui-test-support --locked editor::changelog::ui_tests::overlay_close_is_reachable_by_tab_shift_tab_and_activates_without_document_edits -- --exact
```

Expect exactly1PASS/0ignored. No repeated original UI5/Pythonstartup/Operator2 solely for this request. Sole merger still owns prospective full21. Keep source and original notes unchanged; preserve actual interpreter identity/command/status/all outputs and source before/end proof. This is automated native component evidence only, not physical AX/visual/user acceptance. Coordinator may schedule serially; this document does not start jobs or authorize app operations.
