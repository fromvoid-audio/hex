# PR410 five review returns

Owner commit 6e826f19a05809ed0d904890addf2132eedc0518 (parent actual canonical 4cac2b7b35cdf2a53baf6cf6ad7df5894b20719b), tree 1fc5dc97d32ef58e01b383558ed7580017de6a1f. Ordinary cherry-pick onto the sole merger's canonical candidate; no new PR. Only scripts/changelog.py, its focused tests, private editor/changelog.rs and owning docs changed. No Operator/framework edits. Full21 remains required on the actual prospective tree; old4cac green report is historical.

- _wW: adjacency enforced by prepare, export, import and independent history validation. Exact existing input remains idempotent; valid second batch coverage still round trips.
- _wY: selectors drains stdout/stderr concurrently. Output refuses at bound+1; stderr retains8KiB and drains excess. Overflow/errors/interrupt kill+wait owned child, close handles. Exit diagnostics retain actual status.
- _wZ: Close has its own focus, visible focus styling, key context and Enter/Space actions. Tab/ShiftTab remain within the single-control overlay. Escape/editor restoration and input isolation remain.
- _wc: execution exit_code/attempts require exact int type; booleans refuse before publication.
- _we: exact previous bytes captured before model/import verification; nonblocking fcntl publication lock + compare-and-swap under lock then atomicreplace. Git metadata lock basename includes resolved dataset identity, never unlinked, no tracked lock artifact. CLI exposes --root but no alternate dataset/sharedtarget parameter. Real subprocess test uses two root spellings to one actual dataset, both snapshot absence, first range succeeds and later range refuses stale publication. Explicit lock contention also refuses. No model work under lock.

Original seven real AI notes are byte-identical3428B/SHA1221c2b9547e77c8ee69da49c5baba05b5eabe2b9848235c5094f77e1c2069cc. Original274953B input recomputes e2c0bf048f28ac36c9f201ba6e154c669a8f730e582856d2dbb774016ab8ef20 exactly. No new inference, proof edit or capability claim. Immutable original Mac transport remains ea4492ff33003c6a3a995087ab6cccd796268381:changelog-mac-cb8befc4-generated-v1.tar.gz.

Actual33Python+7readerPASS,86launcher/installer/runner tests run0fail/2existingnative skips, strict UI feature alltargetsClippy and actual QUICKguards/fmt/diff pass. Red originals preserved: five Python tests eight failure/subtest reports; new rendered Close test failed actual missing keyboard focus. Original4cac full21 positive remains separate. Report and complete logs are retained. Wrapper shell tails did not independently save original Cargo returncode; PASS is established by Cargo's complete test success summary/Finished and absence of errors, not an invented extra receipt. No app/native operation, merge or installed acceptance.

Source1 returns next to queued421 picked-path/owned Restore race; A/B5165Storage checkpoint remains published independently/not feature-ready.
