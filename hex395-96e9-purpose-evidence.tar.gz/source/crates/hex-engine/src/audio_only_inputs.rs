//! Consuming source ingress. Constructor declarations are not admission/retirement.
use crate::{Audio, Frame, StreamedSourceMetadata, owned_shared::OwnedShared};
use hex_project::AssetId;
use std::sync::atomic::{AtomicU64, Ordering};

// Identity allocator only: no owner registry or pointer/content-based identity.
static NEXT_HANDLE: AtomicU64 = AtomicU64::new(1);
#[cfg(test)]
thread_local! {
    // Successful real global ID issues by this test thread, never a reset or
    // replacement allocator. Avoids races with unrelated parallel test issuers.
    pub(crate) static ISSUED_HANDLES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}
#[cfg(test)]
pub(crate) fn next_handle_observation() -> u64 {
    NEXT_HANDLE.load(Ordering::Relaxed)
}
pub(crate) fn handle() -> Result<u64, AudioStorageError> {
    let id = NEXT_HANDLE
        .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
        .map_err(|_| AudioStorageError::HandleExhausted)?;
    #[cfg(test)]
    ISSUED_HANDLES.with(|count| count.set(count.get() + 1));
    Ok(id)
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AudioStorageError {
    UnsupportedConstructor,
    InvalidSamples,
    InvalidRate,
    DuplicateAsset,
    Allocation,
    Overflow,
    Capacity,
    ReservationExceeded,
    HandleExhausted,
    UnsupportedGraph,
    SourceMismatch,
    UnknownStorage,
    /// Registered immutable readers still retain the constructor root.
    ExternalReadersPending,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AudioStorageReservation {
    pub allocation_items: usize,
    pub handle_obligations: usize,
    pub max_prepared_data_bytes: usize,
    pub max_construction_data_bytes: usize,
    pub caller_retained_bytes: usize,
    pub caller_construction_bytes: usize,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct AudioPreparationCapacity {
    pub original_source_capacity: usize,
    pub source_container_bytes: usize,
    pub alias_capacity: usize,
    pub alias_container_bytes: usize,
    pub bank_container_bytes: usize,
    pub prepared_data_bytes: Option<usize>,
    pub construction_peak_bytes: Option<usize>,
}
pub struct ResidentSourceRefusal {
    pub reason: AudioStorageError,
    pub frames: Vec<Frame>,
}
pub struct ResidentMonoSourceRefusal {
    pub reason: AudioStorageError,
    pub samples: Vec<f32>,
}
pub struct NativeAudioMoveRefusal {
    pub reason: AudioStorageError,
    pub source: OwnedAudioSource,
}
pub struct NativeAudioIngressRefusal {
    pub reason: AudioStorageError,
    pub audio: Audio,
}
pub(crate) struct MonoSourceData {
    pub(crate) sample_rate: u32,
    pub(crate) samples: Vec<f32>,
}
pub struct StreamedSourceRefusal {
    pub reason: AudioStorageError,
    pub metadata: StreamedSourceMetadata,
}
/// No raw Arc/Weak/Deref escape. Explicit control aliases have distinct sealed
/// owning-handle identities but retain the same constructor-paired allocation.
pub struct OwnedAudioSource {
    pub(crate) kind: SourceKind,
    pub(crate) handle: u64,
}
pub(crate) enum SourceKind {
    Resident(Audio),
    ResidentMono(OwnedShared<MonoSourceData>),
    Streamed(OwnedShared<StreamedSourceMetadata>),
}
/// Borrowed leaf layout for the existing source/clip custody visitors.
/// This confers no owner, constructor declaration or retirement authority.
pub(crate) enum SourceStorageKind<'a> {
    Resident(&'a Audio),
    ResidentMono(&'a OwnedShared<MonoSourceData>),
    Streamed(&'a OwnedShared<StreamedSourceMetadata>),
}
pub(crate) trait SourceStorage: std::any::Any {
    fn storage_kind(&self) -> SourceStorageKind<'_>;
    fn storage_handle(&self) -> u64;
}
impl SourceStorage for OwnedAudioSource {
    fn storage_kind(&self) -> SourceStorageKind<'_> {
        match &self.kind {
            SourceKind::Resident(audio) => SourceStorageKind::Resident(audio),
            SourceKind::ResidentMono(source) => SourceStorageKind::ResidentMono(source),
            SourceKind::Streamed(source) => SourceStorageKind::Streamed(source),
        }
    }
    fn storage_handle(&self) -> u64 {
        self.handle
    }
}
impl OwnedAudioSource {
    /// Borrow an actual constructor-qualified Audio owner and reserve a closed
    /// source header/identity BEFORE its control-side alias is created.
    pub fn alias_native_audio_on_control(
        audio: &Audio,
        max_metadata_bytes: usize,
    ) -> Result<Self, AudioStorageError> {
        if std::mem::size_of::<Self>() > max_metadata_bytes {
            return Err(AudioStorageError::ReservationExceeded);
        }
        audio
            .pcm_arc_receipt
            .and_then(|receipt| receipt.checked_allocations(audio))
            .ok_or(AudioStorageError::UnknownStorage)?;
        if std::sync::Arc::weak_count(&audio.frames) != 0 {
            return Err(AudioStorageError::UnknownStorage);
        }
        let handle = handle()?;
        Ok(Self {
            kind: SourceKind::Resident(audio.clone_with_native_handle_on_control(Some(handle))),
            handle,
        })
    }
    /// Quote the actual source header before creating a closed native control
    /// alias. Both physical owners must join coexistence/retirement accounting.
    /// This never adopts raw/derived Audio or grants graph publication.
    pub fn alias_for_resource_plan_on_control(
        &self,
        max_metadata_bytes: usize,
    ) -> Result<Self, AudioStorageError> {
        if std::mem::size_of::<Self>() > max_metadata_bytes {
            return Err(AudioStorageError::ReservationExceeded);
        }
        if matches!(self.kind, SourceKind::Streamed(_)) {
            return Err(AudioStorageError::UnsupportedGraph);
        }
        crate::audio_input_storage::parts(self)?;
        let handle = handle()?;
        let kind = match &self.kind {
            SourceKind::Resident(audio) => {
                SourceKind::Resident(audio.clone_with_native_handle_on_control(Some(handle)))
            }
            SourceKind::ResidentMono(source) => SourceKind::ResidentMono(source.clone_on_control()),
            SourceKind::Streamed(_) => return Err(AudioStorageError::UnsupportedGraph),
        };
        Ok(Self { kind, handle })
    }
    /// Actual retained PCM capacity, in source frames. This is a control-side
    /// observation, not a complete graph memory or lifetime declaration.
    pub fn resident_pcm_capacity_frames(&self) -> Option<usize> {
        match &self.kind {
            SourceKind::Resident(audio) => Some(audio.pcm_capacity_frames()),
            SourceKind::ResidentMono(source) => Some(source.samples.capacity()),
            SourceKind::Streamed(_) => None,
        }
    }
    /// Borrow this actual unbound decoded owner before an AssetId/bank exists.
    pub fn view(&self) -> OwnedAudioSourceView<'_> {
        OwnedAudioSourceView { kind: &self.kind }
    }
    /// Move a known native stereo owner into the existing clip/media Audio
    /// representation, conserving the same physical owning handle and PCM.
    /// Mono/streamed/refused owners return intact; no raw Arc escapes.
    pub fn try_into_native_audio_on_control(self) -> Result<Audio, Box<NativeAudioMoveRefusal>> {
        let known = match &self.kind {
            SourceKind::Resident(audio) => {
                audio.native_handle.map(|h| h.get()) == Some(self.handle)
                    && audio
                        .pcm_arc_receipt
                        .and_then(|r| r.checked_allocations(audio))
                        .is_some()
            }
            _ => false,
        };
        if !known {
            let reason = if matches!(&self.kind, SourceKind::Resident(_)) {
                AudioStorageError::UnknownStorage
            } else {
                AudioStorageError::UnsupportedGraph
            };
            return Err(Box::new(NativeAudioMoveRefusal {
                reason,
                source: self,
            }));
        }
        match self.kind {
            SourceKind::Resident(audio) => Ok(audio),
            kind => Err(Box::new(NativeAudioMoveRefusal {
                reason: AudioStorageError::UnsupportedGraph,
                source: Self {
                    kind,
                    handle: self.handle,
                },
            })),
        }
    }
    /// Consume actual native Audio lineage. Unknown/caller-created Arc values
    /// are never adopted, and Arc counts cannot establish this provenance.
    pub fn try_from_native_audio_on_control(
        audio: Audio,
    ) -> Result<Self, Box<NativeAudioIngressRefusal>> {
        let handle = audio.native_handle.map(|h| h.get()).filter(|_| {
            audio
                .pcm_arc_receipt
                .and_then(|r| r.checked_allocations(&audio))
                .is_some()
                && std::sync::Arc::weak_count(&audio.frames) == 0
        });
        match handle {
            Some(handle) => Ok(Self {
                kind: SourceKind::Resident(audio),
                handle,
            }),
            None => Err(Box::new(NativeAudioIngressRefusal {
                reason: AudioStorageError::UnknownStorage,
                audio,
            })),
        }
    }
    /// Exact mono custody in the existing native source/bank ownership family.
    /// Refusals precede the owning wrapper allocation and return the same Vec.
    pub fn try_resident_mono(
        sample_rate: u32,
        samples: Vec<f32>,
    ) -> Result<Self, ResidentMonoSourceRefusal> {
        let checked = (|| {
            if sample_rate == 0 {
                return Err(AudioStorageError::InvalidRate);
            }
            if samples.is_empty() || samples.iter().any(|v| !v.is_finite()) {
                return Err(AudioStorageError::InvalidSamples);
            }
            OwnedShared::<MonoSourceData>::declared_parts()
                .ok_or(AudioStorageError::UnsupportedConstructor)?;
            samples
                .capacity()
                .checked_mul(std::mem::size_of::<f32>())
                .ok_or(AudioStorageError::Overflow)?;
            handle()
        })();
        match checked {
            Err(reason) => Err(ResidentMonoSourceRefusal { reason, samples }),
            Ok(handle) => Ok(Self {
                kind: SourceKind::ResidentMono(OwnedShared::new_owned(MonoSourceData {
                    sample_rate,
                    samples,
                })),
                handle,
            }),
        }
    }
    /// All reported refusals precede the Arc wrapper allocation; original pointer/capacity survive.
    /// Process-fatal allocator OOM/abort is outside API-reported recovery.
    pub fn try_resident(rate: u32, frames: Vec<Frame>) -> Result<Self, ResidentSourceRefusal> {
        Self::resident_with_gate(rate, frames, crate::pcm_arc::native_layout_known())
    }
    fn resident_with_gate(
        rate: u32,
        frames: Vec<Frame>,
        gate: bool,
    ) -> Result<Self, ResidentSourceRefusal> {
        let result = (|| {
            if rate == 0 {
                return Err(AudioStorageError::InvalidRate);
            }
            if frames.is_empty() || frames.iter().flatten().any(|v| !v.is_finite()) {
                return Err(AudioStorageError::InvalidSamples);
            }
            if !gate {
                return Err(AudioStorageError::UnsupportedConstructor);
            }
            let receipt = crate::pcm_arc::PcmArcReceipt::current(frames.len(), frames.capacity())
                .ok_or(AudioStorageError::UnsupportedConstructor)?;
            let handle = handle()?;
            Ok((receipt, handle))
        })();
        match result {
            Err(reason) => Err(ResidentSourceRefusal { reason, frames }),
            Ok((receipt, handle)) => Ok(Self {
                kind: SourceKind::Resident(Audio {
                    sample_rate: rate,
                    frames: std::sync::Arc::new(crate::AudioData {
                        values: frames,
                        _derived: None,
                    }),
                    pcm_arc_receipt: Some(receipt),
                    native_handle: std::num::NonZeroU64::new(handle),
                }),
                handle,
            }),
        }
    }
    /// Metadata was numerically validated by its value constructor; copying a
    /// value into a NEW owned allocation never adopts a caller-created Arc.
    /// Error boxing is control-only and follows existing fatal-OOM semantics.
    pub fn try_streamed(
        metadata: StreamedSourceMetadata,
    ) -> Result<Self, Box<StreamedSourceRefusal>> {
        let result = (|| {
            if !crate::pcm_arc::native_layout_known() {
                return Err(AudioStorageError::UnsupportedConstructor);
            }
            handle()
        })();
        match result {
            Err(reason) => Err(Box::new(StreamedSourceRefusal { reason, metadata })),
            Ok(handle) => Ok(Self {
                kind: SourceKind::Streamed(OwnedShared::new_owned(metadata)),
                handle,
            }),
        }
    }
    // No public bare owning clone. OriginalSourceLease's bounded control-only
    // plan alias returns this same closed source type, with a distinct handle;
    // both banks must be included in the real coexistence ledger.
    pub fn sample_rate(&self) -> u32 {
        match &self.kind {
            SourceKind::Resident(a) => a.sample_rate(),
            SourceKind::ResidentMono(source) => source.sample_rate,
            SourceKind::Streamed(s) => s.project_rate(),
        }
    }
    pub fn frames(&self) -> u64 {
        match &self.kind {
            SourceKind::Resident(a) => a.frames.len() as u64,
            SourceKind::ResidentMono(source) => source.samples.len() as u64,
            SourceKind::Streamed(s) => s.playback_frames(),
        }
    }
}
/// Original order and source Vec capacity are preserved. Lookup is control-only;
/// no temporary BTreeMap, sorted-copy bank or public graph owner is introduced.
#[derive(Default)]
pub(crate) struct AliasRow {
    incarnation: u64,
    pub(crate) owner: Option<OwnedAudioSource>,
    pub(crate) source: usize,
}
/// Checked NONOWNING token; no Clone, scalar constructor or source owner.
pub struct AudioSourceToken {
    bank: u64,
    custodian: u64,
    source: usize,
    source_handle: u64,
    alias: Option<(usize, u64, u64)>,
}
/// Borrowed leaf-only view tied to the actual live bank, never to a token alone.
pub struct OwnedAudioSourceView<'a> {
    kind: &'a SourceKind,
}
impl<'a> OwnedAudioSourceView<'a> {
    pub fn sample_rate(&self) -> u32 {
        match self.kind {
            SourceKind::Resident(a) => a.sample_rate(),
            SourceKind::ResidentMono(source) => source.sample_rate,
            SourceKind::Streamed(s) => s.project_rate(),
        }
    }
    pub fn resident_frames(&self) -> Option<&'a [Frame]> {
        match self.kind {
            SourceKind::Resident(a) => Some(a.frames()),
            _ => None,
        }
    }
    pub fn resident_mono_samples(&self) -> Option<&'a [f32]> {
        match self.kind {
            SourceKind::ResidentMono(source) => Some(&source.samples),
            _ => None,
        }
    }
    pub fn streamed_metadata(&self) -> Option<&StreamedSourceMetadata> {
        match self.kind {
            SourceKind::Streamed(s) => Some(s.as_ref()),
            _ => None,
        }
    }
}
#[cfg(test)]
pub(crate) struct OriginalInputDropProbe(pub(crate) Option<Box<dyn FnOnce() + Send + Sync>>);
#[cfg(test)]
impl Drop for OriginalInputDropProbe {
    fn drop(&mut self) {
        if let Some(f) = self.0.take() {
            f();
        }
    }
}
pub struct OwnedAudioInputs {
    #[cfg(test)]
    pub(crate) drop_probe: Option<OriginalInputDropProbe>,
    bank: u64,
    custodian: u64,
    pub(crate) aliases: Vec<AliasRow>,
    pub(crate) reservation: AudioStorageReservation,
    pub(crate) sources: Vec<(AssetId, OwnedAudioSource)>,
    pub(crate) capacity: AudioPreparationCapacity,
}
pub struct AudioInputsRefusal {
    pub reason: AudioStorageError,
    pub sources: Vec<(AssetId, OwnedAudioSource)>,
    pub reservation: AudioStorageReservation,
    pub capacity: AudioPreparationCapacity,
}
impl OwnedAudioInputs {
    /// Scalar conservation observation only; no source/vector/owner escapes.
    #[cfg(any(test, feature = "instrument-test-support"))]
    pub fn test_bank_identity(&self) -> (usize, usize, u64, u64) {
        (
            self.sources.as_ptr() as usize,
            self.sources.capacity(),
            self.bank,
            self.custodian,
        )
    }
    pub fn try_new(
        sources: Vec<(AssetId, OwnedAudioSource)>,
        reservation: AudioStorageReservation,
    ) -> Result<Self, Box<AudioInputsRefusal>> {
        let mut capacity = AudioPreparationCapacity {
            original_source_capacity: sources.capacity(),
            ..AudioPreparationCapacity::default()
        };
        match Self::prepare_sources(&sources, reservation, &mut capacity) {
            Ok((aliases, bank)) => Ok(Self {
                #[cfg(test)]
                drop_probe: None,
                sources,
                capacity,
                bank,
                custodian: 1,
                aliases,
                reservation,
            }),
            Err(reason) => Err(Box::new(AudioInputsRefusal {
                reason,
                sources,
                reservation,
                capacity,
            })),
        }
    }
    /// A host-held source collection remains in its persistent destination
    /// throughout every fallible bank validation/allocation. On success only
    /// fixed moves occur into the already-empty destination. No source owner is
    /// returned in a transient error or dropped on refusal.
    pub fn try_new_in_place(
        sources: &mut Vec<(AssetId, OwnedAudioSource)>,
        reservation: AudioStorageReservation,
        destination: &mut Option<Self>,
    ) -> Result<(), AudioStorageError> {
        if destination.is_some() {
            return Err(AudioStorageError::SourceMismatch);
        }
        let mut capacity = AudioPreparationCapacity {
            original_source_capacity: sources.capacity(),
            ..AudioPreparationCapacity::default()
        };
        let (aliases, bank) = Self::prepare_sources(sources, reservation, &mut capacity)?;
        *destination = Some(Self {
            #[cfg(test)]
            drop_probe: None,
            sources: std::mem::take(sources),
            capacity,
            bank,
            custodian: 1,
            aliases,
            reservation,
        });
        Ok(())
    }
    fn prepare_sources(
        sources: &[(AssetId, OwnedAudioSource)],
        reservation: AudioStorageReservation,
        capacity: &mut AudioPreparationCapacity,
    ) -> Result<(Vec<AliasRow>, u64), AudioStorageError> {
        let mut aliases = Vec::new();
        capacity.source_container_bytes = capacity
            .original_source_capacity
            .checked_mul(std::mem::size_of::<(AssetId, OwnedAudioSource)>())
            .ok_or(AudioStorageError::Overflow)?;
        let alias_limit = reservation
            .handle_obligations
            .checked_sub(sources.len())
            .ok_or(AudioStorageError::Capacity)?;
        // Reject a known-insufficient caller allowance before allocating the
        // alias backing; actual allocator capacity is still checked below.
        let requested = alias_limit
            .checked_mul(std::mem::size_of::<AliasRow>())
            .and_then(|n| n.checked_add(capacity.source_container_bytes))
            .and_then(|n| n.checked_add(std::mem::size_of::<Self>()))
            .and_then(|n| n.checked_add(reservation.caller_retained_bytes))
            .ok_or(AudioStorageError::Overflow)?;
        if requested > reservation.max_prepared_data_bytes
            || requested
                .checked_add(reservation.caller_construction_bytes)
                .is_none_or(|n| n > reservation.max_construction_data_bytes)
        {
            return Err(AudioStorageError::ReservationExceeded);
        }
        aliases
            .try_reserve_exact(alias_limit)
            .map_err(|_| AudioStorageError::Allocation)?;
        capacity.alias_capacity = aliases.capacity();
        capacity.alias_container_bytes = aliases
            .capacity()
            .checked_mul(std::mem::size_of::<AliasRow>())
            .ok_or(AudioStorageError::Overflow)?;
        capacity.bank_container_bytes = std::mem::size_of::<Self>();
        let retained = capacity
            .source_container_bytes
            .checked_add(capacity.alias_container_bytes)
            .and_then(|n| n.checked_add(capacity.bank_container_bytes))
            .ok_or(AudioStorageError::Overflow)?;
        let retained = retained
            .checked_add(reservation.caller_retained_bytes)
            .ok_or(AudioStorageError::Overflow)?;
        let peak = retained
            .checked_add(reservation.caller_construction_bytes)
            .ok_or(AudioStorageError::Overflow)?;
        if retained > reservation.max_prepared_data_bytes
            || peak > reservation.max_construction_data_bytes
        {
            return Err(AudioStorageError::ReservationExceeded);
        }
        let mut allocation_count = 0_usize;
        for (index, (_, source)) in sources.iter().enumerate() {
            if !sources[..index]
                .iter()
                .any(|(_, old)| crate::audio_input_storage::same(old, source))
            {
                allocation_count = allocation_count
                    .checked_add(match &source.kind {
                        SourceKind::Resident(_) | SourceKind::ResidentMono(_) => 2,
                        SourceKind::Streamed(_) => 1,
                    })
                    .ok_or(AudioStorageError::Overflow)?;
            }
        }
        if sources.len() > reservation.handle_obligations
            || allocation_count > reservation.allocation_items
        {
            return Err(AudioStorageError::Capacity);
        }
        for (index, (id, _)) in sources.iter().enumerate() {
            if sources[..index].iter().any(|(previous, _)| previous == id) {
                return Err(AudioStorageError::DuplicateAsset);
            }
        }
        // These are only actual BANK container observations, never complete
        // graph/domain/allocator-memory totals or a prepared admission.
        let bank = handle()?;
        aliases.resize_with(
            reservation.handle_obligations - sources.len(),
            AliasRow::default,
        );
        Ok((aliases, bank))
    }
}

impl OwnedAudioInputs {
    pub fn source_token(&self, asset: AssetId) -> Result<AudioSourceToken, AudioStorageError> {
        let index = self
            .sources
            .iter()
            .position(|(id, _)| *id == asset)
            .ok_or(AudioStorageError::SourceMismatch)?;
        Ok(AudioSourceToken {
            bank: self.bank,
            custodian: self.custodian,
            source: index,
            source_handle: self.sources[index].1.handle,
            alias: None,
        })
    }
    pub(crate) fn checked_source(
        &self,
        token: &AudioSourceToken,
    ) -> Result<&OwnedAudioSource, AudioStorageError> {
        if token.bank != self.bank || token.custodian != self.custodian {
            return Err(AudioStorageError::SourceMismatch);
        }
        let original = self
            .sources
            .get(token.source)
            .map(|(_, source)| source)
            .filter(|source| source.handle == token.source_handle)
            .ok_or(AudioStorageError::SourceMismatch)?;
        match token.alias {
            None => Ok(original),
            Some((index, incarnation, handle)) => self
                .aliases
                .get(index)
                .filter(|row| row.source == token.source && row.incarnation == incarnation)
                .and_then(|row| row.owner.as_ref())
                .filter(|owner| owner.handle == handle)
                .ok_or(AudioStorageError::SourceMismatch),
        }
    }
    pub fn source_view(
        &self,
        token: &AudioSourceToken,
    ) -> Result<OwnedAudioSourceView<'_>, AudioStorageError> {
        Ok(OwnedAudioSourceView {
            kind: &self.checked_source(token)?.kind,
        })
    }
    /// All destinations/identities are preflighted before cloning. No owning
    /// clone is returned: both actual handles remain inside bank custody.
    pub fn alias_on_control(
        &mut self,
        token: &AudioSourceToken,
    ) -> Result<AudioSourceToken, AudioStorageError> {
        self.checked_source(token)?;
        let index = self
            .aliases
            .iter()
            .position(|row| row.owner.is_none())
            .ok_or(AudioStorageError::Capacity)?;
        let incarnation = self.aliases[index]
            .incarnation
            .checked_add(1)
            .ok_or(AudioStorageError::HandleExhausted)?;
        let handle = handle()?;
        let kind = match &self.checked_source(token)?.kind {
            SourceKind::Resident(audio) => {
                SourceKind::Resident(audio.clone_with_native_handle_on_control(Some(handle)))
            }
            SourceKind::ResidentMono(source) => SourceKind::ResidentMono(source.clone_on_control()),
            SourceKind::Streamed(source) => SourceKind::Streamed(source.clone_on_control()),
        };
        self.aliases[index] = AliasRow {
            incarnation,
            source: token.source,
            owner: Some(OwnedAudioSource { kind, handle }),
        };
        Ok(AudioSourceToken {
            bank: self.bank,
            custodian: self.custodian,
            source: token.source,
            source_handle: token.source_handle,
            alias: Some((index, incarnation, handle)),
        })
    }
    /// Scalar rejection returns the original nonowning token. The original
    /// source remains anchored, so retiring an alias cannot final-drop its data.
    pub fn retire_alias_on_control(
        &mut self,
        token: AudioSourceToken,
    ) -> Result<(), (AudioStorageError, AudioSourceToken)> {
        if let Err(reason) = self.checked_source(&token) {
            return Err((reason, token));
        }
        let Some((index, _, _)) = token.alias else {
            return Err((AudioStorageError::SourceMismatch, token));
        };
        drop(self.aliases[index].owner.take());
        Ok(())
    }
    pub fn capacity_report(&self) -> AudioPreparationCapacity {
        self.capacity
    }
    pub fn owning_handle_count(&self) -> usize {
        self.sources.len()
            + self
                .aliases
                .iter()
                .filter(|row| row.owner.is_some())
                .count()
    }
    /// Only the final infallible preparation commit may install this previously
    /// checked nonce. Errors never mutate token validity or alias owners.
    pub(crate) fn next_custodian(&self) -> Result<u64, AudioStorageError> {
        self.custodian
            .checked_add(1)
            .ok_or(AudioStorageError::HandleExhausted)
    }
    pub(crate) fn commit_custodian(&mut self, next: u64) {
        self.custodian = next;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn ids() -> Vec<AssetId> {
        let mut editor =
            hex_project::Editor::new(hex_project::Project::new(48_000).unwrap(), 8).unwrap();
        (0..3)
            .map(|n| {
                let hex_project::Created::Asset(id) = editor
                    .execute(hex_project::Command::AddAsset {
                        path: format!("source-{n}.wav").into(),
                        sample_rate: 48_000,
                        frames: 8,
                    })
                    .unwrap()
                else {
                    panic!("asset");
                };
                id
            })
            .collect()
    }
    fn reservation() -> AudioStorageReservation {
        AudioStorageReservation {
            allocation_items: 8,
            handle_obligations: 8,
            max_prepared_data_bytes: usize::MAX,
            max_construction_data_bytes: usize::MAX,
            caller_retained_bytes: 0,
            caller_construction_bytes: 0,
        }
    }
    fn copy_negative(token: &AudioSourceToken) -> AudioSourceToken {
        AudioSourceToken {
            bank: token.bank,
            custodian: token.custodian,
            source: token.source,
            source_handle: token.source_handle,
            alias: token.alias,
        }
    }
    fn constructor_supported(test: &str) -> bool {
        if crate::pcm_arc::native_layout_known() {
            eprintln!("hex audio bank evidence: {test}; branch=supported-constructor");
            return true;
        }
        let refusal = OwnedAudioSource::try_resident(48_000, vec![[0.0; 2]])
            .err()
            .unwrap();
        assert_eq!(refusal.reason, AudioStorageError::UnsupportedConstructor);
        eprintln!("hex audio bank evidence: {test}; branch=unsupported-refusal");
        false
    }
    #[test]
    fn in_place_bank_refusal_and_transfer_preserve_actual_collection_backing() {
        if !constructor_supported("rooted_source_collection") {
            return;
        }
        let ids = ids();
        let source = OwnedAudioSource::try_resident(48_000, vec![[0.5; 2]; 8])
            .ok()
            .unwrap();
        let handle = source.handle;
        let mut sources = Vec::with_capacity(5);
        sources.push((ids[0], source));
        let original = (sources.as_ptr(), sources.capacity());
        let mut destination = None;
        let mut insufficient = reservation();
        insufficient.handle_obligations = 0;
        assert_eq!(
            OwnedAudioInputs::try_new_in_place(&mut sources, insufficient, &mut destination),
            Err(AudioStorageError::Capacity)
        );
        assert_eq!((sources.as_ptr(), sources.capacity()), original);
        assert_eq!(sources[0].1.handle, handle);
        assert!(destination.is_none());
        let mut insufficient = reservation();
        insufficient.max_prepared_data_bytes = 1;
        assert_eq!(
            OwnedAudioInputs::try_new_in_place(&mut sources, insufficient, &mut destination),
            Err(AudioStorageError::ReservationExceeded)
        );
        assert_eq!((sources.as_ptr(), sources.capacity()), original);
        assert_eq!(sources[0].1.handle, handle);
        assert!(destination.is_none());
        OwnedAudioInputs::try_new_in_place(&mut sources, reservation(), &mut destination).unwrap();
        assert!(sources.is_empty());
        assert_eq!(sources.capacity(), 0);
        let bank = destination.as_ref().unwrap();
        assert_eq!((bank.sources.as_ptr(), bank.sources.capacity()), original);
        assert_eq!(bank.sources[0].1.handle, handle);
        let bank_identity = bank.test_bank_identity();
        assert_eq!(
            OwnedAudioInputs::try_new_in_place(&mut sources, reservation(), &mut destination),
            Err(AudioStorageError::SourceMismatch)
        );
        assert_eq!(
            destination.as_ref().unwrap().test_bank_identity(),
            bank_identity
        );
    }
    #[test]
    fn retained_vec_capacity_and_wrapper_are_independent_charges_without_pcm_copy() {
        if !constructor_supported("retained_vec_pair") {
            return;
        }
        let mut frames = Vec::with_capacity(73);
        frames.resize(8, [0.5; 2]);
        let pointer = frames.as_ptr();
        let capacity = frames.capacity();
        let source = OwnedAudioSource::try_resident(48_000, frames).ok().unwrap();
        let SourceKind::Resident(audio) = &source.kind else {
            panic!("resident");
        };
        assert_eq!(audio.frames.values.as_ptr(), pointer);
        let charges = audio
            .pcm_arc_receipt
            .unwrap()
            .checked_allocations(audio)
            .unwrap();
        assert_eq!(charges[0].0, std::mem::size_of::<crate::AudioData>());
        assert_eq!(charges[1], (capacity * std::mem::size_of::<Frame>(), 0));
        assert!(charges[1].0 > audio.frames.len() * std::mem::size_of::<Frame>());
        let ids = ids();
        let mut bank = OwnedAudioInputs::try_new(vec![(ids[0], source)], reservation())
            .ok()
            .unwrap();
        let token = bank.source_token(ids[0]).unwrap();
        let _first = bank.alias_on_control(&token).unwrap();
        let _second = bank.alias_on_control(&token).unwrap();
        let output = bank.prepare_input_storage_on_control().ok().unwrap();
        assert_eq!(output.summary().unique_allocations, 2);
        assert_eq!(output.summary().unresolved_handles, 3);
        assert_eq!(
            output.summary().declared_source_data_bytes,
            charges.iter().map(|(p, o)| p + o).sum()
        );
        output.validate_unresolved_on_control().unwrap();
    }
    #[test]
    fn raw_constructor_never_inherits_sealed_resident_provenance() {
        let raw = OwnedAudioSource {
            kind: SourceKind::Resident(Audio::new(48_000, vec![[0.0; 2]; 8]).unwrap()),
            handle: handle().unwrap(),
        };
        assert_eq!(
            crate::audio_input_storage::parts(&raw),
            Err(AudioStorageError::UnknownStorage)
        );
    }
    #[test]
    fn original_frame_owners_survive_numerical_and_unsupported_origin_refusal() {
        for (rate, sample, gate, expected) in [
            (0, 0.0, true, AudioStorageError::InvalidRate),
            (48_000, f32::NAN, true, AudioStorageError::InvalidSamples),
            (
                48_000,
                0.0,
                false,
                AudioStorageError::UnsupportedConstructor,
            ),
        ] {
            let mut frames = Vec::with_capacity(19);
            frames.push([sample; 2]);
            let pointer = frames.as_ptr();
            let capacity = frames.capacity();
            let refusal = OwnedAudioSource::resident_with_gate(rate, frames, gate)
                .err()
                .unwrap();
            assert_eq!(refusal.reason, expected);
            assert_eq!(refusal.frames.as_ptr(), pointer);
            assert_eq!(refusal.frames.capacity(), capacity);
        }
    }
    #[test]
    fn aliases_are_bank_owned_tokens_refuse_wrong_stale_duplicate_and_overflow() {
        if !constructor_supported("bank_aliases") {
            return;
        }
        let ids = ids();
        let make = || {
            OwnedAudioSource::try_resident(48_000, vec![[0.25; 2]; 8])
                .ok()
                .unwrap()
        };
        let mut bank = OwnedAudioInputs::try_new(vec![(ids[0], make())], reservation())
            .ok()
            .unwrap();
        let other = OwnedAudioInputs::try_new(vec![(ids[0], make())], reservation())
            .ok()
            .unwrap();
        let original = bank.source_token(ids[0]).unwrap();
        let alias = bank.alias_on_control(&original).unwrap();
        let stale = copy_negative(&alias);
        assert_eq!(bank.owning_handle_count(), 2);
        assert!(other.source_view(&alias).is_err());
        assert_eq!(
            bank.source_view(&alias).unwrap().resident_frames().unwrap()[0],
            [0.25; 2]
        );
        bank.retire_alias_on_control(alias).ok().unwrap();
        assert!(bank.source_view(&stale).is_err());
        let (_, stale) = bank.retire_alias_on_control(stale).err().unwrap();
        let replacement = bank.alias_on_control(&original).unwrap();
        assert!(bank.source_view(&stale).is_err());
        assert!(bank.source_view(&replacement).is_ok());
        bank.retire_alias_on_control(replacement).ok().unwrap();
        bank.aliases[0].incarnation = u64::MAX;
        let before = bank.owning_handle_count();
        assert!(matches!(
            bank.alias_on_control(&original),
            Err(AudioStorageError::HandleExhausted)
        ));
        assert_eq!(bank.owning_handle_count(), before);
        assert!(bank.source_view(&original).is_ok());
        eprintln!("hex audio bank evidence: bank_aliases; supported-controls=completed");
    }
    #[test]
    fn duplicate_and_byte_refusal_return_original_source_vector_and_capacity() {
        if !constructor_supported("bank_duplicate_and_bytes") {
            return;
        }
        let ids = ids();
        for duplicate in [true, false] {
            let mut sources = Vec::with_capacity(17);
            for id in [ids[0], if duplicate { ids[0] } else { ids[1] }] {
                sources.push((
                    id,
                    OwnedAudioSource::try_resident(48_000, vec![[0.0; 2]; 8])
                        .ok()
                        .unwrap(),
                ));
            }
            let pointer = sources.as_ptr();
            let capacity = sources.capacity();
            let mut limit = reservation();
            if !duplicate {
                limit.max_prepared_data_bytes = 0;
            }
            let refusal = OwnedAudioInputs::try_new(sources, limit).err().unwrap();
            assert_eq!(
                refusal.reason,
                if duplicate {
                    AudioStorageError::DuplicateAsset
                } else {
                    AudioStorageError::ReservationExceeded
                }
            );
            assert_eq!(refusal.sources.as_ptr(), pointer);
            assert_eq!(refusal.sources.capacity(), capacity);
            assert_eq!(refusal.reservation, limit);
        }
        eprintln!(
            "hex audio bank evidence: bank_duplicate_and_bytes; supported-controls=completed"
        );
    }
    #[test]
    fn typed_bank_data_dedups_allocations_never_handles_and_commit_invalidates_old_tokens() {
        if !constructor_supported("typed_bank_data") {
            return;
        }
        let ids = ids();
        let make = || {
            OwnedAudioSource::try_resident(48_000, vec![[0.5; 2]; 8])
                .ok()
                .unwrap()
        };
        let mut bank =
            OwnedAudioInputs::try_new(vec![(ids[0], make()), (ids[1], make())], reservation())
                .ok()
                .unwrap();
        let token = bank.source_token(ids[0]).unwrap();
        let _one = bank.alias_on_control(&token).unwrap();
        let _two = bank.alias_on_control(&token).unwrap();
        assert_eq!(bank.owning_handle_count(), 4);
        let output = bank.prepare_input_storage_on_control().ok().unwrap();
        assert_eq!(output.summary().unique_allocations, 4); // two allocations per distinct PCM owner
        assert_eq!(output.summary().unresolved_handles, 4);
        assert!(output.validate_unresolved_on_control().is_ok());
        assert!(output.source_view(&token).is_err());
        assert!(
            output
                .source_view(&output.source_token(ids[0]).unwrap())
                .is_ok()
        );
        eprintln!("hex audio bank evidence: typed_bank_data; supported-controls=completed");
    }
    #[test]
    fn actual_streamed_constructor_and_refusal_preserve_alias_custody_and_tokens() {
        let ids = ids();
        let metadata = StreamedSourceMetadata::new(
            crate::StreamSourceKey::new(11, ids[0]),
            48_000,
            48_000,
            8,
            8,
            hex_project::IDENTITY_CONVERSION,
            [9; 32],
        )
        .unwrap();
        if !crate::pcm_arc::native_layout_known() {
            assert_eq!(
                OwnedAudioSource::try_streamed(metadata)
                    .err()
                    .unwrap()
                    .reason,
                AudioStorageError::UnsupportedConstructor
            );
            eprintln!("hex audio bank evidence: streamed_bank; branch=unsupported-refusal");
            return;
        }
        let source = OwnedAudioSource::try_streamed(metadata.clone())
            .ok()
            .unwrap();
        eprintln!("hex audio bank evidence: streamed_bank; branch=supported-constructor");
        let mut bank = OwnedAudioInputs::try_new(vec![(ids[0], source)], reservation())
            .ok()
            .unwrap();
        let original = bank.source_token(ids[0]).unwrap();
        let alias = bank.alias_on_control(&original).unwrap();
        let pointer = bank.sources.as_ptr();
        let capacity = bank.sources.capacity();
        bank.custodian = u64::MAX; // checked commit overflow BEFORE any move
        let mut alias = alias;
        alias.custodian = u64::MAX;
        let refusal = bank.prepare_input_storage_on_control().err().unwrap();
        assert_eq!(refusal.reason, AudioStorageError::HandleExhausted);
        assert_eq!(refusal.inputs.sources.as_ptr(), pointer);
        assert_eq!(refusal.inputs.sources.capacity(), capacity);
        assert_eq!(refusal.inputs.owning_handle_count(), 2);
        assert_eq!(
            refusal
                .inputs
                .source_view(&alias)
                .unwrap()
                .streamed_metadata(),
            Some(&metadata)
        );
        eprintln!("hex audio bank evidence: streamed_bank; supported-controls=completed");
    }
    #[test]
    fn borrowed_ledger_conserves_capacity_distinct_owners_and_caller_aliases() {
        if !constructor_supported("borrowed_ledger_aliases") {
            return;
        }
        let ids = ids();
        let make = || {
            let mut pcm = Vec::with_capacity(73);
            pcm.resize(8, [0.5; 2]);
            OwnedAudioSource::try_resident(48_000, pcm).ok().unwrap()
        };
        let mut bank =
            OwnedAudioInputs::try_new(vec![(ids[0], make()), (ids[1], make())], reservation())
                .ok()
                .unwrap();
        let token = bank.source_token(ids[0]).unwrap();
        bank.alias_on_control(&token).unwrap();
        bank.alias_on_control(&token).unwrap();
        let expected_data = std::mem::size_of::<OwnedAudioInputs>()
            + bank.capacity.source_container_bytes
            + bank.capacity.alias_container_bytes
            + bank
                .sources
                .iter()
                .map(|(_, s)| {
                    let (p, o) = crate::audio_input_storage::parts(s).unwrap();
                    p + o
                })
                .sum::<usize>();
        let r = crate::AudioStorageLedgerReservation {
            data_rows: 32,
            handle_rows: 16,
            root_rows: 4,
            max_retained_bytes: usize::MAX,
            max_construction_peak_bytes: usize::MAX,
        };
        let mut ledger = crate::AudioRootStorageLedger::try_new_on_control(r).unwrap();
        ledger.borrow_caller_inputs_on_control(&bank).unwrap();
        let summary = ledger.summary().unwrap();
        assert_eq!(summary.unresolved_handles, 4);
        assert_eq!(summary.data_allocations, 6);
        assert_eq!(summary.data_bytes, expected_data);
        assert_eq!(summary.unknown_storage, 0);
        drop(ledger);
        assert!(bank.source_view(&token).is_ok());
        let mut bad = crate::AudioRootStorageLedger::try_new_on_control(r).unwrap();
        bad.borrow_caller_inputs_on_control(&bank).unwrap();
        assert_eq!(
            bad.borrow_caller_inputs_on_control(&bank),
            Err(AudioStorageError::SourceMismatch)
        );
        assert_eq!(bad.summary(), Err(AudioStorageError::UnknownStorage));
    }

    #[test]
    fn borrowed_ledger_refuses_raw_weak_and_ambiguous_caller_costs() {
        if !constructor_supported("borrowed_ledger_refusals") {
            return;
        }
        let ids = ids();
        let r = crate::AudioStorageLedgerReservation {
            data_rows: 32,
            handle_rows: 16,
            root_rows: 4,
            max_retained_bytes: usize::MAX,
            max_construction_peak_bytes: usize::MAX,
        };
        for raw in [false, true] {
            let mut bank = OwnedAudioInputs::try_new(
                vec![(
                    ids[0],
                    OwnedAudioSource::try_resident(48_000, vec![[0.0; 2]; 8])
                        .ok()
                        .unwrap(),
                )],
                reservation(),
            )
            .ok()
            .unwrap();
            let SourceKind::Resident(audio) = &mut bank.sources[0].1.kind else {
                panic!("resident")
            };
            if raw {
                audio.pcm_arc_receipt = None;
            }
            let observer = std::sync::Arc::downgrade(&audio.frames);
            let pointer = bank.sources.as_ptr();
            let mut ledger = crate::AudioRootStorageLedger::try_new_on_control(r).unwrap();
            assert_eq!(
                ledger.borrow_caller_inputs_on_control(&bank),
                Err(AudioStorageError::UnknownStorage)
            );
            drop(ledger);
            drop(observer);
            assert_eq!(bank.sources.as_ptr(), pointer);
            if raw {
                let mut ledger = crate::AudioRootStorageLedger::try_new_on_control(r).unwrap();
                assert_eq!(
                    ledger.borrow_caller_inputs_on_control(&bank),
                    Err(AudioStorageError::UnknownStorage)
                );
            }
            if !raw {
                let mut ledger = crate::AudioRootStorageLedger::try_new_on_control(r).unwrap();
                ledger.borrow_caller_inputs_on_control(&bank).unwrap();
                assert!(ledger.summary().unwrap().require_known_storage().is_ok());
            }
        }
        let mut bank = OwnedAudioInputs::try_new(
            vec![(
                ids[0],
                OwnedAudioSource::try_resident(48_000, vec![[0.0; 2]; 8])
                    .ok()
                    .unwrap(),
            )],
            reservation(),
        )
        .ok()
        .unwrap();
        bank.reservation.caller_retained_bytes = 1;
        let mut ledger = crate::AudioRootStorageLedger::try_new_on_control(r).unwrap();
        ledger.borrow_caller_inputs_on_control(&bank).unwrap();
        assert_eq!(
            ledger.summary().unwrap().require_known_storage(),
            Err(crate::AudioStorageIncomplete::UnknownStorage)
        );
    }
}
