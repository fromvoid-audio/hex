# Group409 current Console composition return

Use ordinary source ref source-integration/409-console-group-d4112fc1, head d4112fc1d85a59e380842ed3e0f0c9995dc55d5c/tree10709b150523370a45f740b940f2783d6bfab75a. Direct parent canonical144d22a7134c59e5a2351b8b55180dd013f70fa0, full2e5 repair and actualqualifiedConsolemainf920 retained. Never build evidence ref.

One real pointer case captures all3 actual selected audio clips, changes view with existing production setter (same setup as existing single Console tests), releases over actual same-track Console cell, runs realService. Current receiver derives CopyArrangementAudioClipToSession from drag.clip even though shared group.ids has3, clears visible/shared capture, then queues and commits exactly one SessionAudioClip. This is a confirmed composition defect, not a hypothetical geometry/cache issue. No fake ClipDrag/Event/canonical state/error.

Small bounded option A (recommended): reject ids.len()>1 at existing Console Arrangement receiver before deriving single-clip command; use existing cancellation/retirement and visible refusal, no queue/full canonical or history change. Preserve supported single Audio/MIDI copy and Browser replacement. The new diagnostic must turn green and existing2ConsoleArrangement tests/all11Console+group controls stay green.

Option B: retire only multi-clip capture on workspace-mode transition while retaining single-clip transition; changes shared mode lifecycle and still requires checking receiver admission. No new multi-cell/scene mapping, no partial fallback, no global gesture redesign. Root chooses bounded contract; continuing Cloud2 owns production return after coherent407 checkpoint, no retired/additional agents.

Before runtime, f005 compile failed E0063 private clone helper missing merged comparison_audio. Canonical144d one-line metadata clone preserves state.comparison_audio.clone(), not None; no production behavior change. DiagnosticD adds only66 private test lines on that exact parent. Original compile negative and new1FAIL preserved. No full21 was started on the known runtime negative, no unchanged retry or native/app action. Proceed independent419+458 while owner repairs.
