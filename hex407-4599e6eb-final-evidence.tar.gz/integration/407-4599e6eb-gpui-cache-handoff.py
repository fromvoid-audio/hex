from pathlib import Path
import fcntl,hashlib,json,re,shutil,subprocess
root=Path('/workspace/hex-integration-eq-gestures')
target=Path('/workspace/hex-project-spectrum/artifacts/portable-target')
lock=Path('/tmp/hex-local-ci-targets/3c068b25c7d1c753c366f96a33d7f5a3aa8a65fb5fd25921412c6d0d264c3960.lock')
out=root/'artifacts/integration/407-4599e6eb-gpui-cache-handoff.json'
assert not out.exists(),'One-shot bounded handoff; do not silently repeat'
with lock.open('a+') as f:
 try:
  fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:
  pass
 else:
  fcntl.flock(f.fileno(),fcntl.LOCK_UN)
  raise RuntimeError('Existing LocalCiRunner must hold the target lock before cache mutation')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
assert head=='4599e6eba2096250e36627450c08ec6f96831016'
source='third_party/gpui/src/interactive.rs'
previous=subprocess.check_output(['git','show','3cda4bec7a40c17c64059ca0365bd8681708e006:'+source],cwd=root)
current=(root/source).read_bytes();assert previous!=current
source_hashes={}
for n in subprocess.check_output(['git','diff','--name-only','3cda4bec7a40c17c64059ca0365bd8681708e006',head,'--','third_party/gpui/src'],cwd=root).decode().splitlines():
 old=subprocess.check_output(['git','show','3cda4bec7a40c17c64059ca0365bd8681708e006:'+n],cwd=root);new=(root/n).read_bytes();source_hashes[n]={'old_sha256':hashlib.sha256(old).hexdigest(),'new_sha256':hashlib.sha256(new).hexdigest()}
assert source_hashes
paths=[]
for parent in [target/'debug/.fingerprint',target/'debug/build']:
 if parent.is_dir():
  paths += [p for p in parent.iterdir() if re.fullmatch(r'gpui-[0-9a-f]{16}',p.name)]
parent=target/'debug/deps'
if parent.is_dir():
 paths += [p for p in parent.iterdir() if re.fullmatch(r'(?:lib)?gpui-[0-9a-f]{16}(?:\..+)?',p.name)]
files={}
for p in paths:
 assert p.resolve().is_relative_to((target/'debug').resolve()) and not p.is_symlink()
 for f in ([p] if p.is_file() else p.rglob('*')):
  if f.is_file():
   assert not f.is_symlink();b=f.read_bytes();files[str(f.relative_to(target))]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
record={'head':head,'changed_source_hashes':source_hashes,'target':str(target),'existing_runner_lock_observed_held':True,'scope':'Only exact gpui debug fingerprints/build/deps. No release cache, source, receipts, owners, other packages, or whole-target clean. Existing normal workspace handoff is performed by LocalCiRunner before this step.','old_source_sha256':hashlib.sha256(previous).hexdigest(),'new_source_sha256':hashlib.sha256(current).hexdigest(),'gpui_paths':[str(p.relative_to(target))for p in paths],'removed_files':files,'removed_file_count':len(files),'removed_bytes':sum(x['bytes']for x in files.values())}
out.write_text(json.dumps(record,indent=2)+'\n')
for p in paths:
 if p.is_dir():shutil.rmtree(p)
 else:p.unlink()
assert not any(p.exists()for p in paths)
print(json.dumps({k:v for k,v in record.items()if k!='removed_files'},indent=2))
