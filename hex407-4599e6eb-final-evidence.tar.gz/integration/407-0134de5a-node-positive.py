import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-integration-eq-gestures')
spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='407-0134de5a-node-positive',adopt_target=True,min_free_bytes=2*1024**3,steps=(m.Step('actual-eq-node-regressions',('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--locked','node_gesture_tests::','--','--nocapture')),))
code=r.run();print('FOCUSED_ONLY_SUMMARY',r.summary_path);raise SystemExit(code)
