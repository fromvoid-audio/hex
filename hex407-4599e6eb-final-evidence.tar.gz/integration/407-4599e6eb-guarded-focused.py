import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-integration-eq-gestures')
spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='407-4599e6eb-guarded-focused',adopt_target=True,min_free_bytes=2*1024**3,steps=(
 m.Step('format',('cargo','fmt','--all','--','--check')),
 m.Step('gpui-cache-handoff',('python3',str(root/'artifacts/integration/407-4599e6eb-gpui-cache-handoff.py')),uses_cargo_target=True),
 m.Step('eq-node-and-wayland-protocol',('python3',str(root/'artifacts/integration/407-4599e6eb-real-types.py')),uses_cargo_target=True),
))
raise SystemExit(r.run())
