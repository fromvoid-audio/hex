//! Actual preview owner, retained in the existing preparation root.
//! Nonempty observation/restore/cleanup is separate from closed constructor admission.
//! Constructor/layout observations leave its allocation/handle obligation OPEN.
mod compiler;
use super::{MidiArrangementPreview, MidiClipPreview};
use crate::{AudioStorageError as Error, owned_shared::OwnedShared};

// A wildcard binding would not enforce this trait obligation.
fn require_copy<T: Copy>(_: &T) {}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct AudioPreviewCapacity {
    pub clips_payload_bytes: usize,
    pub clips_declared_overhead_bytes: usize,
    pub samples_backing_bytes: usize,
    pub compiler_draft_backing_bytes: usize,
    pub reserved_handle_destinations: usize,
    pub independent_handle_obligations: usize,
    pub unresolved_allocations: usize,
}
impl AudioPreviewCapacity {
    pub(crate) fn bytes(self) -> Result<usize, Error> {
        self.clips_payload_bytes
            .checked_add(self.clips_declared_overhead_bytes)
            .and_then(|bytes| bytes.checked_add(self.samples_backing_bytes))
            .and_then(|bytes| bytes.checked_add(self.compiler_draft_backing_bytes))
            .ok_or(Error::Overflow)
    }
}
/// Copyable leaf metadata, not a legacy preview/clip or owning child reference.
/// ```compile_fail
/// fn escape(v: hex_engine::AudioPreviewMetadata) { let _ = v.clips(); }
/// ```
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AudioPreviewMetadata {
    pub clip_count: usize,
}
#[derive(Clone, Copy, Default, PartialEq, Eq)]
enum Phase {
    #[default]
    Vacant,
    Reserved,
    Installed,
    Cleaning,
    Complete,
}
#[derive(Clone, Copy, Default, PartialEq, Eq)]
enum Disposal {
    #[default]
    Unstarted,
    Pending,
    Complete,
}
#[derive(Default)]
pub(crate) struct PreviewCustody {
    clips: Option<OwnedShared<[MidiClipPreview]>>,
    preview: Option<MidiArrangementPreview>,
    draft: Vec<MidiClipPreview>,
    handle: u64,
    phase: Phase,
    disposal: Disposal,
    #[cfg(test)]
    pub(crate) fail_after: Option<usize>,
    #[cfg(test)]
    pub(crate) panic_after: Option<usize>,
    #[cfg(test)]
    pub(crate) probe: Option<crate::audio_preparation::DropProbe>,
}
impl PreviewCustody {
    pub(crate) fn capacity(&self) -> Result<AudioPreviewCapacity, Error> {
        self.capacity_at(None)
    }
    pub(crate) fn can_transfer_revision(&self) -> bool {
        self.phase == Phase::Installed
            && self.preview.is_some()
            && self.clips.is_none()
            && self.draft.capacity() == 0
    }
    pub(crate) fn can_restore_revision(&self) -> bool {
        self.phase == Phase::Installed
            && self.preview.is_none()
            && self.clips.is_none()
            && self.disposal == Disposal::Unstarted
    }
    pub(crate) fn transfer_revision(&mut self, target: &mut Option<MidiArrangementPreview>) {
        *target = self.preview.take();
    }
    pub(crate) fn restore_revision(&mut self, source: &mut Option<MidiArrangementPreview>) {
        self.preview = source.take();
    }
    pub(crate) fn capacity_at(
        &self,
        external: Option<&MidiArrangementPreview>,
    ) -> Result<AudioPreviewCapacity, Error> {
        if self.draft.capacity() != 0
            && (self.clips.is_some() || self.preview.is_some() || external.is_some())
        {
            return Err(Error::SourceMismatch);
        }
        if self.preview.is_some() && external.is_some() {
            return Err(Error::SourceMismatch);
        }
        if self.clips.is_some() && (self.preview.is_some() || external.is_some()) {
            return Err(Error::UnknownStorage);
        }
        let owner = self.clips.as_ref().or_else(|| {
            self.preview
                .as_ref()
                .or(external)
                .map(|MidiArrangementPreview { clips }| clips)
        });
        let mut report = AudioPreviewCapacity {
            reserved_handle_destinations: usize::from(self.handle != 0),
            ..Default::default()
        };
        if let Some(owner) = owner {
            if self.handle == 0 {
                return Err(Error::UnknownStorage);
            }
            let (payload, overhead) = owner.parts().ok_or(Error::UnsupportedConstructor)?;
            report.clips_payload_bytes = payload;
            report.clips_declared_overhead_bytes = overhead;
            report.independent_handle_obligations = 1;
            report.unresolved_allocations = 1;
            for clip in owner.iter() {
                let bytes = clip
                    .samples
                    .capacity()
                    .checked_mul(std::mem::size_of::<super::MidiPreviewSample>())
                    .ok_or(Error::Overflow)?;
                report.samples_backing_bytes = report
                    .samples_backing_bytes
                    .checked_add(bytes)
                    .ok_or(Error::Overflow)?;
                report.unresolved_allocations = report
                    .unresolved_allocations
                    .checked_add(usize::from(bytes != 0))
                    .ok_or(Error::Overflow)?;
            }
        }
        report.compiler_draft_backing_bytes = self
            .draft
            .capacity()
            .checked_mul(std::mem::size_of::<MidiClipPreview>())
            .ok_or(Error::Overflow)?;
        for clip in &self.draft {
            report.samples_backing_bytes = report
                .samples_backing_bytes
                .checked_add(
                    clip.samples
                        .capacity()
                        .checked_mul(std::mem::size_of::<super::MidiPreviewSample>())
                        .ok_or(Error::Overflow)?,
                )
                .ok_or(Error::Overflow)?;
        }
        report.bytes()?;
        Ok(report)
    }
    pub(crate) fn reserve(&mut self, project: &hex_project::Project) -> Result<(), Error> {
        if self.phase != Phase::Vacant
            || self.clips.is_some()
            || self.preview.is_some()
            || self.handle != 0
            || self.disposal != Disposal::Unstarted
            || self.draft.capacity() != 0
        {
            return Err(Error::Capacity);
        }
        if project.tracks().iter().any(|t| !t.midi_clips().is_empty()) {
            return Err(Error::UnsupportedGraph);
        }
        if !crate::pcm_arc::native_layout_known() {
            return Err(Error::UnsupportedConstructor);
        }
        // Checked independent handle and vacant persistent destination precede
        // the explicit sized-zero-array allocation. No raw/default adoption.
        self.handle = crate::audio_only_inputs::handle()?;
        self.phase = Phase::Reserved;
        self.clips = Some(OwnedShared::new_owned_empty_slice());
        self.capacity()?;
        #[cfg(test)]
        self.fault(0)?;
        Ok(())
    }
    pub(crate) fn construct(&mut self) -> Result<(), Error> {
        if self.phase != Phase::Reserved
            || self.preview.is_some()
            || self.disposal != Disposal::Unstarted
            || self.capacity()?.independent_handle_obligations != 1
        {
            return Err(Error::Capacity);
        }
        // The exact slice+declaration travels inside the actual preview value;
        // no allocation, clone, owning error or fallible step between moves.
        if let Some(clips) = self.clips.take() {
            self.preview = Some(MidiArrangementPreview { clips });
        }
        self.phase = Phase::Installed;
        #[cfg(test)]
        self.fault(1)?;
        Ok(())
    }
    #[cfg(test)]
    fn fault(&self, phase: usize) -> Result<(), Error> {
        assert_ne!(self.panic_after, Some(phase), "persistent preview panic");
        if self.fail_after == Some(phase) {
            return Err(Error::Allocation);
        }
        Ok(())
    }
    pub(crate) fn metadata_at(
        &self,
        external: Option<&MidiArrangementPreview>,
    ) -> Option<AudioPreviewMetadata> {
        if self.phase != Phase::Installed {
            return None;
        }
        if self.preview.is_some() && external.is_some() {
            return None;
        }
        self.preview
            .as_ref()
            .or(external)
            .map(|p| AudioPreviewMetadata {
                clip_count: p.clips.len(),
            })
    }
    pub(crate) fn has_next(&self) -> bool {
        !matches!(self.phase, Phase::Vacant | Phase::Complete)
    }
    pub(crate) fn dispose_next(&mut self) -> Result<(), Error> {
        self.phase = Phase::Cleaning;
        if self.preview.is_some() {
            // Validate the vacant persistent destination BEFORE taking owner.
            if self.clips.is_some() || self.disposal != Disposal::Unstarted {
                return Err(Error::Capacity);
            }
            self.capacity()?;
            if let Some(MidiArrangementPreview { clips }) = self.preview.take() {
                self.clips = Some(clips);
            }
            return Ok(());
        }
        if self.disposal != Disposal::Unstarted {
            return Err(Error::UnknownStorage);
        }
        self.capacity()?;
        self.disposal = Disposal::Pending;
        // The exhaustive typed storage visitor audits this closed payload: scalar clip
        // metadata plus Vec<scalar sample>. No provider/PCM/custom destructor
        // or callback is reachable. The actual shared slice stays in this
        // persistent slot until this control-only terminal operation.
        drop(self.clips.take());
        drop(std::mem::take(&mut self.draft));
        #[cfg(test)]
        drop(self.probe.take());
        self.disposal = Disposal::Complete;
        self.phase = Phase::Complete;
        Ok(())
    }
    pub(crate) fn clear_disposed(&mut self) -> Result<(), Error> {
        if self.phase == Phase::Vacant {
            return Ok(());
        }
        if self.phase != Phase::Complete
            || self.disposal != Disposal::Complete
            || self.clips.is_some()
            || self.preview.is_some()
            || self.draft.capacity() != 0
        {
            return Err(Error::Capacity);
        }
        self.handle = 0;
        self.disposal = Disposal::Unstarted;
        self.phase = Phase::Vacant;
        Ok(())
    }
    /// Test-only observation while this actual allocation stays strongly rooted;
    /// never a production identity or lifetime/admission authority.
    #[cfg(test)]
    pub(crate) fn observation(&self) -> Option<(usize, usize, u64, bool)> {
        let owner = self
            .clips
            .as_ref()
            .or_else(|| self.preview.as_ref().map(|p| &p.clips))?;
        Some((
            owner.arc().as_ptr() as usize,
            std::sync::Arc::strong_count(owner.arc()),
            self.handle,
            self.preview.is_some(),
        ))
    }
    #[cfg(test)]
    pub(crate) fn pending(&self) -> bool {
        self.disposal == Disposal::Pending
    }
}
impl PreviewCustody {
    pub(crate) fn visit_audio_storage<'a>(
        &'a self,
        l: &mut crate::AudioRootStorageLedger<'a>,
        external: Option<&'a MidiArrangementPreview>,
    ) -> Result<(), Error> {
        use crate::audio_storage::Owner;
        self.capacity_at(external)?;
        let Self {
            clips,
            preview,
            draft,
            handle,
            phase: _,
            disposal: _,
            #[cfg(test)]
                fail_after: _,
            #[cfg(test)]
                panic_after: _,
            #[cfg(test)]
                probe: _,
        } = self;
        l.vec(draft)?;
        for clip in draft {
            l.vec(&clip.samples)?;
        }
        let owner = clips.as_ref().or_else(|| {
            preview
                .as_ref()
                .or(external)
                .map(|MidiArrangementPreview { clips }| clips)
        });
        if let Some(owner) = owner {
            // Re-visiting this actual physical field is not another owning
            // alias. Keep shared()'s standalone duplicate-root refusal intact.
            if !l.skip_observed_shared_field(owner) {
                l.shared(
                    owner.arc(),
                    owner.parts(),
                    Owner::exclusive(owner),
                    *handle,
                    None,
                )?;
            }
            for super::MidiClipPreview {
                clip_id,
                frame_start,
                frame_end,
                authored_note_count,
                occurrence_count,
                samples,
            } in owner.iter()
            {
                // Copy is part of the closed scalar-ID leaf contract: an
                // owning/non-Copy replacement must force this audit to change.
                require_copy(clip_id);
                let _: (&hex_project::ClipId, &u64, &u64, &usize, &usize) = (
                    clip_id,
                    frame_start,
                    frame_end,
                    authored_note_count,
                    occurrence_count,
                );
                for super::MidiPreviewSample {
                    frame_start,
                    frame_gate_end,
                    pitch,
                } in samples
                {
                    let _: (&u64, &u64, &u8) = (frame_start, frame_gate_end, pitch);
                }
                l.vec(samples)?;
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn explicit_empty_preview_provenance_never_upgrades_legacy_origins() {
        let mut custody = PreviewCustody::default();
        let project = hex_project::Project::new(48_000).unwrap();
        assert!(MidiArrangementPreview::default().clips.parts().is_none());
        assert!(
            MidiArrangementPreview {
                clips: OwnedShared::from_owned_vec(Vec::new())
            }
            .clips
            .parts()
            .is_none()
        );
        if !crate::pcm_arc::native_layout_known() {
            assert_eq!(
                custody.reserve(&project),
                Err(Error::UnsupportedConstructor)
            );
            assert_eq!(custody.capacity().unwrap(), AudioPreviewCapacity::default());
            eprintln!("hex preparation evidence: audio_preview_origin; branch=unsupported-refusal");
            return;
        }
        custody.reserve(&project).unwrap();
        let before = custody.observation().unwrap();
        let declared = custody.capacity().unwrap();
        custody.construct().unwrap();
        let after = custody.observation().unwrap();
        assert_eq!((before.0, before.1, before.2), (after.0, after.1, after.2));
        assert!(!before.3 && after.3);
        assert_eq!(custody.capacity().unwrap(), declared);
        // Test-only raw-origin ingress keeps actual allocation identity, but
        // cannot invent the constructor declaration or erase its obligation.
        let actual = &custody.preview.as_ref().unwrap().clips;
        let raw = OwnedShared::untracked(std::sync::Arc::clone(actual.arc()));
        assert!(raw.parts().is_none());
        assert!(std::sync::Arc::ptr_eq(actual.arc(), raw.arc()));
        drop(raw);
        custody.dispose_next().unwrap();
        custody.dispose_next().unwrap();
        custody.clear_disposed().unwrap();
        assert_eq!(custody.capacity().unwrap(), AudioPreviewCapacity::default());
        eprintln!(
            "hex preparation evidence: audio_preview_origin; supported-controls=completed; raw-default-emptyvec-remain-unknown"
        );
    }
}

#[cfg(test)]
mod nonempty_tests;
