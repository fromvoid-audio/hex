import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-grid-menu')
spec=importlib.util.spec_from_file_location('hex_grid_ui_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('ui-feature-tests',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
