import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-grid-menu')
spec=importlib.util.spec_from_file_location('hex_grid_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('adaptive-density-core',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','adaptive_density','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
