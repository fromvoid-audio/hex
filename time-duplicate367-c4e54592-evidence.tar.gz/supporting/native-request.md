# Pulse2759 / canonical PR367 — finite native follow-up, coordinator only

Current source candidate c4e5459215679e82a4bdf113ea138790e6f050f9; full source CI
still in progress at request creation. Use the eventual exact qualified source;
record any later integration/merge identity separately. No app was built,
installed, launched, quit or changed by this cloud task. Installed7fe4f48f remains
outside this change. Coordinator owns combined optimized delivery and one Mac lane.

Changed behavior is native Command-D action/focus routing and range feedback.
Source-model/canonical worker correctness has focused portable regression coverage;
physical keyboard/focus/visible feedback still needs native observation.

Optional bounded CLI check in coordinator-managed isolated verification source:
  cargo test -p hex-ui --features ui-test-support --locked command_d_ -- --nocapture
Record exact source/tree/toolchain/test binary/log; no whole unchanged native
suite requested by this feature packet. No installed-app operation needed for CLI.

User-present manual check only after coordinator-selected qualified optimized
candidate contains this change, with exact running source/build recorded:
1. Disposable project: an audio sample and MIDI clip, notes crossing selection
   boundaries, nonzero selection start and an empty gap. Root Arrangement focus,
   partial time rectangle selected (also leave an unrelated MIDI clip selected).
   Command-D copies only the range at its end with existing normal overwrite
   semantics. Verify source window, note gates, timing and gap. Source media stays
   immutable; destination content is overwritten only by normal rectangle policy.
2. Repeat after acknowledgement: selection advances, second copy follows the
   first; single Undo removes each duplicate as one operation and Redo restores it.
3. Single-row, multiple-row time rectangle and main-track all-row proxy scope;
   unrelated tracks stay unchanged for row-scoped operations. Unsupported temporal
   automation transforms must refuse atomically, without a partial edit.
4. Browser search, clip/track rename, numeric field and MIDI/detail/session focus
   keep their own keyboard semantics. No active time range retains existing clip
   and scene behavior. No unexpected Arrangement edit while text is being entered.
5. Pending edit or overflow/stale selection refuses visibly, without changing
   content or moving the selection to an uncommitted destination.

Evidence: source/build/exe/provenance, bounded capture and pass/fail per item,
Undo/Redo and scopes. GUI requires authorized user-present session; do not unlock
or self-dispatch, force-quit, replace an app, touch real projects or invent listening.
No new DSP/audio/listening acceptance claimed or requested from this UI-only change.
