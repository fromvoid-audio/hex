# bounded future native verification request: PR376 / PR377 / PR378 / PR335

This records the remaining native gap for the coordinator. It does not dispatch
a Mac job, request a new app build, or change the installed frozen dfa app /
build3751944026. Launcher cloud1 retains optimized delivery and combined-candidate
qualification ownership. Existing source-check reports are per-feature evidence.

## exact source and prerequisites

- Canonical sources: track rename PR376 / Pulse2768, merged642df957; clip range
  PR377 / Pulse2769, mergedf9e1d396; whole-clip paste PR378 / Pulse2770,
  merged31fcfbf4; selected borders PR335 / Pulse2719, final head
  8e507b689d8dcaaca26dec5082319c5fff27949a. The archive manifest records complete
  heads, actual merge commits/trees and original final-check identities.
- Schedule only when the coordinator's ONE serial Mac lane is available and a
  future explicitly approved optimized candidate containing these sources exists.
  Do not stop another Hex/Yield verifier or alter the user's current running app.
- Use the approved candidate's existing verification checkout and provenance.
  Read-only source checklist:

  ```sh
  git rev-parse HEAD
  git merge-base --is-ancestor 8e507b689d8dcaaca26dec5082319c5fff27949a HEAD
  ```

  Record the exit status, checkout source, app's actual source/build label and
  launcher manifest. The checkout alone does not establish running-app identity.
  Report a mismatch without installing/replacing anything.
- Use a disposable project with two ordinary tracks and at least five clips on
  one row, including audio/MIDI and visible gaps. Keep original media/user projects
  intact. User presence/manual keyboard and mouse interaction are required.

## why Mac is needed

Cloud tests prove rendered GPUI scene geometry, synthetic keys/mouse routing,
canonical model/worker history and persistence. They do not prove native macOS
Command/focus/IME routing, actual GPU border appearance, display scaling or the
user's physical interaction. No Mac-specific implementation is pending here.

## finite checklist

1. **PR376:** focus a header by its name and its blank background; Command-R,
   edit and Enter. Verify one Undo/Redo. Open another draft and Escape. Arrow
   focus to another header and repeat; clip-header Command-R must still edit the
   clip name. Search and numeric-input focus must retain their keys.
2. **PR377:** click first clip, Shift-click fifth; check all five. Reverse the
   range and repeat Shift-clicks around the original anchor. Command-toggle a
   member, Command-Shift union, then Shift-click another track (new anchor).
   Clear in a lane, then Command-click: no hidden old members may return. Check
   ordinary header dragging and body time selection still behave normally.
3. **PR378:** header-select one clip, Command-C, click another time/track and
   Command-V. Repeat with several clips. Verify complete contents and original
   gaps, repeated paste, one atomic Undo/Redo, and source retention. Copy/paste
   text in search, return to the Arrangement and paste again: its whole-clip
   payload must remain. Keep accepted multi-source-track stable-owner semantics;
   no new cross-track remapping is expected.
4. **PR335:** inspect single/multiple selected audio and MIDI borders, hover,
   toggle a middle member while the endpoint stays selected, and deselect. Pan
   until clips are cropped at either viewport boundary. Drag/cancel ordinary
   trim/fade affordances and check selected preview borders, original clip colors,
   text, waveform/notes and usable edge hit areas. No source/time geometry change
   is expected.
5. Save/reopen only the disposable project to check renamed tracks and pasted
   whole content persist. This does not require saving/quitting the user's current
   app/project. Never force-quit or discard unsaved data.

## expected evidence and boundary

Return actual source/build/provenance, a short bounded interaction capture and
pass/fail per scope, including Undo/cancel and disposable save/reopen. Record any
failure with exact steps and actual/expected behavior. No native acceptance is
claimed until that evidence returns. No save/quit of the current native app is
intrinsically required; app replacement or another build is outside this request.
