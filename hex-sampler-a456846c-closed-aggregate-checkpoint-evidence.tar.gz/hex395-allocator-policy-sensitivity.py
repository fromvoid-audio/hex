import copy, contextlib, io, json, pathlib, runpy, subprocess
from unittest.mock import patch
root=pathlib.Path('/workspace/hex-sampler-aggregate')
metadata=json.loads(subprocess.check_output(['cargo','metadata','--format-version','1','--no-deps'],cwd=root))
def run(label, change, expected):
    value=copy.deepcopy(metadata)
    change(value)
    out,err=io.StringIO(),io.StringIO()
    code=0
    with patch('subprocess.check_output',return_value=json.dumps(value).encode()), contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:runpy.run_path(str(root/'scripts/check-architecture.py'),run_name='__main__')
        except SystemExit as e:code=e.code
    print(label, 'exit', code, (out.getvalue()+err.getvalue()).strip())
    assert code==expected,(label,code,expected)
def package(m,name):return next(p for p in m['packages'] if p['name']==name)
def counter(m):return next(d for d in package(m,'hex-engine')['dependencies'] if d['name']=='allocation-counter')
run('actual pinned Engine DEV',lambda _:None,0)
run('Engine PRODUCTION rejected',lambda m:counter(m).update(kind=None),1)
run('Engine BUILD rejected',lambda m:counter(m).update(kind='build'),1)
run('Engine unpinned DEV rejected',lambda m:counter(m).update(req='^0.8.1'),1)
def foreign(m):
    dependency=copy.deepcopy(counter(m))
    package(m,'hex-project')['dependencies'].append(dependency)
run('foreign hex-project DEV rejected',foreign,1)
def forbidden(m):
    dependency=copy.deepcopy(next(d for d in package(m,'hex-audio')['dependencies'] if d['name']=='hex-stream'))
    dependency['kind']=None
    package(m,'hex-engine')['dependencies'].append(dependency)
run('unrelated Engine->stream edge still rejected',forbidden,1)
print('6 discriminating cases PASS; real cargo metadata, in-memory mutations only; no manifest/lockfile mutation')
