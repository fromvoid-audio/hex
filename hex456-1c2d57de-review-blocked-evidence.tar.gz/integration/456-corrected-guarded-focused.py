import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-integration-audio-placement')
spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='456-corrected-guarded-focused',adopt_target=True,min_free_bytes=2*1024**3,steps=(
 m.Step('format',('cargo','fmt','--all','--','--check')),
 m.Step('ui-default-placement',('cargo','test','-p','hex-ui','--lib','--locked','editor::arrangement_audio_panel::tests::')),
 m.Step('ui-feature-placement',('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--locked','editor::arrangement_audio_panel::tests::')),
 m.Step('model-audio-view',('cargo','test','-p','hex-project','--test','audio_view','--locked')),
 m.Step('storage-current-format',('cargo','test','-p','hex-storage','--locked')),
))
raise SystemExit(r.run())
