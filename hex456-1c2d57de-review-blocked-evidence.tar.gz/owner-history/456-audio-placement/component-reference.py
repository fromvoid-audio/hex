import importlib.util,pathlib,sys,subprocess
root=pathlib.Path('/workspace/hex-audio-placement')
spec=importlib.util.spec_from_file_location('hex_ci_456',root/'scripts/local-ci.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
files=sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=root).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root).decode().splitlines()))
rust=tuple(p for p in files if p.endswith('.rs'))
steps=(
module.Step('project-model',('cargo','test','-p','hex-project','--locked')),
module.Step('current-storage',('cargo','test','-p','hex-storage','--locked')),
module.Step('session-bridge',('cargo','test','-p','hex-session','--lib','clip_conversion::tests','--','--nocapture')),
module.Step('strict-model-storage-session',('cargo','clippy','-p','hex-project','-p','hex-storage','-p','hex-session','--all-targets','--','-D','warnings')),
module.Step('architecture',('python3','scripts/check-architecture.py')),
module.Step('touched-fmt',('rustfmt','--edition','2024','--check',*rust)),
module.Step('diff-check',('git','diff','--check')),
)
raise SystemExit(module.LocalCiRunner(root=root,mode='quick',steps=steps).run())
