import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-integration')
spec=importlib.util.spec_from_file_location('hex326_integration_ci',root/'scripts/local-ci.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(
 m.Step('place-icon-fixtures',('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','browser_place_icon','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('directory-only-operator-fixtures',('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','operator_tab_cycl','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
r=m.LocalCiRunner(root,mode='focused',steps=steps,min_free_bytes=2*m.GIB)
code=r.run();print(f'FOCUSED ONLY, NOT FULL20: {r.summary_path}');raise SystemExit(code)
