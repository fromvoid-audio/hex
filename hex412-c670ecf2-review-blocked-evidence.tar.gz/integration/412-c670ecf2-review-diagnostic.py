import sys,pathlib,json,hashlib
from unittest.mock import patch,Mock
sys.path.insert(0,str(pathlib.Path('scripts/tests').resolve()))
import test_launch_restart as t
rows=[]
def fixture():
    x=t.RecreatedTargetTests();x.setUp();return x
x=fixture()
try:
    authority=x.inspect();raw=x.owner.read_bytes()
    _,dev=t.fixtures.local_ci.target_state_paths(x.target,x.runner.target_state_dir)
    record={'schema_version':1,'target_directory':str(x.target),'workspace_owner':x.record['workspace_owner'],'target_identity':x.record['target_identity']}
    dev.write_text(json.dumps(record));before=dev.read_bytes()
    assert x.runner.adopt_target is False
    ok=x.runner._prepare_target_cache()
    assert ok is False and 'directory identity changed' in x.runner.summary['target_cache_error']
    assert x.owner.read_bytes()==raw and dev.read_bytes()==before and x.runner.target_lock is None
    rows.append({'case':'test-flow dev ownership','inspection':'succeeded','subsequent_default_CI_prepare':False,'error':x.runner.summary['target_cache_error'],'both_owner_bytes_preserved':True})
finally:x.doCleanups()
x=fixture()
try:
    app=x.f.repo.resolve()/'missing-parent'/'hex.app';raw=x.owner.read_bytes();assert not app.parent.exists()
    with patch.object(t.fixtures.local_ci,'LocalCiRunner',return_value=x.runner),patch.object(t.delivery,'assert_inactive'),patch.object(t.restart,'NativeController',side_effect=AssertionError('no native control')):
        try:t.restart.inspect_recreated_target(x.f.repo,app,x.source,t.fixtures.local_ci,t.delivery,Mock())
        except FileNotFoundError as e:err=str(e)
        else:raise AssertionError('expected actual missing-parent failure')
    assert not app.parent.exists() and x.owner.read_bytes()==raw
    rows.append({'case':'missing configured-app parent','error':err,'owner_bytes_preserved':True,'parent_still_missing':True})
finally:x.doCleanups()
x=fixture()
try:
    authority=x.inspect();original=x.owner.read_bytes()
    try:
        with x.guard(authority):raise RuntimeError('fixture build/consumer failure')
    except RuntimeError:pass
    pending=x.owner.read_bytes();p=json.loads(pending)
    assert p['state']=='pending' and p['target_identity']==authority['target_identity']
    try:x.inspect()
    except t.fixtures.local_ci.TargetCacheError as e:err=str(e)
    else:raise AssertionError('expected retry refusal')
    assert x.owner.read_bytes()==pending and x.keep.read_bytes()==b'preserve external data' and x.runner.target_lock is None
    rows.append({'case':'pending retry after actual guarded-consumer failure','pending_is_replacement_identity':True,'retry_error':err,'pending_bytes_preserved':True,'unrelated_cache_preserved':True})
finally:x.doCleanups()
out=pathlib.Path('artifacts/integration/412-c670ecf2-review-diagnostic.json');out.write_text(json.dumps({'source':'c670ecf2dbb3ca286cd8614b49aba59015347850','scope':'actual private filesystem/production Runner; no native actions; diagnostic assertions prove three refusal paths, not repaired behavior','rows':rows},indent=2)+'\n');print(out.read_text())
