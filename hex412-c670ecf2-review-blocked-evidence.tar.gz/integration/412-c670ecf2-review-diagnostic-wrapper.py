import pathlib,importlib.util,sys
r=pathlib.Path.cwd();s=importlib.util.spec_from_file_location('hex_local_ci',r/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
x=m.LocalCiRunner(r,mode='component',run_id='412-c670ecf2-review-diagnostic',adopt_target=True,min_free_bytes=2*1024**3,steps=(m.Step('three actual review refusal paths',('python3','artifacts/integration/412-c670ecf2-review-diagnostic.py'),uses_cargo_target=True),));sys.exit(x.run())
