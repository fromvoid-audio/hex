from pathlib import Path
import importlib.util,sys
root=Path('/workspace/hex-integration-active');spec=importlib.util.spec_from_file_location('ci408positive',root/'scripts/local-ci.py');ci=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ci;spec.loader.exec_module(ci)
steps=(ci.Step('session-comparison-controls',('cargo','test','-p','hex-session','--test','device_comparison','--locked','--','--nocapture'),uses_cargo_target=True,requires_tests=True),ci.Step('audio-comparison-allocation-controls',('cargo','test','-p','hex-audio','--features','allocation-probe','--test','device_comparison','--locked','--','--nocapture'),uses_cargo_target=True,requires_tests=True),ci.Step('ui-comparison-callback-controls',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','editor::device_panel::tests::device_comparison_tests::device_comparison_metadata_','--','--nocapture'),uses_cargo_target=True,requires_tests=True))
r=ci.LocalCiRunner(root,mode='component',run_id='408-a04d21f6-comparison-fixtures',steps=steps,min_free_bytes=2*1024**3)
raise SystemExit(r.run())
