import importlib.util, pathlib, sys
root = pathlib.Path('/workspace/hex-clip-loop')
spec = importlib.util.spec_from_file_location('hex_local_ci_445', root / 'scripts/local-ci.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
steps = (
    module.Step('midi-template-compile-activity', ('cargo','test','-p','hex-engine','--test','midi_template','--test','midi_activity','--test','midi_compile','--','--nocapture')),
    module.Step('midi-ui-regression', ('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--','editor::clip_loop_tests::','midi_loop_preview_tests','rendered_midi_trim_previews_note_geometry_and_commits_release_snap','rendered_midi_left_trim_keeps_source_note_timeline_position','--nocapture')),
    module.Step('strict-clippy', ('cargo','clippy','-p','hex-engine','-p','hex-ui','--all-targets','--features','hex-ui/ui-test-support','--','-D','warnings')),
    module.Step('touched-fmt', ('rustfmt', '--edition', '2024', '--check', 'crates/hex-engine/examples/playback_stack.rs', 'crates/hex-engine/examples/profile_instrument.rs', 'crates/hex-engine/examples/profile_session_inventory.rs', 'crates/hex-engine/examples/profile_shared_context.rs', 'crates/hex-engine/examples/support/operator_feedback_fixture.rs', 'crates/hex-engine/examples/support/session_fixture.rs', 'crates/hex-engine/src/midi_template.rs', 'crates/hex-engine/src/session_playback/harmonic_accounting.rs', 'crates/hex-engine/src/session_playback/harmonic_accounting/inventory.rs', 'crates/hex-engine/src/session_playback/source_loop_tests.rs', 'crates/hex-engine/src/session_playback/tests.rs', 'crates/hex-engine/src/signal_graph/tests.rs', 'crates/hex-engine/tests/midi_template.rs')),
    module.Step('diff-check', ('git','diff','--check')),
)
raise SystemExit(module.LocalCiRunner(root=root, mode='quick', steps=steps).run())
