# Future new-component selector — no dispatch request

No Mac job requested from this partial feature. If root elects to test just changed policy, exact79c/tree6b708:

    cargo test -p hex-engine --test midi_template captured_once_template -- --nocapture

Expected EXACT4unique PASS/0FAIL/0ignored: captured_once_template_clips_gate_and_keeps_hidden_notes_silent; captured_once_template_exact_end_emits_no_events; captured_once_template_beyond_authored_source_prepares_empty; captured_once_template_explicit_repeat_reactivation_matches_finite. Actual Editor/Project+PreparedTempoMap+ongoing-template query+finite compiler, no GPUI/browser/HOME/catalog or OS audio/MTS/device/app construction. Expected event cardinalities C2=2/2,C4=0/0,C9=0/0,RepeatC3=7/7; both notes retained. Do not call this native fullCI or new PCM/physical export acceptance. UI049a private3 selector is in earlier independent packet; no repeat requested here. Final Audio/MIDI fullfeature checks and physical optimized workflow are still root-owned/open.
