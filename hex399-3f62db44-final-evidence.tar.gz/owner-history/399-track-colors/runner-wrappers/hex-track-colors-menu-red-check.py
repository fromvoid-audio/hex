import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-track-colors');s=importlib.util.spec_from_file_location('colors_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
unused_steps=(m.Step('automatic-track-colors',('cargo','test','-p','hex-project','--test','automatic_track_colors','--locked','--','--nocapture'),uses_cargo_target=True),m.Step('track-color-menu',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','track_header_offers_nine_non_gray','--','--nocapture'),uses_cargo_target=True))
steps=(unused_steps[1],)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
