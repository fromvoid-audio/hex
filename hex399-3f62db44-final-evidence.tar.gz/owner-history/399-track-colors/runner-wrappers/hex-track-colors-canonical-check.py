import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-track-colors');s=importlib.util.spec_from_file_location('colors_final_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('project',('cargo','test','-p','hex-project','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('storage-colors',('cargo','test','-p','hex-storage','--test','automatic_track_colors','--test','appearance','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('context-menu',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','editor::context_menu::tests::','--','--nocapture'),uses_cargo_target=True),
 m.Step('clip-color-cache',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','clip_content_cache::tests::','--','--nocapture'),uses_cargo_target=True),
 m.Step('project-storage-clippy',('cargo','clippy','-p','hex-project','-p','hex-storage','--all-targets','--locked','--','-D','warnings'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
