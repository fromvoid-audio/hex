import pathlib,struct,json,hashlib,math,wave
folder=pathlib.Path('/dev/shm/hex-beats-2847-generated-phrase');folder.mkdir()
rate=44100;length=rate*8;mix=[[0.0,0.0] for _ in range(length)];events=[]
for stem,gain,beats in [('BKCtbss_Pizz_A1_v1_rr1',2.0,[0,3,4,7,8,11,12]),('snare1_f_1',0.4,[1,3,5,7,9,11,13,15])]:
 p=pathlib.Path('/dev/shm/hex-beats-2847-recording-inputs')/(stem+'.f32')
 source=list(struct.iter_unpack('<ff',p.read_bytes()))
 for beat in beats:
  first=beat*22050;events.append(dict(recording=stem,beat=beat,frame=first,gain=gain))
  for i,(left,right) in enumerate(source[:length-first]):
   mix[first+i][0]+=left*gain;mix[first+i][1]+=right*gain
fade=rate//50
for i in range(fade):
 gain=0.5*(1+math.cos(math.pi*i/(fade-1)))
 mix[length-fade+i]=[x*gain for x in mix[length-fade+i]]
raw=b''.join(struct.pack('<ff',*x) for x in mix)
p=folder/'bass-snare-constructed120.f32';p.write_bytes(raw)
with wave.open(str(folder/'bass-snare-constructed120-original.wav'),'wb') as w:
 w.setnchannels(2);w.setsampwidth(3);w.setframerate(rate)
 w.writeframes(b''.join(round(max(-1,min(1,x[0]))*8388607).to_bytes(3,'little',signed=True) for x in struct.iter_unpack('<f',raw)))
metadata=dict(description='Generated 4-bar 120-BPM arrangement of two authorised real VSCO2 CC0 one-shot recordings; NOT a publisher tempo-labelled loop or Live reference',original_recording_bpm=None,construction_bpm=120,rate=rate,frames=length,channels=2,events=events,head_fade_frames=0,end_half_cosine_fade_frames=fade,overlapping_samples='sum at listed fixed gains; tails truncated at exact8s, documented endfade only; originals unchanged',peak=max(abs(x) for f in mix for x in f),source_f32_sha256=hashlib.sha256(raw).hexdigest(),adapter_settings_scope='adapter text original BPM unknown refers to publisher originals; constructed phrase tempo is explicitly120 above',listening='not listened to; preserve fixed gain and exact construction; no musical quality acceptance')
(folder/'construction.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('frames',length,'peak',metadata['peak'],'sha',metadata['source_f32_sha256'])
