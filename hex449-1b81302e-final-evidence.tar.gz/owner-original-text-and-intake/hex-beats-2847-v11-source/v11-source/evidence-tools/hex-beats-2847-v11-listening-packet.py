from pathlib import Path
import struct,wave,math,json,hashlib,shutil,tarfile,array
base=Path('/dev/shm')
root=base/'hex-beats-2847-v11-listening';root.mkdir()
rows=[]
def vals(p):
 a=array.array('f');a.frombytes(p.read_bytes());return a
def stats(a):
 peak=max(map(abs,a));rms=math.sqrt(sum(x*x for x in a)/len(a));step=max(abs(a[i]-a[i-2]) for i in range(2,len(a)))
 windows=[math.sqrt(sum(x*x for x in a[i:i+4410])/len(a[i:i+4410])) for i in range(0,len(a),4410) if len(a[i:i+4410])==4410]
 return dict(peak=peak,rms=rms,max_adjacent_channel_step=step,wholefile_50ms_rms_min=min(windows,default=0),wholefile_50ms_rms_max=max(windows,default=0))
def wav(p,a,g,rate):
 assert not p.exists();assert max(map(abs,a))*g<=1.0
 payload=bytearray()
 for x in a:payload.extend(round(x*g*8388607).to_bytes(3,'little',signed=True))
 with wave.open(str(p),'wb') as w:w.setnchannels(2);w.setsampwidth(3);w.setframerate(rate);w.writeframes(payload)
def pair(label,before,after,rate,dest):
 dest.mkdir(parents=True,exist_ok=True)
 b=vals(before);a=vals(after);assert len(b)==len(a)
 bs,as_=stats(b),stats(a)
 target=min(.05,.8*bs['rms']/max(bs['peak'],1e-20),.8*as_['rms']/max(as_['peak'],1e-20))
 gain_b=target/bs['rms'];gain_a=target/as_['rms']
 for stage,v,g in [('before',b,gain_b),('after',a,gain_a)]:
  wav(dest/(label+'-'+stage+'-fixed.wav'),v,1.0,rate)
  wav(dest/(label+'-'+stage+'-matched.wav'),v,g,rate)
 rows.append(dict(label=label,before_path=str(before),after_path=str(after),rate=rate,frames=len(a)//2,before=bs,after=as_,matched_target_rms=target,gain_before=gain_b,gain_after=gain_a,before_f32_sha256=hashlib.sha256(before.read_bytes()).hexdigest(),after_f32_sha256=hashlib.sha256(after.read_bytes()).hexdigest()))
fixtures=['snare1_f_1','BKCtbss_Pizz_A1_v1_rr1','BKCtbss_SusNV_A1_v1_rr1','trem_B2_v2_1','Timpani5_Roll_v4_rr1_Sum','susp_FX_scrape_rapid']
for stem in fixtures:
 if stem=='snare1_f_1':before=base/'hex-beats-2847-recording-snare-before'
 elif stem=='BKCtbss_Pizz_A1_v1_rr1':before=base/'hex-beats-2847-recording-pluck-before'
 else:before=base/('hex-beats-2847-v11-real-before-'+stem)
 after=base/('hex-beats-2847-screen-v11-'+stem)
 pair(stem+'-2x-Forward100',before/'ratio2-forward.f32',after/'ratio2-forward.f32',44100,root/'real-recordings')
 wav(root/'real-recordings'/(stem+'-original-fixed.wav'),vals(base/'hex-beats-2847-recording-inputs'/(stem+'.f32')),1.0,44100)
 for stage,d in [('before',before),('after',after)]:
  for name in ['settings.txt','metrics.csv']:shutil.copy2(d/name,root/'real-recordings'/(stem+'-'+stage+'-'+name))
 print('real',stem,flush=True)
phrase=root/'constructed-phrase';phrase.mkdir()
for p in sorted((base/'hex-beats-2847-c9f-phrase-before').glob('*.f32')):
 pair('constructed120-'+p.stem,p,base/'hex-beats-2847-v11-phrase-after'/p.name,44100,phrase)
for name in ['construction.json','bass-snare-constructed120.wav']:
 shutil.copy2(base/'hex-beats-2847-generated-phrase'/name,phrase/name)
for stage,d in [('before',base/'hex-beats-2847-c9f-phrase-before'),('after',base/'hex-beats-2847-v11-phrase-after')]:
 for name in ['settings.txt','metrics.csv']:shutil.copy2(d/name,phrase/(stage+'-'+name))
pair('27.5Hz-compression',base/'hex-beats-2847-bass-c9f-before/render/ratio0.5-forward.f32',base/'hex-beats-2847-bass-screen-v11-after/ratio0.5-forward.f32',16000,root/'sub-bass')
wav(root/'sub-bass/source-fixed.wav',vals(base/'hex-beats-2847-bass-c9f-before/source.f32'),1,16000)
shutil.copy2(base/'hex-beats-2847-bass-c9f-before/settings.json',root/'sub-bass/settings.json')
(root/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'LISTENING.txt').write_text('NOT LISTENED TO. No actual Ableton reference or parity claim. Before real/phrase DSP9c1a70a05d43d7d25db3ae7ca96a9429ebde403a with evidence-only same recording adapter; after fff77efcdbe22c67e574e2e6d16bf3f2454d943e version11. Sub-bass beforec9f4b8864189d968a8a19abcc525c9725755e43f version10; afterfff77efc.\nCompare FIXED-gain pairs FIRST at one comfortable playback setting; additional matched pairs use separately recorded whole-file gains to the SAME per-pair RMS target, with peak safety and no limiter. All are PCM24, quantisation only. Original recordings have no asserted publisher BPM; known120BPM phrase is an explicitly GENERATED arrangement of the real snare/bass recordings, not a publisher loop. construction.json is authoritative. Adapter generic unknown-BPM settings refer to recordings, not generated phrase.\nFinite checklist: original attack timing/width/count and no preecho or repeated attacks; sub-bass pitch/colour; sustain stutter/pumping and short/long decay; noise colour/energy; mono compatibility and stereo/antiphase stability; ALL onset/reversal/loop/segment/end neighbourhoods, not a large excluded region. Stop intentional silence and low-envelope gating are separate semantics from default Forward/Alternating100. Compare all9 phrase settings; do not infer quality from peak/maxstep/RMS alone or claim every metric improved. Wholefile50ms RMS includes silence/attacks and is descriptive. No hearing, live backend, transport-loop or optimized performance acceptance implied.\nRights: six original recordings from VSCO2CE commit440300901dfe9275fd84e0b7763af1f8443ae62e, explicitCC0. Courtesy attribution VSCO2CommunityEdition—VersilianStudios/SamGossner;IvyAudio/SimonDalzell;samplecuttingElanHickler/Soundemote. Original-byte corpus/manifest/README/Readme/LICENSE portable archive SHA4ca95f5a0eeee7a01427928209e13e5869b68ae16c497491b49531c28960efa3 on evidence/source4-sampler-cloud-20261018 commit003c2e035a67762b2a75e36f7071a03273e2e834. Paid pack/artwork omitted.\n')
rights=root/'rights';rights.mkdir()
for name in ['LICENSE','README.md','Readme.txt']:
 found=list((base/'hex-beats-2847-vsco-corpus').rglob(name));assert len(found)==1,(name,found);shutil.copy2(found[0],rights/name)
# Keep parts modest for immutable Git transport; shared comparison/provenance in each.
for part in ['real-recordings','constructed-phrase','sub-bass']:
 files=[]
 for p in sorted((root/part).rglob('*')):
  if p.is_file():files.append(dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (root/(part+'-manifest.json')).write_text(json.dumps(files,indent=2)+'\n')
 out=base/('hex-beats-2847-v11-'+part+'.tar.gz')
 with tarfile.open(out,'w:gz',compresslevel=3) as t:
  for name in [part,part+'-manifest.json','comparison.json','LISTENING.txt','rights']:t.add(root/name,arcname=name)
 print(part,len(files),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
