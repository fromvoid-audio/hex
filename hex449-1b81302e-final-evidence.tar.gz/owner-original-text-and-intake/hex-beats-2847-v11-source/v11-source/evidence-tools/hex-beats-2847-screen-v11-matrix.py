import pathlib,subprocess,time,json,hashlib,csv
binary='/dev/shm/hex-beats-declick-target/debug/examples/beats_recording'
fixtures=['snare1_f_1','BKCtbss_Pizz_A1_v1_rr1','BKCtbss_SusNV_A1_v1_rr1','trem_B2_v2_1','Timpani5_Roll_v4_rr1_Sum','susp_FX_scrape_rapid']
allrows=[]
for stem in fixtures:
 output=pathlib.Path('/dev/shm/hex-beats-2847-screen-v11-'+stem)
 args=[binary,'/dev/shm/hex-beats-2847-recording-inputs/'+stem+'.f32','44100',str(output)]
 started=time.monotonic();print('START',stem,flush=True)
 with open('/tmp/hex-beats-2847-screen-v11-'+stem+'.log','xb') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 print('TERMINAL',stem,r.returncode,'debug_seconds',time.monotonic()-started,flush=True)
 assert r.returncode==0
 rows=list(csv.DictReader((output/'metrics.csv').open()));assert len(rows)==9 and all(x['result']=='ok' for x in rows)
 assert 'algorithm_version=11' in (output/'settings.txt').read_text()
 old=pathlib.Path('/dev/shm/hex-beats-2847-score-bound-'+stem);identity=[]
 for p in sorted(old.glob('*.f32')):
  q=output/p.name;same=p.read_bytes()==q.read_bytes()
  identity.append(dict(case=p.name,bytes=q.stat().st_size,identical=same,sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
 assert len(identity)==9
 (output/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
 allrows+=rows;print('PASS9 actual renders;maxwork',max(int(x['work']) for x in rows),flush=True)
assert len(allrows)==54
print('FINAL54 actual renders OK;version11;unchanged caps; identity results descriptive only',flush=True)
