from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile
r=Path('/tmp/hex449-evidence-recovery');g=['git','--git-dir='+str(r/'repository.git'),'show'];ref='4c7007423431336ece8a7b7df9826d7c357011ff';prefix='evidence/beats-2847/fff7-quality/'
data=subprocess.check_output(g+[ref+':'+prefix+'ARCHIVES.json']);(r/'ARCHIVES.json').write_bytes(data)
assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()=='2b605e561f5f6f562124578670e22cb8e8d021ff'
archives=json.loads(data);out=r/'archives';out.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
report=[]
for a in archives:
 for part in a['parts']:
  n=PurePosixPath(part['file']);assert len(n.parts)==1 and not n.is_absolute() and '..' not in n.parts
  p=out/part['file']
  with p.open('wb') as f:subprocess.run(g+[ref+':'+prefix+part['file']],stdout=f,check=True)
  assert p.stat().st_size==part['bytes'] and digest(p)==part['sha256'],part['file']
  print('verified part',part['file'],part['bytes'],flush=True)
 dest=out/a['archive']
 if a['parts'][0]['file']!=a['archive']:
  with dest.open('wb') as f:
   for part in a['parts']:
    with (out/part['file']).open('rb') as source:
     for b in iter(lambda:source.read(1048576),b''):f.write(b)
 assert dest.stat().st_size==a['bytes'] and digest(dest)==a['sha256']
 with tarfile.open(dest) as t:
  members=t.getmembers();assert len(members)==len({x.name for x in members})
  for x in members:
   n=PurePosixPath(x.name);assert not n.is_absolute() and '..' not in n.parts and (x.isfile() or x.isdir()),x.name
  manifests=[x.name for x in members if any(z in x.name.lower() for z in ['manifest','sha256','payloads'])]
 item={'archive':a['archive'],'bytes':a['bytes'],'sha256':a['sha256'],'safe_members':len(members),'manifest_names':manifests};report.append(item);print(json.dumps(item),flush=True)
(r/'transport-verified.json').write_text(json.dumps(report,indent=2)+'\n')
