from pathlib import Path,PurePosixPath
import tarfile,json,hashlib
r=Path('/tmp/hex449-evidence-recovery');out=Path('/workspace/scratch/integration/449-coherent-intake');out.mkdir(exist_ok=True)
reports=[]
for a in json.loads((r/'transport-verified.json').read_text()):
 with tarfile.open(r/'archives'/a['archive']) as t:
  files={m.name:m for m in t.getmembers() if m.isfile()};covered=set();declared=0
  for mn in a['manifest_names']:
   d=json.load(t.extractfile(mn));assert isinstance(d,list);parent=PurePosixPath(mn).parent
   for row in d:
    n=PurePosixPath(row['path']);assert not n.is_absolute() and '..' not in n.parts
    choices=[str(parent/n),str(n)];actual=next((x for x in choices if x in files),None);assert actual,choices
    m=files[actual];h=hashlib.sha256();data=[];keep=not actual.lower().endswith('.wav')
    with t.extractfile(m) as f:
     for b in iter(lambda:f.read(1048576),b''):
      h.update(b)
      if keep:data.append(b)
    assert m.size==row['bytes'] and h.hexdigest()==row['sha256'],actual
    covered.add(actual);declared+=1
    if keep:
     p=out/a['archive'].removesuffix('.tar.gz')/actual;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b''.join(data))
   m=files[mn];p=out/a['archive'].removesuffix('.tar.gz')/mn;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
  extra=sorted(set(files)-covered-set(a['manifest_names']))
  reports.append({**a,'declared_payloads_verified':declared,'regular_members':len(files),'unmanifested_files':extra})
  print(json.dumps(reports[-1]),flush=True)
(out/'verified-all-archives.json').write_text(json.dumps(reports,indent=2)+'\n')
