# Future native scope — not a dispatch request

This partial checkpoint is not full445 acceptance. No native job is requested now. If root elects to check the new bounded component, exact source049a/tree1f2, run only:

    cargo test -p hex-ui --features ui-test-support --lib editor::clip_loop_tests::pointer:: -- --nocapture

Expected EXACT3 unique PASS/0FAIL/0ignored: midi_loop_corner_pointer_repeats_crop_commits_one_undo; midi_loop_first_marker_pointer_keeps_outer_duration_and_undo; midi_loop_corner_stationary_snap_modifier_and_escape_preserve_project. Private RAII browser/sample/recent/theme paths exist BEFORE constructor/workers; actual initial directory/places asserted bounded. Real offline Service worker + GPUI test-window events, no audio device/app/real browser/native UI launch. No full21/old suites repeat implied.

Physical optimized acceptance remains OPEN after fullfeature completion: Audio+MIDI crop capture/nonzero offset, independent outer/first-repeat marker, normal trim/Shift warp/fades/snap focus/escape/stale capture, tiny rows/rounded lower borders/theme/zoom/tempo, Undo/save-reopen/playback/export. User app stays preserved; only root dispatches serial Mac/delivery.
