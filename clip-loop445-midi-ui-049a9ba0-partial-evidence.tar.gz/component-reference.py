import importlib.util, pathlib, sys
root = pathlib.Path('/workspace/hex-clip-loop')
spec = importlib.util.spec_from_file_location('hex_local_ci_445', root / 'scripts/local-ci.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
steps = (
    module.Step('midi-ui-loop-and-adjacent', ('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--','editor::clip_loop_tests::','midi_loop_preview_tests','rendered_midi_trim_previews_note_geometry_and_commits_release_snap','rendered_midi_left_trim_keeps_source_note_timeline_position','--nocapture')),
    module.Step('midi-model-adjacent', ('cargo','test','-p','hex-project','--test','midi_loop_preview','--test','midi_once','--test','midi_split','--test','midi')),
    module.Step('ui-style', ('python3','scripts/check-ui-style.py')),
    module.Step('strict-clippy', ('cargo','clippy','-p','hex-project','-p','hex-ui','--all-targets','--features','hex-ui/ui-test-support','--','-D','warnings')),
    module.Step('touched-fmt', ('rustfmt','--edition','2024','--check','crates/hex-ui/src/editor/trim.rs','crates/hex-ui/src/editor/arrangement.rs','crates/hex-ui/src/editor/clip_loop_tests.rs','crates/hex-ui/src/editor/clip_loop_tests/pointer.rs')),
    module.Step('diff-check', ('git','diff','--check')),
)
raise SystemExit(module.LocalCiRunner(root=root, mode='quick', steps=steps).run())
