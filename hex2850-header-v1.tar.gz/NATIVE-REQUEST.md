# Root-only finite native check

Build ONLY sourcee2f6319c27f87f9e1153ad47b1f27cdc69876704/tree50c4173a0a7427bd7a49189f9a5458dd63b22b2b, never this evidence ref. Current app closed/running state must be read only; no app inputs, replacements, launch, quit, signaling, signing or profile/TCC/keychain/media changes.

Existing serial Mac verifier/private legitimate Cargo target, configured toolchain and NORMAL stack. Retained414 test environment owns disposable browser/home/preferences paths before worker startup; no ambient discovery. Exact ONE changed fixture (three widths inside):

```sh
cargo test -p hex-ui --features ui-test-support --lib --locked editor::header::ui_tests::compact_header_centers_project_title_and_keeps_toolbar_controls_clear_of_traffic_lights -- --exact --nocapture
```

Require1PASS/0ignored/Cargo0, capture printed actual version/Log/Changelog/title/Tempo/Import/window bounds at880/960/1440, macOS light-size/order/title-clearance assertions. Preserve originale626failed full21 and all logs. No repeat unchanged changelog keyboard5/Operator/native AI generation/Python checks solely for TESTONLY delta. If native still fails, stop with actual bounds/style/font/window facts, no normalization/skip.

Solemerger then exact prospective repository-required `python3 scripts/local-ci.py` (full21), fresh review/actualmerge/tree readback before delivery. This packet grants no build/install/activation operation on user's app. Native component pass is not physical visual acceptance or fullCI.
