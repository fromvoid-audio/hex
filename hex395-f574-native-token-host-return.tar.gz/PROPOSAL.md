# 395 mandatory-host operands: representation proposal only

Base d23ec4f5daf20c132922cb2e02bba1abc65fd684, with preserved native-token,
File-slot inventory and pre-DSP identity increment. No proposed host type/API has
been defined. This is the bounded representation return requested in 28202,
not a request to reconsider the vertical or remove existing binding checks.

## Actual typed operands and ownership

1. **File destination, `hex-session` + `hex-export`:** borrow the ACTUAL
   `Vec<MainControlFileJob>` in the existing worker-local File destination.
   `MainControlFileJob` owns `StagedWavFile`, identity/progress/pending block,
   `[Frame; 256]` copy, and optional first-panic payload. `StagedWavFile` owns
   `Option<BufferedWavFile>` (File + `[u8; 2048]` encoding), destination and
   temporary `PathBuf`, and `Publication`; Replace owns a THIRD distinct
   `OverwriteConsent.path` and inline `fs::Metadata`. The actual Vec capacity
   charges WHOLE job elements, including spare slots, copy and encoding. Do not
   add those embedded bodies/buffers again. Visit each occupied slot's actual
   destination/temp/consent backing separately. A panic payload/incomplete job
   refuses; no heap-child absence inferred merely from a role name. No queued
   PCM exists in this direct path. If a later actual queue adds a PCM array,
   its enclosing reserved record is another physical destination and is charged.

2. **Selected compilation target, `hex-session`:** borrow the actual
   `SharedCanonicalAudioSource = SharedMetadata<CanonicalAudioSourceSnapshot>`
   AND its `project: SharedProject = SharedMetadata<Project>` field, context,
   mode and source-binding table. The captured Project remains distinct from
   current authoring. Preserve BOTH physical shared fields; aliases dedup body,
   never erase handle obligations. Actual producer is a borrowed
   `OriginalResourceBankPlan` resolved from `Session.media`/pending original
   assignment through `ResidentResourceSources`, not frame-converted legacy
   Audio. This operand includes actual pending slot/path/device assignment and
   its cancellation when present. `required_sources()` currently projects only
   authored audio references; it must not be mistaken for complete device assets.

3. **Current worker inputs, `hex-session`:** use the existing sealed
   `WorkerRootView`/private `WorkerDispatchState` as the source, not a new Editor.
   Mandatory fields are actual `Session` (editor + all retained history, media,
   sine, cancellation and transform/cache/waveform fields); current `Arc<ViewState>`;
   compiled field; MIDI preview; clipboard; media/recovery/document/journal;
   keyboard activation/hint; audition/expression; device/tuning gesture machines;
   current/pending Event and previews; export/seek pending/completion fields;
   actual `SnapshotWorkerControl`. The target's old captured Project is not
   inferred from this current/history walk. Legacy compiled Arc/Playback and
   opaque queues are ACTUAL unsupported operands until replaced at birth/transport,
   never absent Options invented to make an empty positive. Their normal presence
   must still refuse in the unfinished stage.

4. **All retained Session families, `hex-desktop` + `hex-session` + `hex-audio`:**
   the existing `snapshot_transport::inventory::SnapshotFamilyInventory` borrows
   actual `RetainedFamilyInventory` outer slots plus a SEPARATE actual
   `Vec<SnapshotFamilyInventoryGuard>` inner list. Include their header/backing
   and acquisition scratch. Each guard borrows real `SnapshotExportRecords`,
   `CompiledRetirement` and `RequestRetirement`; visit actual snapshot/read Vecs,
   native compiled records, queued/claimed Request fields and failed/retiring
   fields. Later Event/export/seek records must be real fields here, not opaque
   channel lengths. After composing 447, actual `ComparisonAudioBinding.source`
   captured Project is an additional physical field even after history pruning.
   Current 395 does not have that model API, so no guessed compatibility field.

5. **Native/candidate products, `hex-audio`:** borrow ACTUAL private
   `CandidateRoot`/eligible `Custody::{bank,work}` under existing exclusions.
   `NativeBank` includes both DomainSlot owners/preparing/returned/failure state,
   publication Bank and NativeCandidateBoundary. Publication Bank includes all
   RuntimeSlot body/backing, life/anchors/domains/streaming/workspaces/returned/
   ready state and archive slots. Work includes preparations, anchors, returned
   executions, failed payloads, banks, domain execution and preparation scratch.
   PublicationControl adds actual publication/retired queues, held control return,
   status/forwarding/cancellation. The native callback owner contains current,
   outgoing, pending/replaced runtime and callback-side return state. Full active
   inspection requires the existing native exclusion LAST. Immutable paired
   `AudioCompiledRevision` inputs/anchors are borrowed as actual fields, not
   reconstructed from IDs/counts. Unknown legacy products/pending destructor
   phases remain refusal. No source getter, Arc adoption or scalar summary view.

6. **The ONE selected destination:** the actual `PreparationExecution.cell`
   `AudioCandidatePreparation` in the above Work slot, selected by the existing
   root/slot/incarnation token. Borrow it immutably with other roots for preflight;
   after inspection ends take a safe disjoint mutable borrow of THAT SAME field.
   Do not borrow unrelated parent cleanup authority, extract bank, mem::take rows,
   or use a new custodian. The actual embedded original bank is selected inside
   its existing parent operation. Other fields/owners remain persistent.

## Proposed location and dependency arrows

Keep the closed orchestrator and its complete concrete operand aggregate PRIVATE
in `hex-desktop/src/native_audio/main_construction.rs` (or sibling), where the
actual types above can all be named. Desktop -> Session -> Export -> Engine;
Desktop -> Audio -> Engine, while Session deliberately does not depend on Audio.
Engine cannot directly name `MainControlFileJob`, `StagedWavFile`, WorkerRootView,
SnapshotFamilyInventory or Audio's private native roots: adding those dependency
arrows creates cycles. No new crate/general storage framework is proposed.

Owning modules should construct scoped opaque borrowed views ONLY from their
actual fields: File reserved-slot view in Session, worker input view in Session,
and native-root/destination partition in Audio. Family inventory already exists.
Private constructors retain whole actual borrows; no caller supplies an arbitrary
visitor, claimed root count, list of ledger rows or approved total. Root/worker/
family/captured-source association is checked on actual fields in this closed
Desktop operation. These views are not lifetime/retirement/admission certificates.

**Precise representation decision still needed:** to cross down into Engine's
mandatory Inputs walk without reverse dependencies, I recommend a FINITE
Engine-owned borrowed field projection, emitted only by the concrete owning
module views in that private host call. Its categories must be limited to actual
metadata container/body borrows, path fields, and existing Engine-known paired
Project/source/compiled/runtime/anchor/input descendants. Retain actual references
and physical field identities, not copied bytes/totals/observer output. No arbitrary
`Fn(&mut Ledger)`/trait-object visitor registration. The projection must distinguish
metadata-only enclosing bytes from all reachable owning children; a generic opaque
body entry cannot assert those children absent or explain unrelated PCM.

The remaining question is how to seal the finite foreign-parent BODY projection
(File slots and Session/family enclosing records) to those actual module-created
borrows across this crate DAG. A generic Vec<T>/Any-body list alone would be too
permissive as complete-input authority; its existing API is selected metadata
only. I have NOT defined such a public projection or claimed it sealed. Root can
choose that narrow field-projection boundary (with actual producer restrictions)
or a different concrete cross-crate placement; an arbitrary visitor or full-ledger
import is explicitly not an acceptable fallback. This is the only new interface
representation question, not another full architectural gap review.

## Insertion points and borrow lifetime

- Existing Audio `with_runtime_preparation` validates actual token and selects the
  persistent cell. Extend inside the same private host construction, rather than
  export a second approved object or make the adapter own the cell.
- Existing Engine `sampler_compile::Inputs` adds the chosen borrowed outer operand;
  `visit_at` walks it into the SAME ledger BEFORE `require_original_inputs_bound`
  and `original_ledger_storage`. Actual inner visits remain mandatory unchanged.
- Arithmetic/bootstrap, fallback dedup and NORMAL pass must see the same host
  operands; normal pass cannot be skipped when arithmetic fits. Both retained and
  peak checks include original ledger live body/growth/backings, fresh scoped
  ledger/backing, all actual outer bodies/children and construction scratch.
- Keep actual outer-family then inner-family inventory guards/list ownership,
  actual Session/cache scoped borrows, actual native/root selection and final
  native exclusion ordering. Drop the scoped ledger INSIDE its supporting guard
  scope. After whole immutable inspection ends, continue on the same persistent
  fields under source/worker exclusion and borrow the actual destination mutably;
  no external callback/approval/exported totals intervenes. Existing guarded-cache
  bootstrap/transaction lifecycle remains, not a lifetime cast.
- Construction-stage borrows and any family/control/work/native guards END before
  ControlWork DSP turns or File I/O. Each turn obtains a fresh short exact-token
  loan; File write happens after it returns; later exact ACK is a separate loan.
  Reader-Pending stays recorded in continuation while the host receives nonfatal
  callback success. Native publication frontier remains a later separate full
  recheck; Collecting is not Ready and Main is not native-publication eligible.

## Source evidence and limits

Actual added File rows give SourceMismatch because unchanged Inputs.visit_at does
not name them; original-bound checks correctly refuse. No generic checks changed.
The original desired-positive red/source/log remain preserved. A separate current
regression tests that required refusal; it is NOT green whole-union construction.
The supported token/readerPending component, File exact/minus-one selected quote
and actual stale-identity-before-DSP red->green are independent positive evidence.
Service dispatch remains disabled until representation/composition and actual
normally present startup/transport/input/source fields are verified. No native,
physical app/listening, fullCI, merge, playable Sampler or goal3 completion claim.
