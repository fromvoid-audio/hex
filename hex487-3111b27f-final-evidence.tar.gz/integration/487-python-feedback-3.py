import importlib.util,pathlib,sys
root=pathlib.Path.cwd();s=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='487-python-feedback-3',steps=(m.Step('all tooling and private Cargo regressions',('python3','-m','unittest','discover','-s','scripts/tests','-p','test_*.py'),uses_cargo_target=True,requires_tests=True),),adopt_target=True,min_free_bytes=2*1024**3)
raise SystemExit(r.run())
