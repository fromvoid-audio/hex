import importlib.util,pathlib,sys
root=pathlib.Path.cwd();s=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='487-real-ui-warm-freshness',steps=(m.Step('ui-warm-first',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--no-run','--message-format=json'),uses_cargo_target=True),m.Step('ui-warm-repeat',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--no-run','--message-format=json'),uses_cargo_target=True)),adopt_target=True,min_free_bytes=2*1024**3)
status=r.run()
if status: raise SystemExit(status)
import json,datetime
out=[]
for step in r.summary['steps']:
 events=[]
 for line in (root/step['log']).read_text().splitlines():
  if line.startswith('{'):
   value=json.loads(line)
   if value.get('reason')=='compiler-artifact' and value.get('target',{}).get('name')=='hex_ui': events.append(value)
 if not events: raise RuntimeError('no actual hex-ui Cargo compiler artifact observed')
 out.append({'step':step['step_id'],'fresh':[e.get('fresh') for e in events],
             'targets':[e['target']['kind'] for e in events],
             'seconds':(datetime.datetime.fromisoformat(step['ended_at'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(step['started_at'].replace('Z','+00:00'))).total_seconds()})
if not all(out[-1]['fresh']): raise RuntimeError('identical repeat recompiled hex-ui')
record={'source':r.summary['commit'],'scope':'actual Hex test compilation only; no extra tests claimed',
        'target_action':r.summary.get('target_cache',{}).get('action'),'steps':out,
        'baseline':'469-112b-matrix-before: 170.40 compile seconds over four separate identical-source Cargo calls; 54.12 Rust tests; different exact source, not matched whole-workflow speedup'}
(root/'artifacts/integration/487-real-ui-warm-freshness.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
