import importlib.util,pathlib,sys
root=pathlib.Path.cwd();s=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='487-review-d8bc-green',steps=(m.Step('review native flags timestamp and malformed receiver',('python3','-m','unittest','discover','-s','scripts/tests','-p','test_*.py','-k','test_current_review'),uses_cargo_target=False,requires_tests=True),),min_free_bytes=0)
raise SystemExit(r.run())
