import importlib.util,json,os,pathlib,subprocess,sys
root=pathlib.Path.cwd()
spec=importlib.util.spec_from_file_location("hex_local_ci",root/"scripts/local-ci.py")
ci=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ci;spec.loader.exec_module(ci)
runner=ci.LocalCiRunner(root,mode="full",min_free_bytes=2*1024**3)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()
assert head=="c8a08bea4c7bd4f227f2ef7315e423713b20578f"
pointer={"source":head,"tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=root,text=True).strip(),"python_pid":os.getpid(),"run_id":runner.run_id,"summary":str(runner.summary_path),"stdout":"artifacts/integration/487-c8a08bea-full-bootstrap.stdout"}
(root/"artifacts/integration/487-current-run-pointer.json").write_text(json.dumps(pointer,indent=2)+"\n")
print(json.dumps(pointer),flush=True)
result=runner.run();print("ACTUAL_TERMINAL",result,json.dumps({k:runner.summary.get(k) for k in ("status","duration_seconds","stale","commit","dirty")}),flush=True)
raise SystemExit(result)
