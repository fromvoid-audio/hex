//! Immutable canonical Project/counter pairing owned by the existing worker.
//! Correlation only: constructor custody and exact page protection remain separate.
use super::*;
pub struct CanonicalAudioSourceSnapshot {
    project: Arc<Project>,
    context: hex_engine::AudioSourceContext,
    mode: crate::DocumentAudioMode,
    sources: BTreeMap<hex_project::AssetId, crate::AudioSourceBinding>,
}
impl CanonicalAudioSourceSnapshot {
    pub(super) fn capture(
        project: &Arc<Project>,
        project_generation: u64,
        editor_revision: u64,
        session: &Session,
    ) -> Self {
        Self {
            project: Arc::clone(project),
            mode: session.audio_mode(),
            sources: session.source_bindings(),
            context: hex_engine::AudioSourceContext {
                project_generation,
                editor_revision,
            },
        }
    }
    /// Control-side identity check for retaining this exact preparation source.
    /// File facts and PCM handles are compared, never read/copied/adopted here.
    pub(super) fn matches_session_sources(&self, session: &Session) -> bool {
        if self.mode != session.audio_mode() {
            return false;
        }
        let current = session.source_bindings();
        self.sources.len() == current.len()
            && self
                .sources
                .iter()
                .all(|(id, source)| match (source, current.get(id)) {
                    (
                        crate::AudioSourceBinding::Resident(old),
                        Some(crate::AudioSourceBinding::Resident(new)),
                    ) => old.sample_rate() == new.sample_rate() && old.shares_pcm_with(new),
                    (
                        crate::AudioSourceBinding::VerifiedFile(old),
                        Some(crate::AudioSourceBinding::VerifiedFile(new)),
                    ) => old == new,
                    _ => false,
                })
    }
    pub fn audio_mode(&self) -> crate::DocumentAudioMode {
        self.mode
    }
    /// Immutable resolved bindings paired with this exact Project/context.
    /// Facts only: native publication must match actual retained source leases.
    pub fn sources(&self) -> &BTreeMap<hex_project::AssetId, crate::AudioSourceBinding> {
        &self.sources
    }
    /// Current musical references only, excluding bindings retained solely for
    /// Undo/Redo or unused asset records. This is a projection of the captured
    /// Project, not a second editable model or native source authority.
    pub fn required_sources(
        &self,
    ) -> impl Iterator<Item = (hex_project::AssetId, &crate::AudioSourceBinding)> {
        self.sources.iter().filter_map(|(id, binding)| {
            let arrangement = self.project.tracks().iter()
                .any(|track| track.clips().iter().any(|clip| clip.asset() == *id));
            let session = self.project.session_cells().iter().any(|cell| {
                matches!(cell.content(), hex_project::SessionCellContent::Audio(clip) if clip.asset() == *id)
            });
            (arrangement || session).then_some((*id, binding))
        })
    }
    pub fn sample_rate(&self) -> u32 {
        self.project.sample_rate()
    }
    /// Conservative reservation only; the actual native constructor remains
    /// responsible for source/custody/closed-class validation.
    pub fn candidate_reservation_quote(
        &self,
    ) -> Result<hex_engine::AudioCandidateReservationQuote, hex_engine::AudioStorageError> {
        hex_engine::AudioCandidateReservationQuote::for_project(
            &self.project,
            self.required_sources().count(),
        )
    }
    pub fn context(&self) -> hex_engine::AudioSourceContext {
        self.context
    }
    /// Prepare inside the native host's reserved cell without extracting its
    /// bank, draft or completed owner into the Session/Desktop adapter.
    pub fn prepare_candidate_on_control(
        &self,
        source_catalog_generation: u64,
        destination: &mut hex_engine::AudioCandidatePreparation,
    ) -> Result<(), hex_engine::AudioStorageError> {
        destination.prepare_on_control(&self.project, source_catalog_generation, self.context)
    }
    /// Keep a host's already-rooted input bank in place during all fallible
    /// preparation. Native custody still comes only from the actual constructor.
    pub fn begin_prepared_revision_in_place(
        &self,
        source_catalog_generation: u64,
        custody: &mut hex_engine::AudioPreparationCustody,
        inputs: &mut Option<hex_engine::OwnedAudioInputs>,
    ) -> Result<hex_engine::AudioPreparationToken, Box<hex_engine::AudioArrangementStartRefusal>>
    {
        custody.begin_prepared_revision_in_place_on_control(
            &self.project,
            source_catalog_generation,
            self.context,
            inputs,
        )
    }
    /// Borrow the exact captured Project and copy its paired canonical context.
    /// Catalog generation validates media keys and is not document generation.
    pub fn arrangement_input(
        &self,
        source_catalog_generation: u64,
        inputs: hex_engine::OwnedAudioInputs,
    ) -> hex_engine::AudioArrangementInput<'_> {
        hex_engine::AudioArrangementInput::new(&self.project, source_catalog_generation, inputs)
            .with_source_context(self.context)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn next(service: &Service) -> Event {
        service
            .events
            .recv_timeout(std::time::Duration::from_secs(5))
            .unwrap()
    }
    fn bank() -> hex_engine::OwnedAudioInputs {
        hex_engine::OwnedAudioInputs::try_new(
            vec![],
            hex_engine::AudioStorageReservation {
                allocation_items: 64,
                handle_obligations: 256,
                max_prepared_data_bytes: 64 * 1024 * 1024,
                max_construction_data_bytes: 64 * 1024 * 1024,
                caller_retained_bytes: 0,
                caller_construction_bytes: 0,
            },
        )
        .ok()
        .unwrap()
    }
    #[test]
    fn canonical_worker_captures_project_and_counters_together_and_preview_cannot_mint_context() {
        let service = Service::new(48000, 16, 0).unwrap();
        let initial = next(&service);
        assert_eq!(
            initial
                .state
                .canonical_audio_source
                .as_ref()
                .unwrap()
                .context(),
            hex_engine::AudioSourceContext {
                project_generation: 0,
                editor_revision: 0
            }
        );
        service
            .submit(Request::Edit(Command::AddTrack {
                name: "audio".into(),
            }))
            .unwrap();
        let added = next(&service);
        let track = added.state.project.tracks()[0].id();
        service
            .submit(Request::Edit(Command::RemoveInstrument { track }))
            .unwrap();
        let captured = next(&service);
        assert!(captured.error.is_none());
        let snapshot = captured.state.canonical_audio_source.as_ref().unwrap();
        assert!(Arc::ptr_eq(&snapshot.project, &captured.state.project));
        assert_eq!(snapshot.context().editor_revision, captured.state.revision);
        assert_eq!(snapshot.context().project_generation, 0);
        service
            .submit(Request::Edit(Command::AddTrack {
                name: "later".into(),
            }))
            .unwrap();
        let later = next(&service);
        assert_eq!(
            later
                .state
                .canonical_audio_source
                .as_ref()
                .unwrap()
                .context()
                .editor_revision,
            later.state.revision
        );
        assert!(later.state.revision > snapshot.context().editor_revision);
        assert_eq!(snapshot.project.tracks().len(), 1);
        assert_eq!(later.state.project.tracks().len(), 2);
        let prepared = Arc::clone(
            captured
                .playback
                .as_ref()
                .unwrap()
                .prepared_revision()
                .unwrap(),
        );
        let preview = preview_view_state(
            &captured.state,
            Arc::clone(&captured.state.project),
            prepared,
        );
        assert!(preview.canonical_audio_source.is_none());
        if !hex_engine::audio_storage_constructor_layout_supported() {
            return;
        }
        let mut custody = hex_engine::AudioPreparationCustody::try_new_on_control().unwrap();
        let token = custody
            .begin_input_on_control(
                snapshot
                    .arrangement_input(11, bank())
                    .with_audio_prepared_revision(),
            )
            .ok()
            .unwrap();
        let mut owner = hex_engine::AudioCandidateOwner::try_new_on_control(custody, token)
            .ok()
            .unwrap();
        assert_eq!(owner.source_context(), Some(snapshot.context()));
        assert_eq!(
            owner
                .preparation()
                .audio_prepared_revision_metadata()
                .unwrap()
                .track_count,
            1
        );
        owner
            .seal_constructor_on_control(hex_engine::AudioStorageLedgerReservation {
                data_rows: 4096,
                handle_rows: 2048,
                root_rows: 4,
                max_retained_bytes: 64 * 1024 * 1024,
                max_construction_peak_bytes: 64 * 1024 * 1024,
            })
            .unwrap();
        let (mut runtime, anchors) = owner.split_constructor_on_control().ok().unwrap();
        assert_eq!(runtime.source_context(), Some(snapshot.context()));
        assert!(anchors.matches_current(&runtime));
        let proof = runtime.dispose_on_control().unwrap();
        let mut anchors = [Some(anchors)];
        proof.record_anchor_cells_on_control(&mut anchors).unwrap();
        anchors[0]
            .as_mut()
            .unwrap()
            .finish_disposal_on_control()
            .unwrap();
        assert!(
            anchors[0]
                .as_mut()
                .unwrap()
                .recover_inputs_on_control()
                .is_some()
        );
        let mut custody = hex_engine::AudioPreparationCustody::try_new_on_control().unwrap();
        let token = custody
            .begin_input_on_control(
                hex_engine::AudioArrangementInput::new(&snapshot.project, 11, bank())
                    .with_audio_prepared_revision(),
            )
            .ok()
            .unwrap();
        let mut legacy = hex_engine::AudioCandidateOwner::try_new_on_control(custody, token)
            .ok()
            .unwrap();
        assert_eq!(legacy.source_context(), None);
        legacy.dispose_on_control().unwrap();
    }
}
