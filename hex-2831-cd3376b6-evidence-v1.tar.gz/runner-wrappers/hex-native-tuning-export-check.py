import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-native-tuning')
spec=importlib.util.spec_from_file_location('hex_grid_focused_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('native-tuning-export',('cargo','test','-p','hex-export','--test','native_tuning_coverage','--locked','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
