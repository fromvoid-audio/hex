import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-native-tuning')
spec=importlib.util.spec_from_file_location('hex_native_tuning_focused_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('native-tuning-matrix',('cargo','test','-p','hex-engine','--test','native_tuning_coverage','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('native-tuning-export',('cargo','test','-p','hex-export','--test','native_tuning_coverage','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('native-tuning-providers',('cargo','test','-p','hex-devices','--lib','--locked','project_tuning_tests','--','--nocapture'),uses_cargo_target=True),
 m.Step('keyboard-tuning-guards',('cargo','test','-p','hex-engine','--lib','--locked','computer_keyboard::tuning_tests','--','--nocapture','--skip','profile_keyboard_tuning_handoff_copy_cost'),uses_cargo_target=True),
 m.Step('tuning-worker-history',('cargo','test','-p','hex-session','--lib','--locked','service::tuning_tests','--','--nocapture'),uses_cargo_target=True),
 m.Step('tuning-callback-allocation',('cargo','test','-p','hex-audio','--features','allocation-probe','--test','callback_allocations','--locked','project_tuning','--','--nocapture'),uses_cargo_target=True),
 m.Step('current-reference-roundtrip',('cargo','test','-p','hex-storage','--test','tuning','--locked','fractional_reference_frequencies_roundtrip','--','--nocapture'),uses_cargo_target=True),
 m.Step('native-tuning-clippy',('cargo','clippy','-p','hex-engine','-p','hex-export','--all-targets','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
