//! Sole owning Session producer for original-Sampler construction writers.
use super::*;
use std::cell::RefMut;

/// Held writers cannot escape their actual Session, and inspection cannot
/// return borrowed records across a mutable construction reborrow.
/// ```compile_fail
/// let session = hex_session::Session::new(48000, 16, 1024).unwrap();
/// let loan = session.original_sampler_session_loan_on_control().unwrap();
/// let escaped = loan.with_inventory(|inventory| Ok(inventory));
/// ```
pub struct OriginalSamplerSessionLoan<'a> {
    session: &'a Session,
    waveforms: RefMut<'a, SortedEntries<ClipId, AudioClipWaveform>>,
    transaction: hex_engine::audio_transform::OriginalSamplerTransaction<'a>,
}
impl Session {
    /// Existing order: waveform then cache/pending/tempo, before native guards.
    /// No allocation, pending write or candidate mutation during acquisition.
    pub fn original_sampler_session_loan_on_control(
        &self,
    ) -> Result<OriginalSamplerSessionLoan<'_>, AudioStorageError> {
        let waveforms = self
            .audio_clip_waveforms
            .try_borrow_mut()
            .map_err(|_| AudioStorageError::ExternalReadersPending)?;
        let transaction = self
            .audio_transforms
            .original_sampler_transaction_on_control()?;
        Ok(OriginalSamplerSessionLoan {
            session: self,
            waveforms,
            transaction,
        })
    }
}
impl<'a> OriginalSamplerSessionLoan<'a> {
    /// Actual media/history/waveform/transform fields under the SAME writers.
    /// The inspection result is never constructor authority: the selected
    /// constructor still performs mandatory normal binding and both cap checks.
    pub fn with_inventory<T>(
        &self,
        visit: impl for<'scope> FnOnce(
            &'scope ResidentPcmInventory<'scope>,
        ) -> Result<T, AudioStorageError>,
    ) -> Result<T, AudioStorageError> {
        let transforms = self.transaction.inventory();
        let inventory = ResidentPcmInventory {
            session: self.session,
            waveforms: &self.waveforms,
            transforms: &transforms,
        };
        visit(&inventory)
    }
    /// Sole private Audio construction consumer; source policy restricts this
    /// internal integration accessor. No owner is extracted and no guard ends.
    pub fn original_sampler_writer_on_control(
        &mut self,
    ) -> &mut hex_engine::audio_transform::OriginalSamplerTransaction<'a> {
        &mut self.transaction
    }
}

/// Borrowed real Session fields, produced only from held Session writers.
/// It owns no media, cache, waveform, source snapshot or admission receipt.
/// ```compile_fail
/// let session = hex_session::Session::new(48000, 16, 1024).unwrap();
/// let fields = {
///     let mut loan = session.original_sampler_session_loan_on_control().unwrap();
///     let (fields, _writers) = loan.resident_fields_and_writer_on_control();
///     fields
/// };
/// let _ = hex_engine::sampler_host_fields::OriginalSamplerResidentFields::media(&fields);
/// ```
pub struct OriginalSamplerResidentView<'a> {
    session: &'a Session,
    waveforms: &'a SortedEntries<ClipId, AudioClipWaveform>,
    session_frame: hex_engine::sampler_host_fields::BodyRef<'a>,
    waveform_frame: hex_engine::sampler_host_fields::BodyRef<'a>,
}
impl<'owner> OriginalSamplerSessionLoan<'owner> {
    /// Disjoint safe loans: waveform observations and actual cache writers.
    /// The readonly view never borrows cache payload through its RefCell.
    pub fn resident_fields_and_writer_on_control(
        &mut self,
    ) -> (
        OriginalSamplerResidentView<'_>,
        &mut hex_engine::audio_transform::OriginalSamplerTransaction<'owner>,
    ) {
        (
            OriginalSamplerResidentView {
                session: self.session,
                waveforms: &self.waveforms,
                session_frame: hex_engine::sampler_host_fields::BodyRef::of(&self.session),
                waveform_frame: hex_engine::sampler_host_fields::BodyRef::of(&self.waveforms),
            },
            &mut self.transaction,
        )
    }
}
impl hex_engine::sampler_host_fields::OriginalSamplerResidentFields
    for OriginalSamplerResidentView<'_>
{
    fn body(&self) -> hex_engine::sampler_host_fields::BodyRef<'_> {
        hex_engine::sampler_host_fields::BodyRef::of(self.session)
    }
    fn frame(&self) -> [hex_engine::sampler_host_fields::BodyRef<'_>; 3] {
        [
            hex_engine::sampler_host_fields::BodyRef::of(self),
            self.session_frame,
            self.waveform_frame,
        ]
    }
    fn editor(&self) -> &hex_project::Editor {
        &self.session.editor
    }
    fn transforms(&self) -> &hex_engine::audio_transform::AudioTransformPreparation {
        &self.session.audio_transforms
    }
    fn cancellation(&self) -> Result<&hex_engine::RetainedControlCancellation, AudioStorageError> {
        match &self.session.shutdown {
            crate::session_cancellation::SessionCancellation::Retained(worker) => Ok(worker),
            crate::session_cancellation::SessionCancellation::Unqualified(_) => {
                Err(AudioStorageError::UnknownStorage)
            }
        }
    }
    fn sine(&self) -> &hex_engine::SharedSineTable {
        &self.session.sine_table
    }
    fn media(&self) -> hex_engine::sampler_host_fields::VecRef<'_> {
        hex_engine::sampler_host_fields::VecRef::entries(&self.session.media)
    }
    fn asset(
        &self,
        index: usize,
    ) -> Result<hex_engine::sampler_host_fields::ResidentAssetFields<'_>, AudioStorageError> {
        use hex_engine::sampler_host_fields::{
            BodyRef, ResidentAssetFields, ResidentOriginalFields,
        };
        let (asset, resident) = self
            .session
            .media
            .as_slice()
            .get(index)
            .ok_or(AudioStorageError::SourceMismatch)?;
        let crate::ResidentAsset {
            source_audio,
            audio,
            waveform,
            frames,
        } = resident;
        let _: &u64 = frames;
        Ok(ResidentAssetFields {
            asset: *asset,
            body: BodyRef::of(resident),
            original_body: BodyRef::of(source_audio),
            original: match source_audio {
                OriginalAudio::Stereo(audio) => ResidentOriginalFields::Stereo(audio),
                OriginalAudio::Mono(source) => ResidentOriginalFields::Mono(source),
            },
            rendered: audio.as_ref(),
            waveform: hex_media::waveform::sampler_fields_on_control(waveform),
        })
    }
    fn waveforms(&self) -> hex_engine::sampler_host_fields::VecRef<'_> {
        hex_engine::sampler_host_fields::VecRef::entries(self.waveforms)
    }
    fn clip_waveform(
        &self,
        index: usize,
    ) -> Result<hex_engine::sampler_host_fields::ResidentClipWaveformFields<'_>, AudioStorageError>
    {
        let (_, clip) = self
            .waveforms
            .as_slice()
            .get(index)
            .ok_or(AudioStorageError::SourceMismatch)?;
        let AudioClipWaveform {
            waveform,
            offset,
            length,
        } = clip;
        let _: (&u64, &u64) = (offset, length);
        Ok(
            hex_engine::sampler_host_fields::ResidentClipWaveformFields {
                body: hex_engine::sampler_host_fields::BodyRef::of(clip),
                waveform: hex_media::waveform::sampler_fields_on_control(waveform),
            },
        )
    }
    fn verified_sources(&self) -> hex_engine::sampler_host_fields::VecRef<'_> {
        hex_engine::sampler_host_fields::VecRef::entries(&self.session.verified_sources)
    }
    fn validate_remaining_fields(&self) -> Result<(), AudioStorageError> {
        let Session {
            editor: _,
            audio_transforms: _,
            audio_clip_waveforms: _,
            shutdown: _,
            sine_table: _,
            media: _,
            verified_sources,
            semantic_source_epoch,
            audio_mode,
            source_reservation,
            resident_frames,
            max_resident_frames,
            resident_waveform_bins,
            resident_waveform_bytes,
        } = self.session;
        // Actual scalar-only current types; no ownership is inferred from a
        // counter, and every owning field is mandatory in the finite schema.
        let _: (
            u64,
            crate::DocumentAudioMode,
            Option<crate::SourcePlanReservation>,
            u64,
            u64,
            usize,
            usize,
        ) = (
            *semantic_source_epoch,
            *audio_mode,
            *source_reservation,
            *resident_frames,
            *max_resident_frames,
            *resident_waveform_bins,
            *resident_waveform_bytes,
        );
        if !verified_sources.is_empty() {
            return Err(AudioStorageError::UnknownStorage);
        }
        Ok(())
    }
}
