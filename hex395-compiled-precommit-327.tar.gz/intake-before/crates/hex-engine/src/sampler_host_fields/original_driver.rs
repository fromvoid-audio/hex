//! Borrowed interface for the ONE private Audio selected-parent facade.
//! This is an audited internal call boundary, not a hostile-client capability.
use super::{BodyRef, NativeFields};
use crate::{AudioCandidatePreparation, AudioCandidatePreparationOperations, AudioStorageError};

/// Engine's closed original-Sampler operation may inspect the actual complete
/// host, end ALL readonly projections/ledgers, then reborrow operations on the
/// SAME persistent cell. The concrete facade and every native guard stay in
/// Audio. No construction value, ledger, owner or approval crosses back.
///
/// Calling this interface alone grants no admission. The complete constructor
/// must visit mandatory worker/family/File/current/captured/native inputs and
/// check normal binding and both caps before borrowing mutable operations.
/// Repository policy restricts this to the actual private Audio implementation.
/// ```compile_fail
/// use hex_engine::sampler_host_fields::OriginalSamplerNativeHost;
/// fn extract(host: &mut dyn OriginalSamplerNativeHost)
///     -> &mut hex_engine::AudioCandidatePreparation {
///     host.selected_operations_on_control().unwrap()
/// }
/// ```
pub trait OriginalSamplerNativeHost: NativeFields {
    /// The real temporary facade/guards, footprint only; descendants still use
    /// NativeFields and the mandatory enclosing-input schemas.
    fn construction_frame(&self) -> BodyRef<'_>;
    fn selected_preparation_on_control(
        &self,
    ) -> Result<&AudioCandidatePreparation, AudioStorageError>;
    /// No mutation is possible until overlapping immutable loans have ended.
    /// Audio must revalidate the actual token and persistent field correlation.
    fn selected_operations_on_control(
        &mut self,
    ) -> Result<AudioCandidatePreparationOperations<'_>, AudioStorageError>;
}
