use hex_session::Session;
pub fn held_loan_then_transition(session: &mut Session) {
    let mut loan = session.original_sampler_session_loan_on_control().unwrap();
    let _ = session.undo_prepared_revision(None);
    let _ = loan.resident_fields_and_writer_on_control();
}
pub fn nested_loan_in_existing_finish_hook(session: &mut Session) {
    let _ = session.undo_prepared_revision_with(None, |_, _, _| {
        let _loan = session.original_sampler_session_loan_on_control().unwrap();
        Ok(())
    });
}
