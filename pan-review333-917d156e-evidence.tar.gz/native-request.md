# coordinator-only finite changed PR333 review checks
source 917d156e42c8d4cb6c672046cec48c9a7606eaca
tree 60588c715e4df7d0f103d7d66f06116a90e863f9
Default native stack, checks only, no app/GUI/backend/unlock/user-data operations.
cargo test -p hex-ui --features ui-test-support --locked -- --nocapture does_not_resurrect_hidden_pan_after_project_growth inward_
Expect exactly SIX positive tests, zero ignored/failures: cancel/stale+latergrowth2 (each both audio/MIDI), inward AudioShift both edges2, MIDI existing-clamp control1, both-edge supported release/UndoRedo1. Private bounded startup RAII fixture retained. Capture actual counts, exit/default-stack/source/tree/dirty/raw report+SHA. Do not repeat old333native5,403native6 or346native2.
The audio model-positive1frame boundary intentionally receives the existing prepared1/8..8 warp refusal. Tests assert visible error and unchanged canonical project; do not call this an accepted commit or relax renderer capability. Supported interior release is separately accepted and one Undo/Redo is checked. This repair is pan navigation, not Engine capability expansion.
Merger owns final combined tree FULL20/review/integration/merge. Root owns sole Mac queue and optimized physical acceptance. Physical edge capture/display/affected media/audio remain OPEN. Never checkout/build/merge evidence-only refs.
