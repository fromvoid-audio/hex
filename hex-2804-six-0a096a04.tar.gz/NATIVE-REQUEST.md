# Changed Python only; coordinator serial lane, no app actions

Pinned source 0a096a04b6e2d860491d361f20c3b6354c91f8df; tree 039700c3bcd22fae04de4929aad10bdeeb2deefb. Existing system Python3.9, no fallback/configuration.

```
/usr/bin/python3 -m unittest -v scripts.tests.test_changelog.ChangelogTests.test_followup_export_retains_history_for_second_import scripts.tests.test_changelog.ChangelogTests.test_import_malformed_completion_preserves_existing_dataset scripts.tests.test_changelog.ChangelogTests.test_success_removes_own_private_packet_but_failure_retains_diagnostics scripts.tests.test_changelog.ChangelogTests.test_export_is_owner_private_under_public_umask_and_preserves_foreign_directory scripts.tests.test_changelog.ChangelogTests.test_diff_input_is_independent_of_local_formatting_configuration scripts.tests.test_changelog.ChangelogTests.test_nonexistent_evidence_commit_cannot_publish_imported_notes scripts.tests.test_changelog.ChangelogTests.test_import_binds_exact_offline_archive_and_preserves_notes_on_wrong_proof
```

Expected exactly7/0failed/0ignored. Real temporary Git repos/local evidence archives and injected responses; no actual CLI inference/network/GPU/audio/user files. No Cargo/build/install/launch/New/Open/quit/TCC. Preserve source and production dataset hash before/end. This new archive/timestamp/Git portability path is changed; do not repeat oldUI5/keyboard3/Pythonstartup4. Root decides scheduling, no self-dispatch.
