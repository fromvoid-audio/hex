import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-integration-audio-placement')
spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='456-6a8dba49-guarded-focused',adopt_target=True,min_free_bytes=2*1024**3,steps=(m.Step('format',('cargo','fmt','--all','--','--check')),m.Step('phased-model-three',('cargo','test','-p','hex-project','--test','audio_view','--locked','review_phase_','--','--nocapture')),m.Step('phased-codec-one',('cargo','test','-p','hex-storage','--test','audio_view','--locked','phased_musical_fade_','--','--nocapture'))))
code=r.run();print('FOCUSED_ONLY_SUMMARY',r.summary_path);raise SystemExit(code)
