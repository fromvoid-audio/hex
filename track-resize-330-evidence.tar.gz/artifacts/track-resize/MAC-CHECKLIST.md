# finite track sizing acceptance — Pulse2714 / canonical PR330

Exact immutable source: 7a6595b794b4bd1b0ce9d20080fde88b3e4ba8c7; Git tree 522c57752402044e264146e111a82a419dfcccd1.
Linux full checks: 20/20 passed, clean/unchanged/stale=false.
Original report: artifacts/local-ci/20261017T155740Z-69c83002/summary.json; SHA256 5af6b809832aaa7913fe0bf7d3d22bd7fb30e82fe260fd53df418b62107b63ed.
Source-content SHA256: d16de7378a9f397b2c4072a1df17faf0010e0726f989d77eb1f62fda5c759e51.
PR330 head81092d5778c284850848ca3aea2e69b0df09244c also passed20/20;
five rendered resize regressions passed on the identical integration tree.
Included ancestral revisions are enumerated in included-test-revisions.json.
Use this pinned source for any source-bound native result; later main differs.
Cloud GPUI bounds/gesture checks do not establish physical macOS acceptance.
Coordinator owns the one local lane; no local work is dispatched by this file.
Do not quit or replace the user's running hex. Testing the changed UI requires a
later coordinated exact-source optimized stable-path build and normal user quit;
no new app delivery is needed to begin or finish cloud source work.

Use a disposable project and user-owned physical pointer/keyboard while present.
Record actual installed/running source and per-case outcomes. Existing project,
media, preferences and Ableton/other apps remain intact; no force quit or overwrite.

1. Drag the left boundary of the right-hand track-header column in both directions,
   including the pinned main header with an empty project. Confirm smooth bounded
   motion, complete minimum-size controls and retained timeline room. Verify all
   regular/main headers line up with the ruler, overview, loop rail and timeline.
2. Drag individual regular header bottom edges up/down, across/outside the header,
   to minimum and viewport-size maximum. Only that row changes; header and lane
   stay aligned, following rows move together and main/return rows remain pinned.
3. At minimum and expanded sizes, click name/selection and existing gain, mute,
   solo, automation and send controls. Their hit areas remain usable. Use only
   disposable-track state for intentional gain/mute edits; resizing itself does
   not change project dirty/Undo/audio state or select another track.
4. During each resize, test Escape, focus transfer, window resize and release
   outside the original header. Cancellation restores the prior size; normal
   release uses the last pointer position. No continued resize after release.
5. With many mixed-height tracks, scroll/pan, use keyboard track navigation and
   open a send menu. Keep row/lane alignment and menu anchor at the selected row;
   no scroll jump during a captured row resize. Window/browser width changes keep
   a sensible scroll extent and existing minimum workspace. New-project/reopen
   resets per-track display heights; width lasts for the editor view. No sizing
   persistence or project/schema/Undo change is claimed.
6. At widened/narrowed header sizes, verify a known timeline position against the
   ruler/grid/cursor, clip selection/move/trim and browser landing preview. Frames,
   snap, viewport/loop timing and audio stay unchanged by the layout resize.

Return exact source/receipt and screenshots if useful, fixture dimensions/track
count, physical capture/cancel/scroll results and any reproducible defect. Keep
native smoothness/physical input acceptance pending until the user reports it.
Signing fixtures and sample WAV permissions across identical-binary relaunch are
separate acceptance tasks, not inferred from this geometry check or spinner signoff.
