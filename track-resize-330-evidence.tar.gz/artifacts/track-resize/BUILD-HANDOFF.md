# Source-bound native request: Pulse2714 / PR330

This document requests coordinator scheduling; it does not dispatch Mac work.
PR330 is merged as 7a6595b794b4bd1b0ce9d20080fde88b3e4ba8c7, complete tree
522c57752402044e264146e111a82a419dfcccd1. No main merge hold remains.
The archive includes original merged-source Linux full-CI report/logs, separate
PR-head report/logs, merge/integration proof and the included revision manifest.
Use final-verification.json for report and source SHA256 values.

Prerequisites: existing managed Mac checkout/toolchain, clean source at this
exact immutable commit, configured Developer ID certificate and stable app path,
verified extracted evidence, coordinator-owned serial local slot. Do not change
source or label a later main build as this candidate. Do not run a second launcher
while another launch/build/check workload is active. No purchases or hosted CI.

Read-only preparation may run while Hex remains open: verify source/tree and the
transported report content digest against this checkout. Physical UI testing needs
the changed executable. Before any bundle replacement, coordinate the user's
normal save/quit of Hex and confirm the existing installer process guards pass.
Do not force quit Hex/Ableton, discard files or mutate a running application.

After those prerequisites, from the clean exact-source checkout, the existing
repository delivery command is:

```sh
git rev-parse HEAD HEAD^{tree}
git status --porcelain=v1 --untracked-files=all
sh scripts/bundle-macos.sh \
  --ci-report artifacts/local-ci/20261017T155740Z-69c83002/summary.json \
  --candidate 7a6595b794b4bd1b0ce9d20080fde88b3e4ba8c7 \
  --included artifacts/track-resize/included-test-revisions.json \
  --checklist artifacts/track-resize/MAC-CHECKLIST.md
```

This performs the optimized build and repository-owned signed stable-path
installation with source/provenance/signature/process verification. Preserve its
receipt, executable SHA256, signing identity and installed full source. Use the
existing explicit `./launch --open` only after successful delivery to open that
installed build. Plain `./launch` instead fetches/builds latest main and therefore
may produce another source; record its actual receipt if the user chooses it.
Do not add tests to the normal launcher default.

Ask the user to perform the six finite cases in MAC-CHECKLIST.md; record actual
running source and outcomes. Cloud rendered GPUI tests do not establish native
physical capture/smoothness. No repeated broad spinner acceptance is requested.
Any candidate-required native signing fixtures remain separately truthful; this
Linux report is not a Mac full-CI result.

The older combined signing/sample acceptance remains separate: real Developer ID
fixture on the actual integrated source; user-selected WAV access/real audible
preview in /Users/portalsurfer/Documents/music_production/samples; normal user quit
and `--open` relaunch of the identical executable (hash/signature unchanged), then
repeat access/preview without another grant. No TCC reset or broad permissions.
Neither resize nor prior user spinner signoff establishes these outcomes.
