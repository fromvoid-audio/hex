# Coordinator-only one changed component

Exact source afcd2d717e6ede155ab8d0594d1d4fe1c85a67e2/tree 6cf3948069be4ddcf8af933136cba9404514f178; never build evidence ref. Existing serial Mac lane/private legitimate target only. ONE command, exactly1PASS/0ignored expected:

```sh
cargo test -p hex-ui --features ui-test-support --locked editor::dialogs::ui_tests::selected_open_path_survives_owned_restore_before_render_and_opens_once -- --exact
```

Retained disposable test browser path before worker startup. Real Service + GPUI public action/TestPlatform picker + entity observer ordering, no real OS picker/app/GUI input/CPAL/hardware. Preserve source and raw installed app/primary/profiles/media/receipts/locks; report actual source/command/status/logs/before-end evidence. No repeat oldnative6 solely for this one-condition delta. No launcher/build/install/quit/signals or other app actions authorized. Physical chooser/audio acceptance remains separate; merger owns full prospective candidate.
