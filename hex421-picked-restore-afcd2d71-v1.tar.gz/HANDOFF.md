# PR421 selected-path Restore race

Source afcd2d717e6ede155ab8d0594d1d4fe1c85a67e2, tree 6cf3948069be4ddcf8af933136cba9404514f178, parent 389b629465576c8ccb16c831574e2398cef5768e. Published owner branch source/2815-picked-path-restore; cherry-pick this single owner commit in the sole merger's normal canonical integration. No new PR or canonical overwrite. Original389b full20PASS612.751s and prioracfc native6 remain historical source-bound evidence, not qualification of this new patch.

Production controller delta is one condition: preserve pending_open_path only for the existing already-validated recovery_restore exception. Existing generation ownership checks/edit and foreign-token refusal remain. No mode fields/counters/Session or API changes, no new recovery path.

Actual new red on parent389b: public Open action, real TestPlatform picker continuation, entity notification BEFORErender, matching owned Restore enqueued, selected path unexpectedly cleared. Original Cargo101 log retained. New case now passes, proving foreign recovery+edits refuse at that cutpoint, chosen path survives, original document/revision/history remain until confirmation, then Don't Save opens that same selected document exactly once. Complete20dialog tests pass0ignored, strictUIalltargetsfeatureClippy0 and5guards/fmt/diff0. Logs saved with real Cargo statuses captured in shell wrappers. Tests use retained disposable363browser ctor; injected chooser results are not actual native OS picker acceptance.

User data/live app untouched. No native self-dispatch. Required prospective exact-candidate CI/review and merge belong to cloud3; Pulse remains In Progress until actual merge.
