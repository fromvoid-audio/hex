# Coordinator-only finite border checks
Source 5776b06a8447f17bbadbfd4e6d08531d1e9e03bf
Tree 0a9a966c3177700217aceda5c68ab84c2312d592
No app install/launch/quit/backend or physical input operations from this lane.
If a changed native CLI check is warranted, use default native stack:
cargo test -p hex-ui --features ui-test-support --locked --lib editor::clip_border_ui_test::all_four_clip_edges_paint_above_actual_row_separator_without_geometry_changes -- --exact --nocapture
Expect exactly ONE positive test, zero ignored/failures, twenty `four edges clip=` diagnostics: five mixed audio/MIDI clips x selected/middle-deselected x44/88px rows. Every pixel-center edge strip checks mask-union coverage and order vs actual separator, selection doesn't alter geometry or Project. Private bounded RAII sample/browser/recent/theme paths are established before worker startup. Do not broaden native selector to old335 fixture or repeat unchanged native suites.
Save exact source/tree/default-stack/exit/counts/raw log+SHA. Scene evidence is not framebuffer/GPU/physical proof. On eventual coordinator-qualified optimized delivery, visually inspect all four red edges for audio/MIDI/multi-selection at minimum and enlarged heights, clipped viewport ends and deselection; preserve names/waveform/notes/header/trim/fade affordances. Manual original2719 four-edge acceptance remains OPEN.
Merger owns prospective-tree full20/review/merge. Root owns sole Mac lane and app delivery. Never checkout/build/merge evidence refs.
