# EQ cycle 1 read-only baseline inventory

Prepared 17 October 2026 for Pulse2784 / canonical PR390. This is investigation
material, not implementation, native acceptance or a completed review. Reference
inspection proceeded while separately owned bug2786/PR392 was qualifying.

Source pin: original combined327ebe98d575061f4d16f3db894aea5b624b86b4 and focused
repair96ee313a15111b9dded9dd456632d8b288dda515 (treef6ca184c107ddb5bb3877b7591c40f2e45a22c44).
Actual installed app is earlierdfa/build3751944026; no claim these sources are
installed/running. PR392 full20failed at9 in a separate unchanged engine fixture;
no current full qualification. Prior six EQ PR receipts remain historical source
milestones, immutable evidenceb0713bd6fbf61cebbcc85e6e3fbde1e868f69c83. Gesture2729
already user accepted; no repeat approval gate.

## Reference identity

FabFilter Pro-Q4 official online help, inspected2026-10-17. Moving documentation,
not an installed reference executable/version measurement. No cloud access to a
licensed installed reference, physical audio, native screenshots or direct A/B.
The following links are the exact inspected pages. Interpretations below are
paraphrases, no proprietary code/assets were used.

- https://www.fabfilter.com/help/pro-q/using/eqdisplay
- https://www.fabfilter.com/help/pro-q/using/analyzer
- https://www.fabfilter.com/help/pro-q/using/overview
- https://www.fabfilter.com/help/pro-q/using/bandcontrols
- https://www.fabfilter.com/help/pro-q/using/dynamic-eq
- https://www.fabfilter.com/help/pro-q/using/spectral-dynamics
- https://www.fabfilter.com/help/pro-q/using/processingmode

Workflow reference supports multi-band selection/editing, fine and constrained
gestures, direct values and adjustable graph scales. Analyzer documentation offers
pre/post/external traces and adjustable range, resolution, decay and tilt. Its
band guide explicitly warns that matching numerical Q between EQs need not match
their response. Therefore any later legally available A/B must match measured
response, phase and level, not merely identical knob numbers.

## Source comparison matrix

“source verified” refers to identified existing tests/history, not current full
suite/native acceptance. “unverified” means additional measurement is needed,
not an asserted defect. Keep the original Hex theme and shared native widgets.

| Area | Hex source inventory / evidence | Classification and next action |
| --- | --- | --- |
| Bell/edge-cut creation | eq_panel.rs, docs/eq.md;2729/342 stable-ID preview/release/cancel tests | source verified; user accepted gestures preserved |
| Single-node selection/drag | EqPanel selected Option<NodeId>, ResponseGraph stable-ID events | source verified; native task timing pending |
| Multiple-node selection/group edits | single selected-node owner in current EQ panel | missing capability; propose later, no implied expansion |
| Fine movement | ResponseGraph Shift precision and arrow keys; widget tests | source verified; native text/focus/precision check pending |
| Axis-constrained modifiers/wheel-Q | current graph drag law vs Pro-Q documented axis/wheel workflows | comparison gap; verify actual event coverage before product decision |
| Frequency/gain/Q direct values | shared canonical native controls/descriptors; graph authored curve | implemented; finite native entry/focus check pending |
| Filter shapes | bell, low/high shelf, low/high cut, notch | implemented; broad numerical response matrix still incomplete |
| Slopes | cuts12/24/36/48db/oct; source finite/attenuation tests | deliberate bounded capability; fractional/brickwall/other-shape slopes missing |
| Banks/modes | stereo/L/R/M/S banks, global stereo/LR/MS mode | implemented; independent channel/mid-side stimulus audit pending |
| Capacity |64 stored nodes incl disabled across banks;64lanes/160points/64points-per-lane | existing decision retained; no silent cap/budget changes |
| Per-band bypass/delete | canonical enable/remove; node+automation atomic removal | source verified; native focus isolation pending |
| Solo/listen | stable-ID transient audition,256frame fades; actual callback fixture | source verified; level/discontinuity/listening checks pending |
| Undo/Redo/identity | monotonic node IDs/high-water allocator and atomic history | source verified; current-format disposable save/reopen pending |
| Automation | content clock,64sample coefficient cadence/ramps; partition/retarget/loop tests | source verified within existing contract; zipper metric/listening pending |
| Response graph | explicitly authored response; cache by state/rate | deliberate difference from live automated response; label must remain truthful |
| Static transfer | existing actual-cut impulse transform test at48k/3queries, finite shape/rate tests | source verified limited matrix; high-Q/extreme/rate error audit pending |
| Input/output traces | actual entry pre/post including trims;2730/343 | source verified; native calibration/bypass/Return checks pending |
| Analyzer power |4096Hann/96logbands, stereo power, immediateattack/48db/sdecay, -96..0dbfs | source verified; settings/tilt/freeze/range variation missing or deliberate fixed choices |
| Project spectra | actualMaster plus each selected canonical track up to256, direct postdevice/postfader/balance | implemented; new default-stack defect2786/392 source repair under qualification |
| Analysis freshness/lifecycle |100msEQ, project100/250/400ms, generation/token/sequence refusal | source verified; physical native churn/collapse/driver behavior pending |
| Compact layout | shared intrinsic text actions/frequency dial/separate automation row;2731/344 | rendered source tests; native880x540 and1500x650 pending |
| A/B state slots | no current EQ-owned A/B workflow found; Undo is not A/B | missing capability; propose later scoped decision |
| Auto level matching | output trim exists; no measured auto-match contract found | missing capability; manual calibrated matching for audit only |
| Phase modes | zero algorithmic latency IIR; no Natural/linear phase modes | deliberate current boundary; later architecture/cost proposal |
| Dynamic/spectral EQ | static band/automation model; no detector/spectral processing contract | explicit missing capability; separate native roadmap scope, not polish changes |
| EQ Sketch/Grab/Match | no current authored equivalents | missing capability; later product proposals |
| External/instance spectra | project layer panel exists; not cross-instance external analyzer routing | deliberate distinction; external/instance workflows missing |
| Advanced shapes/channel formats | no bandpass/tilt/allpass or immersive mode in sparseEQ | explicit gaps; no implied parity |

## Prioritized findings and reproducible evidence

1. P1 observed native factory overflow:327 Mac summary1ca28364/log38928b71,
   Linux original fixture red with default stack. Repaired separately in2786/392;
   do not fold that code/history into390. Initial Mac default debug passes relayed
   by coordinator; final release/receipt evidence pending. All256layers retained.
2. P1 qualification blocker: unrelated engine effect-tail fixture overflows default
   debug stack on both327 and96ee. Both engine executable hashes identical
   36245a4db3e0a247fec7c47e5183dd0369da1962bb9b76c5930f75a32d8e35a4.
   Owner/coordinator decision pending; no engine source changes in392 or390.
3. P2 evidence gap: existing numerical curve test only covers one cut at48k.
   Prioritize an independent actual-PCM response audit before asserting sound
   quality. This is insufficient coverage, not an observed sonic defect.
4. P2 evidence gap: new analyzer controls/workflow still require the finite native
   compact-layout/focus/level/listening session. Do not substitute cloud renders
   or old gesture acceptance for those results.
5. Feature gaps above are proposals, not bugs or selected implementation by fiat.
   Multi-select, A/B, axis/Q workflow and clear analyzer scales are candidates for
   coordinator prioritization after concrete numerical/native findings.

## Proposed measurement protocol (freeze before implementing audit fixes)

- Independent PCM response: deterministic impulse and coherent/noncoherent tone
  projections, six supported shapes, all cut slopes, both gain signs, Q extremes,
  low/mid/high frequencies, supported rates8/44.1/48/96/192k. Refuse queries at or
  above Nyquist explicitly; distinguish authoredfrequency from rate-clamped DSP.
- Proposed tolerance:0.05dB relative magnitude error where oracle>-80dB; below
  that use absolute linearerror<=1e-5. Predefine finite impulse truncation/tail
  residual criterion; a not-yet-decayed high-Q response is inconclusive, not a
  reason to widen tolerance. Stereo lane/crosstalk and opposite-polarity probes.
- Analyzer calibration: bin and nonbin unity/half-amplitude tones, bass/noise/
  transient/silence, pre/post trims and bypass. Keep existing kernel calibration
  and decay tolerances; distinguish band energy/leakage from tone peak level.
- Automation: partition invariance, rapid authored revisions, loop/seek clocks,
  stable IDs/history and export equivalence; retain maximum sample-step/RMS and
  spectral sideband metrics with input/transition settings. No physical zipper or
  click verdict without listening and reference conditions.
- Cost: existing64node+64lane allocation and release density fixtures, all project
  layer cases0/32/128/256; record hardware, rate/buffer, warmups/trials/outliers,
  memory accounting and callback total/net allocations. No timing assertion or
  claim these prove driver/GPU deadlines.

## Finite native review session, later coordinator serial lane only

1. Bind exact corrected optimized source/tree/executable/build and original CI
   receipts; safe current app state before any authorized replacement. Record
   unavailable reference instead of requesting a purchase or changing ownership.
2. Disposable current-format project, original theme: bell/edge cuts, fine drag,
   exact values and Q/shape/slopes; record task time/misclicks and bounds.
3. Numeric/text focus, graph navigation, bypass/listen/delete and Undo/Redo;
   switch track/device midgesture, Escape/focus loss, confirm stable identity.
4. Input/output calibrated tones, bypass/Return/anti-phase/silence/stale cases;
   distinguish filter response scale from spectrum dBFS scale.
5. Compact880x540/expanded1500x650, long numeric values and automation row;
   project-panel resize/outside release/cancel/collapse with every selected layer.
6. Save/reopen disposable project; compare authored values, automation IDs and
   history behavior within the documented current format. No legacy migration.
7. Level-matched generated fixtures (sweep, bass, noise, drum-like transient),
   disclose phase/gain/Q laws; legally available installed Pro-Q4 only if present.
8. Raw release64band and all256layer profiles plus sustained callback/GPU evidence
   if instrumentation exists; missing physical telemetry stays UNRUN with owner.

Cycle1 remains open until comparison/baseline and selected findings have concrete
verified candidates or explicit actionable remaining blockers. Cycle2/2785/391
must use an independent reviewer after cycle1's candidate; not started here.
