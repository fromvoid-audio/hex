from pathlib import Path
import importlib.util,json,subprocess,hashlib
root=Path('/workspace/hex-integration');out=Path('/workspace/scratch/integration/410-ancestry-review')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='27b2168484e8250c66863d2eb030f34e9f09967a'
spec=importlib.util.spec_from_file_location('existing_changelog_test_fixture',root/'scripts/tests/test_changelog.py');fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
t=fixture.ChangelogTests('test_real_range_schema_export_and_source_identity');t.setUp()
try:
 t.git('checkout','--detach',t.base)
 # Use owner's explicitly injected test model. This is NOT real AI evidence.
 fixture.notes.prepare(t.root,t.base,source=t.source,model=t.model)
 candidate=t.commit('retain notes for feature absent from candidate')
 ancestor=subprocess.run(['git','-C',str(t.root),'merge-base','--is-ancestor',t.source,'HEAD']).returncode==0
 accepted=False
 try:fixture.notes.validate_current(t.root,if_present=True);accepted=True
 except fixture.notes.Refusal:pass
 spec2=importlib.util.spec_from_file_location('package_changelog_ancestry_fixture',root/'scripts/hex-test-build.py');package=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(package)
 raw,identity=package.changelog_payload(t.root)
 proof={'actual_source':'27b2168484e8250c66863d2eb030f34e9f09967a','base':t.base,'feature_source':t.source,'candidate':candidate,'source_is_ancestor':ancestor,'candidate_feature_text':(t.root/'feature.txt').read_text(),'model_calls':t.calls,'model_kind':'owner injected fixture response, NOT live AI','ordinary_validator_accepted':accepted,'package_identity':identity,'packaged_dataset_sha256':hashlib.sha256(raw).hexdigest() if raw else None,'expected':'refuse source outside candidate ancestry while preserving legitimate older ancestor coverage'}
 (out/'before.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'before-dataset.json').write_bytes((t.root/fixture.notes.DATASET).read_bytes());print(json.dumps(proof,indent=2),flush=True)
 assert not accepted,'ordinary offline validator accepts notes from source absent from candidate ancestry'
 assert identity['status']!='available','packaging accepts feature notes absent from candidate'
finally:t.doCleanups()
