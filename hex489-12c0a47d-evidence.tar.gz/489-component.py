import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-workspace-tab-489')
spec=importlib.util.spec_from_file_location('hex_ci_489',root/'scripts/local-ci.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
adopt='--adopt-target' in sys.argv
args=[arg for arg in sys.argv[1:] if arg!='--adopt-target']
step=module.Step(args[0],tuple(args[1:]))
raise SystemExit(module.LocalCiRunner(root=root,mode='quick',steps=(step,),adopt_target=adopt).run())
