import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-workspace-tab-489')
spec=importlib.util.spec_from_file_location('hex_ci_489_final',root/'scripts/local-ci.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
steps=(
 module.Step('default-ui-lib',('cargo','test','-p','hex-ui','--lib','--locked')),
 module.Step('workspace-feature',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','--','--nocapture','workspace_view_ui_test','operator_tab_cycle','workspace_four_returns_','workspace_adb3_returns_')),
 module.Step('strict-default',('cargo','clippy','-p','hex-ui','--all-targets','--locked','--','-D','warnings')),
 module.Step('strict-feature',('cargo','clippy','-p','hex-ui','--features','ui-test-support','--all-targets','--locked','--','-D','warnings')),
 module.Step('architecture',('python3','scripts/check-architecture.py')),
 module.Step('ui-style',('python3','scripts/check-ui-style.py')),
 module.Step('gpui-patch',('python3','scripts/check-gpui-patch.py')),
 module.Step('touched-fmt',('rustfmt','--edition','2024','--check','crates/hex-ui/src/editor/workspace_view_ui_test.rs')),
 module.Step('diff-check',('git','diff','--check')),
)
if '--remaining' in sys.argv:
    steps=steps[1:]
raise SystemExit(module.LocalCiRunner(root=root,mode='quick',steps=steps).run())
