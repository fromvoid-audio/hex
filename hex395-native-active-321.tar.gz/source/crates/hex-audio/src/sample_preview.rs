//! Independent one-shot browser PCM on the existing output stream.
//! One incoming owner, two retirement slots and one latest control-side pending
//! owner bound memory and callback work. Only control reclaims PCM.
use crate::native_callback_owner::atomic_signal::{self, Signal};
use crate::native_callback_owner::{
    NativePreparedConsumer as Consumer, NativePreparedProducer as Producer, native_prepared_ring,
    registered_prepared_ring,
};
use hex_engine::{Audio, Frame, Invalid};
use rtrb::PushError;
use std::sync::atomic::Ordering::{Acquire, Release};

struct Preview {
    generation: u64,
    audio: Audio,
    position: usize,
}

/// Submission is preparing until the callback actually consumes PCM. Completion
/// reports the last rendered frame, independently of PCM retirement pressure.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Idle,
    Preparing,
    Playing,
    Finished,
    Unavailable,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Snapshot {
    pub generation: u64,
    pub phase: Phase,
    /// Absolute frame within the complete decoded preview PCM.
    pub frame: u64,
    pub frames: u64,
}

/// A synchronous refusal retains the caller's exact PCM owner.
pub struct PublishRefusal {
    pub reason: Invalid,
    pub audio: Audio,
}
impl std::fmt::Debug for PublishRefusal {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PublishRefusal")
            .field("reason", &self.reason)
            .finish_non_exhaustive()
    }
}
impl std::fmt::Display for PublishRefusal {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.reason.fmt(f)
    }
}
impl std::error::Error for PublishRefusal {}
pub struct Control {
    incoming: Producer<Preview>,
    retired: Consumer<Preview>,
    pending: Option<Preview>,
    generation: Signal,
    started: Signal,
    finished: Signal,
    position: Signal,
    start: usize,
    frames: usize,
    rate: u32,
    last_generation: u64,
    closing: bool,
    status: Option<crate::prepared::status_owner::StatusHandle>,
}

pub(crate) struct Callback {
    incoming: Consumer<Preview>,
    retired: Producer<Preview>,
    active: Option<Preview>,
    generation: Signal,
    started: Signal,
    finished: Signal,
    position: Signal,
}

pub(crate) fn constructor_cost() -> Option<(usize, usize)> {
    let retained = crate::prepared::factory::ring_bytes::<Preview>(1)?
        .checked_add(crate::prepared::factory::ring_bytes::<Preview>(2)?)?
        .checked_add(crate::prepared::factory::shared_atomic_bytes()?.checked_mul(4)?)?;
    let peak = retained
        .checked_add(crate::prepared::factory::ring_scratch::<Preview>()?.checked_mul(2)?)?
        .checked_add(size_of::<(Control, Callback)>())?
        .checked_add(crate::prepared::factory::atomic_signal_scratch()?.checked_mul(4)?)?;
    Some((retained, peak))
}
pub(crate) fn channel(rate: u32) -> (Control, Callback) {
    construct_channel(rate, None).expect("unqualified preview channel has no fallible registration")
}
pub(crate) fn registered_channel(
    rate: u32,
    root: &crate::candidate_custody::CandidateRoot,
) -> Result<(Control, Callback), Invalid> {
    construct_channel(rate, Some(root))
}
fn construct_channel(
    rate: u32,
    root: Option<&crate::candidate_custody::CandidateRoot>,
) -> Result<(Control, Callback), Invalid> {
    let (incoming, consumer, returning, retired) = if let Some(root) = root {
        let (incoming, consumer, first) = registered_prepared_ring(1)
            .map_err(|_| Invalid("preview incoming queue pairing refused"))?;
        root.retain_prepared_ring(5, first).map_err(Invalid)?;
        let (returning, retired, second) = registered_prepared_ring(2)
            .map_err(|_| Invalid("preview retirement queue pairing refused"))?;
        root.retain_prepared_ring(6, second).map_err(Invalid)?;
        (incoming, consumer, returning, retired)
    } else {
        let (incoming, consumer) = native_prepared_ring(1);
        let (returning, retired) = native_prepared_ring(2);
        (incoming, consumer, returning, retired)
    };
    let [generation_control, generation] = atomic_signal::pair(root, 4)?;
    let [started_control, started] = atomic_signal::pair(root, 5)?;
    let [finished_control, finished] = atomic_signal::pair(root, 6)?;
    let [position_control, position] = atomic_signal::pair(root, 7)?;
    Ok((
        Control {
            incoming,
            retired,
            pending: None,
            generation: generation_control,
            started: started_control,
            finished: finished_control,
            position: position_control,
            start: 0,
            frames: 0,
            rate,
            last_generation: 0,
            closing: false,
            status: None,
        },
        Callback {
            incoming: consumer,
            retired: returning,
            active: None,
            generation,
            started,
            finished,
            position,
        },
    ))
}

impl Control {
    /// Only the one-time registered carrier birth may rely on these actual
    /// destinations being empty. Later preview ownership is not inferred from
    /// the channel match and requires its own inventory.
    pub(crate) fn matches_fresh_registered_payload_on_control(
        &self,
        root: &crate::candidate_custody::CandidateRoot,
    ) -> bool {
        let Self {
            incoming: _,
            retired: _,
            pending,
            generation: _,
            started: _,
            finished: _,
            position: _,
            start: _,
            frames: _,
            rate: _,
            last_generation: _,
            closing,
            status: _,
        } = self;
        self.matches_constructor_channel_fields_on_control(root) && pending.is_none() && !*closing
    }

    /// Actual constructor channel-field correlation only. Other owning
    /// descendants retain their independent mandatory inventory contracts.
    pub(crate) fn matches_constructor_channel_fields_on_control(
        &self,
        root: &crate::candidate_custody::CandidateRoot,
    ) -> bool {
        root.matches_prepared_producer(5, &self.incoming)
            && root.matches_prepared_consumer(6, &self.retired)
            && root.matches_atomic_signal(4, &self.generation, 0)
            && root.matches_atomic_signal(5, &self.started, 0)
            && root.matches_atomic_signal(6, &self.finished, 0)
            && root.matches_atomic_signal(7, &self.position, 0)
            && self.status.as_ref().is_some_and(|field| {
                root.matches_status_field(field, crate::prepared::status_owner::PREVIEW)
            })
    }

    pub fn snapshot(&self) -> Snapshot {
        let generation = self.generation.load(Acquire);
        let phase = if !self.permitted()
            || self.status.as_ref().is_some_and(|status| {
                status.device_fault.load(Acquire) || status.render_fault.load(Acquire)
            }) {
            Phase::Unavailable
        } else if generation == 0 {
            Phase::Idle
        } else if self.finished.load(Acquire) == generation {
            Phase::Finished
        } else if self.started.load(Acquire) == generation {
            Phase::Playing
        } else {
            Phase::Preparing
        };
        let frame = match phase {
            Phase::Preparing => self.start as u64,
            Phase::Playing | Phase::Finished => self.position.load(Acquire).min(self.frames as u64),
            _ => 0,
        };
        Snapshot {
            generation,
            phase,
            frame,
            frames: self.frames as u64,
        }
    }

    pub(crate) fn bind_status(&mut self, status: crate::prepared::status_owner::StatusHandle) {
        self.status = Some(status);
    }
    fn permitted(&self) -> bool {
        !self.closing
            && self
                .status
                .as_ref()
                .is_none_or(|status| status.preview_permitted())
    }

    /// Silence the previous request, including queued PCM, before decode starts.
    /// The returned token is scoped to this output instance.
    pub fn request(&mut self) -> Result<u64, Invalid> {
        if !self.permitted() {
            return Err(Invalid("sample preview output is closing"));
        }
        let generation = self
            .last_generation
            .checked_add(1)
            .ok_or(Invalid("sample preview request counter exhausted"))?;
        if let Some(status) = &self.status {
            status.mark_preview_used();
        }
        self.start = 0;
        self.frames = 0;
        self.last_generation = generation;
        self.generation.store(generation, Release);
        self.pending = None;
        self.reclaim();
        Ok(generation)
    }

    /// Admit immutable, validated PCM. Stale completions are disposed on control.
    pub fn publish(&mut self, generation: u64, audio: Audio) -> Result<(), PublishRefusal> {
        self.publish_from(generation, audio, 0)
    }

    /// Control-side offset admission; no PCM slicing/copying or callback seek work.
    /// The exact end is valid and completes silently when consumed.
    pub fn publish_from(
        &mut self,
        generation: u64,
        audio: Audio,
        frame: usize,
    ) -> Result<(), PublishRefusal> {
        if !self.permitted() {
            return Err(PublishRefusal {
                reason: Invalid("sample preview output is closing"),
                audio,
            });
        }
        if generation == 0 {
            return Err(PublishRefusal {
                reason: Invalid("sample preview requires a valid request"),
                audio,
            });
        }
        if generation != self.generation.load(Acquire) {
            return Ok(());
        }
        if audio.sample_rate() != self.rate {
            return Err(PublishRefusal {
                reason: Invalid("sample preview rate does not match audio output"),
                audio,
            });
        }
        if frame > audio.frames().len() {
            return Err(PublishRefusal {
                reason: Invalid("sample preview offset exceeds source"),
                audio,
            });
        }
        self.start = frame;
        self.frames = audio.frames().len();
        self.pending = Some(Preview {
            generation,
            audio,
            position: frame,
        });
        self.reclaim();
        Ok(())
    }

    pub(crate) fn reclaim(&mut self) {
        for _ in 0..2 {
            let Ok(preview) = self.retired.pop() else {
                break;
            };
            drop(preview);
        }
        if let Some(preview) = self.pending.take()
            && let Err(PushError::Full(preview)) = self.incoming.push(preview)
        {
            self.pending = Some(preview);
        }
    }

    pub(crate) fn shutdown(&mut self) {
        self.cancel();
        self.closing = true;
    }

    /// Silence and invalidate playback without disturbing project transport.
    pub fn cancel(&mut self) {
        self.generation.store(0, Release);
        self.start = 0;
        self.frames = 0;
        self.pending = None;
        self.reclaim();
    }
}

impl Callback {
    pub(crate) fn matches_fresh_registered_payload_on_control(
        &self,
        root: &crate::candidate_custody::CandidateRoot,
    ) -> bool {
        let Self {
            incoming: _,
            retired: _,
            active,
            generation: _,
            started: _,
            finished: _,
            position: _,
        } = self;
        self.matches_constructor_channel_fields_on_control(root) && active.is_none()
    }

    /// Actual constructor channel-field correlation only. Other owning
    /// descendants retain their independent mandatory inventory contracts.
    pub(crate) fn matches_constructor_channel_fields_on_control(
        &self,
        root: &crate::candidate_custody::CandidateRoot,
    ) -> bool {
        root.matches_prepared_consumer(5, &self.incoming)
            && root.matches_prepared_producer(6, &self.retired)
            && root.matches_atomic_signal(4, &self.generation, 1)
            && root.matches_atomic_signal(5, &self.started, 1)
            && root.matches_atomic_signal(6, &self.finished, 1)
            && root.matches_atomic_signal(7, &self.position, 1)
    }

    pub(crate) fn constructor_channel_storage(
        &self,
    ) -> Option<crate::native_callback_owner::ChannelStorage> {
        use crate::native_callback_owner::ChannelStorage;
        ChannelStorage::ring(self.incoming.buffer())?
            .plus(ChannelStorage::ring(self.retired.buffer())?)?
            .plus(ChannelStorage::paired_payload(self.generation.as_ref()))?
            .plus(ChannelStorage::paired_payload(self.started.as_ref()))?
            .plus(ChannelStorage::paired_payload(self.finished.as_ref()))?
            .plus(ChannelStorage::paired_payload(self.position.as_ref()))
    }

    pub(crate) fn begin_block(&mut self, closing: bool) {
        let generation = self.generation.load(Acquire);
        let retire_active = self.active.as_ref().is_some_and(|preview| {
            closing
                || preview.generation != generation
                || preview.position == preview.audio.frames().len()
        });
        if retire_active
            && !self.retired.is_full()
            && let Some(preview) = self.active.take()
        {
            // This callback is the sole producer; the checked slot cannot vanish.
            if let Err(PushError::Full(preview)) = self.retired.push(preview) {
                self.active = Some(preview);
            }
        }
        if self.active.is_none()
            && !self.retired.is_full()
            && let Ok(preview) = self.incoming.pop()
        {
            self.active = Some(preview);
            if (closing
                || self
                    .active
                    .as_ref()
                    .is_some_and(|p| p.generation != generation))
                && let Some(preview) = self.active.take()
                && let Err(PushError::Full(preview)) = self.retired.push(preview)
            {
                self.active = Some(preview);
            }
        }
    }

    pub(crate) fn is_empty(&self) -> bool {
        self.active.is_none() && self.incoming.is_empty()
    }

    /// Unity preview is added after the project's master stage. It never moves
    /// project transport and is not captured by project-node spectrum taps.
    pub(crate) fn mix(&mut self, output: &mut [Frame]) {
        let Some(preview) = self.active.as_mut() else {
            return;
        };
        if preview.generation != self.generation.load(Acquire) {
            return;
        }
        let frames = preview.audio.frames();
        let count = output.len().min(frames.len() - preview.position);
        for (target, source) in output.iter_mut().zip(&frames[preview.position..][..count]) {
            target[0] += source[0];
            target[1] += source[1];
        }
        preview.position += count;
        self.position.store(preview.position as u64, Release);
        if count > 0 {
            self.started.store(preview.generation, Release);
        }
        if preview.position == frames.len() {
            self.finished.store(preview.generation, Release);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    fn pcm(value: f32, frames: usize) -> Audio {
        Audio::new(48_000, vec![[value, -value]; frames]).unwrap()
    }

    #[test]
    fn offset_renders_exact_remaining_pcm_and_finishes_without_replay() {
        let (mut control, mut callback) = channel(48_000);
        let pcm = || Audio::new(48_000, (0..6).map(|i| [i as f32, -(i as f32)]).collect()).unwrap();
        for start in [0, 3, 6] {
            let token = control.request().unwrap();
            control.publish_from(token, pcm(), start).unwrap();
            assert_eq!(control.snapshot().frame, start as u64);
            callback.begin_block(false);
            let mut rendered = [[0.0; 2]; 8];
            callback.mix(&mut rendered);
            for (i, frame) in rendered.iter().take(6 - start).enumerate() {
                assert_eq!(*frame, [(i + start) as f32, -((i + start) as f32)]);
            }
            assert!(rendered[6 - start..].iter().all(|frame| *frame == [0.0; 2]));
            assert_eq!(control.snapshot().phase, Phase::Finished);
            assert_eq!(control.snapshot().frame, 6);
            rendered.fill([0.0; 2]);
            callback.mix(&mut rendered);
            assert_eq!(rendered, [[0.0; 2]; 8]);
            control.reclaim();
        }
        let token = control.request().unwrap();
        assert!(control.publish_from(token, pcm(), 7).is_err());
        control.publish_from(token, pcm(), 3).unwrap();
        callback.begin_block(false);
        callback.mix(&mut [[0.0; 2]; 1]);
        assert_eq!(control.snapshot().phase, Phase::Playing);
        assert_eq!(control.snapshot().frame, 4);
        let newer = control.request().unwrap();
        control.publish_from(token, pcm(), 0).unwrap();
        control.publish_from(newer, pcm(), 5).unwrap();
        control.cancel();
        callback.begin_block(false);
        let mut silence = [[0.0; 2]; 8];
        callback.mix(&mut silence);
        assert_eq!(silence, [[0.0; 2]; 8]);
        assert_eq!(control.snapshot().phase, Phase::Idle);
    }

    #[test]
    fn status_follows_actual_pcm_end_stop_and_stale_decode_without_replay() {
        let (mut control, mut callback) = channel(48_000);
        assert_eq!(control.snapshot().phase, Phase::Idle);
        let first = control.request().unwrap();
        control.publish(first, pcm(0.25, 3)).unwrap();
        assert_eq!(
            control.snapshot(),
            Snapshot {
                generation: first,
                phase: Phase::Preparing,
                frame: 0,
                frames: 3,
            }
        );
        callback.begin_block(false);
        let mut output = [[0.0; 2]; 2];
        callback.mix(&mut output);
        assert_eq!(output, [[0.25, -0.25]; 2]);
        assert_eq!(control.snapshot().phase, Phase::Playing);
        output.fill([0.0; 2]);
        callback.mix(&mut output);
        assert_eq!(output, [[0.25, -0.25], [0.0; 2]]);
        assert_eq!(control.snapshot().phase, Phase::Finished);
        // Completion is observable even before callback ownership can retire.
        for _ in 0..3 {
            output.fill([0.0; 2]);
            callback.mix(&mut output);
            assert_eq!(output, [[0.0; 2]; 2]);
            assert_eq!(control.snapshot().phase, Phase::Finished);
        }
        let next = control.request().unwrap();
        assert_eq!(
            control.snapshot(),
            Snapshot {
                generation: next,
                phase: Phase::Preparing,
                frame: 0,
                frames: 0
            }
        );
        control.publish(first, pcm(0.9, 4)).unwrap();
        control.publish(next, pcm(0.5, 8)).unwrap();
        callback.begin_block(false);
        callback.mix(&mut output);
        assert_eq!(control.snapshot().phase, Phase::Playing);
        control.cancel();
        output.fill([0.0; 2]);
        callback.mix(&mut output);
        assert_eq!(output, [[0.0; 2]; 2]);
        assert_eq!(control.snapshot().phase, Phase::Idle);
        // A decode that finishes after Stop cannot restart the cancelled token.
        control.publish(next, pcm(0.8, 4)).unwrap();
        callback.begin_block(false);
        callback.mix(&mut output);
        assert_eq!(output, [[0.0; 2]; 2]);
        control.shutdown();
        assert_eq!(control.snapshot().phase, Phase::Unavailable);
    }

    #[test]
    fn output_faults_override_playback_status_and_shutdown_stays_unavailable() {
        let (mut control, mut callback) = crate::prepared::channel(48_000).unwrap();
        let generation = control.sample_preview.request().unwrap();
        control
            .sample_preview
            .publish(generation, pcm(0.5, 8))
            .unwrap();
        callback.begin_block();
        callback.render(&mut [[0.0; 2]; 2]).unwrap();
        assert_eq!(control.sample_preview.snapshot().phase, Phase::Playing);
        control.status.device_fault.store(true, Release);
        assert_eq!(control.sample_preview.snapshot().phase, Phase::Unavailable);
        control.status.device_fault.store(false, Release);
        control.status.render_fault.store(true, Release);
        assert_eq!(control.sample_preview.snapshot().phase, Phase::Unavailable);
        control.status.render_fault.store(false, Release);
        control.request_shutdown();
        assert_eq!(control.sample_preview.snapshot().phase, Phase::Unavailable);
        callback.begin_block();
        control.reclaim();
    }

    #[test]
    fn one_shot_restarts_newest_request_and_retires_finished_pcm() {
        let (mut control, mut callback) = channel(48_000);
        let first = control.request().unwrap();
        control.publish(first, pcm(0.25, 3)).unwrap();
        callback.begin_block(false);
        let mut output = [[0.1; 2]; 2];
        callback.mix(&mut output);
        assert_eq!(output, [[0.35, -0.15]; 2]);
        let newest = control.request().unwrap();
        output.fill([0.0; 2]);
        callback.mix(&mut output);
        assert_eq!(output, [[0.0; 2]; 2], "decode immediately silences old PCM");
        control.publish(first, pcm(0.9, 2)).unwrap();
        control.publish(newest, pcm(0.5, 3)).unwrap();
        callback.begin_block(false);
        callback.mix(&mut output);
        assert_eq!(output, [[0.5, -0.5]; 2]);
        output.fill([0.0; 2]);
        callback.mix(&mut output);
        assert_eq!(output, [[0.5, -0.5], [0.0; 2]]);
        callback.begin_block(false);
        assert!(callback.is_empty());
        control.reclaim();
        assert!(control.retired.is_empty());
    }

    #[test]
    fn saturated_retirement_preserves_pcm_until_control_reclaims_and_latest_wins() {
        let (mut control, mut callback) = channel(48_000);
        // Fill the real return queue, without allowing control reclamation.
        for value in [0.1, 0.2] {
            callback
                .retired
                .push(Preview {
                    generation: 0,
                    audio: pcm(value, 2),
                    position: 0,
                })
                .ok()
                .unwrap();
        }
        let old = control.request().unwrap();
        control.publish(old, pcm(0.3, 4)).unwrap();
        callback.begin_block(false);
        let next = control.request().unwrap();
        control.publish(next, pcm(0.4, 4)).unwrap();
        // Saturate again with callback-owned old PCM and no room to hand back.
        for value in [0.1, 0.2] {
            callback
                .retired
                .push(Preview {
                    generation: 0,
                    audio: pcm(value, 2),
                    position: 0,
                })
                .ok()
                .unwrap();
        }
        callback.begin_block(false);
        let mut output = [[0.0; 2]; 2];
        callback.mix(&mut output);
        assert_eq!(output, [[0.0; 2]; 2]);
        assert!(callback.active.is_some());
        control.reclaim();
        callback.begin_block(false);
        callback.mix(&mut output);
        assert_eq!(output, [[0.4, -0.4]; 2]);
        control.cancel();
        callback.begin_block(true);
        assert!(callback.is_empty());
        control.reclaim();
    }

    #[test]
    fn mismatched_rate_and_cancelled_completions_do_not_play() {
        let (mut control, mut callback) = channel(48_000);
        let token = control.request().unwrap();
        assert!(
            control
                .publish(token, Audio::new(44_100, vec![[0.2; 2]; 2]).unwrap())
                .is_err()
        );
        control.cancel();
        control.publish(token, pcm(0.5, 4)).unwrap();
        callback.begin_block(false);
        assert!(callback.is_empty());
        let later = control.request().unwrap();
        assert!(later > token);
    }

    #[test]
    fn preview_mixes_while_stopped_playing_paused_and_after_project_stop() {
        use hex_engine::{Clip, PlaybackCommand, Project, Track, playback::Playback};
        let audio = Audio::new(48_000, vec![[0.25; 2]]).unwrap();
        let clip = Clip::new(audio, 0, 100, true).unwrap();
        let track = Track::new(vec![clip], 1.0, false).unwrap();
        let project = Arc::new(Project::new(48_000, vec![track]).unwrap());
        let (mut control, mut callback) = crate::prepared::channel(48_000).unwrap();
        control.publish(Playback::from_shared(project)).unwrap();
        let token = control.sample_preview.request().unwrap();
        control.sample_preview.publish(token, pcm(0.5, 20)).unwrap();
        let mut output = [[0.0; 2]; 2];
        callback.begin_block();
        callback.render(&mut output).unwrap();
        assert_eq!(output, [[0.5, -0.5]; 2]);
        assert_eq!(control.status.position.load(Acquire), 0);
        assert!(!control.status.playing.load(Acquire));
        control.command(PlaybackCommand::Play).unwrap();
        callback.begin_block();
        callback.render(&mut output).unwrap();
        assert_eq!(output, [[0.75, -0.25]; 2]);
        assert_eq!(control.status.position.load(Acquire), 2);
        control.command(PlaybackCommand::Pause).unwrap();
        callback.begin_block();
        callback.render(&mut output).unwrap();
        assert_eq!(output, [[0.5, -0.5]; 2]);
        assert_eq!(control.status.position.load(Acquire), 2);
        control.stop();
        callback.begin_block();
        callback.render(&mut output).unwrap();
        assert_eq!(output, [[0.5, -0.5]; 2]);
        assert_eq!(control.status.position.load(Acquire), 0);
        control.request_shutdown();
        callback.begin_block();
        control.reclaim();
    }

    #[test]
    fn full_incoming_coalesces_pending_to_latest_and_shutdown_returns_both_owners() {
        let (mut control, mut callback) = channel(48_000);
        for value in [0.1, 0.2, 0.3] {
            let token = control.request().unwrap();
            control.publish_from(token, pcm(value, 3), 2).unwrap();
        }
        assert!(control.pending.is_some());
        callback.begin_block(false); // reject queued 0.1
        control.reclaim(); // admit only latest 0.3
        callback.begin_block(false);
        let mut output = [[0.0; 2]; 1];
        callback.mix(&mut output);
        assert_eq!(output, [[0.3, -0.3]]);
        let token = control.request().unwrap();
        control.publish(token, pcm(0.4, 2)).unwrap();
        control.cancel();
        callback.begin_block(true);
        assert!(callback.is_empty());
        assert_eq!(control.retired.slots(), 2);
        control.reclaim();
    }

    #[cfg(feature = "allocation-probe")]
    #[test]
    fn sample_replacement_completion_and_shutdown_allocate_and_free_nothing() {
        let (mut control, mut callback) = crate::prepared::channel(48_000).unwrap();
        let token = control.sample_preview.request().unwrap();
        control
            .sample_preview
            .publish_from(token, pcm(0.25, 5), 2)
            .unwrap();
        let mut output = [[0.0; 2]; 2];
        let measure = allocation_counter::measure(|| {
            callback.begin_block();
            callback.render(&mut output).unwrap();
        });
        assert_eq!(
            (
                measure.count_total,
                measure.bytes_total,
                measure.count_current,
                measure.bytes_current
            ),
            (0, 0, 0, 0)
        );
        assert_eq!(output, [[0.25, -0.25]; 2]);
        let token = control.sample_preview.request().unwrap();
        control.sample_preview.publish(token, pcm(0.5, 1)).unwrap();
        let measure = allocation_counter::measure(|| {
            callback.begin_block();
            callback.render(&mut output).unwrap();
            callback.begin_block();
            callback.render(&mut output).unwrap();
        });
        assert_eq!(
            (
                measure.count_total,
                measure.bytes_total,
                measure.count_current,
                measure.bytes_current
            ),
            (0, 0, 0, 0)
        );
        assert_eq!(output, [[0.0; 2]; 2]);
        control.reclaim();
        let token = control.sample_preview.request().unwrap();
        control.sample_preview.publish(token, pcm(0.5, 1)).unwrap();
        callback.begin_block();
        control.request_shutdown();
        assert!(control.sample_preview.request().is_err());
        let measure = allocation_counter::measure(|| callback.begin_block());
        assert_eq!(
            (
                measure.count_total,
                measure.bytes_total,
                measure.count_current,
                measure.bytes_current
            ),
            (0, 0, 0, 0)
        );
        assert!(control.status.shutdown_complete.load(Acquire));
        control.reclaim();
    }
}

#[cfg(all(test, feature = "allocation-probe"))]
mod native_signal_field_tests {
    use super::*;
    #[test]
    fn actual_foreign_signal_field_refuses_before_native_carrier_birth() {
        let mut completed = 0;
        for field in 0..4 {
            let limits = crate::AudioCandidatePublicationReservation {
                runtime_slots: 3,
                archive_slots: 3,
                member_rows: 128,
                transfer_rows: 128,
                receipt_rows: 3,
                data_rows: 512,
                handle_rows: 512,
                max_retained_data_bytes: 4 << 20,
                max_construction_peak_data_bytes: 8 << 20,
            };
            let (mut control, callback) =
                crate::prepared::channel_with_factory_reservation(48000, None, Some(limits))
                    .unwrap();
            let root = control.native_candidate_root();
            // The real Root queue fields remain intact: only this actual atomic
            // owning field changes. Identical scalar value/layout is not origin.
            let foreign = Signal::Legacy(std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0)));
            match field {
                0 => control.sample_preview.generation = foreign,
                1 => control.sample_preview.started = foreign,
                2 => control.sample_preview.finished = foreign,
                3 => control.sample_preview.position = foreign,
                _ => unreachable!(),
            }
            let mut refused = false;
            let birth = allocation_counter::measure(|| {
                refused =
                    crate::native_callback_owner::reserve_native_worker(control, callback, None)
                        .is_err();
            });
            assert!(
                refused,
                "actual foreign signal field {field} must not inherit Root origin"
            );
            assert_eq!(
                birth.count_total, 0,
                "signal field {field}: before any carrier birth"
            );
            assert_eq!(root.test_native_carrier_facts().unwrap().0, 0);
            completed += 1;
            eprintln!("SUPPORTED actual signal field{field} refused before carrier births");
        }
        assert_eq!(completed, 4);
    }
}
