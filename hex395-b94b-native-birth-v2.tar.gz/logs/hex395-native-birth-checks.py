from pathlib import Path
import subprocess,hashlib,json,os
r=Path('/workspace/hex-sampler-aggregate')
def digest():
 names=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=r).decode().splitlines();h=hashlib.sha256()
 for name in sorted(set(names)):
  if name.startswith('artifacts/'):continue
  p=r/name
  if p.is_file():h.update(name.encode()+b'\0'+p.read_bytes()+b'\0')
 return h.hexdigest()
start=digest();results=[]
steps=[('custody',['cargo','test','-p','hex-audio','--lib','--features','allocation-probe','--locked','candidate_custody::','--','--nocapture']),('callback',['cargo','test','-p','hex-audio','--lib','--features','allocation-probe','--locked','prepared::eligible_publication::','--','--nocapture']),('policy',['python3','scripts/check-architecture.py']),('strict',['cargo','clippy','-p','hex-audio','-p','hex-engine','--features','hex-audio/allocation-probe','--all-targets','--locked','--','-D','warnings'])]
for name,argv in steps:
 log=Path(f'/tmp/hex395-native-birth-final-{name}.log')
 with log.open('w') as f:p=subprocess.run(argv,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,argv=argv,exit=p.returncode,log=str(log)));print(name,p.returncode,flush=True)
 Path('/tmp/hex395-native-birth-final-results.json').write_text(json.dumps(dict(start_source=start,end_source=digest(),runner_pid=os.getpid(),results=results),indent=2))
 if p.returncode:raise SystemExit(p.returncode)
