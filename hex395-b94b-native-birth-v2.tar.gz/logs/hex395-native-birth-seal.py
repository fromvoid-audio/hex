from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil,re
r=Path('/workspace/hex-sampler-aggregate');out=Path('/tmp/hex395-b94b-native-birth-v2');out.mkdir(exist_ok=False)
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
def sha(b):return hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();assert head.startswith('b94b0e2f');assert not git('status','--porcelain');rows=[]
for name in git('diff','--name-only','HEAD^','HEAD').decode().splitlines():
 b=(r/name).read_bytes();p=out/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
assert len(rows)==10
(out/'SOURCE.json').write_text(json.dumps(dict(head=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),parent=git('rev-parse','HEAD^').decode().strip(),files=rows),indent=2));(out/'SOURCE.diff').write_bytes(git('diff','--binary','HEAD^','HEAD'))
logs=out/'logs';logs.mkdir()
for p in Path('/tmp').glob('hex395-native-birth-*'):
 if p.is_file() and p.suffix in {'.log','.json','.rs','.diff','.py'}:shutil.copy2(p,logs/p.name)
final=json.loads(Path('/tmp/hex395-native-birth-final-results.json').read_text());assert final['start_source']==final['end_source'] and all(x['exit']==0 for x in final['results'])
h=hashlib.sha256();binding=[]
for name in sorted(set(git('ls-files','-co','--exclude-standard').decode().splitlines())):
 if name.startswith('artifacts/'):continue
 p=r/name
 if p.is_file():
  b=git('show','HEAD^:'+name) if name=='docs/sampler.md' else p.read_bytes();h.update(name.encode()+b'\0'+b+b'\0')
  if name.endswith('.rs') or name in ['Cargo.lock'] or name.endswith('Cargo.toml'):binding.append(dict(path=name,sha256=sha(b)))
assert h.hexdigest()==final['start_source'],(h.hexdigest(),final['start_source'])
(out/'TEST_SOURCE_BINDING.json').write_text(json.dumps(dict(reconstructed_original_source=h.hexdigest(),only_post_run_change='docs/sampler.md appended scope/limits; all Rust/Cargo/policy bytes unchanged',inputs=binding),indent=2))
checks=[]
for name,count in [('custody',39),('callback',26)]:
 text=Path(f'/tmp/hex395-native-birth-final-{name}.log').read_text();names=re.findall(r'^test (.+?) \.\.\. ok$',text,re.M);assert len(names)==len(set(names))==count and f'{count} passed; 0 failed; 0 ignored' in text;checks.append(dict(group=name,names=names,count=count))
(out/'CHECKS.json').write_text(json.dumps(dict(source=final,groups=checks,unique=65,sessions=dict(first_compile=60460,second_compile=3543,two_tests=59196,final=99126,quick=74578),all_terminal=True,limits='Linux Rust1.94/jobs4/16MiB; not native/defaultstack/fullCI'),indent=2))
quick=r/'artifacts/local-ci/20261019T121845Z-48b94754';q=json.loads((quick/'summary.json').read_text());assert q['commit']==head and not q['dirty'] and not q['stale'] and q['status']=='partial' and q['exit_code']==0 and q['start_tree']==q['end_tree'];assert len(q['steps'])==6 and all(s['status']=='passed' for s in q['steps']);shutil.copytree(quick,out/'local-ci')
(out/'HANDOFF.md').write_text('''# Actual native Root + page signal birth; NOT full host admission

Canonical395 b94b overf73f,10files. Existing Root and twoDomainSignal rawArc FIRSTbirths become existing constructor-paired SharedMetadata; exactsame allocation correlation and page return token guards unchanged. All Root metadata quote sites use actual paired payload+header, twoSignal payload+headers; changed inline handles included concreteInner once. Supported-layout checks before Root/slot/signalbirth, unchangedcaps. Existing callback noRootclone assertions use borrowed scalarstrong diagnostic; counts never grant provenance/closure. Actual4allocations/21392B for3slots matches Root+2Signals+actualslotcapacity, borrowedphysicalinspection0alloc/free; omittedRoot/signalaliases refuse, samefielddedup and equal-size distinctRoot/signaldata distinct; require_complete stillErr because actualchildren/retirement missing. No rawArcadoption/newownerfamily/unsafe/genericledgerchange.

Firstcompile60460exit101 missing mechanical signalclone + private siblingfixture; firstsource diff/test preserved. Moved tests under actualowning eligiblemodule without openingvisibility; corrected clone. Secondcompile3543exit101 existingtests inherited Arc import, explicit test-only import restores it. No assertion weakens. Thirdfocused59196 actual2PASS. Final99126/Python176325 terminal0 on sourceac52014c... start=end:39custody+26callback=65distinct0ignored, architecturePASS, strictEngineAudioallocationprobealltargets-DwarningsPASS. Finaldocs appended afterward ONLY, reconstructed sourcebinding verifies original fullsource digest and identical Rust/Cargo/policybytes. ExactcommittedQUICK6PASS/PARTIALclean/stalefalse; nofullCI/native.

Preserves priorf73f fiveinlinewrapper/source/policynegatives and separate component proof. Rootfactory still noaggregateceiling. Current/failed/retiring children, actual native/family/source union, same-parent hostfacade immutablepreflight/dropledgers-underexclusion/mutreborrowconstructor, fullServicebirth/ACK/replace/stoprestore/export/mixed/offline/CapturedMix/Stems/native/library remainOPEN. Do not declare whole395ready. RootMac controls any finite native checks, no dispatch performed. Next realNativeFields/facade continues without merger/nativewait.
''')
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file():
  b=p.read_bytes();manifest.append(dict(path=str(p.relative_to(out)),bytes=len(b),sha256=sha(b)))
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));a=Path(str(out)+'.tar.gz')
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(a) as t:
 m=t.getmembers();assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in m)
 for row in manifest:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
blob=git('hash-object','-w',str(a)).decode().strip();tree=subprocess.check_output(['git','mktree'],cwd=r,input=f'100644 blob {blob}\t{a.name}\n',text=True).strip();commit=git('commit-tree',tree,'-m','Evidence only: actual native Root and signal paired birth b94b').decode().strip();ref='refs/heads/evidence/hex-sampler-2789-b94b-native-birth';subprocess.run(['git','update-ref',ref,commit],cwd=r,check=True)
result=dict(archive=str(a),bytes=a.stat().st_size,sha256=sha(a.read_bytes()),safe_members=len(m),payloads=len(manifest),evidence_commit=commit,ref=ref,source_head=head,source_tree=git('rev-parse','HEAD^{tree}').decode().strip());Path('/tmp/hex395-native-birth-seal-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
