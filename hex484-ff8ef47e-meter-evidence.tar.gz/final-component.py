import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-workspace-tab-489');spec=importlib.util.spec_from_file_location('ci484meter',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(
 m.Step('architecture',('python3','scripts/check-architecture.py')),
 m.Step('ui-style',('python3','scripts/check-ui-style.py')),
 m.Step('gpui-patch',('python3','scripts/check-gpui-patch.py')),
 m.Step('device-layout',('python3','scripts/check-device-layout.py')),
 m.Step('format',('cargo','fmt','--all','--check')),
 m.Step('diff',('git','diff','--check')),
 m.Step('actual-main-renderer-and-lifecycle',('cargo','test','-p','hex-engine','--test','main_chain','--locked','--','--nocapture')),
 m.Step('track-return-metering-PCM-control',('cargo','test','-p','hex-engine','--test','return_routes','--locked','main_observation_is_post_master_asymmetric_and_pcm_identical','--','--nocapture')),
 m.Step('retained-latency-controls',('cargo','test','-p','hex-engine','--lib','--locked','signal_graph::tests::main_review_','--','--nocapture')),
 m.Step('main-return-callback-allocation',('cargo','test','-p','hex-audio','--features','allocation-probe','--test','main_chain_allocations','--test','return_feed_allocations','--locked','--','--nocapture')),
 m.Step('allocation-calibration',('cargo','test','-p','hex-audio','--features','allocation-probe','--test','allocation_probe_calibration','--locked','--','--nocapture')),
 m.Step('strict-engine',('cargo','clippy','-p','hex-engine','--lib','--test','main_chain','--locked','--','-D','warnings')),
)
raise SystemExit(m.LocalCiRunner(root=root,mode='quick',steps=steps).run())
