import pathlib,subprocess,hashlib,json,os
root=pathlib.Path('/workspace/hex-workspace-tab-489');base='d81cdd38ef140f94343fbbea2daf7c8f8acd2f0a'
t='crates/hex-engine/tests/main_chain.rs'
patch=pathlib.Path('/workspace/scratch/484-meter-baseline.patch').read_bytes()
added=b''.join(line[1:] for line in patch.splitlines(keepends=True) if line.startswith(b'+') and not line.startswith(b'+++'))
original=subprocess.check_output(['git','show',base+':'+t],cwd=root)
overrides={t:original+added}
changed=subprocess.check_output(['git','diff',base,'HEAD','--name-only'],cwd=root,text=True).splitlines()
for p in changed:
 if p not in overrides:overrides[p]=subprocess.check_output(['git','show',base+':'+p],cwd=root)
digest=hashlib.sha256()
for rel in sorted(p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0') if p):
 p=root/os.fsdecode(rel);digest.update(len(rel).to_bytes(8,'big'));digest.update(rel)
 if p.is_symlink():digest.update(b'symlink\0');digest.update(os.fsencode(os.readlink(p)))
 else:digest.update(b'file\0');digest.update(overrides.get(os.fsdecode(rel),p.read_bytes()));digest.update(str(p.lstat().st_mode & 0o111).encode())
expected=json.load(open(root/'artifacts/local-ci/20261020T075859Z-a6a5b52b/summary.json'))['source_identity']['content_sha256']
assert digest.hexdigest()==expected,(digest.hexdigest(),expected)
print(json.dumps({'baseline_digest_verified':expected,'patch_bytes':len(patch),'patch_sha256':hashlib.sha256(patch).hexdigest()}))
