use super::*;

#[derive(Clone, Copy, Debug, Default)]
struct Cursor {
    next: usize,
    valid: usize,
}

/// Both banks are identical outside a transaction. Writes form one circular
/// interval regardless of block partitioning; after a full turn it is the whole
/// ring. Finishing therefore needs at most two slice copies and no checkpoints.
#[derive(Debug)]
pub(super) struct RingPair<T> {
    committed: Vec<T>,
    scratch: Vec<T>,
    committed_cursor: Cursor,
    scratch_cursor: Cursor,
    dirty_start: usize,
    dirty_len: usize,
}

impl<T: Copy + Default> RingPair<T> {
    pub(super) fn visit_storage_on_control<'a>(
        &'a self,
        ledger: &mut crate::AudioRootStorageLedger<'a>,
    ) -> Result<(), crate::AudioStorageError> {
        let Self {
            committed,
            scratch,
            committed_cursor,
            scratch_cursor,
            dirty_start,
            dirty_len,
        } = self;
        fn scalar<T: Copy>(_: &T) {}
        scalar(committed_cursor);
        scalar(scratch_cursor);
        scalar(dirty_start);
        scalar(dirty_len);
        ledger.vec(committed)?;
        ledger.vec(scratch)
    }
    pub(super) fn new(capacity: usize) -> Result<Self, CompensationError> {
        let mut committed = reserved(capacity)?;
        let mut scratch = reserved(capacity)?;
        committed.resize(capacity, T::default());
        scratch.resize(capacity, T::default());
        Ok(Self {
            committed,
            scratch,
            committed_cursor: Cursor::default(),
            scratch_cursor: Cursor::default(),
            dirty_start: 0,
            dirty_len: 0,
        })
    }

    pub(super) fn storage_bytes(&self) -> Result<usize, CompensationError> {
        add_bytes(vector_bytes(&self.committed)?, vector_bytes(&self.scratch)?)
    }

    pub(super) fn begin(&mut self) {
        self.dirty_start = self.scratch_cursor.next;
        self.dirty_len = 0;
    }

    pub(super) fn push(&mut self, value: T) -> T {
        let capacity = self.scratch.len();
        if capacity == 0 {
            return value;
        }
        let slot = &mut self.scratch[self.scratch_cursor.next];
        let previous = *slot;
        *slot = value;
        self.scratch_cursor.next += 1;
        if self.scratch_cursor.next == capacity {
            self.scratch_cursor.next = 0;
        }
        self.scratch_cursor.valid = self.scratch_cursor.valid.saturating_add(1).min(capacity);
        self.dirty_len = self.dirty_len.saturating_add(1).min(capacity);
        previous
    }

    pub(super) fn at_delay(&self, delay: usize) -> Option<T> {
        if delay >= self.scratch_cursor.valid {
            return None;
        }
        let capacity = self.scratch.len();
        let index = if self.scratch_cursor.next > delay {
            self.scratch_cursor.next - delay - 1
        } else {
            capacity - (delay + 1 - self.scratch_cursor.next)
        };
        self.scratch.get(index).copied()
    }

    fn copy_dirty(source: &[T], destination: &mut [T], start: usize, len: usize) {
        let first = len.min(source.len() - start);
        destination[start..start + first].copy_from_slice(&source[start..start + first]);
        let second = len - first;
        destination[..second].copy_from_slice(&source[..second]);
    }

    pub(super) fn commit(&mut self) {
        Self::copy_dirty(
            &self.scratch,
            &mut self.committed,
            self.dirty_start,
            self.dirty_len,
        );
        self.committed_cursor = self.scratch_cursor;
        self.dirty_len = 0;
    }

    pub(super) fn rollback(&mut self) {
        Self::copy_dirty(
            &self.committed,
            &mut self.scratch,
            self.dirty_start,
            self.dirty_len,
        );
        self.scratch_cursor = self.committed_cursor;
        self.dirty_len = 0;
    }

    pub(super) fn reset(&mut self) {
        self.committed.fill(T::default());
        self.scratch.fill(T::default());
        self.committed_cursor = Cursor::default();
        self.scratch_cursor = Cursor::default();
        self.dirty_start = 0;
        self.dirty_len = 0;
    }
}

/// A fixed stereo delay with committed/scratch banks. Zero delay allocates no
/// ring buffers. Begin once per complete output request, process all subchunks,
/// and commit only after every downstream renderer and final validator succeeds.
#[derive(Debug)]
pub struct DelayPair {
    ring: RingPair<Frame>,
    delay_frames: u32,
    storage_bytes: usize,
    transaction_active: bool,
}

impl DelayPair {
    pub(super) fn visit_storage_on_control<'a>(
        &'a self,
        ledger: &mut crate::AudioRootStorageLedger<'a>,
    ) -> Result<(), crate::AudioStorageError> {
        let Self {
            ring,
            delay_frames,
            storage_bytes,
            transaction_active,
        } = self;
        let _: (&u32, &usize, &bool) = (delay_frames, storage_bytes, transaction_active);
        if *transaction_active {
            return Err(crate::AudioStorageError::SourceMismatch);
        }
        ring.visit_storage_on_control(ledger)
    }
    pub fn new(delay_frames: u32, limits: CompensationLimits) -> Result<Self, CompensationError> {
        limits.validate()?;
        if delay_frames > limits.max_cumulative_frames {
            return Err(CompensationError::LatencyLimit);
        }
        let capacity =
            usize::try_from(delay_frames).map_err(|_| CompensationError::ArithmeticOverflow)?;
        let requested_bytes = requested_ring_bytes::<Frame>(capacity)?;
        if requested_bytes > limits.max_storage_bytes {
            return Err(CompensationError::StorageLimit);
        }
        let ring = RingPair::new(capacity)?;
        let storage_bytes = ring.storage_bytes()?;
        if storage_bytes > limits.max_storage_bytes {
            return Err(CompensationError::StorageLimit);
        }
        Ok(Self {
            ring,
            delay_frames,
            storage_bytes,
            transaction_active: false,
        })
    }

    pub const fn delay_frames(&self) -> u32 {
        self.delay_frames
    }
    pub const fn storage_bytes(&self) -> usize {
        self.storage_bytes
    }
    pub fn history_ready(&self) -> bool {
        self.ring.scratch_cursor.valid == self.ring.scratch.len()
    }

    pub fn begin_transaction(&mut self) -> Result<(), CompensationError> {
        if self.transaction_active {
            return Err(CompensationError::TransactionActive);
        }
        self.ring.begin();
        self.transaction_active = true;
        Ok(())
    }

    pub fn process(
        &mut self,
        input: &[Frame],
        output: &mut [Frame],
    ) -> Result<(), CompensationError> {
        if !self.transaction_active {
            return Err(CompensationError::TransactionInactive);
        }
        if input.len() != output.len() {
            return Err(CompensationError::BufferLength);
        }
        for (source, target) in input.iter().zip(output) {
            *target = self.ring.push(*source);
        }
        Ok(())
    }

    pub fn process_in_place(&mut self, frames: &mut [Frame]) -> Result<(), CompensationError> {
        if !self.transaction_active {
            return Err(CompensationError::TransactionInactive);
        }
        for frame in frames {
            *frame = self.ring.push(*frame);
        }
        Ok(())
    }

    pub fn commit_transaction(&mut self) -> Result<(), CompensationError> {
        if !self.transaction_active {
            return Err(CompensationError::TransactionInactive);
        }
        self.ring.commit();
        self.transaction_active = false;
        Ok(())
    }

    pub fn rollback_transaction(&mut self) -> Result<(), CompensationError> {
        if !self.transaction_active {
            return Err(CompensationError::TransactionInactive);
        }
        self.ring.rollback();
        self.transaction_active = false;
        Ok(())
    }

    pub fn reset_epoch(&mut self) {
        self.ring.reset();
        self.transaction_active = false;
    }
}
