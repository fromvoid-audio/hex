use super::*;
use std::collections::VecDeque;

fn node(key: u64, latency: u32) -> LatencyNode {
    LatencyNode {
        key,
        latency_frames: Some(latency),
    }
}

fn edge(key: u64, from: u64, to: u64) -> LatencyEdge {
    LatencyEdge { key, from, to }
}

fn plan(nodes: &[LatencyNode], edges: &[LatencyEdge]) -> LatencyPlan {
    LatencyPlan::build(nodes, edges, CompensationLimits::default()).unwrap()
}

fn pair(delay: u32) -> DelayPair {
    DelayPair::new(delay, CompensationLimits::default()).unwrap()
}

fn sample(index: usize) -> Frame {
    [index as f32 + 1.0, -(index as f32) - 0.25]
}

#[test]
fn runtime_storage_visitor_covers_real_delay_pairs_without_allocation() {
    use crate::{
        AudioRootStorageLedger, AudioStorageError, AudioStorageLedgerReservation, AudioStorageRole,
    };
    let compiled = plan(
        &[node(1, 0), node(2, 7), node(3, 0), node(4, 0)],
        &[edge(1, 1, 2), edge(2, 1, 3), edge(3, 2, 4), edge(4, 3, 4)],
    );
    assert_eq!(compiled.edges()[3].delay_frames, 7);
    let mut runtime = CompensationRuntime::new(compiled, CompensationLimits::default()).unwrap();
    let reservation = AudioStorageLedgerReservation {
        data_rows: 64,
        handle_rows: 0,
        root_rows: 1,
        max_retained_bytes: 1024 * 1024,
        max_construction_peak_bytes: 1024 * 1024,
    };
    let mut ledger = AudioRootStorageLedger::try_new_on_control(reservation).unwrap();
    ledger.root(&runtime, AudioStorageRole::Caller).unwrap();
    let measured =
        allocation_counter::measure(|| runtime.visit_storage_on_control(&mut ledger).unwrap());
    assert_eq!(measured.count_total, 0);
    assert_eq!(measured.count_current, 0);
    assert_eq!(
        ledger.summary().unwrap().data_bytes,
        size_of::<CompensationRuntime>() + runtime.storage_bytes()
    );
    drop(ledger);
    runtime.begin_transaction().unwrap();
    let mut ledger = AudioRootStorageLedger::try_new_on_control(reservation).unwrap();
    assert_eq!(
        runtime.visit_storage_on_control(&mut ledger),
        Err(AudioStorageError::SourceMismatch)
    );
    drop(ledger);
    runtime.rollback_transaction().unwrap();
    let mut ledger = AudioRootStorageLedger::try_new_on_control(reservation).unwrap();
    ledger.root(&runtime, AudioStorageRole::Caller).unwrap();
    runtime.visit_storage_on_control(&mut ledger).unwrap();
    assert_eq!(
        ledger.summary().unwrap().data_bytes,
        size_of::<CompensationRuntime>() + runtime.storage_bytes()
    );
}

#[test]
fn planner_sums_serial_latency_and_aligns_each_reconvergence() {
    // source -> a(3) -> c(4) -> merge(2) -> sink
    //       \-> b(5) ---------/    \----------> sink
    let nodes = [
        node(1, 0),
        node(2, 3),
        node(3, 5),
        node(4, 4),
        node(5, 2),
        node(6, 0),
    ];
    let edges = [
        edge(1, 1, 2),
        edge(2, 1, 3),
        edge(3, 2, 4),
        edge(4, 4, 5),
        edge(5, 3, 5),
        edge(6, 5, 6),
        edge(7, 3, 6),
    ];
    let compiled = plan(&nodes, &edges);
    assert_eq!(compiled.try_clone().unwrap(), compiled);
    assert_eq!(compiled.max_latency_frames(), 9);
    assert_eq!(compiled.nodes()[4].input_arrival_frames, 7);
    assert_eq!(compiled.nodes()[4].output_arrival_frames, 9);
    assert_eq!(compiled.edges()[4].delay_frames, 2);
    assert_eq!(compiled.edges()[6].delay_frames, 4);
    let mut reversed_nodes = nodes;
    let mut reversed_edges = edges;
    reversed_nodes.reverse();
    reversed_edges.reverse();
    let reversed = plan(&reversed_nodes, &reversed_edges);
    assert_eq!(compiled.nodes(), reversed.nodes());
    assert_eq!(compiled.edges(), reversed.edges());
    assert_eq!(compiled.topological_order(), reversed.topological_order());
}

#[test]
fn planner_rejects_unknown_duplicate_missing_cyclic_and_overlimit_graphs() {
    let limits = CompensationLimits::default();
    assert!(matches!(
        LatencyPlan::build(
            &[LatencyNode {
                key: 1,
                latency_frames: None
            }],
            &[],
            limits
        ),
        Err(CompensationError::UnknownLatency)
    ));
    assert!(matches!(
        LatencyPlan::build(&[node(1, 0), node(1, 0)], &[], limits),
        Err(CompensationError::DuplicateNode)
    ));
    assert!(matches!(
        LatencyPlan::build(&[node(1, 0)], &[edge(1, 1, 2)], limits),
        Err(CompensationError::MissingNode)
    ));
    assert!(matches!(
        LatencyPlan::build(
            &[node(1, 0), node(2, 0)],
            &[edge(1, 1, 2), edge(1, 1, 2)],
            limits
        ),
        Err(CompensationError::DuplicateEdge)
    ));
    assert!(matches!(
        LatencyPlan::build(&[node(1, 0)], &[edge(1, 1, 1)], limits),
        Err(CompensationError::Cycle)
    ));
    assert!(matches!(
        LatencyPlan::build(
            &[node(1, 0), node(2, 0)],
            &[edge(1, 1, 2), edge(2, 2, 1)],
            limits
        ),
        Err(CompensationError::Cycle)
    ));
    assert!(matches!(
        LatencyPlan::build(&[node(1, 65_536), node(2, 1)], &[edge(1, 1, 2)], limits),
        Err(CompensationError::LatencyLimit)
    ));
    assert!(matches!(
        LatencyPlan::build(&[node(1, u32::MAX)], &[], limits),
        Err(CompensationError::LatencyLimit)
    ));
    assert!(matches!(
        LatencyPlan::build(&vec![node(1, 0); MAX_COMPENSATION_NODES + 1], &[], limits),
        Err(CompensationError::GraphLimit)
    ));
    assert!(matches!(
        LatencyPlan::build(
            &[],
            &vec![edge(1, 1, 1); MAX_COMPENSATION_EDGES + 1],
            limits
        ),
        Err(CompensationError::GraphLimit)
    ));
}

#[test]
fn stereo_delay_matches_fifo_oracle_over_partitions_and_repeated_transactions() {
    for delay in [0, 1, 7, 257, 1024] {
        let mut delayed = pair(delay);
        let mut oracle = VecDeque::from(vec![[0.0; 2]; delay as usize]);
        let mut source_index = 0;
        for count in [1, 13, 256, 907, 2, 1027] {
            delayed.begin_transaction().unwrap();
            let mut frames = (source_index..source_index + count)
                .map(sample)
                .collect::<Vec<_>>();
            let expected = frames
                .iter()
                .map(|&frame| {
                    oracle.push_back(frame);
                    oracle.pop_front().unwrap()
                })
                .collect::<Vec<_>>();
            // Arbitrary subchunks share one transaction, including >256 frames.
            for chunk in frames.chunks_mut(73) {
                delayed.process_in_place(chunk).unwrap();
            }
            assert_eq!(frames, expected, "delay {delay}, request {count}");
            delayed.commit_transaction().unwrap();
            source_index += count;
        }
    }
}

#[test]
fn rollback_after_prior_chunks_restores_partial_wrapped_and_full_rings() {
    for delay in [0, 1, 7, 513] {
        for failed_count in [1, 4, 255, 256, 257, 1029] {
            let mut delayed = pair(delay);
            let mut reference = pair(delay);
            for runtime in [&mut delayed, &mut reference] {
                runtime.begin_transaction().unwrap();
                runtime
                    .process_in_place(&mut (0..11).map(sample).collect::<Vec<_>>())
                    .unwrap();
                runtime.commit_transaction().unwrap();
            }
            delayed.begin_transaction().unwrap();
            let mut failed = (11..11 + failed_count).map(sample).collect::<Vec<_>>();
            for chunk in failed.chunks_mut(127) {
                delayed.process_in_place(chunk).unwrap();
            }
            delayed.rollback_transaction().unwrap();
            let mut actual = (11..1051).map(sample).collect::<Vec<_>>();
            let mut expected = actual.clone();
            delayed.begin_transaction().unwrap();
            reference.begin_transaction().unwrap();
            delayed.process_in_place(&mut actual).unwrap();
            reference.process_in_place(&mut expected).unwrap();
            assert_eq!(
                actual, expected,
                "delay {delay}, failed request {failed_count}"
            );
            delayed.commit_transaction().unwrap();
            reference.commit_transaction().unwrap();
        }
    }
}

#[test]
fn impulses_align_through_serial_processors_and_parallel_runtime_edges() {
    let graph = plan(
        &[node(1, 3), node(2, 4), node(3, 2), node(4, 0)],
        &[edge(1, 1, 2), edge(2, 2, 4), edge(3, 3, 4)],
    );
    let mut runtime = CompensationRuntime::new(graph, CompensationLimits::default()).unwrap();
    let mut first = pair(3);
    let mut second = pair(4);
    let mut parallel = pair(2);
    let mut impulse = [[0.0; 2]; 31];
    impulse[0] = [1.0, -0.5];
    let mut serial_audio = impulse;
    let mut parallel_audio = impulse;
    first.begin_transaction().unwrap();
    second.begin_transaction().unwrap();
    parallel.begin_transaction().unwrap();
    first.process_in_place(&mut serial_audio).unwrap();
    second.process_in_place(&mut serial_audio).unwrap();
    parallel.process_in_place(&mut parallel_audio).unwrap();
    runtime.begin_transaction().unwrap();
    runtime.process_edge_in_place(1, &mut serial_audio).unwrap();
    runtime
        .process_edge_in_place(2, &mut parallel_audio)
        .unwrap();
    assert_eq!(serial_audio, parallel_audio);
    assert_eq!(serial_audio[7], [1.0, -0.5]);
    assert_eq!(
        serial_audio
            .iter()
            .filter(|&&frame| frame != [0.0; 2])
            .count(),
        1
    );
    runtime.commit_transaction().unwrap();
}

#[test]
fn silence_advances_pending_impulse_and_epoch_reset_removes_old_content() {
    let graph = plan(
        &[node(1, 0), node(2, 5), node(3, 0)],
        &[edge(1, 1, 3), edge(2, 2, 3)],
    );
    let mut runtime = CompensationRuntime::new(graph, CompensationLimits::default()).unwrap();
    runtime.begin_transaction().unwrap();
    runtime
        .process_edge_in_place(0, &mut [[1.0, -1.0]])
        .unwrap();
    runtime.commit_transaction().unwrap();
    runtime.begin_transaction().unwrap();
    let mut silence = [[99.0; 2]; 6];
    runtime.process_edge_silence(0, &mut silence).unwrap();
    assert_eq!(silence[4], [1.0, -1.0]);
    assert_eq!(
        silence.iter().filter(|&&frame| frame != [0.0; 2]).count(),
        1
    );
    runtime.rollback_transaction().unwrap();
    runtime.reset_epoch();
    runtime.begin_transaction().unwrap();
    runtime.process_edge_silence(0, &mut silence).unwrap();
    assert_eq!(silence, [[0.0; 2]; 6]);
    assert!(!runtime.history_ready());
}

fn stamp(index: usize) -> TransportStamp {
    TransportStamp {
        performance_frame: index as u64,
        transport_is_running: index % 3 != 0,
        arrangement_frame: (index % 4) as u64,
        loop_pass: (index / 4) as u64,
        performance_beat_raw: (index as u64) << 30,
        arrangement_beat_raw: Some(((index % 4) as u64) << 30),
    }
}

#[test]
fn transport_origins_preserve_loop_identity_and_rollback_long_requests() {
    let graph = plan(&[node(1, 3), node(2, 2)], &[edge(1, 1, 2)]);
    let mut runtime = CompensationRuntime::new(graph, CompensationLimits::default()).unwrap();
    runtime.begin_transaction().unwrap();
    for index in 0..19 {
        runtime.push_transport_stamp(stamp(index)).unwrap();
        assert_eq!(
            runtime.node_input_stamp(1).unwrap(),
            index.checked_sub(3).map(stamp)
        );
        assert_eq!(
            runtime.node_output_stamp(1).unwrap(),
            index.checked_sub(5).map(stamp)
        );
        assert_eq!(runtime.history_ready(), index >= 5);
    }
    runtime.commit_transaction().unwrap();
    runtime.begin_transaction().unwrap();
    for index in 19..1027 {
        runtime.push_transport_stamp(stamp(index)).unwrap();
    }
    runtime.rollback_transaction().unwrap();
    assert_eq!(runtime.node_input_stamp(1).unwrap(), Some(stamp(15)));
    assert_eq!(runtime.node_output_stamp(1).unwrap(), Some(stamp(13)));
    runtime.begin_transaction().unwrap();
    runtime.push_transport_stamp(stamp(19)).unwrap();
    assert_eq!(runtime.node_output_stamp(1).unwrap(), Some(stamp(14)));
    runtime.reset_epoch();
    assert!(!runtime.transaction_active());
    assert_eq!(runtime.node_input_stamp(1).unwrap(), None);
    assert_eq!(runtime.stamp_at_delay(u32::MAX), None);
}

#[test]
fn invalid_calls_refuse_before_mutating_ring_state() {
    let mut delayed = pair(2);
    assert_eq!(
        delayed.process_in_place(&mut [[1.0; 2]]),
        Err(CompensationError::TransactionInactive)
    );
    delayed.begin_transaction().unwrap();
    assert_eq!(
        delayed.begin_transaction(),
        Err(CompensationError::TransactionActive)
    );
    assert_eq!(
        delayed.process(&[[1.0; 2]], &mut []),
        Err(CompensationError::BufferLength)
    );
    let mut frames = [[3.0; 2]; 3];
    delayed.process_in_place(&mut frames).unwrap();
    assert_eq!(frames, [[0.0; 2], [0.0; 2], [3.0; 2]]);
    delayed.rollback_transaction().unwrap();
    assert_eq!(
        delayed.commit_transaction(),
        Err(CompensationError::TransactionInactive)
    );
    let mut runtime =
        CompensationRuntime::new(plan(&[node(1, 0)], &[]), CompensationLimits::default()).unwrap();
    runtime.begin_transaction().unwrap();
    assert_eq!(
        runtime.process_edge_in_place(0, &mut []),
        Err(CompensationError::InvalidIndex)
    );
    assert_eq!(
        runtime.node_output_stamp(9),
        Err(CompensationError::InvalidIndex)
    );
    assert!(!runtime.history_ready());
    let exact = TransportStamp {
        performance_beat_raw: u64::MAX,
        ..stamp(0)
    };
    runtime.push_transport_stamp(exact).unwrap();
    assert_eq!(runtime.stamp_at_delay(0), Some(exact));
    assert!(runtime.history_ready());
    runtime.rollback_transaction().unwrap();
    assert!(!runtime.history_ready());
}

#[test]
fn storage_counts_actual_twin_capacities_and_enforces_exact_budget() {
    let zero = DelayPair::new(
        0,
        CompensationLimits {
            max_cumulative_frames: 0,
            max_storage_bytes: 0,
        },
    )
    .unwrap();
    assert_eq!(zero.storage_bytes(), 0);
    assert!(zero.history_ready());
    let delay = pair(513);
    assert_eq!(delay.storage_bytes(), 2 * 513 * size_of::<Frame>());
    assert!(matches!(
        DelayPair::new(
            513,
            CompensationLimits {
                max_storage_bytes: delay.storage_bytes() - 1,
                ..CompensationLimits::default()
            }
        ),
        Err(CompensationError::StorageLimit)
    ));
    assert!(matches!(
        DelayPair::new(MAX_COMPENSATION_FRAMES + 1, CompensationLimits::default()),
        Err(CompensationError::LatencyLimit)
    ));
    assert!(matches!(
        DelayPair::new(
            1,
            CompensationLimits {
                max_cumulative_frames: u32::MAX,
                ..CompensationLimits::default()
            }
        ),
        Err(CompensationError::PolicyLimit)
    ));
    let graph = || {
        plan(
            &[node(1, 0), node(2, 7), node(3, 0)],
            &[edge(1, 1, 3), edge(2, 2, 3)],
        )
    };
    let runtime = CompensationRuntime::new(graph(), CompensationLimits::default()).unwrap();
    let actual = runtime.plan.storage_bytes().unwrap()
        + vector_bytes(&runtime.edges).unwrap()
        + runtime.stamps.storage_bytes().unwrap()
        + runtime
            .edges
            .iter()
            .map(DelayPair::storage_bytes)
            .sum::<usize>();
    assert_eq!(runtime.storage_bytes(), actual);
    assert!(
        CompensationRuntime::new(
            graph(),
            CompensationLimits {
                max_storage_bytes: actual,
                ..CompensationLimits::default()
            }
        )
        .is_ok()
    );
    assert!(matches!(
        CompensationRuntime::new(
            graph(),
            CompensationLimits {
                max_storage_bytes: actual - 1,
                ..CompensationLimits::default()
            }
        ),
        Err(CompensationError::StorageLimit)
    ));
}

#[test]
fn runtime_rejects_combined_ring_storage_exceeding_its_policy() {
    let mut nodes = vec![node(100, MAX_COMPENSATION_FRAMES), node(101, 0)];
    let mut edges = vec![edge(100, 100, 101)];
    for key in 0..14 {
        nodes.push(node(key, 0));
        edges.push(edge(key, key, 101));
    }
    assert!(matches!(
        CompensationRuntime::new(plan(&nodes, &edges), CompensationLimits::default()),
        Err(CompensationError::StorageLimit)
    ));
}
