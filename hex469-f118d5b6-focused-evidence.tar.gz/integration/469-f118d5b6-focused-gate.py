from pathlib import Path
import json,re,subprocess,hashlib
r=Path('/workspace/hex-integration-captured-release');run=r/'artifacts/local-ci/469-f118d5b6-focused';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']=='f118d5b60d484869d08a0594a422f7ed4118c734' and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and not s['dirty'] and s['start_tree']==s['end_tree']
assert len(s['steps'])==6 and all(t['status']=='passed' and t['exit_code']==0 for t in s['steps']) and not Path('/proc/1536444').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
counts=[]
for t,expected in zip(s['steps'],[26,24,9,6,27,3]):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(r/t['log']).read_text(errors='replace'));assert rows==[(str(expected),'0','0')],rows;counts.append(expected)
p={'head':s['commit'],'source':s['source_identity']['content_sha256'],'all6passed':True,'counts':counts,'unique_tests':sum(counts),'ignored':0,'duration_seconds':s['duration_seconds'],'summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest()};assert p['source']=='7e6c2a4377660ece42d7476ed218dffc8b1bdaa0c84d5142d60b4575174b7732'
(r/'artifacts/integration/469-f118d5b6-focused-gate.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2))
