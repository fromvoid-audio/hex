#![forbid(unsafe_code)]
#![allow(dead_code)]
#[path="/workspace/hex-sampler-aggregate/crates/hex-audio/src/candidate_custody/custody_mutex.rs"]
mod custody_mutex;
fn main() {
 fn send_sync<T:Send+Sync>() {}
 send_sync::<custody_mutex::CustodyMutex<std::cell::Cell<u32>>>();
 let value=custody_mutex::CustodyMutex::new(std::cell::Cell::new(0));
 value.try_lock().unwrap().set(7);
 assert_eq!(value.lock_recover_on_control().get(),7);
}