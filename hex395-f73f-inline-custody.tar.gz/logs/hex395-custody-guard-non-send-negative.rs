#![forbid(unsafe_code)]
#![allow(dead_code)]
#[path="/workspace/hex-sampler-aggregate/crates/hex-audio/src/candidate_custody/custody_mutex.rs"]
mod custody_mutex;
fn main() {
 let value=custody_mutex::CustodyMutex::new(7_u32);
 std::thread::scope(|scope| {
  let guard=value.try_lock().unwrap();
  scope.spawn(move || drop(guard));
 });
}