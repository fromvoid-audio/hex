import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-spectrum-fill')
spec=importlib.util.spec_from_file_location('hex_grid_focused_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('spectrum-painter',('cargo','test','-p','hex-widgets','--locked','spectrum_painter::','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
