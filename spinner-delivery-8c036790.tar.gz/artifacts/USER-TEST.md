# finite combined hex acceptance

Source: PR368 candidate 8c03679060c3798f77d0bf60e3cb3885e2bab920,
Git tree 51bb61d4f083a2c1c6518330f19deed507f62bfc. See
included-test-revisions.json for all supplied PR heads and exact CI report.
Native results remain pending; Linux automated checks do not prove them.

Before app replacement, coordinate the user's normal save and quit of hex.
Keep Ableton and all unrelated apps/data intact. Fixture-only signing and
terminal tests can run with hex open; do not replace its running app.

1. Terminal fixture: observe ASCII animation and stage text, clear line on
   success, failure7 and Ctrl-C130, no remaining progress thread; narrow terminal
   must not wrap. Redirection must contain plain stage text without ESC/CR bytes.
   Do not run another build or --test solely to observe a spinner.
2. Verify the one optimized installed app's receipt, source, signature, complete
   seal and executable hash at the configured stable path. Record its running
   executable separately. Default launcher remains fetch/build/start without
   tests; --test adds full checks; --open verifies/opens installed-only.
3. Use the native chooser for ONLY
   /Users/portalsurfer/Documents/music_production/samples. Confirm listing AND
   a real WAV read and audible preview. Record the sample path and outcome.
4. User saves/quits normally, then reopen the IDENTICAL installed executable via
   ./launch --open. Compare executable SHA-256/signature/requirement, repeat WAV
   listing/read/audible preview without regrant. On failure retain TCC/signature
   evidence; do not reset privacy or broaden grants.
5. In a disposable new project, Arrangement focus, computer MIDI keyboard off
   for hold-f: resize both lower fade edges inward/outward for neutral hold-f and
   authored curves. Clip/header/waveform edge follows; opposite edge and
   constrained upper point remain. Check snap on/off and Command press AND release
   while stationary/moving, with current modifiers at mouse-up.
6. Escape, focus/window loss and return to origin cancel/no-op. One Undo/Redo
   restores edge plus fade. Upper/middle controls, loop/split/musical/warp/events
   source mapping retain their contracts, including explicit local reanchor.
7. Save As to a NEW path, reopen, play/seek/listen and export to a NEW path;
   saved boundaries/fade match. No existing user project overwrite/conversion.
8. Audio/MIDI headers/bodies have no container/source-note tooltip; selection,
   drag, rename, context menus and distinct-control tooltips still work.
9. Finite general smoke: window/titlebar, demo start/stop and clip edit/undo.
   User performs physical interaction while present; no parallel input injection.

Return pass/fail per item, actual source/receipt/signature/hash, native test logs,
terminal identity and fixture/sample/export paths. Partial or unavailable manual
acceptance stays open in Pulse2745/2755/2760/2751/2752. No complete native-device
library or unfinished tuning feature is claimed or required for this delivery.

FINAL SOURCE/DELIVERY CHECKPOINT: PR368 is MERGED 04545f8e8ed49182fd1833b0e85fa511d6935a4a; exact candidate 8c03679060c3798f77d0bf60e3cb3885e2bab920 passed all20Linux, clean/stale=false, complete identical Git tree 51bb61d4f083a2c1c6518330f19deed507f62bfc. Report artifacts/local-ci/20261017T141953Z-9a1a7195/summary.json SHA256 00ceddd9e06bd97dd12a772117a0d29d86807657febac11d11ef2d04a3845e8a. Source SHA256 17c1bf7f7bfbbd0c8f5b20a39a67ec40ce4f4e81df7c594bcce663b27c2647aa. Native checks/installation/user acceptance remain pending. Use accepted plan19585; never follow moving main for this source-bound request. No broad Mac rerun solely for spinner. Fixtures keep Hex open; coordinated normal user quit is mandatory before replacement.
