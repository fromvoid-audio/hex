import importlib.util
from pathlib import Path
import sys
import threading
import time

spec = importlib.util.spec_from_file_location('spinner_smoke', Path('scripts/local-ci.py'))
ci = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ci
spec.loader.exec_module(ci)
try:
    with ci.terminal_progress('building fixture'):
        time.sleep(3)
        if '--fail' in sys.argv:
            raise SystemExit(7)
except KeyboardInterrupt:
    assert not any(t.name == 'hex-terminal-progress' for t in threading.enumerate())
    print('interrupted', file=sys.stderr)
    raise SystemExit(130)
except SystemExit:
    assert not any(t.name == 'hex-terminal-progress' for t in threading.enumerate())
    print('fixture failed', file=sys.stderr)
    raise
assert not any(t.name == 'hex-terminal-progress' for t in threading.enumerate())
print('done')
