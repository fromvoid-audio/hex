"""Audited sampler-host producer boundary, not Rust hostile-client sealing.

These public internal borrowed projections are only constructed/implemented in
reviewed owning modules. Engine, rather than a producer callback, traverses the
finite schema. This check preserves the independent Cargo dependency checks.
"""
import re


EXACT = {
    # Existing closed original-Sampler constructor readers; no new producer.
    'crates/hex-engine/src/native_device_resources/producer.rs',
    'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs',
    'crates/hex-engine/src/audio_candidate/preparation_operations.rs',
    'crates/hex-engine/src/audio_candidate/storage.rs',
    'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs',
    'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs',
    'crates/hex-session/src/service/event_fields.rs',
    'crates/hex-session/src/resource_plan/original_sampler.rs',
    'crates/hex-storage/src/files.rs',
    'crates/hex-storage/src/lib.rs',
    'crates/hex-engine/src/audio_storage/document_token.rs',
    'crates/hex-storage/src/journal.rs',
    'crates/hex-engine/src/audio_storage/native_root_fields.rs',
    'crates/hex-audio/src/candidate_custody/root_fields.rs',
    'crates/hex-engine/src/audio_storage/native_status.rs',
    'crates/hex-engine/src/audio_storage/native_resident.rs',
    'crates/hex-audio/src/prepared/resident_forwarding.rs',
    'crates/hex-audio/src/native_callback_owner/registered.rs',
    'crates/hex-audio/src/prepared/resident_forwarding/tests.rs',
    'crates/hex-audio/src/prepared/status_owner.rs',
    'crates/hex-audio/src/prepared/status_owner/tests.rs',
    'crates/hex-audio/src/prepared/endpoints.rs',
    'crates/hex-audio/src/gain_recording/tests.rs',
    'crates/hex-engine/src/audio_storage/native_atomic_signal.rs',
    'crates/hex-engine/src/audio_storage/native_atomic_signal/tests.rs',
    'crates/hex-audio/src/native_callback_owner/atomic_signal.rs',
    'crates/hex-audio/src/sample_preview.rs',
    'crates/hex-audio/src/gain_recording.rs',
    'crates/hex-audio/src/spectrum_target.rs',
    'crates/hex-audio/src/processor_audition.rs',
    'crates/hex-engine/src/audio_storage/native_carrier.rs',
    'crates/hex-engine/src/audio_storage/native_fixed_ring.rs',
    'crates/hex-audio/src/native_callback_owner/ring_storage/transport.rs',
    'crates/hex-audio/src/prepared.rs',
    'crates/hex-audio/src/native_callback_owner.rs',
    'crates/hex-audio/src/native_callback_owner/storage_tests.rs',
    'crates/hex-audio/src/native_callback_owner/ring_storage/registered_tests.rs',
    'crates/hex-engine/src/audio_candidate/claimed.rs',
    'crates/hex-engine/src/audio_candidate/groups.rs',  # actual constructor archive owns the wrapper counterpart
    'crates/hex-engine/src/audio_storage/native_state.rs',
    'crates/hex-engine/src/audio_storage/native_spectrum.rs',
    'crates/hex-engine/src/audio_storage/native_spectrum/tests.rs',
    'crates/hex-audio/src/spectrum_worker.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/native_host/tests.rs',
    'crates/hex-audio/src/candidate_custody.rs',
    'crates/hex-audio/src/candidate_custody/eligible/pages.rs',
    'crates/hex-audio/src/candidate_custody/eligible.rs',
    'crates/hex-audio/src/prepared/factory.rs',
    'crates/hex-audio/src/prepared/factory/tests.rs',
    'crates/hex-audio/src/candidate_custody/eligible/native_birth_tests.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/tests.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication.rs',
    'crates/hex-audio/src/candidate_custody/eligible/publication/disposal.rs',
    'crates/hex-session/src/service/worker_roots.rs',
    'crates/hex-project/src/time_range.rs',
    'crates/hex-engine/src/lib.rs',
    'crates/hex-engine/src/midi_preview.rs',
    'crates/hex-engine/src/gain_envelope.rs',
    'crates/hex-session/src/snapshot_exports/storage.rs',
    'crates/hex-session/src/snapshot_exports/native_export_results.rs',
    'crates/hex-session/src/snapshot_exports/native_transport.rs',
    'crates/hex-session/src/snapshot_exports/native_transport/tests.rs',
    'crates/hex-session/src/snapshot_exports/native_requests.rs',
    'crates/hex-media/src/waveform.rs',
    'crates/hex-media/src/waveform/shared_storage_tests.rs',
    'crates/hex-engine/src/audio_storage.rs',
    'crates/hex-engine/src/sampler_host_fields.rs',
    'crates/hex-export/src/staged_file.rs',
    'crates/hex-export/src/publication.rs',
    'crates/hex-export/src/buffered_file.rs',
    'crates/hex-session/src/service/main_control_file.rs',
    'crates/hex-session/src/service/canonical_audio_source.rs',
    'crates/hex-session/src/service/main_control_file/tests.rs',
}
# Whole subtrees are restricted to the new Engine schema itself, not arbitrary
# modules in an approved crate. New production producers require explicit review.
PREFIXES = ('crates/hex-engine/src/sampler_host_fields/',)
NAMES = re.compile(r'\b(?:EventMetadataFields|EventReasonFields|EventBatchFailureFields|TuningLibraryMetadataPayload|TuningSlotMetadataFields|event_metadata_fields_on_control|matches_constructor_worker_fields_on_control|matches_actual_field_role_on_control|matches_constructor_channel_fields_on_control|matches_live_endpoint_on_control|NativeRootFieldRegistration|NativeRootFieldLease|borrow_sampler_native_root_fields_on_control|ResidentArchive|ResidentHandle|NativeResidentFields|NativeResidentRegistration|NativeResidentFieldLease|StatusArchive|StatusHandle|NativeStatusRegistration|NativeStatusFieldLease|NativeStatusFields|atomic_signal|NativeAtomicSignal|NativeAtomicSignalRegistration|registered_prepared_ring|NativePreparedProducer|NativePreparedConsumer|native_prepared_ring|NativeFixedRingFields|NativeFixedRingLease|NativeFixedRingRegistration|NativeCarrierStorageRegistration|NativeCarrierStorageLease|borrow_sampler_worker_fields_on_control|track_buffer_on_control|FamilySnapshotFields|FamilyCompiledRecordFields|FamilyCompiledFields|FamilyRequestPayload|FamilyRequestFields|FamilyRequestRecords|borrow_sampler_family_fields_on_control|borrow_sampler_family_requests_on_control|borrow_sampler_family_compiled_on_control|SnapshotViewFields|SnapshotViewPayload|CapturedSourcePayload|borrow_sampler_snapshot_children_fields_on_control|borrow_sampler_snapshot_view_fields_on_control|WaveformFields|WaveformPayload|WaveformLevelsRef|WaveformSamples|borrow_sampler_waveform_fields_on_control|sampler_host_fields|BodyRef|VecRef|SharedMetadataRef|SamplerWorkerFields|DocumentFields|DocumentTokenFields|FileTokenStorageObservation|file_token_storage_on_control|borrowed_file_token_arc_field_on_control|document_storage_fields_on_control|document_file_token_storage_layout_supported|borrow_sampler_document_fields_on_control|JournalFields|journal_storage_fields_on_control|CapturedSourceFields|FamilyFields|FamilyExportResultFields|ExportResultPayloadFields|ExportResultOutcomeFields|borrow_sampler_export_result_fields_on_control|FileSlotsFields|NativeFields|sampler_fields_on_control|borrow_sampler_file_slots_fields_on_control|borrow_sampler_captured_source_fields_on_control)\b')


def violations(path: str, source: str) -> list[str]:
    captured_symbols = re.search(r'\b(?:NativeSpectrumCaptureFields|NativeSpectrumCapturedRegistration|NativeSpectrumCaptureLease|NativeSpectrumJoinLease|pair_actual_capture_on_control|begin_actual_buffers_drop_on_control|complete_actual_buffers_drop_on_control|finalize_actual_join_on_control|finalize_failed_spawn_on_control|pair_spectrum_capture_on_control|finish_spectrum_capture_on_control|abort_spectrum_capture_on_control|finalize_captured_frame_on_control|spawn_worker_with_parent)\b', source)
    if captured_symbols or path in {'crates/hex-audio/src/spectrum_worker.rs', 'crates/hex-audio/src/lifecycle.rs'}:
        owners = {
            'crates/hex-engine/src/audio_storage/native_spectrum.rs',
            'crates/hex-engine/src/audio_storage/native_spectrum/tests.rs',
            'crates/hex-engine/src/sampler_host_fields.rs',
            'crates/hex-engine/src/sampler_host_fields/native.rs',
            'crates/hex-audio/src/spectrum_worker.rs',
            'crates/hex-audio/src/spectrum_worker/native.rs',
            'crates/hex-audio/src/candidate_custody.rs',
            'crates/hex-audio/src/candidate_custody/eligible.rs',
            'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
            'crates/hex-audio/src/native_callback_owner.rs',
            'crates/hex-audio/src/lifecycle.rs',
        }
        if path not in owners:
            return [f'{path}: captured analyzer has exact existing Root/Core/Reaper owners only']
        forwarders = {
            'pair_spectrum_capture_on_control': {'crates/hex-audio/src/candidate_custody.rs', 'crates/hex-audio/src/native_callback_owner.rs', 'crates/hex-audio/src/spectrum_worker.rs'},
            'finish_spectrum_capture_on_control': {'crates/hex-audio/src/candidate_custody.rs', 'crates/hex-audio/src/native_callback_owner.rs', 'crates/hex-audio/src/spectrum_worker.rs'},
            'abort_spectrum_capture_on_control': {'crates/hex-audio/src/candidate_custody.rs', 'crates/hex-audio/src/native_callback_owner.rs', 'crates/hex-audio/src/spectrum_worker.rs'},
            'finalize_captured_frame_on_control': {'crates/hex-audio/src/spectrum_worker.rs', 'crates/hex-audio/src/spectrum_worker/native.rs', 'crates/hex-audio/src/lifecycle.rs'},
            'spawn_worker_with_parent': {'crates/hex-audio/src/spectrum_worker.rs', 'crates/hex-audio/src/spectrum_worker/native.rs', 'crates/hex-audio/src/lifecycle.rs'},
        }
        for name, permitted in forwarders.items():
            if name in source and path not in permitted:
                return [f'{path}: captured spectrum operation {name} has exact owning callsites']
        for method in ['pair_actual_capture_on_control', 'finalize_actual_join_on_control', 'finalize_failed_spawn_on_control']:
            if method in source and path not in {
                    'crates/hex-engine/src/audio_storage/native_spectrum.rs',
                    'crates/hex-engine/src/audio_storage/native_spectrum/tests.rs',
                    'crates/hex-audio/src/candidate_custody/eligible.rs'}:
                return [f'{path}: captured analyzer metadata authority belongs to actual NativeBank']
        for method in ['begin_actual_buffers_drop_on_control', 'complete_actual_buffers_drop_on_control']:
            if method in source and path not in {
                    'crates/hex-engine/src/audio_storage/native_spectrum.rs',
                    'crates/hex-engine/src/audio_storage/native_spectrum/tests.rs',
                    'crates/hex-audio/src/spectrum_worker.rs'}:
                return [f'{path}: only actual captured payload may destroy its buffers']
        if path == 'crates/hex-audio/src/spectrum_worker.rs':
            compact = re.sub(r'\s+', '', source)
            joined = ['self.phase=ReaperPhase::Pending;', 'self.join.take()', 'matchjoin.join()', 'self.phase=ReaperPhase::Complete;']
            joined_positions = [compact.find(item) for item in joined]
            if any(pos < 0 for pos in joined_positions) or joined_positions != sorted(joined_positions):
                return [f'{path}: actual consumed join and Pending must precede normal completion']
            drop_start = source.find('impl Drop for CapturedSpectrumCore')
            drop_end = source.find('struct StreamContext', drop_start)
            destructor = re.sub(r'\s+', '', source[drop_start:drop_end])
            steps = ['begin_actual_buffers_drop_on_control(fields)', 'drop(self.payload.take())', 'complete_actual_buffers_drop_on_control()']
            positions = [destructor.find(step) for step in steps]
            if any(pos < 0 for pos in positions) or positions != sorted(positions):
                return [f'{path}: actual captured payload requires Pending, normal take/drop, then buffer completion']
            if (compact.count('parent.finish_spectrum_capture_on_control(association)') != 1
                    or 'self.phase!=ReaperPhase::Complete||self.join.is_some()||self.first_panic.is_some()' not in compact
                    or 'drop(self.captured_join.take())' not in compact):
                return [f'{path}: captured frame finalization requires same actual normal joined Reaper']
        if path == 'crates/hex-audio/src/lifecycle.rs':
            if 'stamp,native_mode,entry,parent.native.as_ref()' not in re.sub(r'\s+', '', source):
                return [f'{path}: analyzer birth must borrow its actual existing retirement parent']
            start = source.find('fn advance_worker_then_final_native(')
            end = source.find('// One matched retirement bundle', start)
            driver = re.sub(r'\s+', '', source[start:end])
            if (source.count('finalize_captured_frame_on_control(') != 1
                    or driver.find('reaper.advance_shutdown_on_control()') < 0
                    or driver.find('reaper.finalize_captured_frame_on_control(native)') < driver.find('reaper.advance_shutdown_on_control()')
                    or driver.find('reaper.finalize_captured_frame_on_control(native)') > driver.find('native.finish_root_after_native_fields_on_control()')):
                return [f'{path}: same parent actual join must precede frame and final Root completion']
    spectrum_names = re.search(r'\b(?:SpectrumFloatBoxRef|NativeSpectrumCoreFields|native_buffer_fields|native_core_fields|borrow_sampler_spectrum_core_fields_on_control)\b', source)
    spectrum_owned_module = False
    if spectrum_names:
        allowed_spectrum = {
            'crates/hex-engine/src/sampler_host_fields.rs',
            'crates/hex-engine/src/sampler_host_fields/spectrum.rs',
            'crates/hex-audio/src/spectrum.rs',
            'crates/hex-audio/src/spectrum_worker.rs',
            'crates/hex-engine/src/audio_storage/native_spectrum.rs',
            'crates/hex-engine/src/audio_storage/native_spectrum/tests.rs',
            'crates/hex-audio/src/spectrum_worker/native.rs',
        }
        if path not in allowed_spectrum:
            return [f'{path}: actual analyzer float fields require the exact owning constructor modules']
        spectrum_owned_module = path in {
            'crates/hex-audio/src/spectrum.rs', 'crates/hex-audio/src/spectrum_worker.rs', 'crates/hex-audio/src/spectrum_worker/native.rs'}
        spectrum_checked = source
        if path == 'crates/hex-audio/src/spectrum_worker/native.rs':
            # ONLY the two existing static constructor quotes, not borrowed metadata producers.
            for quote in [
                'hex_engine::sampler_host_fields::SharedMetadataRef::constructor_bytes::<RingBuffer<T>>()',
                'hex_engine::sampler_host_fields::SharedMetadataRef::constructor_bytes::<AtomicBool>()',
            ]:
                spectrum_checked = spectrum_checked.replace(quote, '', 1)
        if spectrum_owned_module and any(match.group() not in {'sampler_host_fields', 'BodyRef'} for match in NAMES.finditer(spectrum_checked)):
            return [f'{path}: analyzer float-field permission does not enable unrelated host schemas']
    native_driver = re.search(r'\b(?:OriginalSamplerNativeHost|selected_preparation_on_control|selected_operations_on_control)\b', source)
    if native_driver:
        permitted = {
            'crates/hex-engine/src/sampler_host_fields.rs',
            'crates/hex-engine/src/sampler_host_fields/original_driver.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs',
            'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
            'crates/hex-audio/src/candidate_custody/eligible/publication/native_host/tests.rs',
        }
        if path not in permitted:
            return [f'{path}: selected-parent driver operations belong only to closed Engine/private Audio']
        implementations = re.findall(r'\bimpl(?:<[^>]*>)?\s+(?:[\w:]+::)?OriginalSamplerNativeHost\s+for\s+(\w+)', source)
        if implementations and (path != 'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs' or implementations != ['NativePreparationHost']):
            return [f'{path}: only the actual private guarded Audio facade implements the driver']
    private_driver_names = re.search(r'\b(?:inspect_original_sampler_revision_with_writers_on_control|construct_original_sampler_revision_with_writers_on_control)\b', source)
    if private_driver_names and path not in {
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs'}:
        return [f'{path}: private original-Sampler inspect/construct stages cannot escape the closed Engine driver']
    candidate_stage_names = re.search(r'\b(?:OriginalSamplerConstruction|inspect_original_sampler_with_writers_on_control|construct_original_sampler_with_writers_on_control|original_sampler_compiler_reservation|finish_original_sampler_runtime_on_control)\b', source)
    if candidate_stage_names and path not in {
            'crates/hex-engine/src/audio_preparation.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources/tests/runtime.rs'}:
        return [f'{path}: private candidate construction stages cannot become an external plan/approval API']
    seal_stage_names = re.search(r'\b(?:OriginalSamplerSealInspection|inspect_sampler_constructor_with_inventory_on_control|install_sampler_constructor_inspection_on_control)\b', source)
    if seal_stage_names and path not in {
            'crates/hex-engine/src/audio_candidate/storage.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs'}:
        return [f'{path}: private sampler seal inspection cannot escape the closed Engine constructor']
    resident_names = re.search(r'\b(?:OriginalSamplerResidentFields|OriginalSamplerResidentView|ResidentAssetFields|ResidentClipWaveformFields|ResidentOriginalFields|resident_fields_and_writer_on_control|visit_original_sampler_resident)\b', source)
    if resident_names:
        resident_paths = {
            'crates/hex-engine/src/native_device_resources/producer.rs',
            'crates/hex-session/src/lib.rs', 'crates/hex-session/src/resource_plan.rs',
            'crates/hex-session/src/resource_plan/original_sampler.rs',
            'crates/hex-session/src/resource_plan/tests.rs',
            'crates/hex-engine/src/sampler_host_fields.rs',
            'crates/hex-engine/src/audio_candidate/storage.rs',
            'crates/hex-engine/src/audio_candidate/preparation_operations.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs',
            'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
        }
        if path not in resident_paths and not path.startswith('crates/hex-engine/src/sampler_host_fields/'):
            return [f'{path}: original-Sampler resident fields require the audited owning Session view']
        impls = re.findall(r'\bimpl(?:<[^>]*>)?\s+(?:[\w:]+::)?OriginalSamplerResidentFields\s+for\s+(\w+)', source)
        if impls and (path != 'crates/hex-session/src/resource_plan/original_sampler.rs' or impls != ['OriginalSamplerResidentView']):
            return [f'{path}: exactly one actual Session producer implements resident fields']
    lending_names = re.search(r'\b(?:OriginalSamplerTransaction|OriginalSamplerSessionLoan|original_sampler_transaction_on_control|original_sampler_session_loan_on_control|original_sampler_writer_on_control|compile_original_sampler_lent_on_control)\b', source)
    if lending_names:
        lending_paths = {
            'crates/hex-engine/src/audio_transform/mod.rs',
            'crates/hex-engine/src/audio_transform/original_sampler.rs',
            'crates/hex-engine/src/audio_candidate/preparation_operations.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources.rs',
            'crates/hex-engine/src/audio_candidate/preparation/original_resources/tests/runtime.rs',
            'crates/hex-engine/src/audio_candidate/storage.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs',
            'crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/tests/captured_target.rs',
            'crates/hex-session/src/lib.rs',
            'crates/hex-session/src/resource_plan.rs',
            'crates/hex-session/src/resource_plan/original_sampler.rs',
            'crates/hex-session/src/resource_plan/tests.rs',
            'crates/hex-audio/src/candidate_custody/eligible/publication/native_host.rs',
        }
        if path not in lending_paths:
            return [f'{path}: original-Sampler writers have one Session producer and private Audio consumer']
        if re.search(r'impl(?:<[^>]*>)?\s+.*\bOriginalSamplerTransaction\b', source) and path != 'crates/hex-engine/src/audio_transform/original_sampler.rs':
            return [f'{path}: only Engine implements the original-Sampler transaction']
        if path == 'crates/hex-session/src/resource_plan/original_sampler.rs':
            if source.count('.original_sampler_transaction_on_control(') != 1 or source.count('pub fn original_sampler_session_loan_on_control(') != 1:
                return [f'{path}: original-Sampler acquisition must remain the single audited Session producer']
    event_projection = re.search(r'\b(?:EventMetadataFields|EventReasonFields|EventBatchFailureFields|TuningLibraryMetadataPayload|TuningSlotMetadataFields)\b', source)
    if event_projection and not (path.startswith('crates/hex-engine/src/sampler_host_fields/') or path in {
            'crates/hex-engine/src/sampler_host_fields.rs',
            'crates/hex-session/src/service/event_fields.rs'}):
        return [f'{path}: Event metadata projection belongs to the audited owning adapter and Engine schema']
    if 'event_metadata_fields_on_control' in source and path not in {
            'crates/hex-session/src/service/event_fields.rs',
            'crates/hex-session/src/service/worker_roots.rs'}:
        return [f'{path}: Event metadata accessor belongs to the actual Event/worker borrow']
    token_accessors = re.search(r'\b(?:FileTokenStorageObservation|file_token_storage_on_control|borrowed_file_token_arc_field_on_control|document_storage_fields_on_control)\b', source)
    if token_accessors and path not in {
            'crates/hex-storage/src/files.rs', 'crates/hex-storage/src/lib.rs',
            'crates/hex-session/src/service/worker_roots.rs'}:
        return [f'{path}: FileToken borrowed access belongs only to Storage and ONE Session document producer']
    if path == 'crates/hex-session/src/service/worker_roots.rs':
        start = source.find('fn document_storage_fields_on_control(')
        end = source.find('\n}\n', start)
        bridge = re.sub(r'\s+', '', source[start:end]) if start >= 0 and end > start else ''
        required = ['letSelf{path,token}=self;',
                    'letobservation=token.file_token_storage_on_control();',
                    'body:BodyRef::of(self),', 'body:BodyRef::of(token),',
                    'contents:observation.borrowed_file_token_arc_field_on_control(),']
        if any(item not in bridge for item in required) or any(item in bridge for item in ['.clone(', '.take(', '.as_ptr(', 'Arc::']):
            return [f'{path}: actual immutable DocumentHandle/token fields must feed the audited bridge without owning conversion']
    # Closed Storage token constructors. Read-only observation adds no owning
    # getter/constructor; new ingress needs an explicit constructor audit.
    constructors = re.findall(r'\bFileToken\s*\(', source)
    if constructors and path not in {
            'crates/hex-storage/src/files.rs',
            'crates/hex-storage/src/replacement.rs'}:
        return [f'{path}: FileToken constructors/destructuring belong only to Storage owners']
    if path == 'crates/hex-storage/src/files.rs':
        compact = re.sub(r'\s+', '', source)
        required = ['pubstructFileToken(pub(super)Arc<[u8]>);',
                    'FileToken(bytes.into())', 'FileToken(Arc::from(bytes))',
                    'letFileToken(owner)=self.token;']
        if len(constructors) != 4 or any(value not in compact for value in required):
            return [f'{path}: sealed FileToken definition/two births/borrowed-field match changed']
    if path == 'crates/hex-storage/src/replacement.rs':
        compact = re.sub(r'\s+', '', source)
        if len(constructors) != 2 or any(value not in compact for value in [
                'FileToken(Arc::from(new_bytes))', 'FileToken(Arc::from(payload))']):
            return [f'{path}: sealed replacement/recovery FileToken births changed']
    final = 'finish_root_after_native_fields_on_control'
    if final in source:
        if path == 'crates/hex-audio/src/lifecycle.rs':
            begin = source.find('fn construct_prepared_channel_on_control(')
            stop = source.find('\n    pub fn new(', begin)
            constructor = re.sub(r'\s+', '', source[begin:stop])
            required = ['::preflight_native_worker_birth(', '::channel_with_factory_reservation(',
                        'Self::begin_prepared_custody(', 'parent.construct_spectrum_on_control(']
            positions = [constructor.find(item) for item in required]
            if any(position < 0 for position in positions) or positions != sorted(positions):
                return [f'{path}: combined fixed preflight/Root/parent must precede analyzer birth']
            start = source.find('fn advance_worker_then_final_native(')
            end = source.find('// One matched retirement bundle', start)
            driver = source[start:end]
            compact = re.sub(r'\s+', '', driver)
            if (source.count(final) != 1 or driver.count(final) != 1
                    or compact.find('reaper.advance_shutdown_on_control()') < 0
                    or compact.find('reaper.advance_shutdown_on_control()') > compact.find(final)):
                return [f'{path}: final native Root completion requires the owning parent actual Reaper join']
        elif path != 'crates/hex-audio/src/native_callback_owner.rs':
            return [f'{path}: final native Root completion belongs only to the lifecycle owning parent']
    if path == 'crates/hex-audio/src/spectrum_worker/native.rs':
        # Static fresh constructor quotes ONLY; this does not add another
        # borrowed producer/adoption implementation to the audited schema.
        names = set(NAMES.findall(spectrum_checked))
        if (names - {'sampler_host_fields', 'BodyRef'}
                or re.findall(r'SharedMetadataRef\s*::\s*(\w+)', source) != ['constructor_bytes', 'constructor_bytes']):
            return [f'{path}: spectrum may only use its two fresh typed constructor layout quotes']
        return []
    if path == 'crates/hex-audio/src/native_callback_owner.rs':
        start = source.find('pub(crate) fn reserve_native_worker(')
        end = source.find('fn reserve_carriers(', start)
        worker = source[start:end] if start >= 0 and end > start else ''
        required = ['registered::validate_birth_limits(&root)?;',
                    '!control.matches_constructor_channel_fields_on_control(&root)',
                    '!callback.matches_constructor_channel_fields_on_control(&root)',
                    'control.reserve_worker_endpoints(reader)?']
        positions = [worker.find(text) for text in required]
        if any(position < 0 for position in positions) or positions != sorted(positions):
            return [f'{path}: both actual prepared queue inputs must be checked before ANY carrier birth']
    carrier_module = 'crates/hex-audio/src/native_callback_owner/registered.rs'
    if re.search(r'\bCarrierPayload\b', source):
        if path != carrier_module:
            return [f'{path}: carrier construction trait belongs only to its four concrete producers']
        types = re.findall(r'impl CarrierPayload for (\w+)', source)
        if types != ['NativeCallbackOwner', 'ErrorCallbackOwner', 'ClientEndpoints', 'PublicationControl']:
            return [f'{path}: carrier construction requires exactly four concrete original types']
        required = ['self.matches_constructor_worker_fields_on_control(root)',
                    'root.matches_status_field(&self.status, crate::prepared::status_owner::NATIVE_DATA)',
                    'root.matches_status_field(&self.status, crate::prepared::status_owner::NATIVE_ERROR)']
        if any(text not in source for text in required):
            return [f'{path}: actual worker Resident and native Status field roles must be checked before carrier birth']
    if not NAMES.search(source):
        return []
    if path in EXACT or path.startswith(PREFIXES) or spectrum_owned_module:
        return []
    return [f'{path}: sampler-host projections require a declared audited owning module']


def repository_violations(root):
    from custody_mutex_policy import repository_violations as custody_mutex_violations
    result = custody_mutex_violations(root)
    for path in sorted((root / 'crates').rglob('*.rs')):
        result.extend(violations(path.relative_to(root).as_posix(), path.read_text()))
    return result
