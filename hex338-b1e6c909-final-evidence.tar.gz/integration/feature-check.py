import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-integration')
spec=importlib.util.spec_from_file_location('hex338_feature_ci',root/'scripts/local-ci.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(
 m.Step('note-only-expression-regression',('cargo','test','-p','hex-engine','--example','playback_stack','--features','instrument-test-support','--locked','mutable_instrument::tests::note_only_stack_probe_refuses_expression_before_state_changes','--','--exact','--nocapture'),uses_cargo_target=True),
 m.Step('instrument-feature-clippy',('cargo','clippy','-p','hex-engine','--all-targets','--features','instrument-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
runner=m.LocalCiRunner(root,mode='focused',steps=steps,min_free_bytes=2*m.GIB)
code=runner.run();print(f'focused only: {runner.summary_path}');raise SystemExit(code)
