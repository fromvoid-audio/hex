import importlib.util, pathlib, sys
root = pathlib.Path('/workspace/hex-clip-loop')
spec = importlib.util.spec_from_file_location('hex_local_ci_445_repeat', root / 'scripts/local-ci.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
steps = (
    module.Step('audio-view-model', ('cargo','test','-p','hex-project','--test','audio_view','--','--nocapture')),
    module.Step('strict-project-clippy', ('cargo','clippy','-p','hex-project','--all-targets','--','-D','warnings')),
    module.Step('model-fmt', ('rustfmt','--edition','2024','--check','crates/hex-project/src/audio_edit/view.rs','crates/hex-project/tests/audio_view.rs')),
    module.Step('diff-check', ('git','diff','--check')),
)
raise SystemExit(module.LocalCiRunner(root=root, mode='quick', steps=steps).run())
