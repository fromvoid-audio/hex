import importlib.util,json,pathlib,subprocess,sys,unittest
from unittest.mock import patch
source=pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0,str(pathlib.Path('/dev/shm/hex-launcher-restart/scripts/tests')))
spec=importlib.util.spec_from_file_location('fixture_under_test',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.HERE=pathlib.Path('/dev/shm/hex-launcher-restart/scripts/tests')
real_popen=subprocess.Popen
started=[]
def delayed(*args,**kwargs):
    argv=list(args[0])
    if pathlib.Path(argv[0]).name=='launch-restart':
        # Owned-child adapter: deterministic interpreter startup delay, before
        # the helper can record its invocation. No production file mutation.
        argv=[sys.executable,'-c','import os,sys,time;time.sleep(.5);os.execv(sys.argv[1],sys.argv[1:])']+argv
        args=(argv,)+args[1:]
    child=real_popen(*args,**kwargs);started.append(child)
    return child
names=['test_cold_compile_has_separate_budget_then_fast_operations_keep_runtime_budget','test_native_operation_retains_its_own_timeout_and_never_recompiles']
with patch.object(m.restart.subprocess,'Popen',side_effect=delayed):
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(m.CompiledHelperTests(n) for n in names))
print(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'all_owned_children_reaped':all(p.poll() is not None for p in started)}))
sys.exit(not result.wasSuccessful())
