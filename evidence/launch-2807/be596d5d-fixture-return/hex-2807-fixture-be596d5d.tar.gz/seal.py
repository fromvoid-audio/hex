from pathlib import Path
import hashlib,json,subprocess,ast,tarfile
out=Path('/dev/shm/hex-413-fixture-return');root=Path('/dev/shm/hex-launcher-restart')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
assert head=='be596d5dbbdc05a3ce8aedbc0f05d90e4920a647'
old=Path('/dev/shm/hex-413-compile-evidence')
s=(old/'compiled-absent-smoke.py').read_text().replace('a1a4391e9f5e502a22716423c5bd122a5c9f2290',head).replace('54d12aa9f05d4aa2a176bf29a5577657f2576862',tree)
(out/'compiled-absent-smoke.py').write_text(s);ast.parse(s,feature_version=(3,9))
request=(old/'NATIVE-REQUEST.md').read_text().replace('a1a4391e9f5e502a22716423c5bd122a5c9f2290',head).replace('54d12aa9f05d4aa2a176bf29a5577657f2576862',tree).replace('parentcca3b976','parenta1a4391e').replace('22 NEW +20 +25','22 compiled-helper +20 +25')
request='''# Fixture return — NEW exact source, no production delta

This request supersedes the uncompleted a1a4 request only. Original a1a4 Mac first22 was20PASS1ERROR1FAIL; later20+25 and Swift smoke NOT RUN. Original report977cb6e8b59ec67c8704ec5e06d70f8c2e6e92a93366bb71762311390b8ad798 / manifestedd57e53568f767e103bbcb4acceae56063ef3dafef75f0694b7a102d39fa6f5 remain negative evidence. No a1a4 compiled-native green claim.

Only TWO test methods changed. Positive fixture compile30s / operation5s capture actual wait arguments [30,5,5], one compiler/two calls. Negative fixture waits up to15s ONLY for its own invocation JSONL before starting a real .2s process wait; helper sleeps60s. It asserts timeout, owned child reaped, one compile, no retry or leftover workspace. Production still120/15 INCLUDING startup. Fixture synchronization is not a production readiness exemption.

All three suites must run at THIS new exact source (67 unique /0skip/all3exit0). Actual Swift smoke remains unexecuted and requested after them; no AppKit fixture dispatch. Smoke script differs from old packet ONLY in expected head/tree constants.

'''+request
(out/'NATIVE-REQUEST.md').write_text(request)
(out/'HANDOFF.md').write_text(f'''# Canonical413 fixture-only return

Source {head}, tree {tree}, direct child of a1a4391e9f5e502a22716423c5bd122a5c9f2290. Normal FF push, no main/prospective history rewrite. Only scripts/tests/test_launch_restart_compile.py changed (two methods, +44/-4).

CAUSE AND LAW
The old positive .2s assertion required the fake Python interpreter to launch faster than .2s; the negative assumed its invocation was written before that deadline. A controlled OWNED child adapter delays exec by .5s, reproducing EXACT old1ERROR+1FAIL. New same-adapter2PASS; all owned children reaped. The initial harness had two path-setup errors before being corrected; raw log retained separately, not the red proof.

Positive test now captures compile/runtime wait arguments [30,5,5] under adequate fixture budgets, retains compile delay .35/one compile/two operations. Negative test waits boundedly for its own helper's full invocation record, then actual .2s wait expires on native_sleep60 and production owned-child cleanup reaps it; asserts no recompilation/retry/workspace. This deliberately avoids using interpreter startup as a product performance oracle. Production15s still includes startup, no readiness hook added.

CHECKS
Actual Linux Python3.12.14:22+20+25=67PASS/0skips/all3exit0. Two affected cases ALSO passed controlled .5s slow-start oracle; these2 are not added to unique67. Five guards pass; Python3.9 grammar/current Python compile and diff checks pass. Actual Python3.9 runtime/Swift NOT run here. First guard failed missing cargo PATH after suites had already passed; configured toolchain activated and only remaining guards run. Logs preserve failure, no suite repeated for environment correction. checks.json uses actual unittest-reported seconds, not reread elapsed times.

Production Python, Swift, launch, local-ci.py, hex-test-build.py, docs and other two suites byte-identical to a1a4 (unchanged-files.json). No app/native/Swift/signals/userdata/reset/hostedCI/fullCI/merge. Source4 no Sampler395 or Beats449 edits.

HISTORY / LIMITS
Root reports Mac3.9.6 a1a4 first22=20PASS1ERROR1FAIL/8.741s/exit1; later20+25+actual Swift smoke NOT RUN. Actual production Swift15 not exercised. Report SHA977cb6e8b59ec67c8704ec5e06d70f8c2e6e92a93366bb71762311390b8ad798, manifestedd57e53568f767e103bbcb4acceae56063ef3dafef75f0694b7a102d39fa6f5 (77 verified), raw15af60ae3ab25f255f07055ceec05191c6075b7bccc66e918b831659fa005701. These are root supplied references, not cloud-recovered raw Mac bytes. Original cloud a1a4 archive4897c923f8d7a5d0c17c472c2e43165f6cb81dc399dfff4711209980a781e4ae remains immutable at evidence ref1e8d195b/evidence/launch-2807/a1a4-compiled. Preserve original interpreted timeout, diagnostic compiled result and later merger prospective history independently.

NEXT
Root serial Mac ONLY: exact67 then production compiled absent snapshot/quit/force using pinned supplied smoke. AppKit running fixture1–4 still UNEXECUTED/separate review. No running Hex/real process control, actual installation/delivery or full native qualification. Sole merger owns review/prospective full localCI/integration/merge; Pulse InProgress until actual merge. New native result gets THIS exact source identity; do not relabel old failures.
''')
# Corrected final structured report is authoritative; preserve earlier reporting output.
(out/'verification-summary.log').rename(out/'pre-normalization-report.log')
(out/'verification-summary.log').write_text((out/'checks.json').read_text())
source=out/'source';source.mkdir()
for name in ['scripts/tests/test_launch_restart_compile.py','scripts/launch-restart.py','scripts/launch-restart.swift']:
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
(out/'source-identity.json').write_text(json.dumps({'head':head,'tree':tree,'parent':'a1a4391e9f5e502a22716423c5bd122a5c9f2290','status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)},indent=2)+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='PAYLOADS.json')
rows=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(out/'PAYLOADS.json').write_text(json.dumps({'source':head,'tree':tree,'files':rows},indent=2)+'\n')
archive=Path('/dev/shm/hex-2807-fixture-be596d5d.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in files+[out/'PAYLOADS.json']:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members)
 manifest=json.load(tar.extractfile('PAYLOADS.json'))
 for row in manifest['files']:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloads':len(rows),'manifest_sha256':hashlib.sha256((out/'PAYLOADS.json').read_bytes()).hexdigest()},indent=2))
