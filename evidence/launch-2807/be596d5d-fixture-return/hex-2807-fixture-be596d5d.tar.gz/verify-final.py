from pathlib import Path
import ast,hashlib,json,os,platform,subprocess,sys,time
root=Path('/dev/shm/hex-launcher-restart');logs=Path('/dev/shm/hex-413-fixture-return');rows=[]
for test,count in [('test_launch_restart_compile.py',22),('test_launch_restart.py',20),('test_launch.py',25)]:
 argv=[sys.executable,'-m','unittest','discover','-s','scripts/tests','-p',test,'-v'];out=logs/(test+'.log');start=time.monotonic()
 with out.open('xb') as stream:r=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 text=out.read_text();assert r.returncode==0 and f'Ran {count} tests' in text and '\nOK\n' in text and 'skipped=' not in text,(test,r.returncode)
 rows.append(dict(argv=argv,exit=r.returncode,tests=count,skipped=0,elapsed=time.monotonic()-start,log=out.name,sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
for guard in ['architecture','gpui-patch','dependency-patches','ui-style','device-layout']:
 argv=[sys.executable,'scripts/check-'+guard+'.py'];out=logs/('guard-'+guard+'.log')
 with out.open('xb') as stream:r=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 assert r.returncode==0,(guard,r.returncode)
 rows.append(dict(argv=argv,exit=0,log=out.name,sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
for name in ['scripts/launch-restart.py','scripts/tests/test_launch_restart_compile.py','scripts/tests/test_launch_restart.py','scripts/tests/test_launch.py','launch']:
 ast.parse((root/name).read_text(),filename=name,feature_version=(3,9))
 subprocess.run([sys.executable,'-m','py_compile',name],cwd=root,check=True)
rows.append(dict(python39_grammar='PASS (grammar only, not actual3.9 execution)',current_python_compile='PASS'))
subprocess.run(['git','diff','--check'],cwd=root,check=True)
report=dict(host=platform.platform(),python=sys.version,executable=sys.executable,total_unique_tests=67,failed=0,skipped=0,checks=rows)
(logs/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
