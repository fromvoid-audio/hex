#!/usr/bin/env python3
"""Build, verify and safely activate the configured optimized native test app."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import errno
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import signal
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
IDENTITY = "org.portalsurfer.hex.dev"
SPEC = importlib.util.spec_from_file_location("hex_local_ci", ROOT / "scripts/local-ci.py")
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("local CI module unavailable")
ci = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = ci
SPEC.loader.exec_module(ci)


class DeliveryError(Exception):
    """Fail closed without changing projects, preferences or unrelated apps."""


def run(argv: list[str], root: Path = ROOT) -> str:
    return subprocess.run(argv, cwd=root, check=True, capture_output=True, text=True).stdout.strip()


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


@contextmanager
def optimized_artifact(runner, *, package: str = "hex-desktop", adopt: bool = False,
                       expected_owner_sha256: str | None = None):
    """Build/identify only; shared by delivery and nonactivating review staging.

    The target lock spans compilation, source validation and the caller's copy.
    This helper never installs, activates or launches an application.
    """
    recovery = {"adopt": adopt}
    if expected_owner_sha256 is not None:
        recovery["expected_owner_sha256"] = expected_owner_sha256
    with runner.guarded_release(**recovery) as ownership:
        argv = ["cargo", "build", "--release", "-p", package, "--locked", "--message-format=json"]
        log_path = runner.output_dir / "optimized-build.log"
        with log_path.open("w") as log, \
                ci.terminal_progress("building optimized hex"):
            process = subprocess.run(argv, cwd=runner.root, env=runner.env,
                                     stdout=subprocess.PIPE, stderr=log, text=True, check=False)
            log.write(process.stdout)
        ownership.update(build_argv=argv, build_exit_code=process.returncode, build_log=str(log_path))
        if process.returncode != 0:
            raise DeliveryError(f"optimized build failed; retained log: {log_path}")
        events = [json.loads(line) for line in process.stdout.splitlines() if line.startswith("{")]
        binaries = [Path(event["executable"]) for event in events
                    if event.get("reason") == "compiler-artifact" and event.get("executable")
                    and event.get("target", {}).get("name") == package
                    and event.get("profile", {}).get("opt_level") == "3"]
        if len(binaries) != 1:
            raise DeliveryError("no unique optimized artifact from Cargo")
        ownership["artifact"] = runner.identify_release_artifact(binaries[0], argv)
        if (not runner._capture_repository_state("release_artifact_tree")
                or runner.summary["release_artifact_tree"] != runner.summary["start_tree"]):
            raise DeliveryError("source changed during optimized compilation")
        yield binaries[0], ownership


def write_json(path: Path, value: object) -> None:
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w") as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    temporary.replace(path)
    sync_directory(path.parent)


def sync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def assert_plain_path(path: Path) -> None:
    for component in (path, *path.parents):
        if component.is_symlink():
            raise DeliveryError(f"refusing symlink in application path: {component}")


def assert_identity(app: Path) -> None:
    assert_plain_path(app)
    with (app / "Contents/Info.plist").open("rb") as source:
        info = plistlib.load(source)
    if info.get("CFBundleIdentifier") != IDENTITY or info.get("CFBundleExecutable") != "hex":
        raise DeliveryError(f"refusing unrelated application: {app}")
    if not (app / "Contents/MacOS/hex").is_file():
        raise DeliveryError(f"missing development executable: {app}")


def assert_inactive(app: Path) -> None:
    prefix = str(app.absolute()).casefold() + "/"
    for line in run(["ps", "-ww", "-axo", "pid=,comm="]).splitlines():
        fields = line.strip().split(None, 1)
        if len(fields) == 2 and str(Path(fields[1]).absolute()).casefold().startswith(prefix):
            raise DeliveryError(f"hex is running (pid {fields[0]}); save, quit and retry. "
                                "no application was force-quit; disk replacement cannot reload a process")


def inventory(app: Path, *, signed_payload: bool = False, include_receipt: bool = False) -> dict[str, str]:
    result = {}
    for path in sorted(app.rglob("*")):
        if path.is_symlink():
            raise DeliveryError(f"symlink in staged app: {path}")
        relative = path.relative_to(app).as_posix()
        if not include_receipt and relative == "Contents/Resources/test-build.json":
            continue
        # Signing changes native code and creates the resource seal. The seal
        # itself authenticates those files and the pre-signing bundled receipt.
        if signed_payload and (relative == "Contents/MacOS/hex" or relative.startswith("Contents/_CodeSignature/")):
            continue
        if path.is_file():
            result[relative] = sha(path)
    return result


def signing_configuration(configuration: dict) -> dict[str, str]:
    signing = configuration.get("signing")
    if (not isinstance(signing, dict) or set(signing) != {"certificate_sha1", "team_identifier"}
            or not isinstance(signing.get("certificate_sha1"), str)
            or re.fullmatch(r"[0-9A-F]{40}", signing["certificate_sha1"]) is None
            or not isinstance(signing.get("team_identifier"), str)
            or re.fullmatch(r"[A-Z0-9]{10}", signing["team_identifier"]) is None):
        raise DeliveryError("configure an explicit Developer ID certificate SHA1 and team in scripts/hex-test-build.json")
    return dict(signing)


def native_signature(binary: Path) -> dict[str, str | None]:
    result = subprocess.run(["codesign", "--display", "--verbose=4", "--requirements", "-", str(binary)],
                            check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    lines = result.stdout.splitlines()
    fields = dict(line.split("=", 1) for line in lines if "=" in line and not line.startswith("designated =>"))
    return {"identifier": fields.get("Identifier"), "team_identifier": fields.get("TeamIdentifier"),
            "designated_requirement": next((line for line in lines if line.startswith("designated =>")), None)}


def verify_signed_bundle(app: Path, signing: dict[str, str], actual: dict) -> None:
    signing = signing_configuration({"signing": signing})
    requirement = (f'identifier "{IDENTITY}" and anchor apple generic and '
                   f'certificate leaf[subject.OU] = "{signing["team_identifier"]}" and '
                   'certificate leaf[field.1.2.840.113635.100.6.1.13] exists and '
                   f'certificate leaf = H"{signing["certificate_sha1"]}"')
    run(["codesign", "--verify", "--strict", "--test-requirement", "=" + requirement, str(app)])
    designated = actual.get("designated_requirement") or ""
    if (actual.get("identifier") != IDENTITY or actual.get("team_identifier") != signing["team_identifier"]
            or "cdhash" in designated.lower() or f'identifier "{IDENTITY}"' not in designated
            or signing["team_identifier"] not in designated):
        raise DeliveryError("signed app has no stable configured identifier/team designated requirement")


def sign_bundle(app: Path, signing: dict[str, str]) -> None:
    # No identity search or ad-hoc fallback: keychain/signing failures abort
    # before publication. Local test signing does not request notarization.
    run(["codesign", "--force", "--sign", signing["certificate_sha1"], "--identifier", IDENTITY,
         "--timestamp=none", str(app)])


def verify_native_executable(binary: Path) -> None:
    # Covers legacy linker-signed code and the input/output native executable;
    # schema-2 verification additionally requires the full signed bundle seal.
    run(["codesign", "--verify", "--strict", "--ignore-resources", str(binary)])


def verify(app: Path) -> dict:
    assert_identity(app)
    receipt = json.loads((app / "Contents/Resources/test-build.json").read_text())
    actual = native_signature(app / "Contents/MacOS/hex")
    signed = actual.get("team_identifier") not in (None, "not set")
    if receipt.get("schema") == 2:
        configured = signing_configuration(json.loads((ROOT / "scripts/hex-test-build.json").read_text()))
        if receipt.get("signing") != configured:
            raise DeliveryError("signed receipt does not match the configured certificate/team")
        verify_signed_bundle(app, configured, actual)
    elif signed:
        raise DeliveryError("signed app requires a sealed schema-2 receipt; refusing legacy verification")
    if receipt.get("files") != inventory(app, signed_payload=receipt.get("schema") == 2):
        raise DeliveryError(f"artifact checksum mismatch: {app}")
    if not os.access(app / "Contents/MacOS/hex", os.X_OK):
        raise DeliveryError("packaged binary is not executable")
    verify_native_executable(app / "Contents/MacOS/hex")
    return receipt


@contextmanager
def activation_lock(app: Path):
    lock_path = app.parent / ".hex-test-build.lock"
    assert_plain_path(lock_path)
    with lock_path.open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise DeliveryError("another test-build activation owns this location") from error
        yield


def install_workspace(app: Path) -> Path:
    return app.parent / ".hex-install"


def check_install_workspace(workspace: Path, *, apps: bool = True) -> None:
    """Allow only fixed installer members and Finder's regular metadata file."""
    assert_plain_path(workspace)
    if not workspace.is_dir():
        raise DeliveryError("unexpected temporary installation contents; preserved for inspection")
    for path in workspace.iterdir():
        if apps and path.name in ("stage.app", "previous.app"):
            assert_plain_path(path)
        elif path.name == ".DS_Store" and stat.S_ISREG(path.lstat().st_mode):
            continue
        else:
            raise DeliveryError("unexpected temporary installation contents; preserved for inspection")


def remove_install_workspace(workspace: Path) -> None:
    # Never recursively remove this directory: it can acquire Finder metadata
    # after publication. Inspect every member before unlinking that one file.
    for attempt in range(2):
        check_install_workspace(workspace, apps=False)
        metadata = workspace / ".DS_Store"
        if metadata.exists():
            metadata.unlink()
        try:
            workspace.rmdir()
            break
        except OSError as error:
            if error.errno != errno.ENOTEMPTY:
                raise
            # Finder can recreate metadata immediately before rmdir. Reinspect
            # every member, refuse foreign data, and retry only once. Continued
            # interference remains an honest incomplete installation.
            check_install_workspace(workspace, apps=False)
            if attempt == 1:
                raise
    sync_directory(workspace.parent)


def recover(app: Path) -> None:
    # Older installers own this history. Never guess which app their journal owns.
    legacy = app.parent / ".hex-test-build-transaction.json"
    if os.path.lexists(legacy):
        raise DeliveryError("legacy installation journal requires inspection; preserved unchanged")
    workspace = install_workspace(app)
    assert_plain_path(workspace)
    if not workspace.exists():
        return
    check_install_workspace(workspace)
    stage, previous = workspace / "stage.app", workspace / "previous.app"
    for path in (app, stage, previous):
        assert_plain_path(path)
        assert_inactive(path)
    if previous.exists():
        if app.exists():
            if stage.exists():
                raise DeliveryError("ambiguous interrupted installation; temporary apps preserved")
            try:
                verify(app)
            except (DeliveryError, OSError, ValueError, subprocess.CalledProcessError):
                assert_identity(previous)
                app.rename(stage)
                previous.rename(app)
                sync_directory(workspace)
                sync_directory(app.parent)
        else:
            assert_identity(previous)
            previous.rename(app)
            sync_directory(workspace)
            sync_directory(app.parent)
    elif app.exists():
        # A partial stage never displaced this existing app. After publication,
        # stage is absent and only a verified new bundle permits cleanup.
        if stage.exists():
            assert_identity(app)
        else:
            verify(app)
    # Only these fixed temporary paths belong to this installer. Historical
    # review/rollback apps and legacy journals are never collected.
    for path in (stage, previous):
        if path.exists():
            shutil.rmtree(path)
    remove_install_workspace(workspace)


def activate(app: Path, stage: Path) -> None:
    workspace = install_workspace(app)
    if stage != workspace / "stage.app":
        raise DeliveryError("candidate must use the fixed temporary installation workspace")
    previous = workspace / "previous.app"
    assert_plain_path(workspace)
    check_install_workspace(workspace)
    assert_plain_path(previous)
    assert_plain_path(app)
    if previous.exists():
        raise DeliveryError("unfinished installation; retry before publishing another candidate")
    verify(stage)
    for path in stage.rglob("*"):
        if path.is_file():
            with path.open("rb") as source:
                os.fsync(source.fileno())
    for path in sorted((p for p in stage.rglob("*") if p.is_dir()), reverse=True):
        sync_directory(path)
    sync_directory(stage)
    sync_directory(workspace)
    sync_directory(app.parent)
    assert_inactive(app)
    if app.exists():
        assert_identity(app)
    try:
        # Recheck immediately before publication; never terminate a process.
        assert_inactive(app)
        if app.exists():
            app.rename(previous)
            sync_directory(workspace)
            sync_directory(app.parent)
        stage.rename(app)
        sync_directory(workspace)
        sync_directory(app.parent)
        verify(app)
    except (OSError, DeliveryError, ValueError, subprocess.CalledProcessError):
        if previous.exists():
            assert_inactive(app)
            assert_inactive(previous)
            if app.exists():
                app.rename(stage)
            previous.rename(app)
            sync_directory(workspace)
            sync_directory(app.parent)
        raise
    # previous.app is publication custody only, never a retained version backup.
    check_install_workspace(workspace)
    if previous.exists():
        shutil.rmtree(previous)
    remove_install_workspace(workspace)


def validate_ci(report: Path, runner, candidate: str) -> dict:
    evidence = json.loads(report.read_text())
    if not runner._capture_repository_state("start_tree"):
        raise DeliveryError("cannot identify current source")
    current = runner.summary["start_tree"]
    expected_steps = [(step.step_id, list(step.argv)) for step in ci.FULL_STEPS]
    actual_steps = [(step.get("step_id"), step.get("argv")) for step in evidence.get("steps", [])]
    if (evidence.get("mode") != "full" or evidence.get("status") != "passed"
            or evidence.get("stale") is not False or evidence.get("exit_code") != 0
            or actual_steps != expected_steps
            or any(step.get("status") != "passed" for step in evidence["steps"])
            or evidence.get("start_tree") != evidence.get("end_tree")
            or current["dirty"] or evidence.get("dirty") is not False
            or evidence.get("commit") != candidate
            or evidence["start_tree"].get("content_sha256") != current["content_sha256"]):
        raise DeliveryError("full exact-source local CI evidence is missing, failed, dirty or stale")
    head = current["commit"]
    if head != candidate:
        # A merge commit is eligible only with identical complete Git tree and ancestry.
        if run(["git", "rev-parse", f"{head}^{{tree}}"], runner.root) != run(
                ["git", "rev-parse", f"{candidate}^{{tree}}"], runner.root):
            raise DeliveryError("merged source differs from locally verified candidate")
        run(["git", "merge-base", "--is-ancestor", candidate, head], runner.root)
    return evidence


def validate_source(runner, candidate: str, expected: dict | None = None) -> dict:
    """Freeze clean exact source for build-only launch; this is not CI evidence."""
    if not runner._capture_repository_state("start_tree"):
        raise DeliveryError("cannot identify current source")
    current = runner.summary["start_tree"]
    if (len(candidate) != 40 or any(char not in "0123456789abcdef" for char in candidate)
            or current["dirty"] or current["commit"] != candidate
            or (expected is not None and current != expected)):
        raise DeliveryError("build-only source is dirty, changed or differs from the exact candidate")
    return dict(current)


def build(args) -> dict:
    if sys.platform != "darwin":
        raise DeliveryError("native test delivery requires macOS")
    common = Path(run(["git", "rev-parse", "--git-common-dir"]))
    if not common.is_absolute():
        common = ROOT / common
    configuration = json.loads((ROOT / "scripts/hex-test-build.json").read_text())
    signing = signing_configuration(configuration)
    configured = Path(os.environ.get("HEX_DEV_APP_PATH", configuration["app_path"]))
    app = configured if configured.is_absolute() else common.resolve().parent / configured
    app = app.absolute()
    if app.name.casefold() != "hex.app":
        raise DeliveryError("stable development target must be named hex.app")
    assert_plain_path(app)
    app.parent.mkdir(parents=True, exist_ok=True)
    with activation_lock(app):
        recover(app)
        assert_inactive(app)
        if app.exists():
            assert_identity(app)
        runner = ci.LocalCiRunner(ROOT, adopt_target=False)
        build_only = getattr(args, "build_only", False)
        source_evidence = validate_source(runner, args.candidate) if build_only else None

        def revalidate() -> None:
            if build_only:
                validate_source(runner, args.candidate, expected=source_evidence)
            else:
                validate_ci(args.ci_report, runner, args.candidate)

        revalidate()
        included = json.loads(args.included.read_text())
        if not isinstance(included, list) or not included:
            raise DeliveryError("include PR head revisions")
        for item in included:
            if (not isinstance(item, dict) or not isinstance(item.get("pr"), str)
                    or not item["pr"].startswith("https://github.com/PORTALSURFER/hex/pull/")
                    or not isinstance(item.get("head"), str) or len(item["head"]) != 40
                    or any(char not in "0123456789abcdef" for char in item["head"])):
                raise DeliveryError("invalid included PR revision")
        checklist = args.checklist.read_text()
        if not checklist.strip():
            raise DeliveryError("finite user checklist required")
        runner.output_dir.mkdir(parents=True)
        if not runner._resolve_cargo_identity() or not runner._check_disk_headroom():
            raise DeliveryError(str(runner.summary))
        with optimized_artifact(runner, adopt=getattr(args, "adopt_release_target", False),
                                expected_owner_sha256=getattr(args, "expected_release_owner_sha256", None)) as (binary, release_ownership):
            metadata = json.loads(run(["cargo", "metadata", "--no-deps", "--format-version", "1", "--locked"]))
            version = next(package["version"] for package in metadata["packages"] if package["name"] == "hex-desktop")
            argv = release_ownership["build_argv"]
            revalidate()
            workspace = install_workspace(app)
            workspace.mkdir()
            stage = workspace / "stage.app"
            stage.mkdir()
            contents = stage / "Contents"
            (contents / "MacOS").mkdir(parents=True)
            (contents / "Resources/licenses").mkdir(parents=True)
            shutil.copy2(binary, contents / "MacOS/hex")
            for source, name in ((ROOT / "assets/fonts/ioskeley-mono/OFL.txt", "ioskeley-mono-OFL.txt"),
                                 (ROOT / "third_party/gpui/LICENSE-APACHE", "gpui-LICENSE-APACHE")):
                shutil.copy2(source, contents / "Resources/licenses" / name)
            source = runner.summary["start_tree"]["commit"]
            info = {"CFBundleExecutable": "hex", "CFBundleIdentifier": IDENTITY,
                    "CFBundleName": "hex", "CFBundleDisplayName": "hex", "CFBundlePackageType": "APPL",
                    "CFBundleShortVersionString": version, "CFBundleVersion": str(int(source[:8], 16)),
                    "NSHighResolutionCapable": True, "HexSourceRevision": source}
            with (contents / "Info.plist").open("wb") as output:
                plistlib.dump(info, output)
            (contents / "Resources/USER-TEST.md").write_text(checklist)
            if build_only:
                write_json(contents / "Resources/source-verification.json", {
                    "mode": "source-only", "tests": "not_run", "source": source_evidence,
                })
            else:
                shutil.copy2(args.ci_report, contents / "Resources/local-ci-summary.json")
            verify_native_executable(contents / "MacOS/hex")
            receipt = {"schema": 2, "version": version, "source": source, "candidate": args.candidate,
                       "source_sha256": runner.summary["start_tree"]["content_sha256"],
                       "profile": "release", "build_argv": argv, "target_directory": str(runner.cargo_identity["target_directory"]),
                       "release_target_ownership": {key: release_ownership[key] for key in
                           ("profile", "source", "packages", "target_directory", "owner_path",
                            "lock_path", "action", "cleanup_status", "artifact")},
                       "ci_report": None if build_only else str(args.ci_report.resolve()),
                       "ci_report_sha256": None if build_only else sha(args.ci_report),
                       "verification": {"mode": "source-only" if build_only else "full-ci",
                                        "tests": "not_run" if build_only else "passed"},
                       "included": included, "app_path": str(app), "created_at": ci.utc_now(),
                       "activation": "installed on disk; launch or relaunch required; not launched by delivery",
                       "signature": "Developer ID sealed local test bundle; not notarized",
                       "signing": signing,
                       "input_executable_sha256": sha(contents / "MacOS/hex"),
                       "files": inventory(stage, signed_payload=True)}
            write_json(contents / "Resources/test-build.json", receipt)
            sign_bundle(stage, signing)
            verify(stage)
            verify_native_executable(contents / "MacOS/hex")
            revalidate()
            activate(app, stage)
            verify_native_executable(app / "Contents/MacOS/hex")
            receipt = {**receipt, "artifact_files": inventory(app, include_receipt=True),
                       "native_signature": native_signature(app / "Contents/MacOS/hex")}
            write_json(app.parent / "hex-test-build-receipt.json", receipt)
            return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    verification = parser.add_mutually_exclusive_group(required=True)
    verification.add_argument("--ci-report", type=Path, help="full exact-source local CI report")
    verification.add_argument("--build-only", action="store_true",
                              help="verify clean exact source and build without running or requiring tests")
    parser.add_argument("--candidate", required=True, help="full exact candidate commit")
    parser.add_argument("--included", type=Path, required=True, help="JSON list of pr/head objects (ticket references optional)")
    parser.add_argument("--checklist", type=Path, required=True)
    parser.add_argument("--adopt-release-target", action="store_true",
                        help="explicitly recover unknown/pending release ownership; selectively clean workspace release artifacts")
    parser.add_argument("--expected-release-owner-sha256",
                        help="require this exact previously inspected owner under the release mutation lock")
    args = parser.parse_args()
    if args.expected_release_owner_sha256 and not args.adopt_release_target:
        parser.error("--expected-release-owner-sha256 requires --adopt-release-target")
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    try:
        receipt = build(args)
        print(json.dumps(receipt, indent=2, sort_keys=True))
        return 0
    except (DeliveryError, ci.TargetCacheError, ci.InterruptedRun, OSError, ValueError,
            KeyError, TypeError, StopIteration, subprocess.CalledProcessError, KeyboardInterrupt) as error:
        print(f"test installation incomplete: {error}; temporary publication files preserved for retry. "
              "inspect the reported process/ownership refusal before retrying; no process was terminated", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
