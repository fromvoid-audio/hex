from pathlib import Path
import importlib.util,sys,unittest
root=Path('/dev/shm/hex-launcher-restart')
sys.path.insert(0,str(root/'scripts/tests'))
import test_launch_restart_compile as tests
path=Path(__file__).parent/'baseline-launch-restart.py'
spec=importlib.util.spec_from_file_location('hex_restart_baseline_red',path)
baseline=importlib.util.module_from_spec(spec);sys.modules[spec.name]=baseline;spec.loader.exec_module(baseline)
tests.restart=baseline
suite=unittest.TestSuite([tests.CompiledHelperTests('test_native_calls_compile_once_instead_of_starting_interpreter_per_call')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
