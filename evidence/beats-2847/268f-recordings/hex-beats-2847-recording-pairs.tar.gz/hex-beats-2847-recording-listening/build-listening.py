import pathlib,struct,wave,math,json,hashlib,shutil,tarfile
root=pathlib.Path('/dev/shm/hex-beats-2847-recording-listening');root.mkdir()
def values(p):
 b=p.read_bytes();return [x[0] for x in struct.iter_unpack('<f',b)]
def stats(v):
 return dict(peak=max(map(abs,v)),rms=math.sqrt(sum(x*x for x in v)/len(v)),max_step=max(abs(v[i]-v[i-2]) for i in range(2,len(v))))
def wav(p,v,gain):
 assert not p.exists()
 with wave.open(str(p),'wb') as w:
  w.setnchannels(2);w.setsampwidth(3);w.setframerate(44100)
  w.writeframes(b''.join(round(max(-1,min(1,x*gain))*8388607).to_bytes(3,'little',signed=True) for x in v))
rows=[]
for fixture,original in [('snare','snare1_f_1'),('pluck','BKCtbss_Pizz_A1_v1_rr1')]:
 v=values(pathlib.Path('/dev/shm/hex-beats-2847-recording-inputs')/(original+'.f32'))
 wav(root/(fixture+'-original-fixed.wav'),v,1)
 for p in sorted(pathlib.Path('/dev/shm/hex-beats-2847-recording-'+fixture+'-before').glob('*.f32')):
  q=pathlib.Path('/dev/shm/hex-beats-2847-recording-'+fixture+'-after')/p.name
  before,after=values(p),values(q);bs,as_=stats(before),stats(after)
  assert len(before)==len(after)
  target=min(.05,.8*bs['rms']/max(bs['peak'],1e-20),.8*as_['rms']/max(as_['peak'],1e-20))
  row=dict(fixture=fixture,case=p.stem,before=bs,after=as_,levelmatched_target_rms=target,gain_before=target/bs['rms'],gain_after=target/as_['rms'])
  rows.append(row)
  for label,v,g in [('before',before,row['gain_before']),('after',after,row['gain_after'])]:
   wav(root/(fixture+'-'+p.stem+'-'+label+'-fixed.wav'),v,1)
   wav(root/(fixture+'-'+p.stem+'-'+label+'-matched.wav'),v,g)
 for stage in ['before','after']:
  source=pathlib.Path('/dev/shm/hex-beats-2847-recording-'+fixture+'-'+stage)
  shutil.copy2(source/'metrics.csv',root/(fixture+'-'+stage+'-renderer-metrics.csv'))
  shutil.copy2(source/'settings.txt',root/(fixture+'-'+stage+'-settings.txt'))
(root/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'LISTENING.txt').write_text('NOT LISTENED TO. No Ableton reference. These are original one-shot recordings, not publisher BPM loops. Compare fixed-gain files FIRST at the same playback gain; compare additional whole-file RMS-matched pairs separately (exact gains and original peak/RMS in comparison.json). PCM24 quantisation, no limiter; matched targets bounded against original peak. Inspect attacks, bass pitch/colour, sustain pumping/stutter, new noise, stereo image and end/joins; Stop intentional gaps must not be mistaken for a Forward failure. Include source onset neighbourhoods. Match ratio/tail. Do not infer quality from peak/step/RMS alone.\nBeforeDSP9c1a70a05d43d7d25db3ae7ca96a9429ebde403a plus ONLY identical adapter. After268fb22b2030023616288894b6a68e3c6fab99bd/version9. Adapter SHA54fc5e12ac1518f8353abf0eb8fe759d09d8040c4f6f30cdd0134ea224c0af64. No production cache/owner change. Fixed Preserve timing contract remains open, these use default Transients.\n')
print('pairs',len(rows),'WAVs',len(list(root.glob('*.wav'))))
