from pathlib import Path
from urllib.request import urlopen,Request
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor
import hashlib,struct,json
root=Path('/dev/shm/hex-beats-2847-vsco-corpus');root.mkdir()
pin='440300901dfe9275fd84e0b7763af1f8443ae62e';base='https://raw.githubusercontent.com/sgossner/VSCO-2-CE/'+pin+'/'
rows=[
 ('Strings/Solo Contrabass/SusNV/BKCtbss_SusNV_A1_v1_rr1.wav',1249496,'1bffe0476c289a25c3404d023a37e26d473dee48'),
 ('Strings/Solo Contrabass/Pizz/BKCtbss_Pizz_A1_v1_rr1.wav',623260,'311a5027a127715530f1e723a21f7927d280d493'),
 ('Strings/Cello Section/trem/trem_B2_v2_1.wav',1816706,'8ba6739037b2536455aa1e4209ced38c5fe12f09'),
 ('Percussion/Timpani/Rolls/Timpani5_Roll_v4_rr1_Sum.wav',2967320,'6edd78469dbff041770d9701a77196dd497218e9'),
 ('VSCO 1 Percussion/drums/snare/drum1/snare1_f_1.wav',193630,'0150e2c94ad1c83b071944e3cfb286752546c894'),
 ('VSCO 1 Percussion/varMetal/Cymbals/susp/susp_FX_scrape_rapid.wav',1300906,'c30706a1e4abb4124aa016c6b82658e5ff346463')]
texts=[('README.md','8fbf399338661e6c76585ad9e75eb10324f823935168e0567553293a83f200a0'),('Readme.txt','101ddb88eb013900cc911834ecbdfbd49497bcd913bf09417160b9677952bb38'),('LICENSE','36ffd9dc085d529a7e60e1276d73ae5a030b020313e6c5408593a6ae2af39673')]
def fetch(path,maximum,exact=None):
 url=base+quote(path,safe='/')
 with urlopen(Request(url,headers={'User-Agent':'hex-source4-authorized-test-corpus/1'}),timeout=40) as f:
  assert f.geturl()==url,'unexpected redirect'
  data=f.read(maximum+1)
  assert len(data)<=maximum,'declared download bound exceeded'
  if exact is not None:assert len(data)==exact,'declared size mismatch'
 return url,data
rights=[]
for name,expected in texts:
 url,data=fetch(name,131072)
 sha=hashlib.sha256(data).hexdigest();assert sha==expected,(name,sha)
 with (root/name).open('xb') as f:f.write(data)
 rights.append({'path':name,'url':url,'bytes':len(data),'sha256':sha})
def intake(row):
 path,size,blob=row;url,data=fetch(path,size,size)
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==blob,(path,actual)
 assert data[:4]==b'RIFF' and data[8:12]==b'WAVE','not RIFF/WAVE'
 fmt=None;pcm=None;at=12
 while at+8<=len(data):
  tag=data[at:at+4];n=struct.unpack_from('<I',data,at+4)[0];chunk=data[at+8:at+8+n];assert len(chunk)==n
  if tag==b'fmt ':fmt=struct.unpack_from('<HHIIHH',chunk)
  if tag==b'data':pcm=n
  at+=8+n+(n&1)
 assert fmt and pcm is not None
 kind,channels,rate,byte_rate,align,bits=fmt
 assert align>0 and pcm%align==0
 target=root/Path(path).name
 with target.open('xb') as f:f.write(data)
 return {'publisher_path':path,'path':target.name,'url':url,'bytes':size,'git_blob':actual,'sha256':hashlib.sha256(data).hexdigest(),'wav_format_code':kind,'channels':channels,'sample_rate':rate,'bits_per_sample':bits,'block_align':align,'frames':pcm//align,'duration_seconds':pcm/align/rate,'original_bpm':None,'content_or_pitch_label':'publisher filename only, not listening verified'}
with ThreadPoolExecutor(max_workers=3) as pool:audio=list(pool.map(intake,rows))
manifest={'publisher':'VSCO 2 Community Edition — Versilian Studios / Sam Gossner; Ivy Audio / Simon Dalzell; sample cutting Elan Hickler/Soundemote','publisher_homepage':'http://vis.versilstudios.net/vsco-community.html','repository':'https://github.com/sgossner/VSCO-2-CE','source_commit':pin,'rights':'CC0 1.0 Universal. Retain accompanying publisher requests/credits; no direct sample sale. Test/evidence intake only; not production library.','listening':'not performed; no sonic quality, commercial comparison, or original BPM claim','rights_files':rights,'audio':audio}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
