import wave,struct,math,json,pathlib
rows=[]
for folder in ['hex-beats-2847-original-auto','hex-beats-2847-wsola-auto']:
 d=pathlib.Path('/dev/shm')/folder
 for rate in [44100,48000]:
  for ratio in [0.5,1.375,2.0]:
   p=d/f'bass55-{rate}-ratio{ratio:g}-forward.wav'
   with wave.open(str(p)) as f:
    vals=struct.unpack('<'+'h'*(f.getnframes()*2),f.readframes(f.getnframes()))
   x=[v/32767 for v in vals[::2]];x=x[rate//20:-rate//20]
   n=len(x);mean=sum(x)/n
   s=[math.sin(2*math.pi*55*i/rate) for i in range(n)];c=[math.cos(2*math.pi*55*i/rate) for i in range(n)]
   sm=sum(s);cm=sum(c);ss=sum(v*v for v in s)-sm*sm/n;cc=sum(v*v for v in c)-cm*cm/n;sc=sum(a*b for a,b in zip(s,c))-sm*cm/n
   xs=sum(a*b for a,b in zip(x,s))-mean*sm;xc=sum(a*b for a,b in zip(x,c))-mean*cm
   a=(xs*cc-xc*sc)/(ss*cc-sc*sc);b=(xc*ss-xs*sc)/(ss*cc-sc*sc)
   residual=math.sqrt(sum((v-mean-a*si-b*co)**2 for v,si,co in zip(x,s,c))/n)
   win=round(rate*4/55);energy=[math.sqrt(sum(v*v for v in x[i:i+win])/win) for i in range(0,n-win,win//2)]
   rows.append(dict(renderer=folder,rate=rate,ratio=ratio,phase_independent_55hz_residual=residual,rms=math.sqrt(sum(v*v for v in x)/n),four_cycle_rms_ratio=max(energy)/min(energy),max_adjacent_step=max(abs(a-b) for a,b in zip(x,x[1:]))))
print(json.dumps(rows,indent=2))
pathlib.Path('/dev/shm/hex-beats-2847-wsola-auto/bass-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
