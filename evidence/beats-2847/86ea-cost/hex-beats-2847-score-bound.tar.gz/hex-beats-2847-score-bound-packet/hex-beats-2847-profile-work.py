import pathlib,subprocess,os
root=pathlib.Path('/dev/shm/hex-beats-declick')
p=root/'crates/hex-warp/src/beats/synthesis.rs';q=root/'crates/hex-warp/src/beats.rs'
original={p:p.read_bytes(),q:q.read_bytes()}
try:
 s=original[p].decode().replace('        let points = hop.clamp(1, 64);','        let search_before = work.used;\n        let points = hop.clamp(1, 64);')
 s=s.replace('        work.check(grain as u64 * 64)?;','        let search_units = work.used - search_before;\n        eprintln!("PROFILE grain out={} hop={} length={} search={} reconstruction={} total_before={}", out, hop, grain, search_units, grain as u64 * 64, work.used);\n        work.check(grain as u64 * 64)?;')
 p.write_text(s)
 s=original[q].decode().replace('    let bank = Bandlimited::new(pitch, work)?;','    let bank = Bandlimited::new(pitch, work)?;\n    eprintln!("PROFILE analysis_plan_bank={}", work.used);')
 q.write_text(s)
 patch=subprocess.check_output(['git','diff','--','crates/hex-warp/src/beats/synthesis.rs','crates/hex-warp/src/beats.rs'],cwd=root)
 pathlib.Path('/dev/shm/hex-beats-2847-profile-work.patch').write_bytes(patch)
 env=os.environ.copy();env.update(CARGO_TARGET_DIR='/dev/shm/hex-beats-declick-target',TMPDIR='/dev/shm',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
 with open('/tmp/hex-beats-2847-profile-work.log','xb') as log:
  result=subprocess.run(['/workspace/.hex-tools/rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/cargo','run','-p','hex-warp','--locked','--example','beats_recording','--','/dev/shm/hex-beats-2847-recording-inputs/Timpani5_Roll_v4_rr1_Sum.f32','44100','/dev/shm/hex-beats-2847-timpani-work-profile','2','forward'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('terminal adapter',result.returncode)
finally:
 for file,content in original.items():file.write_bytes(content)
 print('original 90aa files restored byte-for-byte')
