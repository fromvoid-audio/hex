from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/dev/shm/hex-grid-2694');logs=Path('/dev/shm/hex-grid-2694-mixed-final')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
steps=[('resolver', ['cargo','test','-p','hex-ui','--features','ui-test-support','--lib','editor::musical_time::','--','--nocapture'],29),('menu',['cargo','test','-p','hex-ui','--features','ui-test-support','--lib','context_menu','--','--nocapture'],9),('strict-ui',['cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'],None)]
steps += [(g,['python3','scripts/check-'+g+'.py'],None) for g in ['architecture','gpui-patch','dependency-patches','ui-style','device-layout']]
steps += [('format',['cargo','fmt','--all','--check'],None)]
rows=[]
for name,argv,count in steps:
 start=time.monotonic();out=logs/(name+'.log')
 with out.open('xb') as stream:r=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 text=out.read_text();passed=r.returncode==0
 if count is not None:passed &= f'{count} passed; 0 failed; 0 ignored;' in text
 rows.append(dict(name=name,argv=argv,exit=r.returncode,expected_tests=count,passed=passed,elapsed=time.monotonic()-start,log=out.name,sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
 report=dict(head=head,tree=tree,checks=rows,status='PASS' if all(x['passed'] for x in rows) and len(rows)==len(steps) else 'INCOMPLETE_OR_FAIL',source_unchanged=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)=='')
 (logs/'candidate-checks.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,r.returncode,passed,flush=True)
 if not passed:raise SystemExit(1)
