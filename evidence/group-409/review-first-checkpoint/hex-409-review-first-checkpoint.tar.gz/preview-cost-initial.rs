use std::alloc::{GlobalAlloc,Layout,System};
use std::sync::atomic::{AtomicBool,AtomicU64,Ordering::Relaxed};
use std::time::Instant;
use hex_project::{Project,Editor,Command,ClipGroupPosition};
struct Counter;
static ACTIVE:AtomicBool=AtomicBool::new(false);
static ALLOCS:AtomicU64=AtomicU64::new(0);
static BYTES:AtomicU64=AtomicU64::new(0);
static FREES:AtomicU64=AtomicU64::new(0);
unsafe impl GlobalAlloc for Counter {
 unsafe fn alloc(&self,l:Layout)->*mut u8 { if ACTIVE.load(Relaxed) {ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(l.size() as u64,Relaxed);} unsafe{System.alloc(l)} }
 unsafe fn dealloc(&self,p:*mut u8,l:Layout) {if ACTIVE.load(Relaxed){FREES.fetch_add(1,Relaxed);}unsafe{System.dealloc(p,l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {if ACTIVE.load(Relaxed){ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(n as u64,Relaxed);FREES.fetch_add(1,Relaxed);}unsafe{System.realloc(p,l,n)}}
}
#[global_allocator]static COUNTER:Counter=Counter;
fn main(){
 for (total,selected) in [(128,128),(1024,1024),(16384,128),(16384,16384)] {
  let mut editor=Editor::new(Project::new(48000).unwrap(),4).unwrap();
  editor.execute(Command::ImportAudioTrack{name:"profile".into(),path:"model-only.wav".into(),sample_rate:48000,frames:96000}).unwrap();
  let mut snapshot=editor.project().snapshot();
  let template=snapshot.tracks[0].content.audio_clips_mut().unwrap()[0].clone();
  snapshot.tracks[0].content.audio_clips_mut().unwrap().clear();
  for i in 0..total {
   let mut c=template.clone();c.id=snapshot.next_id;snapshot.next_id+=1;c.start=48000+i as u64*96000;
   snapshot.tracks[0].content.audio_clips_mut().unwrap().push(c);
  }
  let p=Project::from_snapshot(snapshot).unwrap();let track=p.tracks()[0].id();
  let ids:Vec<_>=p.tracks()[0].clips().iter().take(selected).map(|c|c.id()).collect();
  for _ in 0..2 {std::hint::black_box(p.preview_clip_group_move(&ids,ids[0],track,ClipGroupPosition::Audio(50000)).unwrap());}
  ALLOCS.store(0,Relaxed);BYTES.store(0,Relaxed);FREES.store(0,Relaxed);
  let iterations=8;
  let start=Instant::now();ACTIVE.store(true,Relaxed);
  for _ in 0..iterations {let result=p.preview_clip_group_move(&ids,ids[0],track,ClipGroupPosition::Audio(50000)).unwrap();assert_eq!(result.len(),selected);std::hint::black_box(&result);drop(result);}
  ACTIVE.store(false,Relaxed);let elapsed=start.elapsed();
  println!("total={total} selected={selected} iterations={iterations} ns_per_call={} allocs_per_call={} requested_bytes_per_call={} frees_per_call={}",elapsed.as_nanos()/iterations,ALLOCS.load(Relaxed)/iterations as u64,BYTES.load(Relaxed)/iterations as u64,FREES.load(Relaxed)/iterations as u64);
 }
}
