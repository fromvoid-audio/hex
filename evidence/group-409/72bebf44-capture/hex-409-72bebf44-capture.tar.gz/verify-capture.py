from pathlib import Path
import subprocess,time,json,hashlib
root=Path('/dev/shm/hex-group-409');logs=Path('/dev/shm/hex-group-409-review-evidence')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
steps=[('capture-final-project',['cargo','test','-p','hex-project','--locked','--lib','--','--nocapture'],96),('capture-final-group-ui',['cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','group_drag_ui_test','--','--nocapture'],10),('capture-final-single-ui',['cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','--','rendered_audio_clip_drag_starts_previews_and_commits_a_move','option_drag_copies_audio_clip_and_modifier_changes_apply_without_pointer_motion','command_modifier_temporarily_bypasses_beat_anchored_midi_drag_snap','--nocapture'],3),('capture-final-strict',['cargo','clippy','-p','hex-project','-p','hex-ui','--features','ui-test-support','--all-targets','--locked','--','-D','warnings'],None),('capture-doc-privacy',['cargo','test','-p','hex-project','--locked','--doc','ClipGroupMovePreview','--','--nocapture'],3)]
steps += [(g,['python3','scripts/check-'+g+'.py'],None) for g in ['architecture','gpui-patch','dependency-patches','ui-style','device-layout']]
steps += [('format',['cargo','fmt','--all','--check'],None)]
rows=[]
for name,argv,count in steps:
 start=time.monotonic();out=logs/(('capture-' if name in ['architecture','gpui-patch','dependency-patches','ui-style','device-layout','format'] else '')+name+'.log')
 with out.open('xb') as stream:r=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 passed=r.returncode==0
 if count is not None:passed &= f'{count} passed; 0 failed; 0 ignored;' in out.read_text()
 rows.append(dict(name=name,argv=argv,exit=r.returncode,expected_tests=count,passed=passed,seconds=time.monotonic()-start,log=out.name,sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
 (logs/'capture-checks.json').write_text(json.dumps(dict(head=head,tree=tree,steps=rows,status='PASS' if len(rows)==len(steps) and all(r['passed'] for r in rows) else 'INCOMPLETE_OR_FAIL',source_clean=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''),indent=2)+'\n')
 print(name,r.returncode,passed,flush=True)
 if not passed:raise SystemExit(1)
