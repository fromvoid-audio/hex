use std::alloc::{GlobalAlloc,Layout,System};
use std::sync::atomic::{AtomicBool,AtomicU64,Ordering::Relaxed};
use std::time::Instant;
use hex_project::{Project,Editor,Command,ClipGroupPosition};
struct Counter;
static ACTIVE:AtomicBool=AtomicBool::new(false);
static ALLOCS:AtomicU64=AtomicU64::new(0);
static BYTES:AtomicU64=AtomicU64::new(0);
static FREES:AtomicU64=AtomicU64::new(0);
unsafe impl GlobalAlloc for Counter {
 unsafe fn alloc(&self,l:Layout)->*mut u8 { if ACTIVE.load(Relaxed) {ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(l.size() as u64,Relaxed);} unsafe{System.alloc(l)} }
 unsafe fn dealloc(&self,p:*mut u8,l:Layout) {if ACTIVE.load(Relaxed){FREES.fetch_add(1,Relaxed);}unsafe{System.dealloc(p,l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {if ACTIVE.load(Relaxed){ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(n as u64,Relaxed);FREES.fetch_add(1,Relaxed);}unsafe{System.realloc(p,l,n)}}
}
#[global_allocator]static COUNTER:Counter=Counter;
fn main(){
 for (total,selected) in [(128,128),(1024,1024),(16384,128),(16384,16384)] {
  let mut editor=Editor::new(Project::new(48000).unwrap(),4).unwrap();
  editor.execute(Command::ImportAudioTrack{name:"profile".into(),path:"model-only.wav".into(),sample_rate:48000,frames:96000}).unwrap();
  if std::env::args().any(|a|a=="musical") {
   let clip=editor.project().tracks()[0].clips()[0].id();
   let warp=hex_project::default_audio_warp(editor.project().clip(clip).unwrap(),editor.project().tempo_map(),hex_project::WarpMode::RePitch).unwrap();
   editor.execute(Command::SetAudioClipWarp{clip,settings:Some(warp)}).unwrap();
  }
  let mut snapshot=editor.project().snapshot();
  let template=snapshot.tracks[0].audio_clips_mut().unwrap()[0].clone();
  snapshot.tracks[0].audio_clips_mut().unwrap().clear();
  for i in 0..total {
   let mut c=template.clone();c.id=snapshot.next_id;snapshot.next_id+=1;c.start=48000+i as u64*96000; if let Some(edit)=c.edit.as_mut() {edit.musical_start=Some(editor.project().tempo_map().frame_to_beat(c.start).unwrap());}
   snapshot.tracks[0].audio_clips_mut().unwrap().push(c);
  }
  let p=std::sync::Arc::new(Project::from_snapshot(snapshot).unwrap());let track=p.tracks()[0].id();
  let ids:Vec<_>=p.tracks()[0].clips().iter().take(selected).map(|c|c.id()).collect();
  let mut capture=hex_project::ClipGroupMovePreview::capture(&p,&ids,ids[0]).unwrap();
  for _ in 0..2 {capture.update(&p,track,ClipGroupPosition::Audio(50000)).unwrap();}
  ALLOCS.store(0,Relaxed);BYTES.store(0,Relaxed);FREES.store(0,Relaxed);
  let iterations=8;
  let start=Instant::now();ACTIVE.store(true,Relaxed);
  for i in 0..iterations {capture.update(&p,track,ClipGroupPosition::Audio(50000+i as u64*17)).unwrap();assert_eq!(capture.previews().len(),selected);std::hint::black_box(capture.previews());}
  ACTIVE.store(false,Relaxed);let elapsed=start.elapsed();
  assert_eq!(ALLOCS.load(Relaxed),0,"update allocated metadata/backing");assert_eq!(FREES.load(Relaxed),0,"update freed metadata/backing");
  // Measure the renderer's original-waveform lookup component separately.
  let lookup_start=Instant::now();let mut checksum=0u64;
  for _ in 0..iterations {for index in 0..capture.previews().len() {checksum=checksum.wrapping_add(capture.original_audio(&p,index).unwrap().id().value());}}
  let lookup_ns=lookup_start.elapsed().as_nanos()/iterations;
  println!("original_index_lookup_ns_per_paint={} checksum={}",lookup_ns,checksum);
  println!("total={total} selected={selected} iterations={iterations} ns_per_call={} allocs_per_call={} requested_bytes_per_call={} frees_per_call={}",elapsed.as_nanos()/iterations,ALLOCS.load(Relaxed)/iterations as u64,BYTES.load(Relaxed)/iterations as u64,FREES.load(Relaxed)/iterations as u64);
 }
}
