from pathlib import Path
import subprocess,json,hashlib
out=Path('/dev/shm/hex-group-409-review-evidence');deps=Path('/dev/shm/hex-beats-ui-target/debug/deps')
s=(out/'preview-cost.rs').read_text()
s=s.replace('  let mut snapshot=editor.project().snapshot();','''  if std::env::args().any(|a|a=="musical") {
   let clip=editor.project().tracks()[0].clips()[0].id();
   let warp=hex_project::default_audio_warp(editor.project().clip(clip).unwrap(),editor.project().tempo_map(),hex_project::WarpMode::RePitch).unwrap();
   editor.execute(Command::SetAudioClipWarp{clip,settings:Some(warp)}).unwrap();
  }
  let mut snapshot=editor.project().snapshot();''')
s=s.replace('let p=Project::from_snapshot(snapshot).unwrap();','let p=std::sync::Arc::new(Project::from_snapshot(snapshot).unwrap());')
s=s.replace('  for _ in 0..2 {std::hint::black_box(p.preview_clip_group_move(&ids,ids[0],track,ClipGroupPosition::Audio(50000)).unwrap());}','''  let mut capture=hex_project::ClipGroupMovePreview::capture(&p,&ids,ids[0]).unwrap();
  for _ in 0..2 {capture.update(&p,track,ClipGroupPosition::Audio(50000)).unwrap();}''')
s=s.replace('  for _ in 0..iterations {let result=p.preview_clip_group_move(&ids,ids[0],track,ClipGroupPosition::Audio(50000)).unwrap();assert_eq!(result.len(),selected);std::hint::black_box(&result);drop(result);}','''  for i in 0..iterations {capture.update(&p,track,ClipGroupPosition::Audio(50000+i as u64*17)).unwrap();assert_eq!(capture.previews().len(),selected);std::hint::black_box(capture.previews());}''')
s=s.replace('  ACTIVE.store(false,Relaxed);let elapsed=start.elapsed();','''  ACTIVE.store(false,Relaxed);let elapsed=start.elapsed();
  assert_eq!(ALLOCS.load(Relaxed),0,"update allocated metadata/backing");assert_eq!(FREES.load(Relaxed),0,"update freed metadata/backing");''')
s=s.replace('  println!("total=', '''  // Measure the renderer's original-waveform lookup component separately.
  let lookup_start=Instant::now();let mut checksum=0u64;
  for _ in 0..iterations {for index in 0..capture.previews().len() {checksum=checksum.wrapping_add(capture.original_audio(&p,index).unwrap().id().value());}}
  let lookup_ns=lookup_start.elapsed().as_nanos()/iterations;
  println!("original_index_lookup_ns_per_paint={} checksum={}",lookup_ns,checksum);
  println!("total=''')
(out/'capture-cost.rs').write_text(s)
p=max(deps.glob('libhex_project-*.rlib'),key=lambda p:p.stat().st_mtime_ns)
argv=['rustc','--edition=2024','-C','opt-level=3',str(out/'capture-cost.rs'),'-L','dependency='+str(deps),'--extern','hex_project='+str(p),'-o',str(out/'capture-cost')]
with (out/'capture-cost-compile.log').open('xb') as f:subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,check=True)
for mode in ['frames','musical']:
 with (out/('capture-cost-'+mode+'.log')).open('xb') as f:subprocess.run([str(out/'capture-cost'),mode],stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'capture-cost-build.json').write_text(json.dumps(dict(argv=argv,library=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),profile='debug library + opt3 standalone counter harness, not native/optimized deadline evidence; original lookup component not whole GPUI paint'),indent=2)+'\n')
