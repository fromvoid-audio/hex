//! Actual multi-selection/header drag → worker candidate → one history step.
use super::super::test_environment::Environment;
use super::super::{EditorView, musical_time::SnapGrid};
use gpui::{
    AppContext, Entity, Modifiers, MouseButton, TestAppContext, VisualTestContext, point, px,
};
use hex_project::{ClipId, Command, Created};
use hex_session::service::{Event, Request, Service};
use std::{
    path::{Path, PathBuf},
    sync::{Arc, atomic::Ordering},
    time::{Duration, Instant},
};

// Armed before any Service work can escape. Only an actual successful Import
// response disarms retention; shutdown is deliberately not treated as a join.
struct PendingSetup {
    environment: Arc<Environment>,
    acknowledged: bool,
}
impl PendingSetup {
    fn new(environment: Arc<Environment>) -> Self {
        Self {
            environment,
            acknowledged: false,
        }
    }
    fn acknowledge_import(&mut self, event: &Event, path: &Path) {
        assert!(event.error.is_none(), "{:?}", event.error);
        assert!(event.request_complete);
        assert_eq!(event.status.as_deref(), Some("audio imported"));
        assert!(
            event.state.project.assets().any(|asset| {
                asset.path() == path
                    && asset.source_sample_rate() == 48_000
                    && asset.source_frames() == 96_000
            }),
            "ACK must contain the actual fixture import"
        );
        self.acknowledged = true;
    }
}
impl Drop for PendingSetup {
    fn drop(&mut self) {
        if !self.acknowledged {
            self.environment.retain_for_unacknowledged_setup_failure();
        }
    }
}

fn fixture_wav(environment: &Environment) -> PathBuf {
    // Identical96k-frame mono PCM fixture; all bytes live under the leased root.
    let rate = 48_000_u32;
    let frames = 96_000_u32;
    let bytes = frames * 2;
    let mut wav = Vec::new();
    wav.extend_from_slice(b"RIFF");
    wav.extend_from_slice(&(36 + bytes).to_le_bytes());
    wav.extend_from_slice(b"WAVEfmt ");
    wav.extend_from_slice(&16_u32.to_le_bytes());
    wav.extend_from_slice(&1_u16.to_le_bytes());
    wav.extend_from_slice(&1_u16.to_le_bytes());
    wav.extend_from_slice(&rate.to_le_bytes());
    wav.extend_from_slice(&(rate * 2).to_le_bytes());
    wav.extend_from_slice(&2_u16.to_le_bytes());
    wav.extend_from_slice(&16_u16.to_le_bytes());
    wav.extend_from_slice(b"data");
    wav.extend_from_slice(&bytes.to_le_bytes());
    for _ in 0..frames {
        wav.extend_from_slice(&8192_i16.to_le_bytes());
    }
    let path = environment.root().join("group.wav");
    std::fs::write(&path, wav).unwrap();
    path
}

fn next(service: &Service) -> Event {
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        if let Ok(event) = service.try_event() {
            assert!(event.error.is_none(), "{:?}", event.error);
            return event;
        }
        assert!(Instant::now() < deadline);
        std::thread::sleep(Duration::from_millis(2));
    }
}
fn pump(editor: &Entity<EditorView>, visual: &mut VisualTestContext) {
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        let done = editor.update(&mut *visual, |v, cx| {
            if v.tick(cx) {
                cx.notify();
            }
            v.worker_requests_pending == 0 && v.pending_requests.is_empty()
        });
        if done {
            visual.run_until_parked();
            return;
        }
        assert!(Instant::now() < deadline);
        std::thread::sleep(Duration::from_millis(2));
    }
}
fn fixture(
    cx: &mut TestAppContext,
) -> (
    Arc<Environment>,
    gpui::AnyWindowHandle,
    Entity<EditorView>,
    Vec<ClipId>,
) {
    cx.update(super::super::bind_editor_keys);
    let files = Environment::new().unwrap();
    let mut setup = PendingSetup::new(Arc::clone(&files));
    let wav = fixture_wav(&files);
    let directory = files.root();
    std::fs::create_dir(directory.join("samples")).unwrap();
    let service = Service::new(48_000, 32, 8_000_000).unwrap();
    next(&service);
    service.submit(Request::Import(wav.clone())).unwrap();
    let event = next(&service);
    setup.acknowledge_import(&event, &wav);
    let source = &event.state.project.tracks()[0];
    let track = source.id();
    let original = source.clips()[0].id();
    let asset = source.clips()[0].asset();
    service
        .submit(Request::Edit(Command::RemoveClip(original)))
        .unwrap();
    next(&service);
    let mut clips = Vec::new();
    for i in 0..3 {
        service
            .submit(Request::Edit(Command::PlaceClip {
                track,
                asset,
                start: 48_000 + i * 48_000,
                duration: 24_000,
                source_offset: i * 24_000,
                source_length: 24_000,
                looping: false,
            }))
            .unwrap();
        let event = next(&service);
        let Created::Clip(clip) = event.created.unwrap() else {
            panic!("placed clip");
        };
        clips.push(clip);
    }
    // Consume the current worker state without making a synthetic project view.
    service
        .submit(Request::Edit(Command::Gain { track, gain: 1.0 }))
        .unwrap();
    let event = next(&service);
    let handle = *cx.add_window(|_, _| gpui::Empty);
    let editor = cx
        .update_window(handle, |_, window, cx| {
            let editor = window.replace_root(cx, |window, cx| {
                EditorView::new_for_test_with_environment(window, cx, service, Arc::clone(&files))
            });
            editor.update(cx, |v, cx| {
                assert!(Arc::ptr_eq(&files, &v.test_environment));
                assert_eq!(v.browser.directory, directory.join("samples"));
                assert_eq!(v.browser.places, vec![directory.join("samples")]);
                v.state = Some(event.state);
                v.snap_grid = SnapGrid::default().with_platform_modifier(true);
                v.focus.focus(window);
                cx.notify();
            });
            editor
        })
        .unwrap();
    (files, handle, editor, clips)
}
fn click(visual: &mut VisualTestContext, clip: ClipId, additive: bool) {
    visual.run_until_parked();
    let selector = Box::leak(format!("clip-name-{}", clip.value()).into_boxed_str());
    let center = visual.debug_bounds(selector).unwrap().center();
    visual.simulate_click(
        center,
        Modifiers {
            platform: additive,
            ..Modifiers::default()
        },
    );
    visual.run_until_parked();
}
#[gpui::test]
fn dragging_nonprimary_selected_header_moves_all_three_clips_with_gaps_and_one_undo(
    cx: &mut TestAppContext,
) {
    let (_files, handle, editor, clips) = fixture(cx);
    let mut visual = VisualTestContext::from_window(handle, cx);
    for (i, clip) in clips.iter().enumerate() {
        click(&mut visual, *clip, i != 0);
    }
    let before = editor.read_with(&visual, |v, _| {
        assert_eq!(v.selected_clip, clips.last().copied());
        assert_eq!(v.selected_clip_ids(), clips);
        v.state.as_ref().unwrap().project.snapshot()
    });
    let anchor = clips[1];
    let selector = Box::leak(format!("clip-drag-surface-{}", anchor.value()).into_boxed_str());
    let down = visual.debug_bounds(selector).unwrap().center();
    visual.simulate_mouse_down(down, MouseButton::Left, Modifiers::default());
    visual.simulate_mouse_move(
        point(down.x + px(12.0), down.y),
        MouseButton::Left,
        Modifiers::default(),
    );
    visual.run_until_parked();
    let target = point(down.x + px(63.0), down.y);
    visual.simulate_mouse_move(target, MouseButton::Left, Modifiers::default());
    visual.run_until_parked();
    editor.read_with(&visual, |v, _| {
        assert_eq!(v.active_clip_drag.as_ref().unwrap().clip, anchor);
        assert_eq!(
            v.selected_clip_ids(),
            clips,
            "dragging a member must retain all selected IDs"
        );
    });
    visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
    pump(&editor, &mut visual);
    let after = editor.read_with(&visual, |v, _| {
        assert!(v.error.is_none(), "{:?}", v.error);
        let p = &v.state.as_ref().unwrap().project;
        let moved_anchor = p.clip(anchor).unwrap().start();
        let delta = i128::from(moved_anchor) - 96_000;
        assert!(delta > 0, "actual dragged member moved");
        for (i, id) in clips.iter().enumerate() {
            let c = p
                .clip(*id)
                .expect("every selected ID survives group movement");
            let expected = 48_000 + i as i128 * 48_000 + delta;
            eprintln!(
                "group anchor={} clip={} delta={delta} actual={} expected={expected}",
                anchor.value(),
                id.value(),
                c.start()
            );
            assert_eq!(
                i128::from(c.start()),
                expected,
                "all selected clips use the anchor delta"
            );
            assert_eq!(c.source_offset(), i as u64 * 24_000);
            assert_eq!(c.source_length(), 24_000);
        }
        assert_eq!(v.selected_clip_ids(), clips);
        p.snapshot()
    });
    visual.simulate_keystrokes("cmd-z");
    pump(&editor, &mut visual);
    editor.read_with(&visual, |v, _| {
        assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before)
    });
    visual.simulate_keystrokes("cmd-shift-z");
    pump(&editor, &mut visual);
    editor.read_with(&visual, |v, _| {
        assert_eq!(v.state.as_ref().unwrap().project.snapshot(), after)
    });
}

fn begin_group(visual: &mut VisualTestContext, clips: &[ClipId]) -> gpui::Point<gpui::Pixels> {
    for (i, clip) in clips.iter().enumerate() {
        click(visual, *clip, i != 0);
    }
    let selector = Box::leak(format!("clip-drag-surface-{}", clips[1].value()).into_boxed_str());
    let down = visual.debug_bounds(selector).unwrap().center();
    visual.simulate_mouse_down(down, MouseButton::Left, Modifiers::default());
    visual.simulate_mouse_move(
        point(down.x + px(12.0), down.y),
        MouseButton::Left,
        Modifiers::default(),
    );
    let target = point(down.x + px(63.0), down.y);
    visual.simulate_mouse_move(target, MouseButton::Left, Modifiers::default());
    target
}
#[gpui::test]
fn group_escape_and_actual_gpui_capture_loss_never_commit_any_member(cx: &mut TestAppContext) {
    for escape in [true, false] {
        let (_files, handle, editor, clips) = fixture(cx);
        let mut visual = VisualTestContext::from_window(handle, cx);
        let before = editor.read_with(&visual, |v, _| v.state.as_ref().unwrap().project.snapshot());
        let target = begin_group(&mut visual, &clips);
        let retained_payload =
            editor.read_with(&visual, |v, _| v.active_clip_drag.as_ref().unwrap().clone());
        assert!(retained_payload.group.borrow().capture.is_some());
        for id in &clips {
            let selector = Box::leak(format!("group-clip-preview-{}", id.value()).into_boxed_str());
            assert!(
                visual.debug_bounds(selector).is_some(),
                "all selected previews are actually rendered"
            );
        }
        if escape {
            visual.simulate_keystrokes("escape");
        } else {
            // Exercise actual GPUI drag-payload retirement, not a fabricated
            // worker/canonical failure or claimed physical window deactivation.
            visual.update(|window, cx| {
                assert!(cx.stop_active_drag(window));
            });
        }
        visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
        pump(&editor, &mut visual);
        assert!(
            retained_payload.group.borrow().capture.is_none(),
            "retired Rc payload cannot keep capture metadata"
        );
        editor.read_with(&visual, |v, _| {
            assert!(v.active_clip_drag.is_none());
            assert_eq!(v.selected_clip_ids(), clips);
            assert_eq!(v.worker_requests_pending, 0);
            assert!(v.last_enqueued_edit.is_none());
            assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before);
        });
    }
}
#[gpui::test]
fn group_pending_or_actual_revision_change_refuses_all_members_without_losing_independent_edit(
    cx: &mut TestAppContext,
) {
    for hold_ack in [true, false] {
        let (_files, handle, editor, clips) = fixture(cx);
        let mut visual = VisualTestContext::from_window(handle, cx);
        let target = begin_group(&mut visual, &clips);
        let before = editor.read_with(&visual, |v, _| v.state.as_ref().unwrap().project.clone());
        let event = editor.update(&mut visual, |v, _| {
            assert!(v.enqueue(Request::Edit(Command::RenameClip {
                clip: clips[0],
                name: "independent rename".into()
            })));
            next(&v.service)
        });
        if hold_ack {
            visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
            editor.update(&mut visual, |v, cx| {
                v.receive(event);
                cx.notify();
            });
        } else {
            editor.update(&mut visual, |v, cx| {
                v.receive(event);
                cx.notify();
            });
            visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
        }
        pump(&editor, &mut visual);
        editor.read_with(&visual, |v, _| {
            let project = &v.state.as_ref().unwrap().project;
            assert!(v.active_clip_drag.is_none());
            for id in &clips {
                let old = before.clip(*id).unwrap();
                let current = project.clip(*id).unwrap();
                assert_eq!(current.start(), old.start());
                assert_eq!(current.source_offset(), old.source_offset());
            }
            assert_eq!(project.clip(clips[0]).unwrap().name(), "independent rename");
            assert!(
                matches!(&v.last_enqueued_edit, Some(Command::RenameClip { .. })),
                "no group command after pending/stale refusal"
            );
        });
    }
}
#[gpui::test]
fn stationary_group_snap_modifier_uses_one_anchor_delta_and_authoritative_release(
    cx: &mut TestAppContext,
) {
    let (_files, handle, editor, clips) = fixture(cx);
    let mut visual = VisualTestContext::from_window(handle, cx);
    editor.update(&mut visual, |v, cx| {
        v.snap_grid = SnapGrid::default();
        cx.notify();
    });
    let before = editor.read_with(&visual, |v, _| v.state.as_ref().unwrap().project.snapshot());
    let target = begin_group(&mut visual, &clips);
    let positions = |v: &EditorView| {
        let group = v.active_clip_drag.as_ref().unwrap().group.borrow();
        let starts = clips
            .iter()
            .map(|id| {
                let item = group.previews().iter().find(|p| p.id() == *id).unwrap();
                let hex_project::ClipGroupContent::Audio(c) = &item.content else {
                    panic!("audio group")
                };
                c.start()
            })
            .collect::<Vec<_>>();
        for pair in starts.windows(2) {
            assert_eq!(
                pair[1] - pair[0],
                48_000,
                "one shared snap delta preserves off-grid gaps"
            );
        }
        starts
    };
    let snapped = editor.read_with(&visual, |v, _| positions(v));
    let command = Modifiers {
        platform: true,
        ..Modifiers::default()
    };
    visual.simulate_modifiers_change(command);
    let free = editor.read_with(&visual, |v, _| positions(v));
    assert_ne!(
        free, snapped,
        "stationary modifier actually changes snapping"
    );
    visual.simulate_modifiers_change(Modifiers::default());
    editor.read_with(&visual, |v, _| assert_eq!(positions(v), snapped));
    // Release's current modifier wins without a preceding changed event.
    visual.simulate_mouse_up(target, MouseButton::Left, command);
    pump(&editor, &mut visual);
    editor.read_with(&visual, |v, _| {
        for (id, expected) in clips.iter().zip(free) {
            assert_eq!(
                v.state.as_ref().unwrap().project.clip(*id).unwrap().start(),
                expected
            );
        }
    });
    visual.simulate_keystrokes("cmd-z");
    pump(&editor, &mut visual);
    editor.read_with(&visual, |v, _| {
        assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before)
    });
}

#[gpui::test]
fn mixed_audio_midi_group_uses_real_track_offsets_or_refuses_whole_vertical_move(
    cx: &mut TestAppContext,
) {
    for fits in [true, false] {
        let (_files, handle, editor, clips) = fixture(cx);
        let mut visual = VisualTestContext::from_window(handle, cx);
        let mut targets = Vec::new();
        for name in ["middle", "last"] {
            editor.update(&mut visual, |v, _| {
                assert!(v.enqueue(Request::Edit(Command::AddMidiTrack { name: name.into() })));
            });
            pump(&editor, &mut visual);
            targets.push(editor.read_with(&visual, |v, _| {
                v.state
                    .as_ref()
                    .unwrap()
                    .project
                    .tracks()
                    .last()
                    .unwrap()
                    .id()
            }));
        }
        editor.update(&mut visual, |v, _| {
            assert!(v.enqueue(Request::Edit(Command::PlaceMidiClip {
                track: targets[0],
                start: hex_project::BeatTime::from_quarters(6).unwrap(),
                length: hex_project::BeatTime::ONE
            })));
        });
        pump(&editor, &mut visual);
        let midi = editor.read_with(&visual, |v, _| {
            v.state
                .as_ref()
                .unwrap()
                .project
                .track(targets[0])
                .unwrap()
                .midi_clips()[0]
                .id()
        });
        editor.update(&mut visual, |v, _| {
            assert!(v.enqueue(Request::Edit(Command::AddMidiNote {
                clip: midi,
                start: hex_project::BeatTime::ZERO,
                duration: hex_project::BeatTime::ONE,
                pitch: 69,
                channel: 0,
                velocity: 100
            })));
        });
        pump(&editor, &mut visual);
        let anchor = clips[1];
        click(&mut visual, anchor, false);
        click(&mut visual, midi, true);
        let before = editor.read_with(&visual, |v, _| {
            assert_eq!(v.selected_clip_ids(), vec![anchor, midi]);
            v.state.as_ref().unwrap().project.snapshot()
        });
        let selector = Box::leak(format!("clip-drag-surface-{}", anchor.value()).into_boxed_str());
        let down = visual.debug_bounds(selector).unwrap().center();
        visual.simulate_mouse_down(down, MouseButton::Left, Modifiers::default());
        visual.simulate_mouse_move(
            point(down.x + px(12.0), down.y),
            MouseButton::Left,
            Modifiers::default(),
        );
        let destination = targets[usize::from(!fits)];
        let target = editor.read_with(&visual, |v, _| {
            let lane = v.drag_lanes[&destination];
            point(down.x + px(63.0), px(lane.top + lane.height / 2.0))
        });
        visual.simulate_mouse_move(target, MouseButton::Left, Modifiers::default());
        let planned = editor.read_with(&visual, |v, _| {
            assert_eq!(v.selected_clip_ids(), vec![anchor, midi]);
            assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before);
            let drag = v.active_clip_drag.as_ref().unwrap();
            let plan = drag.group.borrow().previews().to_vec();
            assert_eq!(plan.len(), if fits { 2 } else { 0 });
            plan
        });
        if fits {
            for id in [anchor, midi] {
                let selector =
                    Box::leak(format!("group-clip-preview-{}", id.value()).into_boxed_str());
                assert!(
                    visual.debug_bounds(selector).is_some(),
                    "both audio and MIDI previews actually paint"
                );
            }
        }
        visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
        pump(&editor, &mut visual);
        let after = editor.read_with(&visual, |v, _| {
            let project = &v.state.as_ref().unwrap().project;
            if !fits {
                assert_eq!(project.snapshot(), before);
                return project.snapshot();
            }
            assert!(v.error.is_none(), "{:?}", v.error);
            for item in &planned {
                let row = project.track(item.track).unwrap();
                match &item.content {
                    hex_project::ClipGroupContent::Audio(c) => assert!(row.clips().contains(c)),
                    hex_project::ClipGroupContent::Midi(c) => assert!(row.midi_clips().contains(c)),
                }
            }
            assert!(
                project
                    .track(targets[0])
                    .unwrap()
                    .clips()
                    .iter()
                    .any(|c| c.id() == anchor)
            );
            assert!(
                project
                    .track(targets[1])
                    .unwrap()
                    .midi_clips()
                    .iter()
                    .any(|c| c.id() == midi)
            );
            project.snapshot()
        });
        if fits {
            visual.simulate_keystrokes("cmd-z");
            pump(&editor, &mut visual);
            editor.read_with(&visual, |v, _| {
                assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before)
            });
            visual.simulate_keystrokes("cmd-shift-z");
            pump(&editor, &mut visual);
            editor.read_with(&visual, |v, _| {
                assert_eq!(v.state.as_ref().unwrap().project.snapshot(), after)
            });
        }
    }
}

#[gpui::test]
fn group_outside_lane_clears_all_previews_and_restores_originals(cx: &mut TestAppContext) {
    let (_files, handle, editor, clips) = fixture(cx);
    let mut visual = VisualTestContext::from_window(handle, cx);
    let before = editor.read_with(&visual, |v, _| v.state.as_ref().unwrap().project.snapshot());
    let target = begin_group(&mut visual, &clips);
    visual.run_until_parked();
    for id in &clips {
        let selector = Box::leak(format!("group-clip-preview-{}", id.value()).into_boxed_str());
        assert!(
            visual.debug_bounds(selector).is_some(),
            "valid landing preview actually painted"
        );
    }
    // A real pointer move left of every painted timeline lane, as the ordinary
    // single-clip drag fixture does; no fabricated planner error.
    let outside = point(px(200.0), target.y);
    visual.simulate_mouse_move(outside, MouseButton::Left, Modifiers::default());
    visual.run_until_parked();
    editor.read_with(&visual, |v, _| {
        let drag = v.active_clip_drag.as_ref().unwrap();
        assert!(drag.preview.get().is_none());
        assert!(drag.destination.get().is_none());
        assert!(
            drag.group.borrow().previews().is_empty(),
            "outside lane must invalidate all group destinations"
        );
    });
    for id in &clips {
        let preview = Box::leak(format!("group-clip-preview-{}", id.value()).into_boxed_str());
        let original = Box::leak(format!("clip-name-{}", id.value()).into_boxed_str());
        assert!(
            visual.debug_bounds(preview).is_none(),
            "stale group overlay hidden"
        );
        assert!(
            visual.debug_bounds(original).is_some(),
            "original reappears outside lane"
        );
    }
    visual.simulate_mouse_up(outside, MouseButton::Left, Modifiers::default());
    pump(&editor, &mut visual);
    editor.read_with(&visual, |v, _| {
        assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before);
        assert_eq!(v.worker_requests_pending, 0);
        assert!(
            v.last_enqueued_edit.is_none(),
            "outside release cannot commit old landing"
        );
    });
}

#[gpui::test]
fn group_vertical_autoscroll_invalidates_all_previews_before_repaint(cx: &mut TestAppContext) {
    let (_files, handle, editor, clips) = fixture(cx);
    let mut visual = VisualTestContext::from_window(handle, cx);
    for index in 0..24 {
        editor.update(&mut visual, |v, _cx| {
            v.enqueue(Request::Edit(Command::AddTrack {
                name: format!("scroll {index}"),
            }))
        });
        pump(&editor, &mut visual);
    }
    let before = editor.read_with(&visual, |v, _| v.state.as_ref().unwrap().project.snapshot());
    begin_group(&mut visual, &clips);
    visual.run_until_parked();
    let target = editor.read_with(&visual, |v, _| {
        let body = v.arrangement_bounds.unwrap();
        point(
            px(body.left + body.width * 0.6),
            px(body.top + body.height - 5.0),
        )
    });
    visual.simulate_mouse_move(target, MouseButton::Left, Modifiers::default());
    visual.run_until_parked();
    editor.update(&mut visual, |v, cx| {
        assert_eq!(
            v.active_clip_drag
                .as_ref()
                .unwrap()
                .group
                .borrow()
                .previews()
                .len(),
            3
        );
        let offset = v.track_scroll.offset().y;
        let generation = v.drag_layout_generation;
        let now = Instant::now();
        v.tick_clip_gesture_autoscroll(now, cx);
        if v.track_scroll.offset().y == offset {
            assert!(v.tick_clip_gesture_autoscroll(now + Duration::from_millis(50), cx));
        }
        assert!(
            v.track_scroll.offset().y < offset,
            "actual UniformList scroll occurred"
        );
        assert!(v.drag_layout_generation > generation);
        assert_ne!(v.arrangement_bounds_epoch, v.drag_layout_generation);
        let drag = v.active_clip_drag.as_ref().unwrap();
        assert!(drag.preview.get().is_none());
        assert!(drag.destination.get().is_none());
        assert!(
            drag.group.borrow().previews().is_empty(),
            "vertical autoscroll invalidates every group destination before repaint"
        );
    });
    // No repaint may turn the stale row into authority for this release.
    visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
    editor.read_with(&visual, |v, _| {
        assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before);
        assert_eq!(v.worker_requests_pending, 0);
    });
}

fn with_project_view(
    state: &hex_session::service::ViewState,
    project: std::sync::Arc<hex_project::Project>,
) -> std::sync::Arc<hex_session::service::ViewState> {
    std::sync::Arc::new(hex_session::service::ViewState {
        canonical_audio_source: state.canonical_audio_source.clone(),
        project,
        waveforms: state.waveforms.clone(),
        audio_clip_waveforms: state.audio_clip_waveforms.clone(),
        midi_preview: state.midi_preview.clone(),
        gain_preview: state.gain_preview.clone(),
        timeline_frames: state.timeline_frames,
        can_undo: state.can_undo,
        can_redo: state.can_redo,
        revision: state.revision,
        unsaved: state.unsaved,
        document_path: state.document_path.clone(),
    })
}
#[gpui::test]
fn group_capture_checks_source_allocation_and_selection_epoch(cx: &mut TestAppContext) {
    for case in 0..3 {
        let replace_project = case == 1;
        let invalid = case != 0;
        let (_files, handle, editor, clips) = fixture(cx);
        let mut visual = VisualTestContext::from_window(handle, cx);
        let before = editor.read_with(&visual, |v, _| v.state.as_ref().unwrap().project.snapshot());
        let target = begin_group(&mut visual, &clips);
        visual.run_until_parked();
        let payload =
            editor.read_with(&visual, |v, _| v.active_clip_drag.as_ref().unwrap().clone());
        editor.update(&mut visual, |v, cx| {
            let old = v.state.as_ref().unwrap();
            let project = if replace_project {
                std::sync::Arc::new((*old.project).clone())
            } else {
                old.project.clone()
            };
            v.state = Some(with_project_view(old, project));
            if case == 2 {
                let track = v.state.as_ref().unwrap().project.tracks()[0].id();
                v.clip_selection.only(track, clips[0]);
            }
            cx.notify();
        });
        visual.simulate_mouse_move(
            point(target.x + px(5.0), target.y),
            MouseButton::Left,
            Modifiers::default(),
        );
        visual.run_until_parked();
        editor.read_with(&visual, |v, _| {
            assert_eq!(
                v.state.as_ref().unwrap().project.snapshot(),
                before,
                "model/revision content stayed equal"
            );
            assert_eq!(
                payload.group.borrow().previews().len(),
                if invalid { 0 } else { 3 }
            );
            if invalid {
                assert!(
                    payload.group.borrow().capture.is_none(),
                    "replacement retires capture despite equal IDs/revision"
                );
            }
        });
        if invalid {
            visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
            pump(&editor, &mut visual);
            editor.read_with(&visual, |v, _| {
                assert_eq!(v.worker_requests_pending, 0);
                assert_eq!(v.state.as_ref().unwrap().project.snapshot(), before);
            });
        } else {
            visual.simulate_keystrokes("escape");
            visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
            pump(&editor, &mut visual);
        }
    }
}

#[gpui::test]
fn group_capture_profiles_actual_redraw_separately_from_projection(cx: &mut TestAppContext) {
    for total in [128, 16_384] {
        let (_files, handle, editor, clips) = fixture(cx);
        let mut visual = VisualTestContext::from_window(handle, cx);
        editor.update(&mut visual, |v, cx| {
            let old = v.state.as_ref().unwrap();
            let mut snapshot = old.project.snapshot();
            let originals = std::mem::take(snapshot.tracks[0].audio_clips_mut().unwrap());
            for index in 0..total - originals.len() {
                let mut c = originals[0].clone();
                c.id = snapshot.next_id;
                snapshot.next_id += 1;
                c.start = 10_000_000 + index as u64 * 48_000;
                snapshot.tracks[0].audio_clips_mut().unwrap().push(c);
            }
            snapshot.tracks[0]
                .audio_clips_mut()
                .unwrap()
                .extend(originals);
            let project =
                std::sync::Arc::new(hex_project::Project::from_snapshot(snapshot).unwrap());
            // Metadata-only renderer fixture: no publication/source authority or
            // commit is inferred from this view; original real-Service cases run separately.
            v.state = Some(with_project_view(old, project));
            cx.notify();
        });
        visual.run_until_parked();
        let target = begin_group(&mut visual, &clips);
        visual.run_until_parked();
        let (row, position) = editor.read_with(&visual, |v, _| {
            let drag = v.active_clip_drag.as_ref().unwrap();
            let preview = drag.preview.get().unwrap();
            (
                preview.target_track,
                super::group_position(preview.position),
            )
        });
        let start = Instant::now();
        editor.update(&mut visual, |v, _| {
            let state = v.state.as_ref().unwrap();
            let drag = v.active_clip_drag.as_ref().unwrap();
            let mut group = drag.group.borrow_mut();
            let capture = group.capture.as_mut().unwrap();
            for _ in 0..32 {
                capture.update(&state.project, row, position).unwrap();
            }
        });
        let projection = start.elapsed();
        // Repaint complete actual GPUI view (including unrelated row cost),
        // separately from the projection loop. No native/deadline threshold.
        for _ in 0..2 {
            editor.update(&mut visual, |_, cx| cx.notify());
            visual.run_until_parked();
        }
        let start = Instant::now();
        for _ in 0..4 {
            editor.update(&mut visual, |_, cx| cx.notify());
            visual.run_until_parked();
        }
        let painting = start.elapsed();
        for id in &clips {
            let selector = Box::leak(format!("group-clip-preview-{}", id.value()).into_boxed_str());
            assert!(
                visual.debug_bounds(selector).is_some(),
                "actual indexed-source overlays painted"
            );
        }
        eprintln!(
            "group capture profile total={total} selected=3 projection_ns_per_update={} full_gpui_redraw_ns={} profile=debug/no_deadline_claim",
            projection.as_nanos() / 32,
            painting.as_nanos() / 4
        );
        visual.simulate_keystrokes("escape");
        visual.simulate_mouse_up(target, MouseButton::Left, Modifiers::default());
        pump(&editor, &mut visual);
    }
}

#[gpui::test]
fn group_capture_reenters_valid_lane_and_commits_only_current_projection(cx: &mut TestAppContext) {
    let (_files, handle, editor, clips) = fixture(cx);
    let mut visual = VisualTestContext::from_window(handle, cx);
    let target = begin_group(&mut visual, &clips);
    visual.run_until_parked();
    let payload = editor.read_with(&visual, |v, _| v.active_clip_drag.as_ref().unwrap().clone());
    visual.simulate_mouse_move(
        point(px(200.0), target.y),
        MouseButton::Left,
        Modifiers::default(),
    );
    visual.run_until_parked();
    assert!(payload.group.borrow().previews().is_empty());
    assert!(
        payload.group.borrow().capture.is_some(),
        "temporary no-target keeps reusable metadata"
    );
    let returned = point(target.x + px(13.0), target.y);
    visual.simulate_mouse_move(returned, MouseButton::Left, Modifiers::default());
    visual.run_until_parked();
    let plan = payload.group.borrow().previews().to_vec();
    assert_eq!(plan.len(), 3);
    visual.simulate_mouse_up(returned, MouseButton::Left, Modifiers::default());
    pump(&editor, &mut visual);
    assert!(
        payload.group.borrow().capture.is_none(),
        "accepted release retires shared capture"
    );
    editor.read_with(&visual, |v, _| {
        let project = &v.state.as_ref().unwrap().project;
        for item in &plan {
            let hex_project::ClipGroupContent::Audio(c) = &item.content else {
                panic!("audio fixture")
            };
            assert_eq!(
                project.clip(c.id()),
                Some(c),
                "fresh canonical release equals current landing"
            );
        }
        assert!(v.error.is_none(), "{:?}", v.error);
    });
}

fn prove_fixture_catalog_custody(cx: &mut TestAppContext, unwind: bool) {
    let (files, handle, editor, _) = fixture(cx);
    let root = files.root().to_owned();
    let weak = Arc::downgrade(&files);
    let gate = files.gate_next_catalog_save();
    editor.read_with(cx, |view, _| {
        assert!(Arc::ptr_eq(&files, &view.test_environment));
        assert_eq!(
            view.browser.directory,
            root.join("samples"),
            "actual filesystem-job owner must own fixture scan path, not a separate root"
        );
        assert!(
            view.state
                .as_ref()
                .unwrap()
                .project
                .assets()
                .all(|asset| asset.path().starts_with(&root))
        );
        assert_eq!(
            view.recent_projects.test_path(),
            root.join("config/recent-projects.json")
        );
        assert_eq!(
            view.theme_settings.test_path(),
            root.join("config/theme.json")
        );
        // These are the exact four paths resolved by the injected constructor;
        // the catalog is derived by its real worker from the browser path.
        let empty = PathBuf::new();
        let paths = files.resolve_paths(
            (empty.clone(), empty.clone(), empty.clone(), empty),
            [true; 4],
        );
        assert_eq!(
            paths,
            (
                root.join("config/browser.json"),
                root.join("config/recent-projects.json"),
                root.join("config/theme.json"),
                root.join("config/project-directory.json")
            )
        );
    });
    let mut visual = VisualTestContext::from_window(handle, cx);
    visual.run_until_parked();
    assert!(
        gate.reached.load(Ordering::Acquire),
        "paused inside actual catalog worker"
    );
    assert!(!gate.finished.load(Ordering::Acquire));
    visual.update(|window, cx| {
        let _ = window.replace_root(cx, |_, _| gpui::Empty);
    });
    let editor_weak = editor.downgrade();
    drop(editor);
    visual.update(|_, _| {});
    visual.run_until_parked();
    assert!(
        editor_weak.upgrade().is_none(),
        "actual view retired before I/O continuation"
    );
    let retired = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
        let _fixture = files;
        if unwind {
            panic!("intentional post-ACK fixture unwind");
        }
    }));
    assert_eq!(retired.is_err(), unwind);
    assert_eq!(
        weak.strong_count(),
        1,
        "only real held filesystem job retains SAME root"
    );
    assert!(root.is_dir());
    gate.release();
    visual.run_until_parked();
    assert!(gate.finished.load(Ordering::Acquire));
    assert!(gate.save_succeeded.load(Ordering::Relaxed));
    assert!(gate.root_present_during_save.load(Ordering::Relaxed));
    visual.update(|_, _| {});
    assert!(
        weak.upgrade().is_none(),
        "fixture/view/job owners released without Arc leak"
    );
    let deadline = Instant::now() + Duration::from_secs(5);
    while root.exists() {
        assert!(
            Instant::now() < deadline,
            "owned background cleanup timed out: {root:?}"
        );
        std::thread::yield_now();
    }
    visual.run_until_parked();
    assert!(!root.exists(), "drained job cannot recreate the root");
    eprintln!(
        "group_fixture_catalog_custody unwind={unwind} actual_save=true same_root=true cleaned=true"
    );
}

#[gpui::test]
fn group_fixture_same_root_survives_real_catalog_job_after_view_retirement(
    cx: &mut TestAppContext,
) {
    prove_fixture_catalog_custody(cx, false);
}

#[gpui::test]
fn group_fixture_post_ack_unwind_keeps_actual_job_root_until_save_and_cleanup(
    cx: &mut TestAppContext,
) {
    prove_fixture_catalog_custody(cx, true);
}

#[test]
fn group_fixture_pre_ack_real_import_failure_retains_disk_but_not_environment_memory() {
    let environment = Environment::new().unwrap();
    let root = environment.root().to_owned();
    let weak = Arc::downgrade(&environment);
    let observed_refusal = std::cell::Cell::new(false);
    let caught = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let mut setup = PendingSetup::new(environment);
        let missing = root.join("missing-import.wav");
        let service = Service::new(48_000, 32, 8_000_000).unwrap();
        next(&service);
        service.submit(Request::Import(missing.clone())).unwrap();
        let deadline = Instant::now() + Duration::from_secs(10);
        let event = loop {
            if let Ok(event) = service.try_event() {
                break event;
            }
            assert!(Instant::now() < deadline);
            std::thread::sleep(Duration::from_millis(2));
        };
        assert!(event.request_complete);
        assert!(
            event.error.is_some(),
            "real missing-file import must refuse"
        );
        observed_refusal.set(true);
        setup.acknowledge_import(&event, &missing); // Must unwind BEFORE disarming.
    }));
    assert!(caught.is_err());
    assert!(
        observed_refusal.get(),
        "caught panic came after actual request completion, not timeout"
    );
    assert!(
        weak.upgrade().is_none(),
        "retain disk evidence without leaking Environment/Arc"
    );
    assert!(
        root.is_dir(),
        "unacknowledged successful setup cannot remove evidence"
    );
    eprintln!(
        "group_fixture_pre_ack_retention actual_refusal=true weak_expired=true disk_retained=true root={root:?}"
    );
    // Only this artificial refusal case has proven its sole I/O request finished
    // and has launched NO UI jobs. Explicit cleanup of that exclusive test root
    // is safe here; general unacknowledged failures have no automatic cleanup.
    std::fs::remove_dir_all(root).unwrap();
}

#[gpui::test]
fn review_group_landing_paints_unselected_overwrite_victim(cx: &mut TestAppContext) {
    let (_files, handle, editor, clips) = fixture(cx);
    let mut visual = VisualTestContext::from_window(handle, cx);
    for (i, clip) in clips[..2].iter().enumerate() {
        click(&mut visual, *clip, i != 0);
    }
    let selector = Box::leak(format!("clip-drag-surface-{}", clips[1].value()).into_boxed_str());
    let victim = Box::leak(format!("clip-name-{}", clips[2].value()).into_boxed_str());
    let down = visual.debug_bounds(selector).unwrap().center();
    let target = visual.debug_bounds(victim).unwrap().center();
    visual.simulate_mouse_down(down, MouseButton::Left, Modifiers::default());
    visual.simulate_mouse_move(
        point(down.x + px(12.0), down.y),
        MouseButton::Left,
        Modifiers::default(),
    );
    visual.simulate_mouse_move(target, MouseButton::Left, Modifiers::default());
    visual.run_until_parked();
    editor.read_with(&visual, |view, _| {
        let drag = view.active_clip_drag.as_ref().unwrap();
        let group = drag.group.borrow();
        assert_eq!(group.previews().len(), 2);
        let state = view.state.as_ref().unwrap();
        let victim = state.project.clip(clips[2]).unwrap();
        assert!(
            group.previews().iter().any(|p| match &p.content {
                hex_project::ClipGroupContent::Audio(c) =>
                    c.start() < victim.start() + victim.duration()
                        && victim.start() < c.start() + c.duration(),
                _ => false,
            }),
            "actual valid group landing must overlap the unselected victim"
        );
    });
    assert!(
        visual.debug_bounds("clip-drop-overlap-0").is_some(),
        "group landing must paint actual overwrite victims"
    );
    visual.simulate_keystrokes("escape");
}
