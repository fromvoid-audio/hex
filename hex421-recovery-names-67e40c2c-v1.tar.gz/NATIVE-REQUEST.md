# Coordinator-only changed UI component

Exact source 67e40c2c4a52f85256ae0c0a1f1d99b45745c78b, tree c5434c2e4ea5e77a9aa7bf1ba6782037cd3f5c3f. Use existing sole serial Mac lane/private legitimate target; no self-dispatch. Materialize actual source, never evidence ref. Verify all source bytes/modes against source-files.json (this checkout launch0700; isolated checkout with umask077 reproduces it; do not chmod primary or alter guards).

ONE command, expected exactly11PASS/0ignored:

```sh
cargo test -p hex-ui --features ui-test-support --locked editor::dialogs::ui_tests::recovery_name_tests::
```

Names/case counts are in final original cloud log. Actual public Open action/inline CmdR+text/Service save-open plus TestPlatform picker; manualRecovery production cutpoint and four real recovery action dispatches. Disposable browser/settings/samples paths retained before worker startup. No ambient HOME/native OS picker/CPAL/app input. No need repeat unchanged native6 or afcd1 solely for these UI changes.

Preserve source and existing primary/installed app/receipts/READY/profiles/media/locks. Capture actual command/cardinality/status/log/before=end source and preservation evidence. No app launch/build/install/quit/signals/real NewOpenSave actions. Future user acceptance only in a coordinator-approved disposable document: type a track/clip name then Open; Save includes it, Cancel leaves it Undoable, Don'tSave replaces once, refused/cancelled Save preserves it; manual recovery cannot steal Open. Actual OS picker/physical interaction/audio acceptance remain separate, not a new approval gate on source progress.
