# PR421 owner repair

Source 67e40c2c4a52f85256ae0c0a1f1d99b45745c78b; tree c5434c2e4ea5e77a9aa7bf1ba6782037cd3f5c3f; exact parent 8a84933261009c07fcbb95673d3e833cdc9d131b. Published source/2815-recovery-name-drafts. Canonical PR421 unchanged. Sole merger: ordinary cherry-pick this ONE owner commit, fresh prospective exact-source required CI/review; never build evidence refs. Pulse stays In Progress until actual merge. No A/B/main stack.

Actual original3RED -> first3GREEN -> final31dialogPASS/0ignored/Cargo0. Strict feature UI alltargets Clippy0 and all5 source guards/fmt/diff0. Original compile/fixture/environment failures retained. All materialized source bytes match Git blobs and executable-mode classes. Physical launch0700 is recorded, not normalized.

Name law: valid current track/clip draft commits like Enter/blur BEFORE picker, one canonical Undoable rename; selected path waits original worker settlement. Save includes name; Cancel leaves rename Undoable; Don't Save replaces only after successful load. Invalid/stale/blocked draft refuses Open without consumption. Manual Recovery cannot steal picker or chosen path; matching owned internal Restore still passes unchanged token admission. No controller/Session/Engine/vendor/action binding changes.

New11 bounded private UI fixtures use retained disposable paths BEFORE Editor workers. Fullgroup31 includes unchanged ownedRestore/tuning/save/media/window routes. Injected TestPlatform results are not actual OS picker/native acceptance. Original8a84 full21/native historical receipts not relabelled. No production app operations.

A/B checkpoint7cffaaaa and unwired private helper retained separately; no451 changes. See NATIVE-REQUEST.md for coordinator-only changed component.
