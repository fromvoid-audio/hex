from pathlib import Path
import importlib.util,sys,os
root=Path('/workspace/hex-tempo')
spec=importlib.util.spec_from_file_location('hex_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
env=dict(os.environ);env['CARGO_TARGET_DIR']='/workspace/hex-tuning-editor/target'
r=m.LocalCiRunner(root,mode='quick',env=env,min_free_bytes=2*m.GIB,steps=(m.Step('tempo-blur-focus-negative',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','project_tempo_blur_commits_valid_text_and_invalid_blur_releases_editor_shortcuts','--','--nocapture'),uses_cargo_target=True),))
raise SystemExit(r.run())
