from pathlib import Path
import importlib.util,sys,os
root=Path('/workspace/hex-tempo')
spec=importlib.util.spec_from_file_location('hex_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
env=dict(os.environ);env['CARGO_TARGET_DIR']='/workspace/hex-tuning-editor/target'
r=m.LocalCiRunner(root,mode='quick',env=env,adopt_target=True,min_free_bytes=2*m.GIB,steps=(m.Step('project-tempo-ui',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','project_tempo_','--','--nocapture'),uses_cargo_target=True),m.Step('operator-tab-regression',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','operator_tab_cycles_rendered_controls_in_both_directions_without_project_edits','--','--nocapture'),uses_cargo_target=True),))
raise SystemExit(r.run())
