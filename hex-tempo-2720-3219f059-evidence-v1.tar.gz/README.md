# Evidence only — never build or merge this ref

Application source is actual merge5bd4220d08f37f422eb17561bc4a350620e0c4ef,
original checked3219f059d0f84d52806f652d1b5b53098c135937, identicaltreecabfdd2e.
All15 original source-check summaries and every adjacent log are copied verbatim.
The finalfull20 passed588.994s, clean unchanged/stale=false. Historical failed,
partial, stale, lock-refused and control-pass receipts remain historical. Read
source-identity.json/report-catalog.json/actual-merge-proof.json; no receipt has
been relabeled or rewritten. Source/mode ledger binds original candidate bytes.
Native Mac7 execution is coordinator-owned and separate; no Mac bytes included.
Installed7fe4/build2145711247 remains unchanged by cloud; physical UI/input, audio/
listening/current-format save-reopen and old tuning/MTS/client/WAV gaps stay open.
No source389/sampler delivery claim. No credentials, user projects or build caches.
Verify published archive size/SHA256, reject unsafe/duplicate/link/nonregular
members, then verify every file-manifest payload before using this packet.
