from pathlib import Path
import subprocess
r=Path('/workspace/hex-tempo')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='5d5315e74963624a3621cdc830cb4dc03b58a7a3'
p=r/'crates/hex-ui/src/editor/tempo_input.rs'
s=p.read_text().replace('use gpui::{Context, Div, Entity, Subscription, div, prelude::*, px};','use gpui::{Context, Div, Entity, Focusable, Subscription, div, prelude::*, px};')
s=s.replace('pub(super) fn project_tempo_editing(&self, cx: &Context<Self>) -> bool {','pub(super) fn project_tempo_editing(&self, window: &gpui::Window, cx: &gpui::App) -> bool {')
s=s.replace('            numeric.set_tab_navigation(true, cx);\n', '')
s=s.replace('                && binding.entity.read(cx).is_editing()', '                && binding.entity.read(cx).is_editing()\n                && binding.entity.read(cx).focus_handle(cx).is_focused(window)')
p.write_text(s)
p=r/'crates/hex-ui/src/editor/render.rs';p.write_text(p.read_text().replace('self.project_tempo_editing(cx)', 'self.project_tempo_editing(window, cx)'))
p=r/'crates/hex-ui/src/editor/tempo_input_ui_test.rs';s=p.read_text().replace('editor.update(cx, |view, cx| {\n            assert!(!view.project_tempo_editing(cx));', 'editor.update(cx, |view, _| {');p.write_text(s)
p=r/'docs/project-tempo-input.md';s=p.read_text().replace('Click the value or Tab to it to edit. Enter commits a valid changed number once;\nEscape cancels.', 'Click the value to edit. Enter or focus loss commits valid changed text once;\nEscape cancels. Keyboard adjustments use the shared numeric control, without\nadding a new Tab stop to the existing device traversal.')
s=s.replace('Text entry owns the keyboard so', 'Focused text entry owns the keyboard so')
s=s.replace('Undo/Redo does not consume a numeric text draft.', 'Undo/Redo does not consume a focused numeric text draft. An invalid unfocused\ndraft does not suppress workspace shortcuts.')
s=s.replace('and four rendered input/layout/lifecycle tests.', 'and five rendered input/layout/lifecycle tests.')
s=s.replace('and cursor movement during typing.', 'and cursor movement during typing. The blur regression checks valid commit,\ninvalid/empty refusal and shortcut recovery after returning focus to the editor.')
s=s.replace('Escape and a\n   click-away cancel leave it unchanged;', 'Escape cancels; clicking away commits valid changed text once, while')
s=s.replace('actions; editor Undo must not apply a text draft.', 'actions; editor Undo must not apply a focused text draft. After leaving invalid\n   text and focusing the workspace, normal DAW shortcuts must work again.')
p.write_text(s)
p=r/'todo.md';s=p.read_text().replace('- Five focused range/input/layout/lifecycle tests pass. Required final exact-source', '- Six focused range/input/layout/lifecycle/blur regressions cover the control;\n  final source validation is recorded in PR336/Pulse2720. Required exact-source');p.write_text(s)
