from pathlib import Path
import subprocess,json,hashlib
r=Path('/workspace/hex-tempo')
p=r/'artifacts/local-ci/20261018T131225Z-54ebcb9c/summary.json'
s=json.loads(p.read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
head='3219f059d0f84d52806f652d1b5b53098c135937'
tree='cabfdd2ed5b11c4307d9c088f5fbfd2d844a2e45'
assert s['commit']==head and s['mode']=='full' and s['status']=='passed' and s['exit_code']==0
assert s['dirty'] is False and s['stale'] is False and s['start_tree']==s['end_tree']
assert len(s['steps'])==20 and all(x['status']=='passed' for x in s['steps'])
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
assert git('rev-parse','HEAD^{tree}')==tree
base=git('rev-parse','origin/main')
prospective=git('merge-tree','--write-tree','origin/main','HEAD')
out={'candidate':head,'tree':tree,'actual_main':base,'prospective_tree':prospective,'prospective_tree_matches':prospective==tree,'full_steps_passed':20,'duration_seconds':s['duration_seconds'],'ended_at':s['ended_at'],'report':str(p),'report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_content_sha256':s['start_tree']['content_sha256'],'clean_unchanged_stale_false':True}
(r/'artifacts/tempo-2720-final-proof.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
assert prospective==tree,'Current main changes the prospective merge tree; integrate and qualify deliberately, no relabeling.'
