# Coordinator-only changed component

Exact 01c686fdedf92b953f081a779119bc782020105b/tree 2a3db5a30d7ee5c8a64c9571af59122d9e2d0370; never build evidence ref. Sole existing serial Mac/private legitimate target only. No app operations or native self-dispatch.

Two commands, exactly4+2 new/changed PASS0ignored:

```sh
cargo test -p hex-ui --features ui-test-support --lib --locked device_delete_review_
cargo test -p hex-ui --features ui-test-support --lib --locked device_delete_release_
```

Actual rendered title/pointer/key routes and Service, retained disposable363 browser/settings/samples paths before worker startup. Existing old9 passed cloud; do not repeat earlier unchanged native9 solely for these cases. Normal stack/configured toolchain. Preserve source/primary/userapp/receipts/profiles/media/locks. Report exact selectors/cardinality/exit/raw logs/source byte+mode/preservationbefore=end. Physical keyboard/UI acceptance remains separate; no user-app input/build/install/launch/quit/signals.
