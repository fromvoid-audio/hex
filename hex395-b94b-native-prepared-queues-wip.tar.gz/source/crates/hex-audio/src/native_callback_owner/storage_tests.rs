//! Real existing Guard/Terminal transport, not a model of its lifecycle. Until
//! the complete Root factory has a before-birth union, production reserve stays
//! explicitly unqualified. This fixture supplies finite local constructor caps.
use super::*;
use hex_engine::{
    AudioRootStorageLedger, AudioStorageError, AudioStorageLedgerReservation,
    sampler_host_fields::NativeCarrierStorageRegistration,
};

fn reserved<T>(
    value: T,
    retained: usize,
    peak: usize,
) -> Result<(Guard<T>, Terminal<T>, NativeCarrierStorageRegistration), AudioStorageError> {
    let bytes = NativeCarrierStorageRegistration::requested_bytes_on_control::<T>()?;
    let scratch = NativeCarrierStorageRegistration::construction_scratch_bytes_on_control::<T>()?
        .checked_add(size_of::<Guard<T>>())
        .and_then(|n| n.checked_add(size_of::<Terminal<T>>()))
        .ok_or(AudioStorageError::Overflow)?;
    if bytes > retained
        || bytes
            .checked_add(scratch)
            .ok_or(AudioStorageError::Overflow)?
            > peak
    {
        return Err(AudioStorageError::ReservationExceeded);
    }
    // Exactly the existing private fresh constructor, after both cap checks.
    let (mut guard, mut terminal) = reserve(value);
    let GuardState::Live { owner, cell } = &guard.state else {
        unreachable!()
    };
    let (registration, [body, producer, receiver]) =
        NativeCarrierStorageRegistration::pair_actual_fresh_carrier_on_control(
            owner.as_ref(),
            cell,
            terminal.cell.as_ref().unwrap(),
        )?;
    guard.storage = Some(producer);
    terminal.cell_storage = Some(receiver);
    terminal.body_storage = Some(body);
    Ok((guard, terminal, registration))
}

fn bound<T>() -> (usize, usize) {
    let bytes = NativeCarrierStorageRegistration::requested_bytes_on_control::<T>().unwrap();
    let peak = bytes
        + NativeCarrierStorageRegistration::construction_scratch_bytes_on_control::<T>().unwrap()
        + size_of::<Guard<T>>()
        + size_of::<Terminal<T>>();
    (bytes, peak)
}
fn data(registration: &NativeCarrierStorageRegistration) -> Result<usize, AudioStorageError> {
    let mut ledger = AudioRootStorageLedger::try_new_on_control(AudioStorageLedgerReservation {
        data_rows: 16,
        handle_rows: 16,
        root_rows: 4,
        max_retained_bytes: 1 << 20,
        max_construction_peak_bytes: 1 << 20,
    })?;
    registration.visit_storage_on_control(&mut ledger)?;
    ledger.validate_selected_shared_handles_on_control()?;
    Ok(ledger.summary()?.data_bytes)
}

#[test]
fn actual_guard_terminal_lease_pair_follows_box_to_control_and_each_physical_drop() {
    // Cell proves Send-only payload support without widening it to Sync.
    type Payload = std::cell::Cell<[u64; 7]>;
    fn is_send<T: Send>() {}
    is_send::<Guard<Payload>>();
    is_send::<Terminal<Payload>>();
    let (bytes, peak) = bound::<Payload>();
    for (retained, peak) in [(bytes - 1, peak), (bytes, peak - 1)] {
        let refusal = allocation_counter::measure(|| {
            assert!(matches!(
                reserved(Payload::new([29; 7]), retained, peak),
                Err(AudioStorageError::ReservationExceeded)
            ));
        });
        assert_eq!((refusal.count_total, refusal.bytes_total), (0, 0));
    }
    let mut actual = None;
    let allocated = allocation_counter::measure(|| {
        actual = Some(reserved(Payload::new([29; 7]), bytes, peak).unwrap());
    });
    assert_eq!(
        (allocated.count_total, allocated.bytes_total),
        (3, bytes as u64)
    );
    let (mut guard, mut terminal, registration) = actual.unwrap();
    assert_eq!(data(&registration).unwrap(), bytes);
    let address = guard.owner_ref().unwrap() as *const Payload;
    guard.owner_mut().unwrap().set([31; 7]);
    let closed = allocation_counter::measure(|| {
        guard.close();
        guard.close();
    });
    assert_eq!(
        (
            closed.count_total,
            closed.count_current,
            closed.bytes_total,
            closed.bytes_current
        ),
        (0, 0, 0, 0)
    );
    assert!(terminal.ready());
    assert_eq!(data(&registration).unwrap(), bytes);
    let owner = terminal.take().unwrap();
    assert_eq!(owner.as_ref() as *const Payload, address);
    assert_eq!(owner.get(), [31; 7]);
    let metadata = NativeCarrierStorageRegistration::metadata_requested_bytes_on_control().unwrap();
    assert_eq!(
        data(&registration).unwrap(),
        metadata + size_of::<Payload>()
    );
    terminal.begin_body_drop().unwrap();
    let dropped = allocation_counter::measure(|| drop(owner));
    assert_eq!(
        (
            dropped.count_total,
            dropped.count_current,
            dropped.bytes_current
        ),
        (0, -1, -(size_of::<Payload>() as i64))
    );
    // Pending persists until the actual existing outer control completion step.
    assert_eq!(data(&registration), Err(AudioStorageError::UnknownStorage));
    terminal.complete_body_drop().unwrap();
    assert_eq!(data(&registration).unwrap(), metadata);
    assert!(registration.is_normally_disposed_on_control());
    drop(terminal);
    drop(guard);
    assert_eq!(data(&registration).unwrap(), metadata);
    eprintln!(
        "SUPPORTED actual Audio Guard/Terminal Send-only Cell;3alloc{bytes}; both-minus1 beforebirth0alloc; callback close twice0alloc/free; actual cell unwrap followed by sameBox pending/normaldrop; immutable metadata{metadata} remains"
    );
}

#[test]
fn actual_body_destructor_panic_keeps_first_payload_and_failed_carrier_charge() {
    struct Fails {
        drops: Arc<std::sync::atomic::AtomicUsize>,
    }
    impl Drop for Fails {
        fn drop(&mut self) {
            self.drops.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            std::panic::panic_any(137u64);
        }
    }
    let drops = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let (bytes, peak) = bound::<Fails>();
    let (mut guard, mut terminal, registration) = reserved(
        Fails {
            drops: drops.clone(),
        },
        bytes,
        peak,
    )
    .unwrap();
    guard.close();
    let owner = terminal.take().unwrap();
    terminal.begin_body_drop().unwrap();
    let first = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| drop(owner))).unwrap_err();
    assert_eq!(first.downcast_ref::<u64>(), Some(&137));
    assert_eq!(drops.load(std::sync::atomic::Ordering::SeqCst), 1);
    for _ in 0..2 {
        assert_eq!(data(&registration), Err(AudioStorageError::UnknownStorage));
    }
    // Exactly the existing outer failure protocol: no complete/retry after a
    // destructive unwind; release merely latches failure in the retained record.
    drop(terminal);
    assert_eq!(data(&registration), Err(AudioStorageError::UnknownStorage));
    assert_eq!(drops.load(std::sync::atomic::Ordering::SeqCst), 1);
    assert_eq!(first.downcast_ref::<u64>(), Some(&137));
    drop(guard);
}
