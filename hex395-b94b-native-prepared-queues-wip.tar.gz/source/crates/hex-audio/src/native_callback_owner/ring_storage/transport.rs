//! Affine holders for the THREE existing prepared-audio queues. They neither
//! create a new queue/family nor expose owning raw endpoints. A constructor
//! lease, when present, follows the same endpoint through existing custody.
use hex_engine::sampler_host_fields::NativeFixedRingLease;

pub(crate) struct NativePreparedProducer<T> {
    value: Option<rtrb::Producer<T>>,
    storage: Option<NativeFixedRingLease>,
}
pub(crate) struct NativePreparedConsumer<T> {
    value: Option<rtrb::Consumer<T>>,
    storage: Option<NativeFixedRingLease>,
}
pub(crate) fn native_prepared_ring<T>(
    capacity: usize,
) -> (NativePreparedProducer<T>, NativePreparedConsumer<T>) {
    let (producer, consumer) = rtrb::RingBuffer::new(capacity);
    // No legacy endpoint is retrospectively qualified. Complete Root factory
    // preflight/registration must select the constructor-bound path before any
    // endpoint escapes; None here remains explicitly unsupported by that union.
    (
        NativePreparedProducer {
            value: Some(producer),
            storage: None,
        },
        NativePreparedConsumer {
            value: Some(consumer),
            storage: None,
        },
    )
}
impl<T> NativePreparedProducer<T> {
    pub(crate) fn push(&mut self, value: T) -> Result<(), rtrb::PushError<T>> {
        self.value
            .as_mut()
            .expect("prepared producer already disposed")
            .push(value)
    }
    pub(crate) fn is_full(&self) -> bool {
        self.value
            .as_ref()
            .expect("prepared producer already disposed")
            .is_full()
    }
    pub(crate) fn buffer(&self) -> &rtrb::RingBuffer<T> {
        self.value
            .as_ref()
            .expect("prepared producer already disposed")
            .buffer()
    }
    pub(crate) fn write_chunk_uninit(
        &mut self,
        count: usize,
    ) -> Result<rtrb::chunks::WriteChunkUninit<'_, T>, rtrb::chunks::ChunkError> {
        self.value
            .as_mut()
            .expect("prepared producer already disposed")
            .write_chunk_uninit(count)
    }
    #[cfg(test)]
    pub(crate) fn slots(&self) -> usize {
        self.value
            .as_ref()
            .expect("prepared producer already disposed")
            .slots()
    }
}
impl<T> NativePreparedConsumer<T> {
    pub(crate) fn pop(&mut self) -> Result<T, rtrb::PopError> {
        self.value
            .as_mut()
            .expect("prepared consumer already disposed")
            .pop()
    }
    pub(crate) fn peek(&self) -> Result<&T, rtrb::PeekError> {
        self.value
            .as_ref()
            .expect("prepared consumer already disposed")
            .peek()
    }
    pub(crate) fn is_empty(&self) -> bool {
        self.value
            .as_ref()
            .expect("prepared consumer already disposed")
            .is_empty()
    }
    pub(crate) fn buffer(&self) -> &rtrb::RingBuffer<T> {
        self.value
            .as_ref()
            .expect("prepared consumer already disposed")
            .buffer()
    }
}
impl<T> Drop for NativePreparedProducer<T> {
    fn drop(&mut self) {
        if let Some(storage) = self.storage.as_mut() {
            let _ = storage.begin_actual_endpoint_drop_on_control();
        }
        drop(self.value.take());
        if let Some(storage) = self.storage.as_mut() {
            let _ = storage.complete_actual_endpoint_drop_on_control();
        }
    }
}
impl<T> Drop for NativePreparedConsumer<T> {
    fn drop(&mut self) {
        if let Some(storage) = self.storage.as_mut() {
            let _ = storage.begin_actual_endpoint_drop_on_control();
        }
        drop(self.value.take());
        if let Some(storage) = self.storage.as_mut() {
            let _ = storage.complete_actual_endpoint_drop_on_control();
        }
    }
}

#[cfg(all(test, feature = "allocation-probe"))]
#[path = "registered_tests.rs"]
mod registered_tests;
