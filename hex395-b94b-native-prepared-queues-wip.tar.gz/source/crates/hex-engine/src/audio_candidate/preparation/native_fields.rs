//! Exhaustive children of an actual unpublished collecting preparation field.
use super::*;
impl AudioCandidatePreparation {
    pub(crate) fn visit_sampler_host_children<'a>(
        &'a self,
        ledger: &mut crate::AudioRootStorageLedger<'a>,
    ) -> Result<(), AudioStorageError> {
        let Self {
            sources,
            resident_draft,
            reservation: _,
            bank,
            custody,
            token,
            draft,
            owner,
            control_work,
            owner_runtime_done,
            original_resource_attempted: _,
            original_resource_refused,
            cleaning,
            complete,
            failed,
            first_panic,
        } = self;
        if *failed
            || *cleaning
            || *complete
            || *original_resource_refused
            || first_panic.is_some()
            || token.is_some()
            || owner.is_some()
            || control_work.is_some()
            || *owner_runtime_done
        {
            return Err(AudioStorageError::UnknownStorage);
        }
        ledger.vec(sources)?;
        for (_, source) in sources {
            ledger.embedded_native_source(source)?;
        }
        ledger.vec(resident_draft)?;
        if let Some(bank) = bank {
            ledger.inputs(bank)?;
        }
        let custody = custody.as_ref().ok_or(AudioStorageError::SourceMismatch)?;
        if custody.phase() != AudioPreparationPhase::Vacant {
            return Err(AudioStorageError::UnknownStorage);
        }
        custody.visit_audio_storage(ledger, crate::AudioStorageRole::Current)?;
        draft
            .as_ref()
            .ok_or(AudioStorageError::SourceMismatch)?
            .visit_unconstructed_host_children(ledger)
    }
}
