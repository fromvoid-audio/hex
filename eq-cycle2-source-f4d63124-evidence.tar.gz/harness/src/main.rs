use hex_engine::eq::{self,EqState,Node,NodeId};
use hex_lattice_contract::NativeDeviceState;
mod fixed { include!("fixed.rs"); pub fn sample(s:&EqState,r:u32)->Vec<f32>{frequencies(s,r)} }
mod baseline { include!("baseline.rs"); }
fn one(f:f32,q:f32)->EqState {let mut s=EqState::default(); let mut n=Node::new(NodeId::new(1).unwrap(),f,0.0,0).unwrap(); n.kind=eq::NodeKind::Notch;n.q=q;s.add(n).unwrap();s}
fn check(s:&EqState,r:u32)->usize {
 let fs=fixed::sample(s,r); assert!((2..=256).contains(&fs.len())); assert!(fs.windows(2).all(|w|w[0]<w[1]));
 let upper=(r as f32*0.49).min(20000.0); assert_eq!(fs[0],20.0); assert_eq!(*fs.last().unwrap(),upper);
 for n in s.nodes.iter().filter(|n|n.enabled){assert!(fs.contains(&n.frequency_hz.min(r as f32*0.49).clamp(20.0,upper)));}
 let a=s.encode().unwrap(); let cs=fixed::curves(&a,s,r).unwrap(); let oracle=hex_engine::native_effect_frequency_response(&a,r,&fs).unwrap().unwrap();
 for c in 0..2 {assert_eq!(cs[c].len(),fs.len());for (i,p) in cs[c].iter().enumerate(){assert!(p.iter().all(|x|x.is_finite()&&(0.0..=1.0).contains(x)));if i>0{assert!(p[0]>=cs[c][i-1][0]);} let x=(fs[i]/20.0).ln()/(upper/20.0).ln();assert!((p[0]-x).abs()<1e-6);let y=((oracle[i][c].max(1e-5).log10()*20.0+24.0)/48.0).clamp(0.0,1.0);assert!((p[1]-y).abs()<1e-6);}}
 fs.len()
}
fn main(){
 let args:Vec<_>=std::env::args().collect();
 if args.get(1).is_some_and(|x|x=="baseline"){
  let s=one(1000.0,18.0);let a=s.encode().unwrap();let cs=baseline::curves(&a,&s,48000).unwrap();let y=cs[0].iter().map(|p|p[1]).fold(1.0,f32::min);println!("baseline notch minimum normalized={y} db={}",y*48.0-24.0);assert!(y<0.001,"original notch display failure independently reproduced");return;
 }
 let s=one(1000.0,18.0);let cs=fixed::curves(&s.encode().unwrap(),&s,48000).unwrap();let expected=(1000.0_f32/20.0).ln()/(20000.0_f32/20.0).ln();assert!(cs[0].iter().any(|p|(p[0]-expected).abs()<1e-6&&p[1]<0.001));println!("fixed original notch: center location and floor PASS");
 let mut cases=0; let mut maxpoints=0;
 for r in [8000,44100,48000,96000,192000]{let mut s=EqState::default();for i in 0..64{let f=24.0*(120.0_f32.ln()*i as f32/63.0).exp();let mut n=Node::new(NodeId::new(i+1).unwrap(),f,6.0,(i%5) as u8).unwrap();n.q=18.0;s.add(n).unwrap();}let p=check(&s,r);assert_eq!(p,256,"all64 distinct feature anchors plus background fit full budget");maxpoints=maxpoints.max(p);cases+=1;}
 println!("full 256-query budget: all64 enabled/distinct centers+shoulders, five rates PASS");
 println!("rate,count,mode,pattern,queries");
 for r in [8000,44100,48000,96000,192000] {for count in [0,1,32,53,54,63,64] {for mode in 0..3 {for pattern in 0..3 {
  let mut s=EqState::default();s.mode=mode;
  for i in 0..count {let f=match pattern{0=>(20.0*(1000.0_f32.ln()*i as f32/63.0).exp()).min(20000.0),1=>1000.0,_=>if i%2==0{20000.0}else{20.0}};let mut n=Node::new(NodeId::new(i as u64+1).unwrap(),f,if i%2==0{12.0}else{-12.0},(i%5) as u8).unwrap();n.q=if i%2==0{18.0}else{0.1};n.kind=match i%6{0=>eq::NodeKind::Bell,1=>eq::NodeKind::Notch,2=>eq::NodeKind::LowCut,3=>eq::NodeKind::HighCut,4=>eq::NodeKind::LowShelf,_=>eq::NodeKind::HighShelf};if pattern==2{n.enabled=i%3!=0;}s.add(n).unwrap();}
  let p=check(&s,r);maxpoints=maxpoints.max(p);cases+=1;println!("{r},{count},{mode},{pattern},{p}");
 }}}}
 // State/rate/key changes must produce a different response; this is helper coverage,
 // NOT an executed EditorView cache or GUI test.
 let s=one(1000.0,18.0); let mut moved=s.clone();moved.nodes[0].frequency_hz=8000.0;assert_ne!(fixed::curves(&s.encode().unwrap(),&s,48000),fixed::curves(&moved.encode().unwrap(),&moved,48000));
 moved.nodes[0].enabled=false;assert!(fixed::curves(&moved.encode().unwrap(),&moved,48000).unwrap()[0].iter().all(|p|(p[1]-0.5).abs()<1e-6));
 println!("PASS: {cases} helper/API cases; maximum queries={maxpoints}; all active centers, actual log x, both output curves, full capacity/banks/modes, collisions, disabled and rate clamps");
}
