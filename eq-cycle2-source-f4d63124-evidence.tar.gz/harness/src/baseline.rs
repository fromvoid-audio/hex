use super::*;

pub(super) fn curves(
    authored: &NativeDeviceState,
    _state: &EqState,
    rate: u32,
) -> Option<[Vec<[f32; 2]>; 2]> {
    let upper = (rate as f32 * 0.49).min(20000.0);
    let frequencies: Vec<_> = (0..96)
        .map(|i| 20.0 * ((upper / 20.0).ln() * i as f32 / 95.0).exp())
        .collect();
    let response =
        hex_engine::native_effect_frequency_response(authored, rate, &frequencies).ok()??;
    Some(std::array::from_fn(|channel| {
        response
            .iter()
            .enumerate()
            .map(|(i, m)| {
                [
                    i as f32 / 95.0,
                    ((m[channel].max(0.00001).log10() * 20.0 + 24.0) / 48.0).clamp(0.0, 1.0),
                ]
            })
            .collect()
    }))
}
