# Independent EQ cycle 2 — source/portable handoff

Pulse2785 / canonical draftPR391. Reviewer cloud6 did not author cycle1PR390.
Scope: READ-ONLY SOURCE and portable tests/evidence, no implementation or PR edits.
Pinned source f4d631248c2ae02db31f07c8a7e882e80a550913; tree e5639cac4d9e163dcb58cc835dd254ee6b5a0bef.
The three examined cycle1 implementation/test files are byte-identical between tested cycle1a821ccc69ab089aaf671ada680c8361dd740ba8f and f4.
Source worktree /workspace/hex-eq-cycle2 is detached and clean; original /workspace/hex unchanged at327ebe98. No branch/commit/push, app/Mac operation or duplicate full20 run.

## Findings

No NEW actionable source correctness defect found in this bounded pass. This is not whole-cycle acceptance, sonic/reference parity, native GUI acceptance or a universal interpolation-error guarantee.

### Executed evidence

1. Recovered immutable evidence-only2721968f archive hex-eq-cycle1-evidence.tar.gz (144723bytes/SHA9f6305fb1255babca6b2d0a0eaa79ea4571e0ef48b7ec0618d22671e41394064). Verified safe unique regular relative members and all62payload manifest hashes; never checked out/built evidence ref. Read BEFORE-REPRO, original red/green, insufficient-window/inconclusive PCM log, final addendum and required-CI summary. Original evidence preserved unchanged.
2. Independent scratch harness uses UNMODIFIED production helper bodies, with only module doc wrappers/test sections removed for standalone inclusion. Baseline is retained pre-repair helper; native response calls bind actual pinned hex-engine and its local path-dependency sources. No copied/mock DSP or alternate response oracle. Original 48k/1k/Q18 notch assertion reproduces actual model failure: normalized0.36088595 / -6.677475dB, exit101. Fixed source passes exact center-log-position and -24dB display-floor assertion. This is graph-model/helper evidence, not GPUI rendering/pixels.
3. 320 bounded helper/API cases PASS:5rates(8/44.1/48/96/192k);0/1/32/53/54/63/64 nodes;3modes;5bank distribution; mixed six shapes; Q0.1/18; distinct/colliding centers; disabled subsets;20Hz/high authored and0.49rate clamp. Every active center survives; sorted/deduplicated frequency queries and normalized finite ordered coordinates; both channel curves match actual response queries. Five additional all64-enabled distinct feature-anchor cases exercise EXACT256queries. Bound is64background+3x64anchors; no center cap. The 320 includes those5full-budget cases. Disabled and moved-state smoke cases also pass. Table in fixed.log; source/lock retained in harness/.
4. Actual repository tests executed unchanged at pinned f4:
   CARGO_TARGET_DIR=/workspace/scratch/eq-cycle2/target cargo test -p hex-devices --lib --locked plotted_response_matches_actual -- --nocapture
   2PASS/0FAIL/0ignored,34.31s. Original cut impulse regression and504-query six-shape/allcutslopes/fiverates/extremes audit; maximum relative error0.0007426099225554888dB, opposite-polarity preservation and settled tails. Existing fixed0.05dB above-80dB /1e-5absolute below and tail criterion unchanged. This is independent execution of existing PCM tests, not independent authorship of those tests.
Toolchain Rust/Cargo1.94.0; Linux x86_64. Activated existing cloud toolchain (documented16MiB test stack; no claim default native stack from cloud run). Small scratch target contains only this bounded build; no Cargo jobs remain. No benchmark/timing claim from wallclock test duration.

### Source inspection (not executed whole-UI/cache integration)

- eq_panel/response.rs10–54: validated EqState64maximum, bounded base+3enabled sampler, exact0.49rate clamp, sorting/dedup, per-Hz log x; allbank anchors intentionally included even when inactive in currentmode; actual runtime filters applicable banks. Disabled nodes contribute no anchors; no DSP/Q/filter law changed.
- eq_panel.rs759–815: displayed creation/drag/effective scalar state is encoded before cache lookup; full effective NativeDeviceState plus rate form key. Successful recalculation replaces two owned bounded vectors; bank switching selects cached channel rather than dropping another bank's anchors. Static cache payload <=4096B plus returned model's own <=4096B, excluding allocator overhead/authored key/model-node/UI storage. This is not a whole-app memory bound.
- generation change removes panel at119; existing device navigation clears panels/device spectra. No reference into a retired runtime/cache escapes; curve vectors owned by panel/widget model. No callback or automation code changed in390.
- spectrum target identity/token/generation/rate/revision filtering remains in eq_panel.rs838+, controller.rs678+; reader freshness expiry remains spectrum_worker.rs253+. These were inspected, not newly instrumented physical churn/deadline tests.
- Actual shared widget validation permits 2..256 finite normalized ordered curve points. Harness checks relevant curve constraints directly; does not import GPUI or claim it executes ResponseGraphModel::validate/set_model/paint.
- Existing accepted gestures2729, spinner2760, stable automation IDs and64maximum are preserved; no historical migration reader work or advanced-feature implementation.

### Official reference matrix audit

Read current official moving help (2026-10-17):
https://www.fabfilter.com/help/pro-q/
https://www.fabfilter.com/help/pro-q/using/eqdisplay
https://www.fabfilter.com/help/pro-q/using/analyzer
The28-row cycle1matrix appropriately distinguishes implemented/source evidence, unverified native tasks, deliberate current boundaries and deferred features. Multi-band editing, axis/wheel-Q workflow, adjustable graph/analyzer scales, external/instance traces, A/B and advanced phase/dynamic/spectral/sketch/match capabilities are not silently claimed achieved. Official workflow documents multiple-band selection, fine/constrained edits and separate response/analyzer scales; analyzer docs describe selectable traces/range/resolution/speed/tilt. No installed Pro-Q4 binary or version/settings observed; no direct A/B or listening. Earlier docs' installeddfa/pending390 wording is historical source-frozen context superseded by live coordinator provenance, not current installed-app assertion.

## Native phase remains OPEN — coordinator owns serial Mac lane

Coordinator independently reports actual installed f4/version0.1.0/build4107677988, signedexe e2ef1876323f6fb43727fa4759fb30d2dd77228ea4c4f8b7e77a73675afb103a, cloud20/20d8ca4d4c... and native20/20 024fde06..., signed/sealed/adjacent receipts/all46heads/READY owner and workspace absent. This review did not access physical Mac/raw native receipt files, launch Hex or change installed app. User away/Mac locked/Hex closed; no self-dispatch or implicit permission to launch. Installer review is unrelated evidence.

Concrete next actions for root:
1. Accept/reject this source-phase handoff; no bounded source repair selected because no new defect proved. Keep2785 open/in_review; canonical391 unchanged planning draft, no duplicate issue/PR.
2. When root schedules user-present single Mac lane, bind running optimized app/source/build/exe to above receipts. No replacement needed for unchanged reviewed f4. Capture notch floor/location, all64banks/clamped rate, compact880x540 vs expanded1500x650, original theme/contrast/readouts, exact numeric/focus, hover/rapid redraw and track/device/source changes, Escape/cancel.
3. Finite disposable bass/kick correction, resonant percussion and broad tonal tasks using identified media/project: record actual steps/time/misclicks against cycle1 (missing baseline must be reported, not invented). Include two/maximum-admitted instances, bypass/listen, Undo/Redo, automation and current-format save/reopen; preserve stable IDs and user projects.
4. Level/response-matched listening using identified reference version only if legitimately available; raw physical callback/worker/GPU/cost evidence at fixed rate/buffer/workload. Missing instrumented deadlines/reference/listening remain explicitly UNRUN. Existing deterministic PCM/alloc tests are not listening or deadline proof.
5. Any native finding returns root for duplicate check and bounded owner repair, followed by affected independent regression/required exact checks/new qualified source-bound build if source changes. No advanced Pro-Q feature expansion by inference.

Executed helper tests do NOT independently exercise full EditorView cache/GPUI gestures; cache invalidation/lifetime findings above are source inspection only. Human workflow, physical GPU/driver/callback deadlines, listening, native focus/layout and save/reopen remain required open acceptance. No wholecycle Done claim.
