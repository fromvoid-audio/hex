import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-workspace-tab-489');spec=importlib.util.spec_from_file_location('hex_ci_491',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(
 m.Step('architecture',('python3','scripts/check-architecture.py')),
 m.Step('ui-style',('python3','scripts/check-ui-style.py')),
 m.Step('gpui-patch',('python3','scripts/check-gpui-patch.py')),
 m.Step('device-layout',('python3','scripts/check-device-layout.py')),
 m.Step('touched-fmt',('rustfmt','--edition','2024','--check','crates/hex-widgets/src/numeric_control.rs','crates/hex-widgets/src/lib.rs','crates/hex-widgets/src/numeric_control/compact_slider_tests.rs','crates/hex-ui/src/editor/track_gain.rs','crates/hex-ui/src/editor/track_gain/tests.rs')),
 m.Step('diff-check',('git','diff','--check')),
 m.Step('widget-controls',('cargo','test','-p','hex-widgets','--lib','--locked','--','--nocapture')),
 m.Step('header-controls',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','track_gain::tests','--','--nocapture')),
 m.Step('strict-default',('cargo','clippy','-p','hex-ui','-p','hex-widgets','--all-targets','--locked','--','-D','warnings')),
 m.Step('strict-feature',('cargo','clippy','-p','hex-ui','-p','hex-widgets','--features','hex-ui/ui-test-support','--all-targets','--locked','--','-D','warnings')),
)
raise SystemExit(m.LocalCiRunner(root=root,mode='quick',steps=steps).run())
