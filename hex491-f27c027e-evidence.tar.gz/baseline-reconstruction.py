import pathlib,subprocess,hashlib,json,os,difflib
root=pathlib.Path('/workspace/hex-workspace-tab-489');base='59054702cc2ff17c12259d7c8e7613b357619694';test='crates/hex-ui/src/editor/track_gain/tests.rs'
def before(p):return subprocess.check_output(['git','show',base+':'+p],cwd=root).decode()
current=(root/test).read_text();new=current[current.index('#[gpui::test]\nfn header_pan_vertical_drag_direction'):]
baseline=before(test)+'\n'+new
paths=subprocess.check_output(['git','diff',base,'HEAD','--name-only'],cwd=root,text=True).splitlines();overrides={p:before(p) for p in paths};overrides[test]=baseline
d=hashlib.sha256()
for rel in sorted(x for x in subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0') if x):
 p=root/os.fsdecode(rel);d.update(len(rel).to_bytes(8,'big'));d.update(rel)
 if p.is_symlink():d.update(b'symlink\0');d.update(os.fsencode(os.readlink(p)))
 else:d.update(b'file\0');d.update(overrides[os.fsdecode(rel)].encode() if os.fsdecode(rel) in overrides else p.read_bytes());d.update(str(p.lstat().st_mode&0o111).encode())
expected=json.load(open(root/'artifacts/local-ci/20261020T060740Z-4edcf1c9/summary.json'))['source_identity']['content_sha256'];assert d.hexdigest()==expected,(d.hexdigest(),expected)
patch=''.join(difflib.unified_diff(before(test).splitlines(True),baseline.splitlines(True),fromfile='a/'+test,tofile='b/'+test));pathlib.Path('/workspace/scratch/491-baseline-exact.patch').write_text(patch);print(json.dumps({'exact_negative_source_digest':expected,'patch_bytes':len(patch.encode())}))
