# Root serial native compile + tests

Exact source08ad5e12a08ebd68868dd6dead5e5dc33e418818/treecf3e11280785df7c761c0929f16a2af682ddee6d, original normal Rust1.94/nativeaarch64/default stack/private legitimate target with existing component guard. Source clean/materialized byte+mode manifest match, retain old626 failure unchanged; do not patch native checkout or normalize source/report. No app build/install/launch/picker/user inputs/quit/signals/TCC/keychain/profile/media operations.

```sh
cargo test -p hex-ui --features ui-test-support --lib --locked editor::project_directory::tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked editor::dialogs::ui_tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked browser_test_environment_ -- --nocapture
```

Require15+31+5=51uniquePASS0ignored, overall Cargo/runner0, including actual mac Foundation NSURL rawbytes/case/NUL pure probe; no panel shown. First require compilation passes actual formerly E0603 call. Stop on actual failure; no skip/waiver/sourcepatch. Parent626 codec5 alreadyPASS; codec source unchanged so no need repeat solely for bridge delta. If coordinator needs complete current four-command packet, optionally first cargo test -p hex-preferences --lib --locked project_directory::tests:: -- --nocapture [5] and report56 truthfully. Old626codec remains own historical source identity.

This qualifies components only, not physical OS picker presentation/real-directory initial selection/user acceptance/fullprospectiveCI. Later manual disposable-project picker acceptance remains pending. Solemerger full exact integrated requiredCI/review, compose qualified452 header before broad native delivery. No whole-app or old suites repeated just to fix this test bridge.
