import pathlib,subprocess,hashlib,json,difflib,os
root=pathlib.Path('/workspace/hex-workspace-tab-489');base='4fda283dac2a6a60150dcd6454165bf4bcafd8dc'
def before(p):return subprocess.check_output(['git','show',base+':'+p],cwd=root).decode()
a='crates/hex-ui/src/editor/arrangement_seek.rs';t='crates/hex-ui/src/editor/device_panel/tests/eq_held_pointer_tests.rs'
s=before(a);current=(root/a).read_text()
block=current[current.index('// Scalar-only'):current.index('pub(super) trait SeekAudioControl')]
s=s.replace('pub(super) trait SeekAudioControl',block+'pub(super) trait SeekAudioControl',1)
old='''    fn retire_seek_result(&mut self, result: ArrangementSeekResult) {
        if let Err(result) = self.service.retire_arrangement_seek_result(result) {
            self.retired_seek_result = Some(result);
        }
    }'''
new='''    fn retire_seek_result(&mut self, result: ArrangementSeekResult) {
        #[cfg(test)]
        let identity = (
            result.request_id,
            Arc::as_ptr(&result.prepared_revision) as usize,
        );
        if let Err(result) = self.service.retire_arrangement_seek_result(result) {
            #[cfg(test)]
            LAST_SEEK_RETIREMENT.set(Some((identity.0, identity.1, false)));
            self.retired_seek_result = Some(result);
        } else {
            #[cfg(test)]
            LAST_SEEK_RETIREMENT.set(Some((identity.0, identity.1, true)));
        }
    }'''
assert old in s;s=s.replace(old,new)
currenttest=(root/t).read_text();test=currenttest[:currenttest.index('\n#[gpui::test]\nfn eq_held_node_retirement_fallback')]
# Appending the second test left one separating newline after the first test.
test=test.rstrip()+'\n'
overrides={a:s,t:test}
changed=subprocess.check_output(['git','diff',base,'HEAD','--name-only'],cwd=root,text=True).splitlines()
for p in changed:
 if p not in overrides: overrides[p]=before(p)
digest=hashlib.sha256()
paths=sorted(p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0') if p)
for rel in paths:
 p=root/os.fsdecode(rel);digest.update(len(rel).to_bytes(8,'big'));digest.update(rel)
 if p.is_symlink():digest.update(b'symlink\0');digest.update(os.fsencode(os.readlink(p)))
 else:digest.update(b'file\0');digest.update(overrides.get(os.fsdecode(rel),p.read_text() if False else '').encode() if os.fsdecode(rel) in overrides else p.read_bytes());digest.update(str(p.lstat().st_mode & 0o111).encode())
expected=json.load(open(root/'artifacts/local-ci/20261020T055325Z-393a11af/summary.json'))['source_identity']['content_sha256']
assert digest.hexdigest()==expected,(digest.hexdigest(),expected)
patch=''.join(''.join(difflib.unified_diff(before(p).splitlines(True),overrides[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in [a,t])
pathlib.Path('/workspace/scratch/483-baseline-exact.patch').write_text(patch)
print(json.dumps({'baseline_source_digest_verified':expected,'patch_bytes':len(patch.encode())}))
