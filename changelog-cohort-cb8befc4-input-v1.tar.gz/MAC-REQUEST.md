# One configured CLI request — root serial Mac lane only
This is the REAL merged user-facing cohort, not the earlier empty fixture.
No Hex app/build/install/launch/save/quit/profile/permissions/config/credentials/provider changes.
Use already configured codex CLI/ChatGPT account only. No model override or API fallback.
Input covers explicit named Git base/source in input.json; no prior release/install is assumed.
Copied immutable packet files are data. Never build an evidence ref.
Run once in a retained private work directory after verifying INPUTS/PAYLOADS hashes:

codex exec --ephemeral --sandbox read-only --skip-git-repo-check --output-schema /ABS/schema.json --output-last-message /OWNED/result.json --json -

Feed EXACT prompt.txt bytes on stdin; cwd owned private directory. Python subprocess.run(timeout=120) bounds it on macOS without requiring GNU timeout. Capture original JSONL/stdout and stderr in private files. No tools are requested/permitted by prompt. Existing CLI transport fallback is internal; do not manually retry or change settings.
Success requires overall exit0 plus actual result.json, valid schema, lowercase concise end-user entries citing only supplied commit IDs. Preserve exit/logs/model output/file SHA256 and actual CLI version/login execution origin, including failures. Empty entries require a real reason. This is actual generation capability/declared-range output, not proof of installed app, final candidate fullCI or unattended cloud success. Return original output+receipt via immutable evidence transport for repository adapter validation/import. Cloud route already returned403 twice; do not repeat there.
