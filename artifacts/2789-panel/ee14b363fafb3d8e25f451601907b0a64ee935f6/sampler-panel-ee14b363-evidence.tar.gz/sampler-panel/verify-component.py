import datetime,hashlib,json,os,pathlib,platform,re,subprocess,time
out=pathlib.Path('artifacts/sampler-panel-mvp')
def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
env['PATH']='/opt/homebrew/opt/python@3.13/libexec/bin:'+env['PATH']
steps=[
('final-leaf', ['cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','sampler_ui_tests','--','--nocapture']),
('final-engine-bridge', ['cargo','test','-p','hex-engine','--locked','--lib','sampler_parameters','--','--nocapture']),
('final-session-retained', ['cargo','test','-p','hex-session','--locked','--lib','snapshot_exports::','--','--nocapture']),
('final-strict-default', ['cargo','clippy','-p','hex-ui','--all-targets','--locked','--','-D','warnings']),
('final-strict-feature', ['cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings']),
('final-quick', ['python3','scripts/local-ci.py','--quick']),
('final-format', ['cargo','fmt','--all','--check']),
('final-diff', ['git','diff','--check']),
]
font=pathlib.Path('assets/fonts/ioskeley-mono/ioskeley-mono-regular.ttf')
report={'source':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'branch':git('branch','--show-current'),'base':'b94b0e2f6fbec0932d422c00d4584739c192cb9a','imported_bridge':'5705c482','original_bridge':'1d5b89a2f658a22cb9c1f76c5bfc1631326e192d','initial_status':git('status','--porcelain'),'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','-vV'],text=True),'python':subprocess.check_output(['python3','--version'],env=env,text=True).strip(),'environment':{k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']},'steps':[],'font':{'path':str(font),'sha256':hashlib.sha256(font.read_bytes()).hexdigest(),'measurement':'headless CoreText actual bundled family Ioskeley Mono at9pt,16777216 advance43.2px; compactdial field64px leaves58px. See coretext-font-measure.log.'},'status':'explicitly unintegrated component; Native retained UI capability and binding migration required','merge_qualified':False,'native_acceptance':False}
for name,argv in steps:
 start=time.monotonic(); log=out/(name+'.log')
 with log.open('w') as stream: result=subprocess.run(argv,env=env,stdout=stream,stderr=subprocess.STDOUT)
 text=log.read_text()
 entry={'name':name,'argv':argv,'exit_code':result.returncode,'elapsed_s':round(time.monotonic()-start,3),'log':log.name,'results':re.findall(r'test result: (.+)',text)}
 report['steps'].append(entry)
 (out/'component-summary.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,result.returncode,entry['results'],flush=True)
report['final_source']=git('rev-parse','HEAD');report['final_tree']=git('rev-parse','HEAD^{tree}');report['final_status']=git('status','--porcelain')
report['unchanged_clean_source']=report['source']==report['final_source'] and not report['initial_status'] and not report['final_status']
report['all_checks_passed']=all(step['exit_code']==0 for step in report['steps'])
report['limitations']=['No actual UI SnapshotRead/stamp/adapter entry exists on this component; no parent dispatch, registry/load/source/current fallback or invented stamp.','Feature-only module mount leaves strict dead_code failures in default and feature configurations.','Device-layout guard deliberately requires the missing real instrument dispatch; quick remains failed, not merge evidence.','Leaf fixtures use real widgets from production section recipes plus actual metadata descriptors; scalar display facts are test data, not canonical playback/admission.','GPUI mock font registration probe failed; retained as setup evidence. Font advance is independently measured with headless CoreText on the actual bundled file, no physical paint/user acceptance.','No app stop/launch/install/rebuild-in-place, hosted CI or merge.']
(out/'component-summary.json').write_text(json.dumps(report,indent=2)+'\n')
