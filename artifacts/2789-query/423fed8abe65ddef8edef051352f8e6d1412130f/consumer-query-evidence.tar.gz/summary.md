# Sampler UI consumer query check

- Checkout HEAD while checked: `0fcdc40a135790700d023d6976250b80287105f1`.
- Modified query sources were uncommitted at check time. Final `ui_consumers.rs` SHA-256: `8dbfa5096e3dddb6b664b73c1843fb8491ad7ee5206ab145443e26881f62e31a`.
- `cargo test -p hex-session --locked snapshot_exports::model_read`: first attempt failed because test fixtures called crate-private `Project::apply`; fixtures were corrected to use public `Editor::execute`. Retry passed 5 tests, including retained snapshot tests and 3 new reader behavior tests.
- Final rerun after adding Stop-versus-Empty coverage passed the same 5 tests; raw log `session-model-read-final.log`, SHA-256 `a6ba1b53fd2ef90a5584534bc4dcab1e17a10a81155f4360b3487c46c7bfe5f4`.
- `cargo check -p hex-session --locked --lib`: passed.
- `cargo clippy -p hex-session --locked --lib -- -D warnings`: passed. The build script emitted its existing diagnostic that the PCM declared Arc layout is `Unknown` due to `unsupported_wrapper_or_ambiguous_flags`; Clippy reported no denied warnings. Raw log `session-lib-clippy.log`, SHA-256 `924a2675aef2faf84f2f3828ef36003fd4eed5ba1b294b84087480060fbc82f3`.
- `rustfmt --edition 2024` on `model_read.rs` and `model_read/ui_consumers.rs`: passed.
- `git diff --check` on both query source paths: passed.

Raw logs:

- `session-model-read.log` (initial expected fixture-access failure), SHA-256 `1fcdde0c357d292e5ef93cc09c34b2788c23776bf8615d31e08f78d1a3031797`.
- `session-model-read-retry.log` (5 passed), SHA-256 `17e905c7e6ce36ec110df627d1940caf88046cb8ac9da3091aca664396f3ce31`.
- `session-lib-check.log` (passed), SHA-256 `41cde279ad2ee7c5f5dd1dec41073c4f72239c705b958264e77ab9b2de1ef8b3`.

This is targeted component evidence only. It does not qualify PR395, the combined Session/UI migration, native playback, or user acceptance.

Published source component `423fed8abe65ddef8edef051352f8e6d1412130f` contains only the child and its module mount. Exact Native central re-export `2b867c64350b009ca80633a8ec6f2b608dae2153` composed as `4cbdd1c9`; `cargo check -p hex-session --locked --lib` on that mounted source passed (session-mounted-check.log). UI working changes remain uncommitted, incomplete and unqualified; no UI or native readiness claim.
