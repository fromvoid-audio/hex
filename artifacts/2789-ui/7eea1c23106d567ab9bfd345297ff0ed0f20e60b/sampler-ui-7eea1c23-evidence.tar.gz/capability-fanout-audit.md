# actual UI retained-read fanout audit

Source baseline: component4cbdd1c9 plus incomplete UI reader migration. Actual controller algorithm is still baseline b94; this is source inspection, not a runtime qualification.

Four field types do not imply four live capability instances. Let Q be playback_candidates length, R the pending_resident_publication slot including its temporary local after take, P pending_playback, A audible_playback, C current. P,A,C are independently at most1. New receive can refill P while R is outstanding.

Actual mutation inventory (repository-wide search found only these production candidate pushes/resident assignments):
- Submitted observation increments Q only if Q<32. R may be1; do not assume the modes make this impossible without proof.
- Resident admission makes R=1 only if R=0 and Q<32, moving P into it.
- Resident successful ACK consumes R then increments Q, preserving Q+R.
- Failed ACK consumes R and replaces P; wrong-token ACK restores the same R.
- Promotion and rejection pruning reduce Q; replacing audible moves the popped candidate. Reset/close/recovery reduce holdings.

Therefore conservative invariant Q+R<=33, even though nominal candidate admission capacity is32. Existing aggregate held cache reads C+P+A+Q+R<=36. This requires descendant clip/draw caches to be scalar-only, with no additional retained read. A promotion-local candidate is counted by the removed queue slot, not an extra persistent role.

Actual source mapping and operation fanout:
- Event canonical source moves into current, except early completion branches retaining existing current.
- Resident playback pending source chooses matching generation/canonical revision device preview first, otherwise tuning preview, otherwise canonical. Canonical current plus canonical pending needs one extra derived read; distinct preview can move its own Event source.
- Event receive does not simultaneously create resident/candidate/audible copies. Those transitions move pending -> resident -> candidate -> audible.
- Submitted observation needs one current-derived candidate read. Actual backend canonical ACK fallback needs one current-derived audible read, only with exact backend association.
- Thus receive requires at most two simultaneous new receiver roles (current and pending), rather than deriving all four categories on every event. Native fixed-four preflight may conservatively reserve more, but no new cache or invented authority is justified by that reservation.

Native must compose this actual old-held bound with its exact queue/head/producer/Initial/released-read representation. The arithmetic36+2*3+4+3=49 is only a conservative input to that audit, not a certified minimum or authorization to raise a configured table cap. Queued/head source double-counting and real producer roles must be resolved from actual implementation. Released records remain occupied until durable control collection; releases and inactive cached roles are not immediately vacant slots. Both receiver fanout and out-of-event single derives must preserve progress for the same head. On refusal retain the actual event/observation/ACK and all UI drafts without partial effects; continue ACK/retirement collection then retry via existing tick.

No tests or app operations were run for this source audit. Saturated queued-events/current/preview/candidates/audible eventual progress still requires actual endpoint regression coverage.
