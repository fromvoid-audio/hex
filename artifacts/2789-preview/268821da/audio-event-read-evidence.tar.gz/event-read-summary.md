# borrowed audio event root continuation

Frozen candidate tree `c5f23a25602ea50e74664e121e063296d76e0fd5` on published base `0d8ea48b411ed3ecdf9b435fc30b2e2c74d9cf35` (tree `6248145e3dea427c54bb82bee3dff29cdc3e44e4`). Source remains uncommitted for primary publication. The10-file manifest is `event-read-source-inputs.json`, SHA256 `9b0883db002c8f8fe3b084c9864da7d299650539f11e9dc906e928ca22013a29`.

## behavior

`Clip::with_audio_event_root` supplies an opaque HRTB borrowed read with Copy current/default root/domain facts, complete actual warp/source-gain/stored-fade-tempo point streams and shared root/frame conversion. Capture uses the same scalar default factory; actual owning capture/container construction stays outside reads. Facts/counts are not a full-domain identity token.

Editable events borrow the source and apply two Copy overlays using the same interior split law as canonical owning Split. Hidden intervals, implicit ID1/next2, start-then-end fresh IDs, the full-view shortcut, original-geometry/range/intermediate error order and canonical1024 plus2 virtual fragments are preserved. Setup uses existing16KiB identity scratch and O(n log n) work; iteration is O(n+2) with constant per-event state.

The new cropped borrowed API explicitly refuses noncanonical authored sources already >1024, before bounded scratch. Owning helper behavior and full-view shortcut remain unchanged, and canonical Project validation rejects that state. The unit fixture checks this exact distinction, both ID-exhaustion stages and malformed geometry priority. No arbitrary gesture-preview or clipboard engine was added.

## continuation checks

- Initial Project check PASS; initial literal/error/max units4 PASS; current/default/frozen-point integration4 PASS. The unit-filter command also emitted an honest0-test integration result; log33 runs those4 directly.
- Final targeted Project48 PASS: new integration4 plus existing owning44.
- Final event units9 PASS: new boundary4 plus existing event5.
- Doc tests5 PASS, including the new root-read HRTB escape compile-fail.
- Audio tests5 PASS: allocation tests3 plus sensitivity calibration2. All25 measured cases reported zero total and signed-net allocation count/bytes; the5 new root cases cover actual default, retained full, implicit crop, authored empty and actual1024+2 virtual events. Fixture/oracle creation and ownership destruction occur outside measure.
- Project all-target strict Clippy, targeted Audio feature strict Clippy, formatting, architecture and diff checks PASS.

No failures occurred in this continuation. Raw continuation logs only: 31-event-read-initial-check.log, 32-event-read-literal-boundaries.log, 33-event-root-current-default-parity.log, 34-event-read-owning-regressions.log, 35-event-read-unit-boundaries.log, 36-event-read-project-strict.log, 37-event-read-docs.log, 38-event-read-allocation.log, 39-event-read-audio-strict.log, 40-event-read-format.log, 41-event-read-architecture.log, 42-event-read-diff.log. Prior archives/manifests are untouched and are not repacked or relabeled.

## remaining

Primary owns publication, Session/UI/Native composition and exact combined-source required CI. This is component evidence, not a workspace/full/native qualification or app delivery. No history exports, manifests, dependencies, UI/Session source or app state changed.
