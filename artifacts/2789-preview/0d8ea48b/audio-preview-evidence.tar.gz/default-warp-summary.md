# default warp Copy helper follow-up

Candidate tree `6248145e3dea427c54bb82bee3dff29cdc3e44e4` on exact modern-main base `b05a9eaa61edc60f711acdc06d907f7525d6197c`; source remains uncommitted for primary publication. Manifest `default-warp-source-inputs.json` SHA256 `8ffc1a1447a038ccf4cd0e4618de4bb7b6bc94b0e26c0e94bb58f78fa07fe4d4`.

Added `hex_project::default_audio_warp_markers(&Clip, &TempoMap) -> Result<[WarpMarker; 2], Invalid>`. It uses the same borrowed anchor/default plan as stretch and creates no model, domain, marker-list or tempo owner. Owning `default_audio_warp` calls it before materializing its Vec outside reads. Provider mode validation and resource admission remain separate, preserving the existing helper contract.

Targeted tests cover literal source endpoints, media phase invariance, retained frame/musical domains, current tempo changes, Repeat/Once placement phase, an exhausted Once negative origin and the unchanged frame-event timing refusal. Project12 tests passed, including9 preview tests and3 existing warp tests. Project all-target and targeted Audio feature Clippy passed with warnings denied. Audio4 tests passed, including calibration2 and2 allocation tests. All20 measured fixture cases were zero total/net count and bytes;4 new default-helper cases invoke64 calls each. Formatting/diff passed. Raw follow-up logs25-30 retain actual results.

Previous component evidence (tree8301fc6b, original manifest and logs16-24) is preserved unchanged; these focused checks are not a new full audit. No clipboard, history, Session, UI, manifests, dependencies, commits, pushes or app operations were added. Primary owns publication, integration and combined-source qualification.
