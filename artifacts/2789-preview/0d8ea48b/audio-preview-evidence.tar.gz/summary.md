# sampler preview math component

Base `b05a9eaa61edc60f711acdc06d907f7525d6197c`; candidate tree `8301fc6b9ff8d9950e9cd179d92b760413b4a491`. Source is uncommitted in branch `codex/sampler-preview-math-2789` for primary review/publication.

Final 18-file input manifest SHA256: `15f875c2dd63f3c3787f8bae8ef5d92440af78f82b1b25476e2a39a7e82e8759`.

## behavior

`Clip::with_audio_preview` lends an opaque HRTB evaluator; only Copy facts, occurrence geometry, fade samples and accepted waveform positions escape. Plain/musical trim, lower fade resize and stretch use the same plans as owning commands. Stored tempo projection, Once/Repeat placement, loop phase, warp/event scaling and early no-ops are preserved. All model ownership operations are confined to materialize.rs. Full event validation uses 16 KiB fixed stack scratch for 1024 IDs; temporary edit-fragment validation keeps its separate allocation/capacity path.

## final checks

56 Project regression tests (7 new, 49 existing), 5 existing event boundary tests, 4 doc tests (new evaluator escape compile-fail included), and 3 Audio tests passed. The allocation test emits 16 measured cases, all zero total/net allocation count and bytes, with fixtures/oracles/reclamation outside measurement. Both targeted strict Clippy configurations, formatting, architecture and diff checks passed. Raw final logs are 16-24.

## retained failures and limits

02 caught domain identity regression; 04 caught a fixture Arc mutation compile error; 05 caught the raw occurrence duration bug. These were repaired and final checks passed. The final diff review restored the original signed-projection/error order before logs16-24. Logs01-03 precede the mandated cache-target separation; they are not substituted for final source checks.

This is a model component, not merge qualification or native app acceptance. Primary owns publication, integration with Native metadata wrappers/history exports and Session/UI facades, combined exact-source local CI and requested optimized delivery. No UI, Session, Engine, Desktop, manifests or dependencies were edited. No app operations or hosted CI ran.
