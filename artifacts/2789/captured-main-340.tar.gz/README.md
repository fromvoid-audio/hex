# Finite captured-Main continuation / native-resource frontier WIP

Canonical checkout remains b94b0e2f6fbec0932d422c00d4584739c192cb9a. This is immutable source/evidence, not a merge candidate, startup enable or Sampler readiness claim.

Source base: cdb4d626a9575d2106df93946550d80910ae9e78. SOURCES.json records all 33 actual changed/new source files with authenticated before Git objects and before/current SHA256. This includes the earlier six route-A constructor paths from 27dc and the separate 602 source key; neither is relabeled newly qualified. CURRENT-WIP-CONTINUITY.json records 211 actual current WIP paths; unchanged bytes are referenced, not recursively archived. OWNING.diff is readable exact current vs cdb4.

Implemented: nonClone CapturedMainFile bound to same Root/token/incarnation/identity, finite nonSend loans, actual Root metadata individual alias pair and normal destruction, normal closing skips only that actual obligated cell. The lifecycle parent performs actual stream/native cleanup and actual same Reaper join; only a typed traversal of retained original-Sampler Main DATA permits moving the actual retirement actor into existing Root Work and releasing the actual backend Lease. No fourth Root role/pool/thread/queue. Failure and pending-before-take remain sticky. The class traversal is NOT normal handle closure or aggregate admission.

Meaningful current focused results are separate source epochs, not a synthesized full suite:
- final-source-main-file.log: session69050, 3PASS0ignored, byte-identical513frame baseline/replacement; actual publication close+StreamOwner drop; new backend obtains actual lease while old Main/compiled reader/Client remain; readerPending; publish once; ordinaryprepare/duplicatecapture/stale completion refusals; callback0alloc/free. Application/headless frontier ONLY, no OS/native claim.
- root-field-lib-tests.log: session89253,5PASS0ignored, actual Main pair/alias closure/recycle, foreign registration and pending/failed controls. Before final behavior-preserving let-return simplification.
- lifecycle-tests.log: session8846,43PASS0ignored, actual stop/panic/join/abandon/cancel and both-minus-one controls. Before final behavior-preserving let-return simplification; no full-source transfer.
- session-file-tests.log: session34671 first stage,6PASS0ignored, real Main reader/ACK behavior and physical projections.
- session-legacy-export-test.log: same shell second stage,1PASS0ignored, existing headless exporter behavior after allocation-free wrapper return-shape correction.
- captured-main-docs.log:94271,3compilefail controls.
- strict-libraries-final.log:97166,exit0/3.49s Engine+Audio+Session library Clippy -Dwarnings.
- strict-desktop.log:43639,exit0/20.43s Desktop binary Clippy -Dwarnings. NOT all-target/UI validation. Known two failclosed build-script layout Unknown diagnostics remain explicit.
- policy-tests-final.log:46PASS; architecture-final.log:25cratesPASS; diff check passed.

Preserved negatives: original69389 actual Host(Closed), zero-match57422 NOT coverage; 46544/final-main-file.log ZERO tests missing allocation-probe;96623 fixture lease-reopen race1PASS2FAIL (cascade), corrected fixture waits actual prior retirement;83922 root-field-tests.log linker BusError/workspacefull BEFORE runtime. Three old generated Desktop executables moved to /tmp custody to recover1.2GiB; no source/raw logs deleted. Prior policy/Clippy failures retained, no backdating.

Root requested exact old Unknown branch: diagnosis/first-branch-exact has actual old-wrapper desired RED101, first nested rejection canonical_state.rs47:14 valid=false required=true, with diagnostic and final bytes plus restoration proof. The outer public custody wrapper sets valid=false, then the actual NativeDeviceState visitor enters another guarded mutation. Correction uses existing compiler Inputs' direct root+typed descendant traversal; no validity guard changed. The first-branch-diagnostic attempt had setup substring error (partial instrumented corrected-body run), not the old-wrapper negative; restoration failure only concerned a never-written diagnostic file, and both final files match their saved bytes. No diagnostic remains in source.

OPEN: persistent actual worker job representation, complete continuation/old+new NativeFields normal+bootstrap union/alias closure and BOTH aggregate caps, real qualified Initial/Service/source role-seal/postbackend publication and loaded Sampler/native/UI acceptance. WORKER-JOB-SEAM.md records exact fields; Primary subsequently approved moving the ONE native slot Vec into existing Desktop NativeAudioSink. That move is NEXT, not part of this sealed source. Native producer remains UNARMED. Existing headless export remains explicit unqualified path.
