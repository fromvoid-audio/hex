# Exact remaining worker-job representation seam (read-only)

The finite captured-Main continuation and actual native-resource/DATA split are implemented and headless-tested. They are not production admission.

Actual owning types now:
- Session `WorkerEvents.main_files: Option<NativeMainFiles>`.
- Session private `NativeMainFiles { slots: Vec<MainControlFileJob> }`.
- Session public `MainControlFileJob { file:StagedWavFile, identity:Option<AudioCandidateIdentity>, copy:[Frame;256], pending:Option<Block>, phase:Phase, first_panic:Option<Box<dyn Any+Send>> }`.
- Audio `CapturedMainFile { root:Option<CandidateRoot>, lineage:Option<NativeCapturedMainRootLease>, token:AudioCandidatePreparationToken, identity:AudioCandidateIdentity, complete:bool }`.
- Desktop `NativeAudioSink`, owned as the existing Session worker's `Box<dyn WorkerAudioSink>`, already owns its output/preparation/submitted state and drives polling.

Session cannot add a concrete Audio field without reversing the approved DAG (Audio->Engine, Desktop->Session+Audio). Keeping the continuation in an unrelated local variable, separate owner table or copied scalar descriptor is not the required persistent File-job binding. No such workaround is enabled.

Smallest concrete next representation proposed: move ownership of the ONE existing File slot Vec from WorkerEvents into its existing Desktop NativeAudioSink, with element `NativeMainFileJob { file:MainControlFileJob, continuation:Option<CapturedMainFile> }`. This replaces that Vec; it does not add a parallel pool/queue/thread/registry. The wrapper is private and its sole closed constructor binds the actual file job to the same captured parent. Persistent jobs retain failed/cancel/panic and completed-but-retirement-Pending continuation until normal disposition.

Necessary finite borrowed schema adaptation: Session supplies an owner-local actual single-job projection, while Desktop's audited FileSlotsFields producer projects the real wrapper Vec/body/spare element layout. Engine currently requires exact element-body equality with FileJobFields.body; this must instead explicitly check the named embedded file body in the actual wrapper, and separately require the continuation's actual root/metadata alias descendants through guarded native fields. Neither body observation nor alias match certifies absent children. Native preflight must walk BOTH old captured Root and new selected Root under existing guard law and charge the complete overlapping union to both aggregate caps before new birth. No arbitrary visitor, supplied sizes, raw Root getter, boxed erased owner or opaque body-only qualification is proposed.

Alternative of retaining the Session Vec requires a new erased owning continuation interface and allocation/layout/descendant protocol; that is broader and is not proposed. Source remains unchanged at this boundary pending whether the approved existing-owner continuation direction includes moving the concrete slot Vec into the already-existing Desktop worker adapter. If a move is selected, update startup/current host readers to use the actual new persistent Vec directly in the same closed Native constructor; never leave the old header as a fake empty substitute.

Remaining normal Service Initial/source/producer/backend/old-new admission are still unarmed. A green headless lease frontier is not proof of the above aggregate union or OS/native acceptance.
