# Actual persistent native File job WIP (unarmed)

Source0610c25c820ebb648df3df7698ea9d689e3a4d72 parent e12e122fbd8ef969a93b6215c91eee761be05bb6. Fourteen exact changed/new sources with authenticated Git bytes before/current. Actual canonical b94 and all WIP preserved. Paired-preclaim work started AFTER this frozen source and is NOT in this packet.

The ONE native File Vec moved from Session WorkerEvents into existing Desktop NativeAudioSink. Its private element owns MainControlFileJob plus Option<CapturedMainFile>. No erased owner/table/queue/pool/thread added. NativeSink cursor is a real additional scalar, included in actual type size; no presumed byte savings/cap increase. Prototype Session header and forwarding accessors were removed, rather than left empty. Existing headless exporter unchanged.

Engine checks the actual indexed wrapper contains the embedded File body; wrapper Vec capacity/spare element bodies are charged once, paths separately. Session remains sole File child producer. A present continuation explicitly refuses in reserved-file projection until its real guarded old+new Root descendants are composed. Unknown is NOT proof of absent memory or final feature policy.

Native worker poll now performs ONE actual File-tail retirement step per turn. It retains failed jobs and removes only published jobs after same actual continuation Root normal retirement. Productive render/write/ACK dispatch still needs real closed preparation/request/transport integration. No FileIO under native guards, new admission or startup enable claimed.

Current affected file-only run37197:4PASS0ignored/0.85s. Actual513frame continuation is now owned in adapter slot through publication close/newbackend and normal DATA retirement; exact baseline file equality and readerPending retained. New real2occupied+spare wrapper Vec test covers exact and both-minus-one, actual foreign File body refusal.

First compile15845 had test-only private sibling fixture and nonexistent VecRef.capacity API errors; fixed by putting test beneath existing fixture owner and inspecting actual Vec.capacity. Native-wide44860:5PASS8FAIL1existingignored; FIRST is actual desired-positive closedService refusal worker fields UnknownStorage because real current_owner remains Unqualified. Seven others are poisoned-lock cascades, NOT seven new lifecycle bugs. This remains the qualified Initial/current birth gap; no guard weakened/desired test removed/ignored. Focused four selected after preserving negative.

Strict Desktop/dependency libraries99159 terminal0/24.56s, policy47PASS, architecture25PASS, diffcheck0. Known two failclosedClippy layoutUnknown diagnostics explicit. Not all-target/full source/native/Mac/UI qualification. No Sampler usable claim.
