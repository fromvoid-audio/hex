import datetime, json, os, pathlib, re, subprocess, time
root = pathlib.Path.cwd()
out = root / 'artifacts/aba2880'
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
filters = ['editor::time_selection::', 'editor::edit_cursor_ui_test::', 'editor::selection::tests::', 'editor::clip_selection::tests::', 'editor::clip_clipboard_ui_test::', 'editor::track_selection_ui_test::', 'editor::drag::group_drag_ui_test::', 'editor::arrangement_main_track_ui_test::', 'editor::session_navigation_ui_test::']
commands = [
('targeted83', ['cargo', 'test', '-p', 'hex-ui', '--features', 'ui-test-support', '--locked', '--', *filters]),
('strict-default', ['cargo', 'clippy', '-p', 'hex-ui', '--all-targets', '--locked', '--', '-D', 'warnings']),
('strict-ui-feature', ['cargo', 'clippy', '-p', 'hex-ui', '--all-targets', '--features', 'ui-test-support', '--locked', '--', '-D', 'warnings']),
('quick-final', ['python3', 'scripts/local-ci.py', '--quick']),
('diff-check', ['git', 'diff', '--check']),
]
report = {'source':git('rev-parse','HEAD'), 'tree':git('rev-parse','HEAD^{tree}'), 'base':'e4c0f55c69a78839eab25151286aef0855d1f640', 'branch':git('branch','--show-current'), 'initial_status':git('status','--porcelain'), 'target':str(root/'target'), 'environment':{k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']}, 'rustc':subprocess.check_output(['rustc','-vV'],text=True), 'steps':[], 'scope':'Targeted local source verification only. Quick is partial; full integration/merge qualification belongs to Cloud3. No app/native install, launch, listening, or UI acceptance.'}
for name, argv in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = time.monotonic()
    log = out / (name+'.log')
    with log.open('w') as stream:
        result = subprocess.run(argv, env=env, stdout=stream, stderr=subprocess.STDOUT)
    entry = {'name':name,'argv':argv,'started_utc':started,'duration_s':round(time.monotonic()-before,3),'exit_code':result.returncode,'log':log.name}
    if name=='targeted83':
        entry['test_results'] = re.findall(r'test result: (.+)',log.read_text())
    report['steps'].append(entry)
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        break
report['final_source']=git('rev-parse','HEAD')
report['final_tree']=git('rev-parse','HEAD^{tree}')
report['final_status']=git('status','--porcelain')
report['unchanged']=report['source']==report['final_source'] and not report['initial_status'] and not report['final_status']
report['passed']=report['unchanged'] and len(report['steps'])==len(commands) and all(s['exit_code']==0 for s in report['steps'])
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['passed'] else 1)
