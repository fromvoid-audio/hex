//! One startup aggregate, so spawn failure cannot drop completion before its
//! actual Session/Event children. No new queue, flag or readiness state.
use super::*;
use crate::snapshot_exports::{SnapshotWorkerControl, SnapshotWorkerStop};

/// Actual pre-Session worker operands, borrowed only during negotiation.
/// The registered family must be inspected separately under its real guards.
/// Neither this view nor its phase query grants storage/admission authority.
/// ```compile_fail
/// fn save<'a>(view: hex_session::service::WorkerStartupView<'a>)
///     -> hex_session::service::WorkerStartupView<'static> { view }
/// ```
/// ```compile_fail
/// fn send(view: hex_session::service::WorkerStartupView<'static>) {
///     std::thread::spawn(move || drop(view));
/// }
/// ```
pub struct WorkerStartupView<'a> {
    pub(super) startup: &'a WorkerStartup,
    pub(super) queues: &'a WorkerStartupQueues,
    pub(super) event_sender: &'a SyncSender<Event>,
    pub(super) recovery: &'a Option<PathBuf>,
    pub(super) cancellation: &'a SessionCancellation,
    pub(super) last_source: &'a Option<(
        hex_engine::AudioSourceContext,
        hex_engine::SharedMetadataCacheIdentity,
    )>,
    pub(super) startup_error: &'a Option<String>,
}
impl WorkerStartupView<'_> {
    pub fn cancellation_on_control(&self) -> &dyn hex_engine::CancellationQuery {
        self.cancellation
    }
    /// Reports the actual constructor phase; it is not an empty-project claim.
    pub fn has_session_on_control(&self) -> bool {
        self.startup.session.is_some()
    }
    pub fn worker_control_on_control(&self) -> Option<&SnapshotWorkerControl> {
        self.startup.control.as_ref()
    }
    /// No selected totals can qualify the still-opaque Event/export transports.
    /// Retain their ACTUAL operands here until their qualified records replace
    /// those paths; a zero occupancy or pre-Session phase cannot waive them.
    pub fn require_complete_storage_on_control(&self) -> Result<(), hex_engine::AudioStorageError> {
        let Self {
            startup,
            queues,
            event_sender,
            recovery,
            cancellation,
            last_source,
            startup_error,
        } = self;
        let _ = (
            startup,
            queues,
            event_sender,
            recovery,
            cancellation,
            last_source,
            startup_error,
        );
        Err(hex_engine::AudioStorageError::UnknownStorage)
    }
}
/// Actual worker destinations travel together through failed spawn/startup.
/// They are moved once into run_worker; no receiver/queue clone is fabricated.
pub(super) struct WorkerStartupQueues {
    pub(super) requests: RequestReceiver,
    pub(super) export_work: SyncSender<ExportWork>,
    pub(super) export_events: SyncSender<ExportEvent>,
}
pub(super) enum ServiceStop {
    Unqualified(Arc<AtomicBool>),
    Registered(SnapshotWorkerStop),
}
impl ServiceStop {
    pub(super) fn request_cancel(&self) {
        match self {
            Self::Unqualified(flag) => flag.store(true, Ordering::Release),
            Self::Registered(stop) => {
                let _ = stop.request_cancel();
            }
        }
    }
}
pub(super) struct WorkerStartup {
    session: Option<Session>,
    events: Option<WorkerEvents>,
    queues: Option<WorkerStartupQueues>,
    pending_cancellation: Option<SessionCancellation>,
    control: Option<SnapshotWorkerControl>,
}
impl WorkerStartup {
    pub(super) fn new(
        session: Option<Session>,
        control: Option<SnapshotWorkerControl>,
        cancellation: SessionCancellation,
    ) -> Self {
        Self {
            session,
            events: None,
            queues: None,
            pending_cancellation: Some(cancellation),
            control,
        }
    }
    pub(super) fn install_events(&mut self, events: WorkerEvents) {
        self.events = Some(events);
    }
    pub(super) fn install_queues(&mut self, queues: &mut Option<WorkerStartupQueues>) -> bool {
        if self.queues.is_some() || queues.is_none() {
            return false;
        }
        self.queues = queues.take();
        true
    }
    pub(super) fn take_queues(&mut self) -> Option<WorkerStartupQueues> {
        self.queues.take()
    }
    pub(super) fn take_cancellation(&mut self) -> Option<SessionCancellation> {
        self.pending_cancellation.take()
    }
    pub(super) fn take_events(&mut self) -> Option<WorkerEvents> {
        self.events.take()
    }
    pub(super) fn take_session(&mut self) -> Option<Session> {
        self.session.take()
    }
    pub(super) fn control(&self) -> Option<&SnapshotWorkerControl> {
        self.control.as_ref()
    }
}

impl Drop for WorkerStartup {
    fn drop(&mut self) {
        drop(self.session.take());
        // Native close precedes completion, independently of retained UI reads.
        drop(self.events.take());
        drop(self.queues.take());
        drop(self.pending_cancellation.take());
        drop(self.control.take());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failed_startup_drops_actual_queues_and_duplicate_install_retains_incoming() {
        let make_queues = || {
            let (request_sender, requests) = mpsc::sync_channel(1);
            let (export_work, work_receiver) = mpsc::sync_channel(1);
            let (export_events, event_receiver) = mpsc::sync_channel(1);
            (
                Some(WorkerStartupQueues {
                    requests: RequestReceiver::Unqualified(requests),
                    export_work,
                    export_events,
                }),
                request_sender,
                work_receiver,
                event_receiver,
            )
        };
        let mut startup = WorkerStartup::new(
            None,
            None,
            SessionCancellation::Unqualified(Arc::new(AtomicBool::new(false))),
        );
        let (mut first, first_requests, first_work, first_events) = make_queues();
        let (mut second, second_requests, second_work, second_events) = make_queues();
        assert!(startup.install_queues(&mut first));
        assert!(first.is_none());
        assert!(!startup.install_queues(&mut second));
        assert!(second.is_some());
        drop(startup);
        assert!(matches!(
            first_requests.try_send(Request::Edit(Command::AddTrack {
                name: "closed".into()
            })),
            Err(TrySendError::Disconnected(_))
        ));
        assert!(matches!(
            first_work.try_recv(),
            Err(TryRecvError::Disconnected)
        ));
        assert!(matches!(
            first_events.try_recv(),
            Err(TryRecvError::Disconnected)
        ));
        second_requests
            .try_send(Request::Edit(Command::AddTrack {
                name: "retained".into(),
            }))
            .unwrap();
        assert!(
            second
                .as_ref()
                .unwrap()
                .requests
                .unqualified()
                .unwrap()
                .try_recv()
                .is_ok()
        );
        drop(second);
        assert!(matches!(
            second_work.try_recv(),
            Err(TryRecvError::Disconnected)
        ));
        assert!(matches!(
            second_events.try_recv(),
            Err(TryRecvError::Disconnected)
        ));
    }
}
