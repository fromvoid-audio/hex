from pathlib import Path
import json,re,subprocess,hashlib
r=Path('/workspace/hex-integration-resize-pan');run=r/'artifacts/local-ci/463-dfccc368-guarded-focused';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']=='dfccc36835c3d227ec027d0e8b829bbcf910df76' and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and not s['dirty'] and s['start_tree']==s['end_tree']
assert len(s['steps'])==4 and all(t['status']=='passed' and t['exit_code']==0 for t in s['steps']) and not Path('/proc/1429452').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
counts=[]
for t,expected in zip(s['steps'],[21,18,9,6]):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(r/t['log']).read_text(errors='replace'));assert rows==[(str(expected),'0','0')],rows;counts.append(expected)
p={'head':s['commit'],'source':s['source_identity']['content_sha256'],'all4passed':True,'counts':counts,'unique_tests':sum(counts),'ignored':0,'duration_seconds':s['duration_seconds'],'summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest()};assert p['source']=='08f136abaa6e58ae6cab906a272de3b2c8f65cebdfc15dc5476cf2937e01b8bb'
(r/'artifacts/integration/463-dfccc368-focused-gate.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2))
