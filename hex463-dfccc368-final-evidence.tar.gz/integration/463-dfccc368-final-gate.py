from pathlib import Path
import subprocess,json,hashlib,os
root=Path('/workspace/hex-integration-resize-pan'); head='dfccc36835c3d227ec027d0e8b829bbcf910df76';base='3ddacedeaed38c9a7422af7bf0c66570cd29920b'
def git(*a):return subprocess.check_output(['git',*a],cwd=root).decode().strip()
run=root/'artifacts/local-ci/20261019T162127Z-ae860e4e';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']==head and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and not s['dirty']
assert s['start_tree']==s['end_tree'] and len(s['steps'])==21 and all(t['status']=='passed' and t['exit_code']==0 for t in s['steps'])
assert not Path('/proc/1430963').exists()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain') and git('rev-parse','origin/main')==base
h=hashlib.sha256()
for name in sorted(x for x in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).split(b'\0') if x):
 h.update(len(name).to_bytes(8,'big'));h.update(name);p=root/os.fsdecode(name)
 try:st=p.lstat()
 except FileNotFoundError:h.update(b'missing\0');continue
 if p.is_symlink():h.update(b'symlink\0');h.update(os.fsencode(os.readlink(p)))
 elif p.is_file():h.update(b'file\0');h.update(p.read_bytes());h.update(str(st.st_mode&0o111).encode('ascii'))
 else:h.update(f'other:{st.st_mode}\0'.encode())
assert h.hexdigest()==s['source_identity']['content_sha256']=='08f136abaa6e58ae6cab906a272de3b2c8f65cebdfc15dc5476cf2937e01b8bb'
tree=git('rev-parse',head+'^{tree}');assert git('merge-tree','--write-tree',base,head)==tree
out={'head':head,'tree':tree,'base':base,'all21passed':True,'clean':True,'stale':False,'start_equals_end':True,'current_source_digest':h.hexdigest(),'summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest(),'started_at':s['started_at'],'ended_at':s['ended_at']}
(root/'artifacts/integration/463-dfccc368-final-gate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
