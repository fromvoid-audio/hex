# Finite checks-only request (root dispatches)
Exact source5405fff4d89c26ef7a446648ef71f22fafe0281f. Isolated legitimate target, normal native stack; no app/backend actions. Confirm actual source/modes and preserve original receipts; no guard/report normalization.
Run:
`cargo test -p hex-ui --features ui-test-support --lib editor::device_panel::tests::keyboard_delete_tests --locked`
Expected9matched/9passed, no ignore/zero-match. All nine own fixtures use actual363 bounded browser-directory constructor, retained owned temp paths before startup, assert empty owned samples/places. No ambient EditorView::new or shared clip_drag constructor. No native execution claimed by cloud PASS.
Capture original command/status/logs/source/tree/materialized fingerprint and counts. No broad suite solely for this finite request; merger separately owns required combined CI.
Manual later user checklist: title-select instrument/Track effect/Return effect then Backspace, one Undo restores exact chain/state and Redo; numeric/browser text deletes locally, EQ node Backspace deletes node only; invalid draft refuses device removal, valid draft commits before removal; hold Backspace with another clip selected, confirm no track/clip/next-device loss; title drag/reorder and controls still work. Physical input/listening remains pending. No install/launch/quit/permissions/data operations authorized here.
