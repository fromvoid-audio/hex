from pathlib import Path
import hashlib,json,tarfile,difflib,tempfile,subprocess
v=Path('third_party/gpui');m=json.loads((v/'hex-provenance.json').read_text());archive=Path('/tmp/hex421-gpui-0.2.2.crate');assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['crates_io_sha256'];base=Path(tempfile.mkdtemp(prefix='hex424-gpui-verified-'))
with tarfile.open(archive) as t:
 for name,digest in m['original_files'].items():
  b=t.extractfile('gpui-0.2.2/'+name).read();assert hashlib.sha256(b).hexdigest()==digest
  p=base/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
m['patched_files']['src/app.rs']=hashlib.sha256((v/'src/app.rs').read_bytes()).hexdigest()
for name in m['patched_files']:m['patched_files'][name]=hashlib.sha256((v/name).read_bytes()).hexdigest()
for name in m['added_files']:assert hashlib.sha256((v/name).read_bytes()).hexdigest()==m['added_files'][name]
(v/'hex-provenance.json').write_text(json.dumps(m,indent=2)+'\n')
patch=[]
for name in sorted(set(m['patched_files'])|set(m['added_files'])):
 old=(base/name).read_text() if name in m['original_files'] else '';new=(v/name).read_text();patch.append(f'diff --git a/{name} b/{name}\n');
 if name in m['added_files']:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name,n=0))
(v/'hex-patches.diff').write_text(''.join(patch));subprocess.run(['git','apply','--check','--unidiff-zero',str((v/'hex-patches.diff').resolve())],cwd=base,check=True);subprocess.run(['git','apply','--unidiff-zero',str((v/'hex-patches.diff').resolve())],cwd=base,check=True)
for name in set(m['patched_files'])|set(m['added_files']):assert (base/name).read_bytes()==(v/name).read_bytes()
print('verified original archive/all original blobs/full cumulative patch roundtrip',base)
