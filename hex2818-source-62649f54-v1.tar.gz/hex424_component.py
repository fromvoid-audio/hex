import importlib.util,sys,json,os
from pathlib import Path
root=Path.cwd();spec=importlib.util.spec_from_file_location('hex424_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
commands=json.loads(sys.argv[1]);steps=tuple(m.Step(f'component-{i+1}',tuple(c)) for i,c in enumerate(commands));runner=m.LocalCiRunner(root,mode='component',env=dict(os.environ),steps=steps,min_free_bytes=512*1024*1024);result=runner.run();print('ORIGINAL_COMPONENT_SUMMARY',runner.summary_path,flush=True);raise SystemExit(result)
