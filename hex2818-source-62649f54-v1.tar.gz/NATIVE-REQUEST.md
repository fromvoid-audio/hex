# Root serial native component request

ONLY immutable source 62649f54f5ed499a211712dc84dfa1753ea31069, tree 3bba0a6c3d6624da834f9e29a4566aa1bf77985c, normal configured stack/toolchain/private legitimate target with existing LocalCiRunner component guard; never evidence refs. Preserve user app/install/settings/profile/TCC/keychain/media and all old reports. Full414 bounded test roots supplied before startup. No actual OS chooser, user project, app launch/quit/install/signal.

```sh
cargo test -p hex-preferences --lib --locked project_directory::tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked editor::project_directory::tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked editor::dialogs::ui_tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked browser_test_environment_ -- --nocapture
```

Require respectively5+15+31+5=56unique PASS0ignored. Folder15 includes one Mac Foundation NSURL raw-byte/case/NUL roundtrip, no panel configured/shown. Linux ran14; do not claim native compilation/execution. If byte capability fails stop with exact error, no normalization/skip. Tests cover actual dispatch/picker argument, canonical success/failure/history, dirty save/cancel, named path, preference restart/raw bytes, stale generations/window close and actual write lifetime; injected TestPlatform is not OS chooser acceptance.

Separate later manual disposable-project native panel acceptance: valid last folder appears for Open/firstSave/SaveAs across restart; named Save stays its path; Cancel/declined overwrite/failure leaves prior; missing directory fallback; raw case preserved. Root schedules only, never user-current-project automatic input. Final prospective full21/review/merged source and changed native verification required before delivery. This frozen dependency has old pre452 header oracle; merger must preserve qualified452 when composing delivery candidate, not label component receipts as whole native qualification.
