# Pulse2718 / PR334 — finite coordinator-owned native checks

Frozen source51488f8fdb02fd25d2eae1a7abde5fc081709919
Git tree8f26a35290831db9eb490da86203ced5e609d331
Original cloud exact full20 PASSED, clean unchanged/stale=false. Summary20261018T135154Z-ffae25ec SHA256f2704ccb29473a50edf23f47d700bb8b584b49280389bb01246377d16d0c21eb. This is frozen source qualification; final integration/merge/native acceptance remain separate.
No Mac/app/installation work by cloud6. Dedicated cloud3 owns final integration/required prospective-tree CI/GitHub merge; root owns single Mac lane and optimized delivery.

CLI on isolated exact source or a verified identical tree, ordinary native toolchain/default stack; no launch/quit/unlock/install required:

    cargo test -p hex-project --locked --test clip_paint -- --nocapture
    cargo test -p hex-ui --features ui-test-support --locked editor::clip_paint_ui_test:: -- --nocapture

Expected2 selected/2pass/0fail/0ignored model tests and7 selected/7pass/0fail/0ignored GPUI tests. Model full names:
- clip_paint_cuts_audio_and_midi_with_source_mapping_boundaries_and_one_undo
- clip_paint_refuses_invalid_stale_and_failed_preparation_without_partial_cuts
Rendered module cases:
- clip_paint_double_click_hold_previews_then_commits_once
- clip_paint_cancels_and_rejects_clip_headers_and_stale_state
- clip_paint_minimum_length
- clip_paint_free_drag_uses_pointer_beats
- clip_headers_grab_while_audio_and_midi_bodies_select_and_paint
- clip_review_header_selects_while_pending_and_when_leaving_rename
- clip_review_visible_body_wins_over_occluded_edges
Capture actual source/tree/toolchain, raw commands/logs, cardinalities and exits; no unchanged native full20 repeat requested here. GPUI synthetic event/render tests use bounded fixture PCM and actual prepared MIDI summaries; they are not physical input/listening/installed-app acceptance.

Historical negative5c4d4870dea4999101f152cf83ced50f020616db modifies only tests above qualified09c: actual body gesture fails2clips vs3. Baseline compile error2861 and model iterator error3d10 are retained separately, not product regression evidence. First positive691 model2pass/UI6pass1missing-prepared-preview-fixture failure also retained. Final514 targeted2+7 pass.

Deferred user-present optimized acceptance, on a separately qualified delivery and disposable project:
1. Long audio clip, body double-click/hold inside original then drag/release: exact before/new empty MIDI/after adjacency, no original full-length underlay. Click and move each header independently. One Undo restores long original, Redo restores result.
2. Repeat with MIDI notes spanning both boundaries, then looping/nonzero-source-offset audio and authored fades/gain. Retained material should keep timing/source playback and anchored fades outside the new interval; newly painted MIDI clip is empty and editable. Compare playback of retained regions, not a listening-parity claim.
3. Paint through left/right edge, exactly over clip, touching boundary and with one-cell minimum. Inspect source mapping, fresh IDs/selection, no tiny hidden underlay or unintended overlap. Ordinary clip placement/drag overlap contract remains unchanged.
4. Leftward/reverse-direction paint and snap/grid/Command toggling: preview matches release; cancel Escape/outside lane/project-switch gives no edit. Upper header drag and visible trim edges still own their gestures; occluded edges must not intercept visible body.
5. Undo/Redo and save/reopen the disposable result; original media unchanged. Browser/text/numeric focus and track-header Backspace retain their separate behaviors.

No GUI/screenshot/physical callback/GPU deadline/level-matched listening or Live-parity acceptance is implied by source/CLI passes.
