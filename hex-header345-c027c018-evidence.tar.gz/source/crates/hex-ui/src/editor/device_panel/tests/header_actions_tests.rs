use super::*;

fn bounds(visual: &mut VisualTestContext, prefix: &str, device: DeviceId) -> Bounds<Pixels> {
    visual
        .debug_bounds(Box::leak(
            format!("{prefix}-{}", device.value()).into_boxed_str(),
        ))
        .unwrap_or_else(|| panic!("visible {prefix} for {device:?}"))
}

fn assert_order(visual: &mut VisualTestContext, device: DeviceId, remove_prefix: &str) {
    let title = bounds(visual, "device-drag-title", device);
    let bypass = bounds(visual, "device-bypass", device);
    let save = bounds(visual, "device-preset-save", device);
    let load = bounds(visual, "device-preset-load", device);
    let remove = bounds(visual, remove_prefix, device);
    let frame = bounds(
        visual,
        if remove_prefix == "instrument-remove" {
            "instrument-device"
        } else {
            "effect-device"
        },
        device,
    );
    let inset =
        px(hex_widgets::DEVICE_FRAME_HEADER_PADDING + hex_widgets::DEVICE_FRAME_BORDER_WIDTH);
    assert_eq!(
        bypass.left() - frame.left(),
        inset,
        "toggle is the far-left control"
    );
    assert_eq!(
        frame.right() - px(gain_meters::WIDTH) - remove.right(),
        inset,
        "X occupies the right inset"
    );
    assert!(
        load.right() <= save.left(),
        "load precedes save without overlap"
    );

    assert!(
        bypass.right() <= title.left(),
        "bypass must precede the name"
    );
    assert!(
        title.size.width >= px(24.0),
        "compact name retains useful space"
    );
    assert!(title.right() <= save.left().min(load.left()));
    assert!(
        save.right() <= remove.left() && load.right() <= remove.left(),
        "X is last"
    );
    for action in [bypass, save, load, remove] {
        assert!(action.size.width >= px(12.0));
        assert_eq!(action.size.height, px(12.0));
        assert!(action.top() >= title.top() && action.bottom() <= title.bottom());
    }
    for prefix in [
        "device-up",
        "device-down",
        "return-device-up",
        "return-device-down",
    ] {
        assert!(
            visual
                .debug_bounds(Box::leak(
                    format!("{prefix}-{}", device.value()).into_boxed_str()
                ))
                .is_none(),
            "movement buttons removed, title drag remains"
        );
    }
}

#[gpui::test]
fn shared_header_orders_specialized_and_descriptor_panels_at_compact_widths(
    cx: &mut TestAppContext,
) {
    let (service, state, track, effect, _, _) = actor_utility_fixture();
    let instrument = state
        .project
        .track(track)
        .unwrap()
        .instrument()
        .unwrap()
        .id();
    let (handle, _) = actor_editor_window(cx, service, state, track);
    let mut visual = VisualTestContext::from_window(handle, cx);
    for width in [1280.0, 880.0] {
        visual.simulate_resize(size(px(width), px(540.0)));
        visual.run_until_parked();
        assert_order(&mut visual, effect, "device-remove");
        assert_order(&mut visual, instrument, "instrument-remove");
    }
    let (service, state, track, operator) = operator_navigation_tests::operator_fixture();
    let (handle, _) = actor_editor_window(cx, service, state, track);
    let mut visual = VisualTestContext::from_window(handle, cx);
    visual.simulate_resize(size(px(880.0), px(540.0)));
    visual.run_until_parked();
    assert_order(&mut visual, operator, "instrument-remove");
}

#[gpui::test]
fn shared_header_return_order_bypass_remove_and_history_keep_owner(cx: &mut TestAppContext) {
    let (service, state, track, return_id, device, _) = actor_return_utility_fixture();
    let before = state.project.clone();
    let (handle, editor) = actor_editor_window(cx, service, state, track);
    editor.update(cx, |view, cx| {
        view.focused_return = Some(return_id);
        cx.notify();
    });
    let mut visual = VisualTestContext::from_window(handle, cx);
    visual.simulate_resize(size(px(880.0), px(540.0)));
    visual.run_until_parked();
    assert_order(&mut visual, device, "return-device-remove");
    let bypass = bounds(&mut visual, "device-bypass", device);
    visual.simulate_click(bypass.center(), Modifiers::default());
    pump_until(&editor, cx, |view| {
        view.state
            .as_ref()
            .unwrap()
            .project
            .device(device)
            .unwrap()
            .bypassed()
    });
    editor.read_with(cx, |view, _| {
        assert_eq!(view.device_panel.selected_device, Some(device));
        assert!(view.active_native_device_drag.is_none());
        assert_eq!(
            view.state.as_ref().unwrap().project.track(track),
            before.track(track)
        );
    });
    editor.update(cx, |view, _| assert!(view.enqueue(Request::Undo)));
    pump_until(&editor, cx, |view| {
        view.state.as_ref().unwrap().project == before
    });
    visual.run_until_parked();
    let remove = bounds(&mut visual, "return-device-remove", device);
    visual.simulate_click(remove.center(), Modifiers::default());
    pump_until(&editor, cx, |view| {
        view.state
            .as_ref()
            .unwrap()
            .project
            .device(device)
            .is_none()
    });
    editor.update(cx, |view, _| assert!(view.enqueue(Request::Undo)));
    pump_until(&editor, cx, |view| {
        view.state.as_ref().unwrap().project == before
    });
}

#[gpui::test]
fn shared_header_track_effect_and_instrument_actions_preserve_history_without_drag(
    cx: &mut TestAppContext,
) {
    let (service, state, track, effect, _, _) = actor_utility_fixture();
    let before = state.project.clone();
    let instrument = state
        .project
        .track(track)
        .unwrap()
        .instrument()
        .unwrap()
        .id();
    let (handle, editor) = actor_editor_window(cx, service, state, track);
    let mut visual = VisualTestContext::from_window(handle, cx);
    visual.run_until_parked();
    for (device, remove_prefix) in [(effect, "device-remove"), (instrument, "instrument-remove")] {
        let bypass = bounds(&mut visual, "device-bypass", device);
        visual.simulate_click(bypass.center(), Modifiers::default());
        pump_until(&editor, cx, |view| {
            view.state
                .as_ref()
                .unwrap()
                .project
                .device(device)
                .unwrap()
                .bypassed()
        });
        editor.read_with(cx, |view, _| {
            assert_eq!(view.device_panel.selected_device, Some(device));
            assert!(view.active_native_device_drag.is_none());
            let other = if device == effect { instrument } else { effect };
            assert!(
                !view
                    .state
                    .as_ref()
                    .unwrap()
                    .project
                    .device(other)
                    .unwrap()
                    .bypassed()
            );
        });
        editor.update(cx, |view, _| assert!(view.enqueue(Request::Undo)));
        pump_until(&editor, cx, |view| {
            view.state.as_ref().unwrap().project == before
        });
        visual.run_until_parked();
        let remove = bounds(&mut visual, remove_prefix, device);
        visual.simulate_click(remove.center(), Modifiers::default());
        pump_until(&editor, cx, |view| {
            view.state
                .as_ref()
                .unwrap()
                .project
                .device(device)
                .is_none()
        });
        editor.update(cx, |view, _| assert!(view.enqueue(Request::Undo)));
        pump_until(&editor, cx, |view| {
            view.state.as_ref().unwrap().project == before
        });
        visual.run_until_parked();
    }
}
