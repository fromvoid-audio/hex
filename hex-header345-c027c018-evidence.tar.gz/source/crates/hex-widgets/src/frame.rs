use crate::{ControlStyle, DEVICE_CORNER_RADIUS, DeviceFrameStyle};
use gpui::{Div, IntoElement, div, prelude::*, px, rgb};

/// Canonical compact shell geometry, in logical pixels, for every device.
pub const DEVICE_FRAME_HEADER_HEIGHT: f32 = 14.0;
pub const DEVICE_FRAME_HEADER_PADDING: f32 = 3.0;
pub const DEVICE_FRAME_HEADER_GAP: f32 = 2.0;
pub const DEVICE_FRAME_BORDER_WIDTH: f32 = 1.0;
pub const DEVICE_BODY_INSET: f32 = 3.0;
pub const DEVICE_LAYOUT_GUTTER: f32 = 4.0;
pub const DEVICE_SECTION_RADIUS: f32 = 3.0;
pub const DEVICE_SECTION_INSET: f32 = 4.0;
pub const DEVICE_ROW_GUTTER: f32 = 2.0;

/// Orthogonal compositions; owners supply sizes, children and musical meaning.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DeviceLayout {
    Row,
    Column,
    Wrapped,
    /// Equal-width columns. Zero is treated as one column.
    Grid(u16),
}

/// Compose controls without coupling appearance to a device type or parameter.
pub fn device_layout(layout: DeviceLayout) -> Div {
    let base = div().min_w_0().min_h_0().gap(px(DEVICE_LAYOUT_GUTTER));
    match layout {
        DeviceLayout::Row => base.flex(),
        DeviceLayout::Column => base.flex().flex_col(),
        DeviceLayout::Wrapped => base.flex().flex_wrap().content_start(),
        DeviceLayout::Grid(columns) => base.grid().grid_cols(columns.max(1)),
    }
}

/// Equal flexible split panes. Use a Row composition for unequal/fixed widths.
pub fn device_split(first: impl IntoElement, second: impl IntoElement) -> Div {
    device_layout(DeviceLayout::Row)
        .child(div().min_w_0().flex_1().child(first))
        .child(div().min_w_0().flex_1().child(second))
}

/// Shared surround body. Children are inset beyond the rounded lower corners.
/// Keep this inset when adding scrolling or custom layouts. GPUI's overflow mask
/// is rectangular: the inset, not `overflow_hidden` alone, protects the corners.
pub fn device_body(style: ControlStyle) -> Div {
    device_layout(DeviceLayout::Row)
        .w_full()
        .overflow_hidden()
        .rounded_bl(px(DEVICE_SECTION_RADIUS))
        .rounded_br(px(DEVICE_SECTION_RADIUS))
        .border_l(px(DEVICE_BODY_INSET))
        .border_r(px(DEVICE_BODY_INSET))
        .border_color(rgb(style.surface))
        .py(px(1.0))
        .bg(rgb(style.surface))
}

/// Scroll body whose content owns the inset, so row offsets and scroll extent
/// include it exactly once while preserving the shared surface and corners.
pub fn device_windowed_body(style: ControlStyle, content: impl IntoElement) -> Div {
    device_body(style)
        .flex_col()
        .border_l_0()
        .border_r_0()
        .py_0()
        .child(div().w_full().p(px(DEVICE_BODY_INSET)).child(content))
}

/// Semantic surfaces, independent of device identity and section dimensions.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DeviceSectionSurface {
    Surround,
    Rail,
    Display,
}

/// Rounded short/tall section. Horizontal content inset is at least the radius,
/// so even full-height child artwork stays out of the rounded corner cutouts.
/// Children may choose row/column/grid layout and explicit height independently.
pub fn device_section(style: ControlStyle, surface: DeviceSectionSurface) -> Div {
    section(
        style,
        surface,
        DEVICE_SECTION_RADIUS,
        DEVICE_SECTION_INSET,
        false,
    )
}

/// Rounded section with vertical structural insets instead of horizontal ones.
/// Useful for narrow full-width controls: callers keep their width, and the
/// top/bottom borders keep descendant paint and hits out of rounded corners.
/// Use one section boundary; do not nest another inset around the same content.
pub fn device_compact_section(style: ControlStyle, surface: DeviceSectionSurface) -> Div {
    section(
        style,
        surface,
        DEVICE_SECTION_RADIUS,
        DEVICE_SECTION_INSET,
        true,
    )
}

/// Dense full-width sections use one-pixel corners/insets for tightly packed
/// columns. This preserves fourteen/fifty-two-pixel controls at fixed heights.
pub fn device_dense_section(style: ControlStyle, surface: DeviceSectionSurface) -> Div {
    section(style, surface, 1.0, 1.0, true)
}

fn section(
    style: ControlStyle,
    surface: DeviceSectionSurface,
    radius: f32,
    inset: f32,
    vertical: bool,
) -> Div {
    let color = match surface {
        DeviceSectionSurface::Surround => style.surface,
        DeviceSectionSurface::Rail => style.rail,
        DeviceSectionSurface::Display => style.background,
    };
    div()
        .min_w_0()
        .min_h_0()
        .relative()
        .rounded(px(radius))
        .overflow_hidden()
        .when(vertical, |section| {
            section.border_t(px(inset)).border_b(px(inset))
        })
        .when(!vertical, |section| {
            section.border_l(px(inset)).border_r(px(inset))
        })
        .border_color(rgb(color))
        .bg(rgb(color))
}

/// A short selectable row with one-pixel rounding and vertical containment.
/// Fourteen-pixel controls fit in a seventeen-pixel row without width changes.
pub fn device_compact_row(style: ControlStyle, active: bool) -> Div {
    section(
        style,
        if active {
            DeviceSectionSurface::Surround
        } else {
            DeviceSectionSurface::Rail
        },
        1.0,
        1.0,
        true,
    )
    .flex()
    .items_center()
    .gap(px(DEVICE_ROW_GUTTER))
}

/// A rail's shared surround and row gutters. Width/height belong to composition.
pub fn device_rail(style: ControlStyle) -> Div {
    device_layout(DeviceLayout::Column)
        .gap(px(DEVICE_ROW_GUTTER))
        .bg(rgb(style.surface))
}

/// Grouped parameter row with shared focus surface; no semantic focus ownership.
pub fn device_grouped_row(style: ControlStyle, active: bool) -> Div {
    device_section(
        style,
        if active {
            DeviceSectionSurface::Surround
        } else {
            DeviceSectionSurface::Rail
        },
    )
    .w_full()
    .flex()
    .flex_shrink_0()
    .items_center()
    .gap(px(DEVICE_ROW_GUTTER))
}

/// Recessed graph/inspector display. Owners retain graph and tab/focus state.
pub fn device_display(style: ControlStyle) -> Div {
    device_section(style, DeviceSectionSurface::Display)
        .flex()
        .flex_col()
        .gap(px(DEVICE_SECTION_RADIUS))
}

/// Canonical device frame. Title/actions retain caller input handlers. The idle
/// header and surround use the same surface, without an intervening border.
/// `leading_control` precedes the flexible title; trailing actions follow it.
/// The caller owns control state, commands and input; no decorative toggle is added.
/// Use `device_body` for rounded lower-surface/content containment.
pub fn device_frame(
    title: impl IntoElement,
    style: impl Into<DeviceFrameStyle>,
    leading_control: impl IntoElement,
    header_actions: impl IntoElement,
    body: impl IntoElement,
) -> Div {
    let style = style.into();
    let radius = DEVICE_CORNER_RADIUS;
    div()
        .flex()
        .flex_col()
        .min_w_0()
        .min_h_0()
        .border_1()
        .border_color(rgb(style.controls.border))
        .bg(rgb(style.controls.surface))
        .rounded(px(radius))
        .overflow_hidden()
        .child(device_header(title, style, leading_control, header_actions))
        .child(body)
}

/// Canonical header composition, also available to custom surrounds. Insets clip
/// oversized caller actions/title content to the safe rounded interior.
pub fn device_header(
    title: impl IntoElement,
    style: impl Into<DeviceFrameStyle>,
    leading_control: impl IntoElement,
    header_actions: impl IntoElement,
) -> Div {
    let style = style.into();
    div()
        .debug_selector(|| "device-frame-header".into())
        .flex()
        .flex_shrink_0()
        .h(px(DEVICE_FRAME_HEADER_HEIGHT))
        .border_l(px(DEVICE_FRAME_HEADER_PADDING))
        .border_r(px(DEVICE_FRAME_HEADER_PADDING))
        .border_color(rgb(style.header_background))
        .overflow_hidden()
        .gap(px(DEVICE_FRAME_HEADER_GAP))
        .items_center()
        .bg(rgb(style.header_background))
        .rounded_tl(px(DEVICE_CORNER_RADIUS - DEVICE_FRAME_BORDER_WIDTH))
        .rounded_tr(px(DEVICE_CORNER_RADIUS - DEVICE_FRAME_BORDER_WIDTH))
        .child(div().flex_shrink_0().child(leading_control))
        .child(
            div()
                .flex_1()
                .h_full()
                .flex()
                .items_center()
                .min_w_0()
                .overflow_hidden()
                .text_color(rgb(style.header_text))
                .text_size(px(style.controls.font_size))
                .child(title),
        )
        .child(div().flex_shrink_0().child(header_actions))
}
