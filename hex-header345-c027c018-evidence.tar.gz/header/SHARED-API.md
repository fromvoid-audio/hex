# Shared header API for other source owners

Canonical2732/PR345 candidate15383ed599cf4bc7cb5d3df7bf7ab02150bebc9b, treea163a7de89d7569afc37d132aa8dac5029d217b0; published branchpulse/task-2732-g1-b67a4dbaa299. RequiredCI pending at this snapshot. No unpublished owner code imported. Do not use this evidence artifact as source or a merge ref.

hex_widgets::device_frame(title, frame_style, leading_control, header_actions, body)
hex_widgets::device_header(title, frame_style, leading_control, header_actions)

The leading_control slot is before the flexible/min-width-zero clipped title. Trailing actions do not shrink. The widget inserts no decorative dot. Both control slots accept implIntoElement and own no device/canonical/DSP semantics. Existing generic14pxheader/12pxdevice_action geometry/theme remains the contract. Old4argframe/3argheader call signatures are deliberately replaced; all publishedmain callers, gallery and widget tests are updated in this PR, no historical adapter added.

Production render_instrument/render_effect/render_return_effect pass shared private bypass_action(device,class,selected,cx) on left. Instrumentreplacement stays on right, then preset LoadDOWN(false)/SaveUP(true), then existing remove action. Canonical SetDeviceBypass/RemoveDevice/RemoveInstrument and preset routing/focus refusal are unchanged. No Sampler/resource/compiler/registration source edited. A future Sampler-specific BODY dispatched through render_instrument automatically receives this header; if a custom surround is actually needed, use device_header with the same slot/action geometry rather than fork the chrome. Return private renderhelper drops obsolete devices/index args; its drag caller only updates arguments, retaining all drop/cancel/history logic.


Integration checkpoint: identical production API on published d6fbb7c423569350c1a4c3a773d3f1be6f3d5485/tree102d3b06f57126ecbd3858214cc8b316a3b218ff, including published main150776e9. Original361 full20 passed; final integrated full20 pending. This addendum supersedes the earlier pending-source snapshot identity, not the original receipts.


FINAL SOURCE CHECKPOINT: exactc027c0181b4f028414d4f8a269390eb9a9a2b8ed FULL20PASS/20261018T132505Z-a395a8d4/summarySHA256b840a738dcef20f549ad372552552e5678a2b67eb4cbec10cd24d9241ec058a9, clean unchanged0037f6b2f1b8f630fd31e76484087746838911bee0212d1806b167ccb4135f3e, stale=false; actualmerge7ffabbdd0023e167af314253225740e9cfd125d3/tree1fdc7636098a2e86a3ef0e86da76cf3a26547e84 EXACTequalsqualifiedtree; actualparents5bd4220d+c027/ancestryverified. No newfullCIclaim forotherheads. Native4CLI result pending coordinator at sealing; physicalLoad/glyph/dialog/input/focus/display acceptance OPEN; installed7fe unchanged.
