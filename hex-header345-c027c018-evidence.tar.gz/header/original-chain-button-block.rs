    let second_up_selector =
        Box::leak(format!("device-up-{}", second_device_id.value()).into_boxed_str());
    let second_up = visual
        .debug_bounds(second_up_selector)
        .expect("move second device left");
    let click_point = point(second_up.center().x, second_up.center().y);
    visual.simulate_mouse_down(click_point, MouseButton::Left, Modifiers::default());
    visual.simulate_mouse_up(click_point, MouseButton::Left, Modifiers::default());
    visual.run_until_parked();
    editor.read_with(cx, |view, _| {
        assert!(matches!(
            view.last_enqueued_edit,
            Some(Command::MoveDevice {
                device,
                track: moved_track,
                before: Some(before),
            }) if device == second_device_id && moved_track == track && before == device_id
        ));
    });

