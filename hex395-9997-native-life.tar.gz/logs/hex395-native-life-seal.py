from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil,re
r=Path('/workspace/hex-sampler-aggregate');out=Path('/tmp/hex395-9997-native-life');out.mkdir(exist_ok=False)
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
def sha(b):return hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();assert head=='99978443ca2438aaa0830d1764d6259f546deed0';assert not git('status','--porcelain')
rows=[]
for name in git('diff','--name-only','HEAD^','HEAD').decode().splitlines():
 b=(r/name).read_bytes();p=out/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
assert len(rows)==5
(out/'SOURCE.json').write_text(json.dumps(dict(head=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),parent=git('rev-parse','HEAD^').decode().strip(),files=rows),indent=2))
(out/'SOURCE.diff').write_bytes(git('diff','--binary','HEAD^','HEAD'))
for name in ['crates/hex-engine/src/audio_storage.rs','crates/hex-engine/src/audio_storage/arithmetic.rs','crates/hex-session/src/service/worker_roots.rs','crates/hex-desktop/src/snapshot_transport/inventory.rs','crates/hex-audio/src/candidate_custody/eligible/publication/preparation.rs']:
 p=out/'context'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,p)
logs=out/'logs';logs.mkdir()
for p in Path('/tmp').glob('hex395-native-life-*'):
 if p.is_file():shutil.copy2(p,logs/p.name)
final=json.loads(Path('/tmp/hex395-native-life-final-results.json').read_text());assert final['start_source']==final['end_source'];assert all(x['exit']==0 for x in final['results'][:-1]);assert final['results'][-1]['exit']==101;assert 'function `advance` is never used' in Path(final['results'][-1]['log']).read_text();assert 'Finished `dev`' in Path('/tmp/hex395-native-life-strict-feature.log').read_text()
names=[]
for log in ['/tmp/hex395-native-life-final-publication.log']:
 names+=re.findall(r'^test (.+?) \.\.\. ok$',Path(log).read_text(),re.M)
assert len(names)==len(set(names))==13
(out/'CHECKS.json').write_text(json.dumps(dict(exact_final_unique=13,names=names,final_source_receipt=final,limits='Cloud16MiB/jobs4;13publication runtime tests. Broad strict without test feature FAILED existingDesktopdead_code; same unchanged source strict with hex-desktop/allocation-probe PASS. FullCI/native not run.'),indent=2))
quick=r/'artifacts/local-ci/20261019T113824Z-ee292ff5';q=json.loads((quick/'summary.json').read_text());assert q['commit']==head and not q['dirty'] and not q['stale'] and q['exit_code']==0 and q['status']=='partial' and q['start_tree']==q['end_tree'];assert len(q['steps'])==6 and all(s['status']=='passed' for s in q['steps']);shutil.copytree(quick,out/'local-ci')
(out/'HANDOFF.md').write_text("""# Actual native Life paired-birth component, NOT ready395

Canonical9997 over99a1,5files. Existing RuntimeSlot Life owner is now constructor-paired SharedMetadata from FIRST birth, same atomic payload/cancel/incarnation protocol,3field types+1clone call. No rawArc adoption/newowner family/lock. Engine SharedMetadataRef constructor_bytes delegates actual private existing OwnedShared declared_parts checked payload+header; physical cost ONLY, no child/origin/admission authority. Both requested and actual-capacity metadata prequote count Life header and changed wrapper actual size, caps unchanged; unsupported pinned layout refuses before slots/Life allocation. Actual new two tests reconcile Life48bytes/count1, cloned/nonfinaldrop0; Bank7actualVecs+2Life totals31362bytes exactly; retained-minus1 quote refuses with0alloc, peakminus1 refuses existing peak>=retained law with0alloc (metadata-only equal demand, NOT independent transientpeak proof). Actual aliases require data1/handles2, omission refuses/samefielddedups. All13publication testsPASS0ignored incl partialpanic/cancel/readerretention/splitdisposal. Policy5/architecture0. Initial broad strict EngineAudioDesktop alltargets FAIL existing Desktop main_control_file advance/run_loan dead_code when allocation-probe test consumers disabled, original negative preserved. SAME unchanged source strict WITH existing hex-desktop/allocation-probe PASS; no warning guard weakened. Exact quick6PASS/PARTIALclean/stalefalse; nofullCI/native/merge/app claim. All source/evidence checkpoints preserved; wholeService/native/Library remainsOPEN.

Next concrete native projection boundary: existing actual FIVE locked stdMutex fields in candidate_custody::Inner(bank/execution/returns) and eligible::Custody(bank/work) are prewarmed by CandidateRoot::new/eligible.prewarm_on_control. On the pinned macOS backend already established by reader81audit, firstlock creates hidden backendBox. Current std safe API exposes payload only, not physical child ref; BodyRef footprint/warmup/root group counts cannot satisfy mandatory28256physical union for these allocations. Need Root decision on a narrowly preserved-existing-exclusion primitive/storage contract before claiming positive full native union. No synchronization change made. Terminal carrier Mutex is DIFFERENT: production only new/get_or_init/into_inner, NEVER lock; no new hiddenbox claim made there, existing constructor law can be examined without assuming five-lock finding applies to it. This source-backed design conflict is NOT a new native runtime observation. No unsafe/guessedlayout/opaqueBoxcertificate/perrecordlock/genericframework workaround.
""")
for name in ['crates/hex-audio/src/candidate_custody.rs','crates/hex-audio/src/candidate_custody/eligible.rs','crates/hex-audio/src/native_callback_owner.rs','crates/hex-audio/src/native_callback_owner/allocations.rs','crates/hex-audio/src/candidate_custody/eligible/publication/resources.rs']:
 p=out/'boundary-context'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,p)
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file():
  b=p.read_bytes();manifest.append(dict(path=str(p.relative_to(out)),bytes=len(b),sha256=sha(b)))
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
a=Path(str(out)+'.tar.gz')
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(a) as t:
 m=t.getmembers();assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in m)
 for row in manifest:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
blob=git('hash-object','-w',str(a)).decode().strip();tree=subprocess.check_output(['git','mktree'],cwd=r,input=f'100644 blob {blob}\t{a.name}\n',text=True).strip();commit=git('commit-tree',tree,'-m','Evidence only: native lifecycle paired birth9997').decode().strip();ref='refs/heads/evidence/hex-sampler-2789-9997-native-life';subprocess.run(['git','update-ref',ref,commit],cwd=r,check=True)
result=dict(archive=str(a),bytes=a.stat().st_size,sha256=sha(a.read_bytes()),safe_members=len(m),payloads=len(manifest),evidence_commit=commit,ref=ref,source_head=head,source_tree=git('rev-parse','HEAD^{tree}').decode().strip());Path('/tmp/hex395-native-life-seal-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
