# Pulse2790 / PR396 — finite changed-behavior portability checks

Prospective integrated CODE candidate daf55e5c2ed0c3a2933172a872689d28462c2b83,
tree1f3cf49bf5af86b96eeca271bbc1d10162315bf0, sourceguard digest
01879992040c646eed17db5fd6994940d9b0249ba8d047f4d81c2f8f5a185632.
It includes actual Command-D main150776e9 unchanged. Final cloud run
20261018T131457Z-08dfd168 is pending at packet preparation; qualification.json
records its actual terminal result. Earlier2472 run passed20/20 on its original
identity; interrupted404 run remains historical partial evidence. Neither is
qualification of this combined tree. Actual merge/source mapping is recorded
separately after verified integration. Never build evidence refs.

No additional Mac execution is a source merge gate for this portable model fix.
If coordinator includes it in the next native cohort qualification, these are the
finite changed selectors, run serially by the sole existing Mac verifier from
clean pinned CODE source and its legitimate private target/toolchain:

    cargo test -p hex-project --test prepared_batch_routing --locked
    cargo test -p hex-session --test prepared_batch_routing --locked

Expected:4 public Project cases and1 Session test covering both invalid batches,
no private-field construction. Audio case starts with ReturnR1→R2 and typed
R2→trackT, then batches sendT→R1. MIDI case removes a destination instrument with
its incoming route retained. Both reject before invoking the caller's prepare
callback, preserve speculative IDs and both history stacks. Valid-final audio
and MIDI batches may pass through transient invalid states, prepare once and
retain one-step Undo/Redo; a no-op retains redo. Existing command-local checks
and single-transition refusals remain intact.

The Session fixture compiles an initial valid nonsilent MIDI graph through actual
Session/Engine preparation, retains its prepared Arc and compares the next64PCM
frames against uninterrupted128-frame output after both refusals. It does not
establish physical audio-device/GPU/deadline/listening acceptance. It does not
implement or substitute for cloud4's private Engine borrowed validator/Sampler
resource/compiler/custody work. No Sampler installation is included.

Save actual command/exit/source/tree/dirty-state/target identity and test counts.
Stop and relay a real failure; no source/report/guard edits or repeated broad
unchanged suites. No GUI, user save/quit, app build/package/install/launch/restart,
TCC/keychain/profile/media/database/security changes are requested. User away;
installed7fe4f48f95a23123981f41bdc4fa934f3d3d091b remains untouched.

This change adds no routing-batch UI. Do not invent a manual gesture to reproduce
an unexposed API. For the later coordinator-owned optimized cohort delivery,
existing ordinary playback/routing/import/one-stepUndoRedo listening acceptance
remains separate; no new broad native/user approval gate is created here.
