# Root serial Mac request

Exact source 4737b68e53bb9bf1193880257bfe21474e5754a7, tree 0d29b745753e23e9a7efb6ea1bd0786e05fd7374; existing guarded component runner/private legitimate target/Rust1.94/native aarch64/default stack. Preserve old08ad failure and all app/previous outputs. No install/build-app/launch/quit/signals/real chooser/user inputs/TCC/settings/media operations.

```sh
cargo test -p hex-ui --features ui-test-support --lib --locked editor::project_directory::tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked editor::dialogs::ui_tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --lib --locked browser_test_environment_ -- --nocapture
```

Expected15+31+5=51 unique PASS/0ignored/overall0. Changed case is project_directory_existing_native_folder_preserves_case_and_bytes. Existing pure Foundation raw bytes/case/NUL is included. Existing raw-byte preference codec5 already qualified parent and unchanged; optionally run its selector project_directory::tests:: in hex-preferences if coordinator needs a full56 packet, not required solely for test fixture edit. Stop on actual failure, do not skip or patch source. Injected chooser arguments and Foundation URL probe are not physical native panel acceptance. Actual optimized app/native OS picker/manual workflow remains separate.
