# retained lifecycle checkpoint — snapshot only

28706 implementation in progress. Canonical source is still b94b plus the complete18-file dirty snapshot, including preserved NativeFields/privateAudio prototypes. This ref is EVIDENCE ONLY. Never build this evidence tree.

Implemented actual Engine runtime-shell and group constructor registrations, non-Clone leases, Draft→CandidateState→ClaimedState→normal-disposal proof moves, same-chain group inheritance, real pairing checks, Pending-before-drop, failure retention, normal physical destructor→archive fanout closure, unpublished-draft cancel closure. Existing metadata field visitor declares actual new paired SharedMetadata bodies/headers and each actual handle, no cap change.

Final tests31PASS0ignored; real two handoffs each measured alloc/free zero (count_total/current and bytes_total/current all0). Strict Engine all-targets instrument-test-support -Dwarnings PASS; architecture PASS; git diff --check PASS. Rust1.94.0/Linux/cloud16MiB stack remains distinct from native qualification. Wrapper Clippy layout warning is Unknown as designed, not a platform allocation proof. No new Mac work.

Preserved negatives: initial check visibility warning corrected; unsupported Engine allocation-probe strict invocation exit101 before compilation; new shell test E0616 private sibling access corrected using actual claims/proof API with no getter/visibility relaxation. Expected destructor-fault panics terminate testPASS.

OPEN: these registrations currently establish actual lifecycle and account their metadata ONLY; they do not yet declare transported runtime allocation DATA/individual transported shared-handle lineage. Retained physical schema/domain, NativeState/carrier/rings/domain pairings, mandatory full nativeSome union and same-parent facade consumer, root-factory aggregate before-birth admission, qualified normal startup/Service source correlation and Mono+Stereo Sampler native publication remain required. Existing Audio host unused-consumer strict negative remains unresolved; no new allow/guard weakening. No full395/playable/source-ready/native/merge claim. No model/tool/ownership contradiction, no live owned job.
