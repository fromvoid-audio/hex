import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-eq-layout')
spec=importlib.util.spec_from_file_location('hex_eq_lifecycle_focused_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('eq-production-ui',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','eq_ui_tests','--','--nocapture'),uses_cargo_target=True),
 m.Step('eq-model',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','eq_panel::','--','--nocapture'),uses_cargo_target=True),
 m.Step('shared-response-graph',('cargo','test','-p','hex-widgets','--locked','response_graph::','--','--nocapture'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
 m.Step('widget-clippy',('cargo','clippy','-p','hex-widgets','--all-targets','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
