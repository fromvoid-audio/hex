import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-grid-review')
spec=importlib.util.spec_from_file_location('hex_grid_focused_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('grid-resolution',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','editor::musical_time::','--','--nocapture'),uses_cargo_target=True),
 m.Step('arranger-menus',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','context_menu','--','--nocapture'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
