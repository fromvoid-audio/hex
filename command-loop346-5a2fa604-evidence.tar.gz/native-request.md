# bounded Command-L native request — coordinator single lane only

Source 5a2fa604a159381cffef9d3ad2d04054f79113e6
Tree c0b26720b046dddb8713ae8020d68b68ab911748

Checks-only/locked desktop. No app install/build delivery/launch/quit/unlock/GUI:

cargo test -p hex-ui --features ui-test-support --locked editor::loop_selection_ui_test::command_l_ -- --nocapture

Expected EXACTLY2 positive/0fail/0ignored, capture actual filtered count, cargoexit, defaultnative stack, raw stdout/stderr+hash. These tests dispatch actual platform cmd-l (not bare l). Real Service worker/prepared Engine+GPUI windows and actual clip header clicks. First uses3 selectedIDs (2audio+MIDI with gaps), permutations making nonprimary earliest/latest, full0..192000span, content/IDs/selection unchanged, repeatednoop/singleUndoRedo; musicalkeyboardON still letsCommand-L setMIDI72000..120000 whilebareL remainsnote. Second uses explicit reversed12000..36000bounds beforeprimaryaudio, ordinary/Mainproxy, stale range/clip, empty/pending/no deferrededit, browser input, MIDIchild, actual numeric widget andtrack rename, Sessioncontext refusal.

Cloud final exacthead passed12 loop tests0ignored (new2+originalL4+oldrail6), strictUIClippy andQUICK6 statusPARTIAL. Priorf605checkpoint6+toolbar1 evidence remainsprioronly. Do NOTrepeat unchanged optionalrail/newnativefull20; fe9 native4/SHA660222bcdf2230ddfe99f0da6c26b33a57e6a2913ece42f11d9c835d7075613c is historical bareL evidence, not qualification for changedCommand-L.

Physical optimized/user-present acceptance remainsROOTowned: allselected audio/MIDI/gaps/primarypermutations, nonemptytimefirst/reverse/Mainproxy, exactvisiblebounds, repeatedCommand-L/oneUndoRedo/save-reopen, text/numeric/browser/rename/musicaltyping/focus andSession. No combined-tree/FULL20/physicalkeyboard/display/audio/GPU/listening/delivery acceptance fromCLI. Root latest external appsourcef7bf/build4156515146 is NOT333/346; no ownappoperations occurred. Originalfe9 evidence ref/archive unchanged. Dedicatedmerger owns finalactualprospectivetree requiredFULL20/review/integration/merge.
