import importlib.util
import sys
from pathlib import Path
root=Path('/workspace/hex-operator-tab')
spec=importlib.util.spec_from_file_location('hex_operator_final_ci', root/'scripts/local-ci.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('operator-tab',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','operator_tab_cycle','--','--nocapture'),uses_cargo_target=True),
 m.Step('browser-compatibility',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','editor::browser::ui_test','--','--nocapture'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
