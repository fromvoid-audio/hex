import importlib.util
import sys
from pathlib import Path
root=Path('/workspace/hex-operator-tab')
spec=importlib.util.spec_from_file_location('hex_operator_ci', root/'scripts/local-ci.py')
m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('operator-tab',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','operator_tab_cycle','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
