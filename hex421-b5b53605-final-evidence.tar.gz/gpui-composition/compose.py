from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,difflib,subprocess
r=Path('/workspace/hex-integration-open');v=r/'third_party/gpui';scratch=Path('/workspace/scratch/integration/421-recovery-gpui-merge')
# Only actual merge-conflict metadata; auto-merged runtime/test-support bytes retained.
p=v/'hex-provenance.json';s=p.read_text();a=s.index('<<<<<<< HEAD\n');b=s.index('=======\n',a);c=s.index('>>>>>>> origin/main\n',b);s=s[:a]+s[a+len('<<<<<<< HEAD\n'):b]+s[c+len('>>>>>>> origin/main\n'):];m=json.loads(s)
archive=Path('/workspace/scratch/integration/406-gpui-merge/gpui-0.2.2.crate');assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['crates_io_sha256']
base=scratch/'reapplied';base.mkdir(exist_ok=True);original={}
with tarfile.open(archive) as t:
 for x in t.getmembers():
  q=PurePosixPath(x.name);assert not q.is_absolute() and '..' not in q.parts and q.parts[0]=='gpui-0.2.2'
  if x.isdir():continue
  assert x.isfile();n=PurePosixPath(*q.parts[1:]).as_posix();data=t.extractfile(x).read();original[n]=data
  o=base/n;o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(data)
for n,sha in m['original_files'].items():assert hashlib.sha256(original[n]).hexdigest()==sha,n
name='src/app/test_context.rs';actual=(v/name).read_bytes();m['patched_files'][name]=hashlib.sha256(actual).hexdigest();p.write_text(json.dumps(m,indent=2)+'\n')
p=v/'hex-patches.diff';s=p.read_text();start=s.index('diff --git a/'+name+' b/'+name+'\n');end=s.find('\ndiff --git ',start+1);end=len(s) if end<0 else end+1
patch='diff --git a/'+name+' b/'+name+'\n'+''.join(difflib.unified_diff(original[name].decode().splitlines(keepends=True),actual.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name,n=0));s=s[:start]+patch+s[end:];assert '<<<<<<< HEAD' not in s;p.write_text(s)
subprocess.run(['git','apply','--check','--unidiff-zero',str(p)],cwd=base,check=True);subprocess.run(['git','apply','--unidiff-zero',str(p)],cwd=base,check=True)
for n in set(m['original_files'])|set(m['added_files']):
 assert (base/n).read_bytes()==(v/n).read_bytes(),n
for n,sha in m['patched_files'].items():assert hashlib.sha256((v/n).read_bytes()).hexdigest()==sha,n
for n,sha in m['added_files'].items():assert hashlib.sha256((v/n).read_bytes()).hexdigest()==sha,n
p=r/'todo.md';s=p.read_text();a=s.index('<<<<<<< HEAD\n');b=s.index('=======\n',a);c=s.index('>>>>>>> origin/main\n',b);s=s[:a]+s[a+len('<<<<<<< HEAD\n'):b]+'\n'+s[b+len('=======\n'):c]+s[c+len('>>>>>>> origin/main\n'):];assert '<<<<<<< HEAD' not in s;p.write_text(s)
proof={'archive_sha256':m['crates_io_sha256'],'combined_test_context_sha256':m['patched_files'][name],'original_files_verified':len(m['original_files']),'patched_files_verified':len(m['patched_files']),'added_files_verified':len(m['added_files']),'all_reapplied_bytes_match':True,'scope':'Ordinary42167/current450main integration: preserve pickerqueue+quadaccessor+Macfontoptin; onlycumulative test_contextdiff/provenance regenerateagainst verifiedoriginalarchive. No sourcefeature/guard weakening. todo keepsbothindependententries.'};(scratch/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
