# finite resize-release native request — coordinator single lane only

source 36cdec81428f00dcaed92354434c4e7139729107
tree bb6e8fdc52d530108914d318fdd3f3bc9bad3f82

Checks only / default native stack / no app install, launch, quit, GUI, unlock, permissions, backend or user-data changes:

cargo test -p hex-ui --features ui-test-support --locked editor::trim::resize_release_tests:: -- --nocapture
cargo test -p hex-ui --features ui-test-support --locked editor::drag_autoscroll::resize_pan_tests::fitted_resize_release_keeps_accepted_pan_horizon_until_exact_worker_terminal -- --nocapture

Both selectors use private disposable RAII browser/sample/recent/theme paths via the existing bounded constructor before startup workers, asserting actual initial directory/places; no ambient HOME/Music discovery. Expect EXACTLY5 + EXACTLY1 positive, zero failure/ignored. Capture actual filtered counts, exit, raw stdout/stderr/report+SHA and source/tree/dirty/default-stack provenance. First5 actual workers/prepared Engine and GPUI test windows cover both Shift and normal audio edges, both MIDI edges/source events, held→released→accepted canonical extent and metadata, oneUndoRedo, no motion/Escape/stale generation/closeprompt refusal. Controlled real queue/event test distinguishes earlier unrelated loop ack from own terminal, preserves independent loop edit, invalidates deleted stable clip owner, observes real resize refusal, and deferred submission. It is queue-seam coverage, not a claim ordinary gestures produce that artificial order. New1 uses real fitted audio/MIDI edgepan then release, immediate geometry+viewport equality through terminal, canonical edit and Undo. Correct namespace is editor::drag_autoscroll::resize_pan_tests (not trim).

Do not repeat unchanged old333 native5/full-suite/FULL20. Old333ef58 native5 proves only its old edgepan source, not this pending-release seam. Merger owns actual prospective combined tree FULL20/review/integration/merge. Physical acceptance OPEN/root-owned: affected media normal/Shift left/right, rapid moves/release/leave, stationary Shift/Command change, source limits/loop/warp/BPM, fitted/zoomed/held-edge pan, stable correct waveform, final extent/oneUndoRedo/save-reopen; physical/GPU/audio/listening/optimized delivery unverified. Original red proves transient old canonical repaint while pending, not permanent worker commit loss. Keep checking that user's broader report. Latest root-observed external app bbe35811/build3152238609, not our delivery; no app operations.
