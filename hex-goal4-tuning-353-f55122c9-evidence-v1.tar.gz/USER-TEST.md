# Hex tuning merged-source acceptance — source checks passed, native acceptance open

Chosen actual source `7fe4f48f95a23123981f41bdc4fa934f3d3d091b` / tree `c0a7f9fbd28e7c6f51e693f0e3d63e22b8b95f72`. Original final cloud candidate
`f55122c99bdbcb73d65ca6b1761c1180c509d6bc`. All four original source receipts and every retained log are in
this packet; final-qualification.json binds each receipt to its real head and
actual merge tree. Only352/353 are tree-identical to their original candidates;
350/351 original receipts remain source-bound historical per-PR evidence, and
final353 full20 qualifies the complete current integrated source. Included48 = byte-preserved prior46 entries plus
352/5a364458 and353/f55122c9; uniqueness and ancestry are verified.

This is NOT an installed-delivery or native acceptance claim. Installed f4d63124
build4107677988 remains the coordinator-verified READY baseline and excludes
352/353. Only the coordinator/launcher may schedule the one optimized delivery.
If Hex has been reopened, user save and normal quit are required before replacement.
Never force-quit, overwrite occupied user presets, reset a database or convert
unsupported alpha projects. Use disposable current schema31 projects containing
both tuning and assets. Accepted spinner/EQ gestures stand; no broad repeat gate.

Headless source/certificate/dynamic-fixture checks may run while the user is away;
physical UI/input/GPU/listening/real MTS-client behavior remain OPEN until actually
performed and recorded. No library installation, privileged change, entitlement
weakening, foreign master takeover or unattended real-master registration.

## New UI cases


1. **PR376:** focus a header by its name and its blank background; Command-R,
   edit and Enter. Verify one Undo/Redo. Open another draft and Escape. Arrow
   focus to another header and repeat; clip-header Command-R must still edit the
   clip name. Search and numeric-input focus must retain their keys.
2. **PR377:** click first clip, Shift-click fifth; check all five. Reverse the
   range and repeat Shift-clicks around the original anchor. Command-toggle a
   member, Command-Shift union, then Shift-click another track (new anchor).
   Clear in a lane, then Command-click: no hidden old members may return. Check
   ordinary header dragging and body time selection still behave normally.
3. **PR378:** header-select one clip, Command-C, click another time/track and
   Command-V. Repeat with several clips. Verify complete contents and original
   gaps, repeated paste, one atomic Undo/Redo, and source retention. Copy/paste
   text in search, return to the Arrangement and paste again: its whole-clip
   payload must remain. Keep accepted multi-source-track stable-owner semantics;
   no new cross-track remapping is expected.
4. **PR335:** inspect single/multiple selected audio and MIDI borders, hover,
   toggle a middle member while the endpoint stays selected, and deselect. Pan
   until clips are cropped at either viewport boundary. Drag/cancel ordinary
   trim/fade affordances and check selected preview borders, original clip colors,
   text, waveform/notes and usable edge hit areas. No source/time geometry change
   is expected.
5. Save/reopen only the disposable project to check renamed tracks and pasted
   whole content persist. This does not require saving/quitting the user's current
   app/project. Never force-quit or discard unsaved data.


## EQ remaining cases (preserve accepted gestures)


Use two independently audible tones/tracks, a Return and sparse EQ. Record PASS/FAIL/UNRUN with exact cohort SHA, device/rate/buffer, screenshots/listening notes and available callback/underrun telemetry. Do not reopen the accepted2729 gesture signoff.

1. Dual spectra: conspicuous EQ plus host trims produces real distinct input/output curves; input is before entry input trim, output after effect/output trim. Hide input independently. Check ordinary/Return EQ, bypass, silence/anti-phase stereo, stopping/keyboard monitoring and reopen.
2. Quality/layout: inspect bass readability, capture-driven decay and fixed−96..0dbfs display without claiming extra FFT resolution or exact Prism parity. At880x540 and1500x650, full labels/actions/readouts, response/automation rows and graph remain usable and unclipped.
3. Backspace: focused selected EQ node removes only that node/automation; Undo/Redo restores identities. Empty/held/pending/stale/automation-point cases preserve track/clip isolation; numeric/text editing retains its keys.
4. Project signals: no selection shows real Master; one/two/ALL256 selected canonical tracks produce independent correctly assigned-color layers plus Master, never a selected-track sum or silent prefix cap. Color edits, reorder/removal/reselection and project/output replacement clear stale/reused identities.
5. Tap semantics: each track is actual direct post-device/post-fader/balance output including owned tails; Master includes Returns/master gain before monitor-only metronome/browser preview. Vary effects/faders/mute/bypass/Return/master gain; nonlinear bus output is not claimed to equal the sum of track curves.
6. Lifecycle/input/GPU: collapse stops new project capture/analysis after bounded queued work drains; expand starts fresh. Resize outside release commits view height; Escape/focus/window/context change cancels without project Undo. Compact live header retains ALL layers at constrained populated details, restores preferred height in larger windows, and leaves Auto Pan/Operator/Return details and timeline usable.
7. Callback/profile bounds:33 fixed packet owners,32 forward/33 return slots, at most263168 stereo contribution frames/callback, whole-window refusal on exhaustion, no callback allocation/final-drop/lock/log/FFT. Worker uses the existing thread, max2 packets/8 stereo layers per turn. Caps30Hz/100ms up to32 tracks,10Hz/250ms for33–128,5Hz/400ms for129–256. Exercise selection churn/collapse/output restart and all256 layers at the supported rate plus one other available rate. Record real-device sustained audio/deadline and GPU responsiveness separately from worker profile. If a256-track fixture or telemetry is unavailable, mark that item UNRUN and report the bounded fixture/instrumentation need.

Return one finite result table, exact source/build/signature identity, minimum-window screenshots, raw profile/callback evidence and listening observations. Installation/merge is not human/native acceptance. Failures return to the owning canonical scope; unrun checks stay pending with the coordinator, without new source-feature scope or forced immediate Mac work.


Preparation API373 is included source provenance, not completed sampler389/tuning352/MTS353. Record one short regression smoke for existing ordinary playback/import/browser preview/Undo without changing user media; no new feature scope. Preserve prior resize/waveform/BPM/Shift/Command-T behavior; report a concrete regression rather than restarting all accepted manual work. Real WAV access and identical-executable relaunch acceptance are separate. Mark unavailable256-track fixtures or deadline telemetry UNRUN, retain bounded need; no source/native parity claims from cloud checks.

## Source392/393 and prior-cohort preservation

392 heap-constructs fixed257-layer publications/owners. Current factory-owned
payload26419596 bytes;32MiB cap excludes caller UI copies and total process/UI
memory.393 corrects two fixture caller frames without behavior/workload changes.
Those cases and installer394 regressions passed the NEW exacta60 full20 on both
platforms; actual Mac stack was unset/default. No new human approval gate or away-
user crash reproduction/quit/screenshot is required. Historical98/b101 reports
remain historical and are not relabeled. Current actual native original is
run20261017T203315Z-f7ceb696/SHA024fde063cd9255d6d1d80d3935b583e6bf12d84200a8f41680503eb58f9cd28.


After coordinator-scheduled recovery installs the verified new app and the user normally launches it, retain a bounded ordinary trim/fade/Warp/BPM/browser smoke: affected/control samples, normal left/right edges and lower fade handles, raw/Warp-on/processed-Warp-off, crop/reveal/loops and two zooms; no disappearing waveform/stale border. Lower fade free by default/Command snap and stationary modifier behavior; Escape/focus/outside-release cancellation, source retention and one UndoRedo. Shift stretch/BPM live preview remains coherent. Browser hover/progress/click-seek and sample-result double-click must not accidentally insert clips. Preserve accepted spinner/EQ gesture behavior; no repeated signoff gate.


## Added EQ390 response check

On the later qualified running app, inspect a narrow high-Q bell/notch and both
sides of its center, including disabled/out-of-bank nodes, overlapped bands and
narrow viewport. Authored response must retain narrow features without treating
it as an animated/automated response or promising reference-plugin parity.
Preserve accepted direct-value/drag gestures and test text/selection isolation.

## Evidence that remains separate

The finite ignored EQ maximum profile PASSED historically on qualified394
(Pulse2745/20958, log SHA2aa34bd3d5c0947dd0996a4565e5b2af8dc2abffc42af9e68a7119faef572df8).
Do not relabel it as a new candidate result. This focused installer fix and390
response-display sampling do not change its capture/worker ownership or caps;
no broad profile replay is requested solely for installer cleanup. Actual device
DSP/GPU deadlines and total UI memory remain unverified.
Physical/native input, listening and sample access remain OPEN. With user present,
preview a real WAV; after a NORMAL user save/quit, explicitly --open the SAME
installed executable and preview again. Verify hashes before/after. Default
./launch fetches/builds latest main and is not identical-binary relaunch evidence.
--test remains opt-in; do not run another launcher concurrently.


# Goal4 tuning/MTS acceptance

# finite native tuning acceptance

This is the queued Mac follow-up for goal4 and canonical PR350–353. It is not
permission to start a second local thread. The coordinator assigns the one local
lane; the launcher remains the owner of one combined optimized app delivery.
The final Pulse handoff supplies the exact candidate, four PR heads and cloud
receipts. Do not test an unrecorded working tree or infer native acceptance from
Linux checks.

## prerequisites and source checks

Record the clean checkout's full commit, Rust/Cargo versions, macOS/architecture
and SDK/toolchain. Confirm the candidate contains both schema31 data families,
the merged launcher and signing/provenance changes. Preserve any existing dirty
work rather than resetting it. Use disposable projects and new preset paths;
never convert or rewrite unsupported alpha30 projects.

Run the Mac-specific package checks from the exact checkout:

```sh
cargo test -p hex-mts --locked
cargo test -p hex-storage --test tuning --test device_assets --locked
cargo test -p hex-audio --features allocation-probe --test callback_allocations --locked
CARGO_TARGET_DIR=third_party/mts-esp-master/target cargo test --manifest-path third_party/mts-esp-master/Cargo.toml --locked
CARGO_TARGET_DIR=third_party/mts-esp-master/target cargo clippy --manifest-path third_party/mts-esp-master/Cargo.toml --all-targets --locked -- -D warnings
```

These compiled fixtures exercise the platform loader boundary without touching
the installed library or machine-wide master. Retain commands, source identity,
exit codes and output. Use repository target-ownership rules; do not adopt or
clean another active checkout's cache. Report a platform failure to cloud5 before
changing source; a repair needs fresh exact-source evidence.

Record the bounded keyboard handoff release probe on the actual Mac CPU, with
its own inactive/owned profile target and no concurrent compiler job:

```sh
CARGO_TARGET_DIR=artifacts/tuning-native-profile/target cargo test --release -p hex-engine --lib profile_keyboard_tuning_handoff_copy_cost --locked -- --ignored --nocapture
```

Retain the printed workload, runtime/override sizes and same-tuning/retune
percentiles, plus hardware, toolchain and background-load context. This is a CPU
handoff measurement; physical CoreAudio/listening evidence remains separate.

## launcher-owned delivery

The launcher owner supplies one optimized, signed, stable-path combined bundle
through the current repository delivery tooling, with exact candidate, included
PR heads, checklist and receipt. Preserve the launcher's build-only/test mode
and provenance distinctions: a build-only receipt does not assert that tests ran.
Verify the actual signature/team and receipt against the delivered bundle.

App replacement requires the user to save their work and quit Hex normally.
Never force-quit, discard unsaved data, create competing test-app copies or start
an installation from this checklist. Ordinary user Hex use may continue until
the coordinator schedules that delivery window.

## user interaction and listening

The user performs these interactions while present, with no parallel automated
computer-use session. Record pass/fail and a reproducer for each failed item:

1. Open tuning in a new neutral project. Opening does not enable tuning or dirty
   the project. Check useful resizing, lowercase typography, focus, scroll,
   shortcuts, keyboard accessibility and traffic-light clearance. Record any
   missing accessibility semantics explicitly. Native MTS errors render lowercase
   while original source/error metadata stays intact.
2. Edit degree Hz/cents with Enter, Escape, blur and arrow/fine steps. Insert,
   drag and remove on the pitch line and context menu; exercise the 3/48-degree
   bounds and protected root. Right-click an unselected node: add/remove must
   target that node. A period compression that violates one-cent spacing must
   report refusal and preserve the scale; a valid period must recover. Check
   fractional audition-level coarse/fine steps. One whole gesture is one Undo/Redo step.
3. Set root degree/key/Hz, non-octave period and ratio/Shift snapping; exercise
   equal divisions, just major and selected-note snap. Check pitch-space point
   selection, Reach/dice changes and lattice/pair/whole-scale statistics. Click
   dice repeatedly with unchanged scale/Reach: choices must change while the
   project stays untouched until a point is selected.
4. Save/load/rename/duplicate among eight local slots using disposable names.
   Use an empty/disposable slot; never overwrite an occupied user preset to
   manufacture acceptance. If none is available, leave that write check pending.
   Save/reopen with a locally pending tuning Change and with a reserved Commit:
   both must persist the latest value. Closing/quitting an acknowledged but
   uncommitted preview must prompt; canceling close must preserve the work.
   In an otherwise empty project with a tuning draft, Open/New must require the
   existing replacement confirmation before discarding it.
   Import/export FREQS1/2/3 scratch fixtures, including malformed refusal.
   Save/reopen a tuning scratch project and verify working scale/audition,
   independent of slot names. The storage fixtures above verify both schema31
   data families together. For a reviewed bound-device project fixture, record
   any unsupported resource-processing refusal separately: the file and current
   project must stay intact, with no silent removal of bindings or conversion.
   Resource-backed playback admission remains the native host owner's gate.
   Loading/importing the identical scale must preserve clean state and Redo.
   Start Undo or another canonical edit, then immediately try a new tuning edit:
   it must wait rather than resurrect an older whole tuning value.
   While a device gesture is finishing, request a current tuning-library action:
   it must observe that exact terminal without an unnecessary stale retry and
   retain FIFO order with a later canonical edit. New import/export dialogs wait
   before capturing context. A dialog opened earlier must still refuse after a
   revision change and preserve its chosen existing destination; do not overwrite
   user presets or files to manufacture this check.
5. With no selected track and project tuning disabled, audition triangle, square
   and saw; change level/attack/release and tuning while holding/releasing notes.
   Numeric/text focus must not play notes. Modified key release, deactivation,
   close, Stop and project replacement must leave no stuck note or autorepeat
   restart. Press Stop while reference preparation or publication is pending:
   the delayed candidate must not restart a held tone. Include a refused held
   high note, then retune it into the supported
   range without releasing the physical key: it should become audible while
   already sounding supported voices keep their phase/envelope. Move a held or
   releasing reference tone above Nyquist: only that voice must retire with a
   visible refusal, while the valid retuned project graph still installs. Check held/recent reference
   and Arrangement/Session gate highlights. Hold all 17 mapped input keys: the
   excess note must refuse visibly without stealing an already held owner;
   release/repress after capacity is available to recover. Verify bypassed or
   missing instruments show no gates, and an instrumentless Session MIDI source
   routed to instrument destinations highlights its actual routed notes.
6. In sine, FM4 and Operator scratch projects, compare neutral and enabled custom
   tuning in Arrangement, Session and keyboard monitoring. Include root offsets,
   7/19-degree non-octave scales, rapid edits/Undo and held/released voices.
   Listen for unintended restart/clicks; fixed-Hz oscillators remain fixed. Check
   the exported PCM against the same authored pitches. Record audio device,
   sample rate/buffer and any underrun/fault; listening is not a deadline proof.

## installed MTS and compatible client

Record whether the existing compatible library is present at
`/Library/Application Support/MTS-ESP/libMTS.dylib`, its version/identity, the
actual bundle signing flags/entitlements and the client's version/IPC domain.
Do not install privileged software, change entitlements, buy a client or reset
another master. Absence is explicit unavailable evidence and leaves this item
open; fixture success is not an installed-client pass.

1. With an existing foreign master, explicitly enable Hex broadcast: observe
   blocked, with the other master/table unchanged. Do not end the user's other
   session to manufacture a pass. Test reacquisition only when that owner has
   voluntarily released; use explicit retry.
2. In a free domain, explicitly enable the intended Hex project. Confirm active
   status, client count and actual compatible-client frequencies/metadata for
   the custom root/period. Compare a second publication and held-note behavior;
   record client limitations and asynchronous native/MTS revisions separately.
   A transient preview must publish only after its exact native candidate applies;
   a refused nonterminal preview must preserve the previous published table.
   Check Cancel/Commit restoration and canonical commits without an audio output
   separately. Worker preparation alone is not an applied-audio receipt.
3. Change window focus: ownership stays explicit. Close the tuning popup:
   broadcasting continues. Disable, replace the project and quit normally:
   owned registration is released, a different master can acquire, and native
   Hex tuning worked throughout unavailable/blocked states.
4. Capture an actual signed-bundle loader failure verbatim. If library validation
   prevents loading, report the bounded signing decision through the coordinator;
   do not silently weaken signing policy. Retain the delivered bundle's identity.

Report source/build/fixture evidence separately from user interaction, physical
audio/listening and real-client evidence. Keep goal4/native acceptance open for
any unperformed item and relay results to the existing Pulse tickets.
