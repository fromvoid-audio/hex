# Finite coordinator-owned native request — goal4 tuning/MTS

Chosen actual merged source: `7fe4f48f95a23123981f41bdc4fa934f3d3d091b`
Original cloud candidate: `f55122c99bdbcb73d65ca6b1761c1180c509d6bc`
Identical Git tree: `c0a7f9fbd28e7c6f51e693f0e3d63e22b8b95f72`

This is a checks/build/delivery packet for the coordinator's ONE serial Mac lane,
not cloud permission to execute locally. Existing stable f4d63124/build4107677988
and its READY owner stay unchanged until coordinator/launcher scheduling. Never
checkout, build or merge the separate evidence ref: extract its archive only.

## Evidence and prerequisites

1. Verify archive byte count/SHA256, safe members and every file-manifest payload.
   Read final-qualification.json, source-identity.json and the original full reports.
   Verify all48 unique included heads are ancestors of chosen source. The first46
   entries exactly preserve the prior verified manifest; 352 and353 add actual
   qualified heads. Historical1251 and partial/failed/quick receipts stay historical.
2. Use a clean exact source checkout; preserve unrelated work. Verify Git tree,
   source-byte-mode-ledger.json and actual executable modes, especially `launch`.
   Record macOS/architecture/SDK, Rust/Cargo, CPU and target identity/ownership.
   A same-tree actual merge is not a relabeled CI report: either retain the real
   candidate report with the tooling's unchanged ancestry/digest acceptance, or
   run native full CI on the chosen actual merge and retain that new original.
3. No competing job/app replacement. Inspect any existing target's owner/inode;
   use an inactive owned private target under repository rules. Do not guess an
   adoption, clean someone else's target, weaken disk floors or edit owner files.
   The user may ordinarily use Hex; if opened, save and normal quit are necessary
   before any later replacement. Never force-quit or discard unsaved data.

## Headless source and configured-certificate checks

The coordinator may perform these while the user is away. Native source fixtures
are distinct from native platform acceptance and real client behavior. Existing
f551 native checks and adapter results must be reused if exact source/tree/mode
and original report are valid; do not duplicate a live or completed owned run.

From exact chosen source (or original candidate when explicitly recorded), with
`HEX_NATIVE_CI_TARGET` set to the inspected inactive/owned target:

```sh
: "${HEX_NATIVE_CI_TARGET:?set the inspected owned private target}"
(
  unset RUST_MIN_STACK
  export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
  export CARGO_TARGET_DIR="$HEX_NATIVE_CI_TARGET"
  export HEX_TEST_SIGNING_IDENTITY=4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E
  python3 scripts/local-ci.py
)
```

The certificate opt-in runs existing isolated temporary signature fixtures using
configured team DKTKQ8U5T8; it is not an installed-app signing/delivery claim. No
unlock/keychain policy or identity change. Retain original full summary and ALL
stage logs, default-stack/jobs context, exit/stale/clean/digest evidence, exact
fixture counts/skips and source/mode proof. Do not relabel a source or receipt.
Cloud uses Rust1.94/jobs4/16MiB stack; its pass is not a Mac default-stack proof.

The excluded `mts-esp-master` crate is NOT covered by workspace CI. If the exact
f551 coordinator-reported pass is already backed by its raw logs, reuse it rather
than rerun. Otherwise use a distinct inactive/owned adapter target, serially after
workspace CI:

```sh
: "${HEX_NATIVE_ADAPTER_TARGET:?set an inactive owned adapter target}"
CARGO_TARGET_DIR="$HEX_NATIVE_ADAPTER_TARGET" cargo test --manifest-path third_party/mts-esp-master/Cargo.toml --locked
CARGO_TARGET_DIR="$HEX_NATIVE_ADAPTER_TARGET" cargo clippy --manifest-path third_party/mts-esp-master/Cargo.toml --all-targets --locked -- -D warnings
```

Dynamic fixtures compile isolated temporary stub dylibs. Their registration/table
calls are against those fixtures, NOT the installed system master. Keep original
stdout/stderr, counts and exit codes. Existing read-only inspection reports an
installed universal arm64/x86_64 `/Library/Application Support/MTS-ESP/libMTS.dylib`,
Developer ID ZTMS6M322L. That is existence/identity evidence only. During checks-only
work, do not load/call that real library, register a real master, install a new
library, take over/reset another master, change entitlements or require a purchase.

## Optimized CPU measurement (separate from physical deadlines)

The coordinator already reports exactf551 release probe PASS; reuse its original
report/log identities in independent-review-and-native-relay.md rather than rerun.
The following command is reproducibility guidance only if source or proof requires
a new measurement. Use an inactive/owned profile target, no concurrent compiler, actual Mac CPU and
record background load. This finite ignored probe has no audio-device/client claim:

```sh
: "${HEX_NATIVE_PROFILE_TARGET:?set an inactive owned profile target}"
CARGO_TARGET_DIR="$HEX_NATIVE_PROFILE_TARGET" cargo test --release -p hex-engine --lib profile_keyboard_tuning_handoff_copy_cost --locked -- --ignored --nocapture
```

Retain workload/runtime/override sizes and p50/p95/p99/max for same-tuning/retune,
OS/toolchain/hardware. Do not infer a CoreAudio deadline or listening result.

## Launcher-owned optimized signed delivery — only when scheduled/qualified

One combined stable-path optimized bundle, no competing test-app copies. Preserve
current launcher build-only/test distinctions and installer provenance. Run the
existing source guard before build/delivery; a partial output or build-only receipt
cannot claim tests or successful publication. Use actual native report bytes and
the verified48 manifest plus this packet's USER-TEST.md. A representative supported
command, only in the coordinator/launcher's scheduled lane, is:

```sh
: "${HEX_NATIVE_FULL_REPORT:?set the verified original native full summary}"
: "${HEX_PACKET_DIR:?set the safely verified extracted packet directory}"
: "${HEX_NATIVE_REPORT_CANDIDATE:?set the exact commit field from the original native report}"
sh scripts/bundle-macos.sh --ci-report "$HEX_NATIVE_FULL_REPORT" --candidate "$HEX_NATIVE_REPORT_CANDIDATE" --included "$HEX_PACKET_DIR/included-test-revisions.json" --checklist "$HEX_PACKET_DIR/USER-TEST.md"
```

If the original native report is for candidate f55122c99bdbcb73d65ca6b1761c1180c509d6bc, record that actual
candidate as HEX_NATIVE_REPORT_CANDIDATE (not the merge SHA) and use only the existing unchanged guard's same-tree/ancestry/digest
acceptance; do not substitute report fields or force an acceptance. Follow current
repository target-ownership/build instructions. Do not add ad-hoc adoption or owner
writes. User save/normal quit if Hex is open. No launch/GUI automation while away.
After delivery require OVERALL exit0, strict actual signature/team/DR and sealed+
adjacent receipt match, actual signed/unsigned identities, all48 heads/checklist/
original-CI hash and READY owner/source/artifact/inode proof. Retain original logs,
failures and preserved old baseline. Source merge alone is not delivery.

## User-present GUI, audio and real compatible-client acceptance

Use USER-TEST.md and source-docs/tuning-native-acceptance.md. User performs physical
interaction/listening while present, without parallel automated computer use.
Preserve accepted spinner/EQ gesture signoffs. Check all original Freqs capabilities,
current-format save/reopen with BOTH data families, gesture Undo/Redo/Save/Close,
new device-terminal library/FIFO and stale earlier-dialog guards, independent
reference audition, native instrument tuning and actual exported PCM. Scratch
projects/new paths/empty disposable slots only. Never overwrite occupied user data
or convert unsupported historical-alpha projects to manufacture a pass.

Real MTS phase requires an existing compatible client and explicit user project
ownership/broadcast. Record client/library/domain/version and actual frequencies,
foreign-master blocked state without takeover, voluntary release/retry, held notes,
applied native versus published revision, Cancel/Commit/no-audio behavior, disable/
replacement/normal-quit cleanup. No purchase or installation. If no real client is
available, leave this item OPEN. For signed-loader failure, preserve the actual
error/bundle identity and request a bounded signing decision; never silently weaken
library validation. UI errors stay lowercase; technical source metadata stays exact.

Return four separate evidence rows: (1) cloud source checks, (2) native compiled/
certificate/adapter/profile evidence, (3) actual installed-library/client behavior,
(4) physical GUI/audio/listening. Give exact source/tree/build/signature, original
report hashes, PASS/FAIL/UNRUN and repros. Keep goal4 and Pulse2741/2742 open for
unperformed acceptance. No database reset, destructive conversion/deletion, hosted
CI, privileged/system-library change or registration takeover is authorized.
