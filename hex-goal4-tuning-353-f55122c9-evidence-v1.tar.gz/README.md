# Evidence-only Hex goal4 source/native handoff

NEVER checkout/build/merge the evidence ref. Application source is `7fe4f48f95a23123981f41bdc4fa934f3d3d091b`;
original cloud candidate `f55122c99bdbcb73d65ca6b1761c1180c509d6bc`, identical tree `c0a7f9fbd28e7c6f51e693f0e3d63e22b8b95f72`. This packet
contains original final four full reports plus ALL retained source-check logs
and failed/partial/interrupted history. Read final-qualification.json first;
all-report-catalog.json does not promote historical/quick runs into eligibility.
Native platform/real-library/client/UI/listening acceptance remains separate.

Use included-test-revisions.json (48 verified unique ancestral heads), USER-TEST.md
and NATIVE-REQUEST.md for the coordinator-owned next step. Review and source/mode
ledgers are included. All raw report content is copied byte-identically; no
summary fields or failure receipts were rewritten. No binaries, user projects,
credentials, app ownership files or generated target caches are included.
Prior installer evidence ref: evidence/hex-installer-2788-a60adf63-v1, commit
2a8b6eafd25a879493e3bb9ae1f67d37ab23ed93. Prior raw manifest/checklist copies are
historical provenance; the root USER-TEST.md is the active combined checklist.

Before extraction, verify the published archive byte count/SHA256, then reject
absolute paths, '..', duplicate names, links or nonregular members. After extraction
verify every file-manifest.json size/hash. Durable Git transport instructions
and exact archive identity are recorded on existing Pulse2742 and this chat.
