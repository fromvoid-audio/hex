use super::*;
fn reservation(retained: usize, peak: usize) -> AudioCandidatePublicationReservation {
    AudioCandidatePublicationReservation {
        runtime_slots: 3,
        archive_slots: 3,
        member_rows: 128,
        transfer_rows: 128,
        receipt_rows: 3,
        data_rows: 256,
        handle_rows: 256,
        max_retained_data_bytes: retained,
        max_construction_peak_data_bytes: peak,
    }
}
#[test]
fn actual_root_three_queues_exact_and_each_minus_one_before_all_births() {
    let (retained, peak) = bound().unwrap();
    for limits in [
        reservation(retained - 1, peak),
        reservation(retained, peak - 1),
    ] {
        let measured = allocation_counter::measure(|| {
            assert!(matches!(
                construct(Some(limits)),
                Err(Invalid("prepared Root/queue birth reservation exceeded"))
            ));
        });
        assert_eq!(
            (
                measured.count_total,
                measured.count_current,
                measured.bytes_total,
                measured.bytes_current
            ),
            (0, 0, 0, 0)
        );
    }
    let mut actual = None;
    let measured = allocation_counter::measure(|| {
        actual = Some(construct(Some(reservation(retained, peak))).unwrap())
    });
    assert_eq!(
        (measured.count_total, measured.bytes_total),
        (13, retained as u64)
    );
    let Queues {
        root,
        publications,
        incoming,
        returning,
        retired,
        mut commands,
        mut events,
    } = actual.unwrap();
    let rings = ring_bytes::<QueuedPublication>(1).unwrap()
        + ring_bytes::<ReturnedPublication>(RETIRED).unwrap()
        + ring_bytes::<QueuedCommand>(COMMANDS).unwrap();
    assert_eq!(root.test_prepared_ring_data().unwrap(), (3, rings));
    let transfers = allocation_counter::measure(|| {
        // The actual typed queue is used, not a surrogate test transport.
        assert!(commands.write_chunk_uninit(0).is_ok());
        assert!(events.pop().is_err());
    });
    assert_eq!((transfers.count_total, transfers.count_current), (0, 0));
    drop(publications);
    drop(incoming);
    drop(returning);
    drop(retired);
    drop(commands);
    drop(events);
    assert_eq!(
        root.test_prepared_ring_data().unwrap(),
        (
            3,
            3 * NativeFixedRingRegistration::metadata_requested_bytes_on_control().unwrap()
        )
    );
    eprintln!(
        "SUPPORTED real factory Root+3queue registrations13births/{retained}bytes, typed scratch peak{peak}; retained/peak-minus1 before any allocation; actual Root retains3 physical records through six normal endpoint drops. OTHERchannel/family/native inputs remain mandatory; not full factory admission"
    );
}
#[test]
fn actual_resident_legacy_queues_are_not_adopted_by_new_factory_record_path() {
    let queues = construct(None).unwrap();
    assert_eq!(queues.root.test_prepared_ring_data().unwrap(), (0, 0));
    assert!(CandidateRoot::requested_birth_bytes(usize::MAX).is_none());
    eprintln!(
        "SUPPORTED legacy/resident constructor records stay absent/unqualified; no retrospective adoption, Root slot layout overflow refuses"
    );
}

#[test]
fn actual_domain_configuration_retains_three_records_and_charges_only_old_budget_omissions() {
    let (retained, peak) = bound().unwrap();
    let queues = construct(Some(reservation(retained, peak))).unwrap();
    let old_queue_bodies = size_of::<rtrb::RingBuffer<QueuedPublication>>()
        + size_of::<QueuedPublication>()
        + size_of::<rtrb::RingBuffer<ReturnedPublication>>()
        + RETIRED * size_of::<ReturnedPublication>()
        + size_of::<rtrb::RingBuffer<QueuedCommand>>()
        + COMMANDS * size_of::<QueuedCommand>();
    let ring_bytes = ring_bytes::<QueuedPublication>(1).unwrap()
        + ring_bytes::<ReturnedPublication>(RETIRED).unwrap()
        + ring_bytes::<QueuedCommand>(COMMANDS).unwrap();
    let required =
        CandidateRoot::requested_birth_bytes(RETIRED).unwrap() + ring_bytes - old_queue_bodies;
    let short = allocation_counter::measure(|| {
        assert!(
            queues
                .root
                .configure_domains(crate::AudioCandidateDomainReservation {
                    max_retained_data_bytes: required - 1,
                    max_construction_peak_data_bytes: required,
                })
                .is_err()
        );
    });
    assert_eq!((short.count_total, short.count_current), (0, 0));
    assert_eq!(
        queues.root.test_prepared_ring_data().unwrap(),
        (3, ring_bytes)
    );
    let exact = allocation_counter::measure(|| {
        queues
            .root
            .configure_domains(crate::AudioCandidateDomainReservation {
                max_retained_data_bytes: required,
                max_construction_peak_data_bytes: required,
            })
            .unwrap();
    });
    assert_eq!(
        (
            exact.count_total,
            exact.count_current,
            exact.bytes_total,
            exact.bytes_current
        ),
        (0, 0, 0, 0)
    );
    assert_eq!(
        queues.root.test_prepared_ring_data().unwrap(),
        (3, ring_bytes)
    );
    eprintln!(
        "SUPPORTED actual3 records survive zeroalloc configure; old core/backing budget not charged twice, actual omitted core-header/padding+3metadata is charged before configure accepts. Domain-only test is NOT full native/channel admission"
    );
}

#[test]
fn actual_registered_constructor_channel_preserves_silence_and_callback_zero_alloc_free() {
    let (_, peak) = bound().unwrap();
    let (control, mut callback) = channel_with_factory_reservation(
        48000,
        None,
        Some(reservation(1 << 20, (2 << 20).max(peak))),
    )
    .unwrap();
    let root = control.native_candidate_root();
    assert_eq!(root.test_prepared_ring_data().unwrap().0, 3);
    let mut output = [[1.0_f32; 2]; 128];
    let measured = allocation_counter::measure(|| {
        for _ in 0..64 {
            callback.render(&mut output).unwrap();
            assert!(output.iter().all(|frame| *frame == [0.0; 2]));
        }
        control.stop();
        callback.render(&mut output).unwrap();
    });
    assert_eq!(
        (
            measured.count_total,
            measured.count_current,
            measured.bytes_total,
            measured.bytes_current
        ),
        (0, 0, 0, 0)
    );
    drop(callback);
    drop(control);
    assert_eq!(
        root.test_prepared_ring_data().unwrap(),
        (
            3,
            3 * NativeFixedRingRegistration::metadata_requested_bytes_on_control().unwrap()
        )
    );
    eprintln!(
        "SUPPORTED real registered channel unchanged silent128frame/64turn+Stop callback0alloc/free; actual endpoint normaldisposal leaves only Root-heldmetadata. No nativeSome/activeSampler/fullstartup qualification from silence"
    );
}

#[test]
fn actual_invalid_publication_shape_refuses_before_any_root_queue_birth() {
    let (retained, peak) = bound().unwrap();
    let valid = reservation(retained, peak);
    for invalid in [
        AudioCandidatePublicationReservation {
            runtime_slots: 0,
            ..valid
        },
        AudioCandidatePublicationReservation {
            archive_slots: 0,
            ..valid
        },
        AudioCandidatePublicationReservation {
            receipt_rows: 0,
            ..valid
        },
        AudioCandidatePublicationReservation {
            max_retained_data_bytes: peak + 1,
            ..valid
        },
    ] {
        let measured = allocation_counter::measure(|| {
            assert!(matches!(
                construct(Some(invalid)),
                Err(Invalid("invalid constructor publication reservation"))
            ));
        });
        assert_eq!(
            (
                measured.count_total,
                measured.count_current,
                measured.bytes_total,
                measured.bytes_current
            ),
            (0, 0, 0, 0)
        );
    }
    eprintln!(
        "SUPPORTED same canonical publication shape validation now precedes first Root/queue birth as well as later publication bank preparation;4invalid shapes0alloc/free"
    );
}

#[test]
fn actual_later_publication_budget_equals_real_existing_root_queues_plus_new_cell_births() {
    let limits = reservation(1 << 20, 2 << 20);
    let (root_bytes, _) = bound().unwrap();
    let old_queue_bodies = size_of::<rtrb::RingBuffer<QueuedPublication>>()
        + size_of::<QueuedPublication>()
        + size_of::<rtrb::RingBuffer<ReturnedPublication>>()
        + RETIRED * size_of::<ReturnedPublication>()
        + size_of::<rtrb::RingBuffer<QueuedCommand>>()
        + COMMANDS * size_of::<QueuedCommand>();
    let first = construct(Some(limits)).unwrap();
    let allocated = allocation_counter::measure(|| {
        first
            .root
            .configure_publications(limits, old_queue_bodies)
            .unwrap()
    });
    let actual_total = root_bytes + allocated.bytes_total as usize;
    assert_eq!(
        first.root.domain_usage().unwrap().retained_data_reservation,
        actual_total,
        "old core/backing DATA counted once, actual header/padding/registration and new cell backings all present"
    );
    for cap in [actual_total - 1, actual_total] {
        let next = construct(Some(limits)).unwrap();
        let mut selected = limits;
        selected.max_retained_data_bytes = cap;
        selected.max_construction_peak_data_bytes = actual_total;
        let measured = allocation_counter::measure(|| {
            let result = next.root.configure_publications(selected, old_queue_bodies);
            assert_eq!(result.is_ok(), cap == actual_total);
        });
        if cap < actual_total {
            assert_eq!(
                (
                    measured.count_total,
                    measured.count_current,
                    measured.bytes_total,
                    measured.bytes_current
                ),
                (0, 0, 0, 0)
            );
        } else {
            assert_eq!(root_bytes + measured.bytes_total as usize, actual_total);
        }
        assert_eq!(next.root.test_prepared_ring_data().unwrap().0, 3);
    }
    eprintln!(
        "SUPPORTED later publication retained accounting EXACT{actual_total}=actual first Root+3queues plus allocator-measured new cell/receipt/Life births; minus1 refuses before new cell birth; records persist; not full native/host lifetime admission"
    );
}
