//! Closed Root + THREE existing queue birth. This necessary local bound is not
//! complete channel/family/native admission: the other channel children and
//! retained external parents still need mandatory joint construction inventory.
use super::*;
use crate::{
    candidate_custody::{AudioCandidatePublicationReservation, CandidateRoot},
    native_callback_owner::registered_prepared_ring,
};
use hex_engine::sampler_host_fields::NativeFixedRingRegistration;

pub(super) struct Queues {
    pub(super) publications: Producer<QueuedPublication>,
    pub(super) incoming: Consumer<QueuedPublication>,
    pub(super) returning: Producer<ReturnedPublication>,
    pub(super) retired: Consumer<ReturnedPublication>,
    pub(super) commands: Producer<QueuedCommand>,
    pub(super) events: Consumer<QueuedCommand>,
    // Keep constructor custody alive until all six local endpoint fields drop.
    pub(super) root: CandidateRoot,
}
fn ring_bytes<T>(capacity: usize) -> Option<usize> {
    NativeFixedRingRegistration::requested_bytes_on_control::<rtrb::RingBuffer<T>, T>(capacity).ok()
}
fn ring_scratch<T>() -> Option<usize> {
    NativeFixedRingRegistration::construction_scratch_bytes_on_control::<rtrb::RingBuffer<T>>()
        .ok()?
        .checked_add(size_of::<(rtrb::Producer<T>, rtrb::Consumer<T>)>())?
        .checked_add(size_of::<(
            Producer<T>,
            Consumer<T>,
            NativeFixedRingRegistration,
        )>())
}
fn bound() -> Option<(usize, usize)> {
    let retained = CandidateRoot::requested_birth_bytes(RETIRED)?
        .checked_add(ring_bytes::<QueuedPublication>(1)?)?
        .checked_add(ring_bytes::<ReturnedPublication>(RETIRED)?)?
        .checked_add(ring_bytes::<QueuedCommand>(COMMANDS)?)?;
    // Conservatively include all typed constructor scratch together, plus the
    // actual returned aggregate. No scalar savings from mutually exclusive paths.
    let peak = retained
        .checked_add(CandidateRoot::birth_scratch_bytes()?)?
        .checked_add(ring_scratch::<QueuedPublication>()?)?
        .checked_add(ring_scratch::<ReturnedPublication>()?)?
        .checked_add(ring_scratch::<QueuedCommand>()?)?
        .checked_add(size_of::<Queues>())?;
    Some((retained, peak))
}
pub(super) fn construct(
    reservation: Option<AudioCandidatePublicationReservation>,
) -> Result<Queues, Invalid> {
    if let Some(reservation) = reservation {
        reservation.validate_shape().map_err(Invalid)?;
        let (retained, peak) =
            bound().ok_or(Invalid("prepared Root/queue constructor layout is unknown"))?;
        if retained > reservation.max_retained_data_bytes
            || peak > reservation.max_construction_peak_data_bytes
        {
            return Err(Invalid("prepared Root/queue birth reservation exceeded"));
        }
    }
    let root = CandidateRoot::new(RETIRED).map_err(Invalid)?;
    if reservation.is_some() {
        let (publications, incoming, record) = registered_prepared_ring(1)
            .map_err(|_| Invalid("publication queue constructor pairing refused"))?;
        root.retain_prepared_ring(0, record).map_err(Invalid)?;
        let (returning, retired, record) = registered_prepared_ring(RETIRED)
            .map_err(|_| Invalid("return queue constructor pairing refused"))?;
        root.retain_prepared_ring(1, record).map_err(Invalid)?;
        let (commands, events, record) = registered_prepared_ring(COMMANDS)
            .map_err(|_| Invalid("command queue constructor pairing refused"))?;
        root.retain_prepared_ring(2, record).map_err(Invalid)?;
        Ok(Queues {
            root,
            publications,
            incoming,
            returning,
            retired,
            commands,
            events,
        })
    } else {
        // Historical resident/legacy constructor stays unqualified. Its actual
        // endpoints are not adopted by a later reservation/configuration call.
        let (publications, incoming) = native_prepared_ring(1);
        let (returning, retired) = native_prepared_ring(RETIRED);
        let (commands, events) = native_prepared_ring(COMMANDS);
        Ok(Queues {
            root,
            publications,
            incoming,
            returning,
            retired,
            commands,
            events,
        })
    }
}
#[cfg(all(test, feature = "allocation-probe"))]
mod tests;
