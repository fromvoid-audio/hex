from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil,re
r=Path('/workspace/hex-sampler-aggregate');out=Path('/tmp/hex395-99a1-worker-fields-v2');out.mkdir(exist_ok=False)
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
def sha(b):return hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();assert head=='99a1f23d712621d279cbb8bacac67e0b3e8f4f68';assert not git('status','--porcelain')
rows=[]
for name in git('diff','--name-only','HEAD^','HEAD').decode().splitlines():
 b=(r/name).read_bytes();p=out/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
assert len(rows)==5
(out/'SOURCE.json').write_text(json.dumps(dict(head=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),parent=git('rev-parse','HEAD^').decode().strip(),files=rows),indent=2))
(out/'SOURCE.diff').write_bytes(git('diff','--binary','HEAD^','HEAD'))
for name in ['crates/hex-engine/src/audio_storage.rs','crates/hex-engine/src/audio_storage/arithmetic.rs','crates/hex-session/src/service/worker_roots.rs','crates/hex-desktop/src/snapshot_transport/inventory.rs','crates/hex-audio/src/candidate_custody/eligible/publication/preparation.rs']:
 p=out/'context'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,p)
logs=out/'logs';logs.mkdir()
for p in Path('/tmp').glob('hex395-worker-fields-*'):
 if p.is_file():shutil.copy2(p,logs/p.name)
final=json.loads(Path('/tmp/hex395-worker-fields-final-results.json').read_text());assert final['start_source']==final['end_source'];assert all(x['exit']==0 for x in final['results'])
names=[]
for log in ['/tmp/hex395-worker-fields-final-worker.log','/tmp/hex395-worker-fields-final-dispatch.log','/tmp/hex395-worker-fields-final-borrow.log']:
 names+=re.findall(r'^test (.+?) \.\.\. ok$',Path(log).read_text(),re.M)
assert len(names)==len(set(names))==4
(out/'CHECKS.json').write_text(json.dumps(dict(exact_final_unique=4,names=names,final_source_receipt=final,limits='Cloud stack16MiB/jobs4; 3 runtime +1 compile-fail borrow doc. FullCI/native not run. f3a0 previous component unchanged.'),indent=2))
quick=r/'artifacts/local-ci/20261019T113207Z-2e85c9a7';q=json.loads((quick/'summary.json').read_text());assert q['commit']==head and not q['dirty'] and not q['stale'] and q['exit_code']==0 and q['status']=='partial' and q['start_tree']==q['end_tree'];assert len(q['steps'])==6 and all(s['status']=='passed' for s in q['steps']);shutil.copytree(quick,out/'local-ci')
(out/'HANDOFF.md').write_text("""# Actual worker dispatch descendant component, NOT ready395

Canonical99a1 over f3a0,5files. Actual existing WorkerRootChildInventory now builds finite Engine SamplerWorkerFields from exhaustive actual WorkerDispatchState/Event/preview/export fields. Mandatory named Engine traversal covers actual current/Event/device/tuning previews, MIDI and media/recovery/export/completion paths; no projection-list allocation/owner clone/arbitrary ledger callback. Actual Session/cache/transform/cancellation selected visits unchanged; explicit whole-parent/legacy compiled/journal/gesture/channel refusal unchanged. No source/publishing readiness or complete worker claim. Actual pending Event fixture independently compares all4 distinct views/paths against explicit original visits;4 omission negatives and repeated physical-field dedup. Existing omitted-MIDI/path-capacity closure/exactminus1 positive remains. Real Service dispatch test checks Changed/Pending/Idle/backpressure/edit/Undo with old-source refusal; lifetime compile-fail confirms fields cannot escape.3runtime+1doc=4unique0ignored; strictEngineSessionalltargets0/policy5/architecture0; quick6PASS/PARTIALclean exact. No native/fullCI/merge/install; no repeated accepted f3a0 components. Full host/native immutable preflight/same-parent facade/reborrow + actual Service startup/admission/publication and entire originalMonoStereo/mixed/export/nativeSampler/library goal remainOPEN. Evidence NEVER build/merge.
""")
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file():
  b=p.read_bytes();manifest.append(dict(path=str(p.relative_to(out)),bytes=len(b),sha256=sha(b)))
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
a=Path(str(out)+'.tar.gz')
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(a) as t:
 m=t.getmembers();assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in m)
 for row in manifest:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
blob=git('hash-object','-w',str(a)).decode().strip();tree=subprocess.check_output(['git','mktree'],cwd=r,input=f'100644 blob {blob}\t{a.name}\n',text=True).strip();commit=git('commit-tree',tree,'-m','Evidence only: actual sampler worker fields99a1').decode().strip();ref='refs/heads/evidence/hex-sampler-2789-99a1-worker-fields';subprocess.run(['git','update-ref',ref,commit],cwd=r,check=True)
result=dict(archive=str(a),bytes=a.stat().st_size,sha256=sha(a.read_bytes()),safe_members=len(m),payloads=len(manifest),evidence_commit=commit,ref=ref,source_head=head,source_tree=git('rev-parse','HEAD^{tree}').decode().strip());Path('/tmp/hex395-worker-seal-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
