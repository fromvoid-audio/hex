import importlib.util, pathlib, sys
root = pathlib.Path('/workspace/hex-clip-loop')
spec = importlib.util.spec_from_file_location('hex_local_ci_445_painter', root / 'scripts/local-ci.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
steps = (
    module.Step('painter-and-midi-loop-ui', ('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--','waveform_header_ui_test::','editor::clip_loop_tests::','midi_loop_preview_tests','rendered_midi_trim_previews_note_geometry_and_commits_release_snap','rendered_midi_left_trim_keeps_source_note_timeline_position','--nocapture')),
    module.Step('ui-style', ('python3','scripts/check-ui-style.py')),
    module.Step('strict-ui-clippy', ('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--','-D','warnings')),
    module.Step('painter-fmt', ('rustfmt','--edition','2024','--check','crates/hex-ui/src/editor/clip_name.rs','crates/hex-ui/src/editor/tracks.rs','crates/hex-ui/src/editor/waveform.rs','crates/hex-ui/src/editor/waveform_geometry.rs','crates/hex-ui/src/editor/waveform_header_ui_test.rs')),
    module.Step('diff-check', ('git','diff','--check')),
)
raise SystemExit(module.LocalCiRunner(root=root, mode='quick', steps=steps).run())
