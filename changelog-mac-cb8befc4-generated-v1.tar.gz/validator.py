import pathlib,json,subprocess,hashlib,re
O=pathlib.Path('outputs/hex-changelog-cli-cb8');I=O/'original-input';execdata=json.loads((O/'execution.json').read_text());assert execdata['exit_code']==0 and not execdata['timed_out'];schema=json.loads((I/'schema.json').read_text());data=json.loads((O/'result.json').read_text())
def check(s,x,path='$'):
 kind=s.get('type');types={'object':dict,'array':list,'string':str};assert kind not in types or isinstance(x,types[kind]),path+' type'
 if 'enum' in s:assert x in s['enum'],path+' enum'
 if isinstance(x,dict):
  assert set(s.get('required',[]))<=set(x),path+' required'
  if s.get('additionalProperties') is False:assert set(x)<=set(s.get('properties',{})),path+' additional'
  for k,v in x.items():
   if k in s.get('properties',{}):check(s['properties'][k],v,path+'.'+k)
 if isinstance(x,list) and 'items' in s:
  for i,v in enumerate(x):check(s['items'],v,f'{path}[{i}]')
check(schema,data);inp=json.loads((I/'input.json').read_text());allowed={c['commit'] for c in inp['commits']};actual=set(subprocess.check_output(['git','rev-list',inp['base']+'..'+inp['source']],cwd='/Users/portalsurfer/dev/hex',text=True).splitlines());assert allowed==actual
assert len(data['entries'])<=32
for e in data['entries']:
 assert e['text'] and len(e['text'])<=320 and e['text']==e['text'].lower();assert e['commits'] and set(e['commits'])<=allowed;assert not any(c in e['text'] for c in allowed)
assert data['reason']==data['reason'].lower();assert data['entries'] or data['reason'].strip()
events=[json.loads(l) for l in (O/'stdout.jsonl').read_text().splitlines()];items=[e.get('item',{}).get('type') for e in events if e.get('item')];tooltypes=[x for x in items if x not in ['reasoning','agent_message']];assert not tooltypes,tooltypes;assert any(e.get('type')=='turn.completed' for e in events)
compact=json.dumps(data,separators=(',',':'),ensure_ascii=False)+'\n';(O/'generated-compact.json').write_text(compact)
secret=re.compile(r'(?i)(authorization\s*:|bearer\s+\S+|(?:sk-|sess-|ghp_|github_pat_|eyJ)[A-Za-z0-9_.-]{12,}|(?:token|api_key|password|secret)\s*[=:]\s*[\"\x27]?[A-Za-z0-9_./+-]{12,})')
scan={}
for n in ['stderr.raw','stdout.jsonl','result.json','cli-version.stdout','cli-version.stderr']:
 txt=(O/n).read_text(errors='replace');scan[n]={'suspected_sensitive':bool(secret.search(txt)),'sha256':hashlib.sha256((O/n).read_bytes()).hexdigest(),'bytes':(O/n).stat().st_size}
(O/'sensitivity-scan.json').write_text(json.dumps(scan,indent=2));(O/'validation.json').write_text(json.dumps({'schema_valid':True,'entry_count':len(data['entries']),'allowed_range_commit_count':len(allowed),'all_reference_ids_in_actual_supplied_range':True,'lowercase_prose':True,'maximum_entry_length':max([len(x['text']) for x in data['entries']],default=0),'within32entries320chars':True,'tool_item_types':tooltypes,'item_types':items,'turn_completed':True,'compact_sha256':hashlib.sha256(compact.encode()).hexdigest(),'semantic_editorial_review_not_claimed':True},indent=2))
print('VALID',len(data['entries']),'entries','tool_types',tooltypes,'sensitivity_flags',{k:v['suspected_sensitive'] for k,v in scan.items()});print('VERSION',(O/'cli-version.stdout').read_text().strip());print('GENERATED_COMPACT',compact)
# Print a short benign diagnostic excerpt only after checking the entire private stderr.
if not scan['stderr.raw']['suspected_sensitive']:print('STDERR_EXCERPT',(O/'stderr.raw').read_text()[:250])
