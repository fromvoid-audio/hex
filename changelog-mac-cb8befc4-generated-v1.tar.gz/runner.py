import pathlib,subprocess,os,json,hashlib,time,threading,signal
from datetime import datetime,timezone
B=pathlib.Path(__file__).resolve().parent;O=B.parent.parent/'outputs/hex-changelog-cli-cb8';I=O/'original-input';C=B/'invocation';C.mkdir(exist_ok=False);CLI='/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex';W=O/'result.json'
os.umask(0o077)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
assert sha(I/'prompt.txt')=='29382d674fdfe3640daabe2fea0725685f7a95a01ebae4f8a60cf4b69358627a';assert sha(I/'schema.json')=='2c3b465d30445567dfb7a75bc850bcc47974b6c20bdd080952f43790cb71a988';assert not W.exists()
argv=[CLI,'exec','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--output-schema',str(I/'schema.json'),'--output-last-message',str(W),'--json','-']
version=subprocess.run([CLI,'--version'],cwd=C,capture_output=True,timeout=10);(O/'cli-version.stdout').write_bytes(version.stdout);(O/'cli-version.stderr').write_bytes(version.stderr)
write('invocation.json',{'argv':argv,'cwd':str(C),'stdin_bytes':(I/'prompt.txt').stat().st_size,'stdin_sha256':sha(I/'prompt.txt'),'timeout_seconds':120,'attempts_authorized':1,'runner_pid':os.getpid(),'cli_binary_sha256':sha(pathlib.Path(CLI)),'cli_version_exit_code':version.returncode,'version_stdout_sha256':sha(O/'cli-version.stdout'),'unchanged_inherited_configuration':True,'model_provider_override':False,'credential_or_environment_override':False,'started_utc':datetime.now(timezone.utc).isoformat(),'official_cli_reference':'https://learn.chatgpt.com/docs/non-interactive-mode'})
# Observe only process metadata, never argument/environment strings or credentials.
seen={};events=[];stop=threading.Event();target={'pid':None};guard=threading.Lock()
def snapshot():
 rows={}
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,lstart=,comm='],text=True).splitlines():
  f=line.split(maxsplit=8)
  if len(f)!=9:continue
  rows[int(f[0])]={'pid':int(f[0]),'ppid':int(f[1]),'pgid':int(f[2]),'start':' '.join(f[3:8]),'comm':f[8]}
 return rows
def observe():
 while not stop.is_set():
  rows=snapshot();ids={os.getpid()};changed=True
  while changed:
   child={p for p,row in rows.items() if row['ppid'] in ids or (target['pid'] and row['pgid']==target['pid'])};new=child-ids;ids|=new;changed=bool(new)
  for p in ids-{os.getpid()}:
   if p in rows and rows[p]['comm'].rsplit('/',1)[-1]!='ps':
    with guard:seen[p]=rows[p]
  stop.wait(.25)
original_popen=subprocess.Popen
class CapturePopen(original_popen):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw)
  actual=a[0] if a else kw.get('args',[])
  if isinstance(actual,list) and actual[:2]==[CLI,'exec']:
   target['pid']=self.pid;events.append({'event':'spawn','pid':self.pid,'pgid':self.pid,'utc':datetime.now(timezone.utc).isoformat()})
subprocess.Popen=CapturePopen
thread=threading.Thread(target=observe,daemon=True);thread.start();start=time.monotonic();code=None;timeout=False;error=None
try:
 with (O/'stdout.jsonl').open('wb') as out,(O/'stderr.raw').open('wb') as err:
  try:result=subprocess.run(argv,cwd=C,input=(I/'prompt.txt').read_bytes(),stdout=out,stderr=err,timeout=120,start_new_session=True);code=result.returncode
  except subprocess.TimeoutExpired:timeout=True;error='TimeoutExpired after120seconds; subprocess.run killed/reaped direct child'
  except OSError as e:error=f'{type(e).__name__}: {e.strerror}'
finally:
 elapsed=time.monotonic()-start;time.sleep(1);stop.set();thread.join(timeout=3);subprocess.Popen=original_popen
 rows=snapshot();group=[row for row in rows.values() if target['pid'] and row['pgid']==target['pid']];cleanup=[]
 # Only a private session created by this invocation can be signalled on timeout.
 if timeout and group:
  os.killpg(target['pid'],signal.SIGTERM);cleanup.append('SIGTERM owned private process group after timeout');time.sleep(1);rows=snapshot();group=[row for row in rows.values() if row['pgid']==target['pid']]
  if group:os.killpg(target['pid'],signal.SIGKILL);cleanup.append('SIGKILL remaining owned private process group after timeout');time.sleep(.5)
 rows=snapshot();alive=[row for p,row in rows.items() if ((p in seen and row['start']==seen[p]['start'] and row['comm']==seen[p]['comm']) or(target['pid'] and row['pgid']==target['pid']))]
 write('terminal-processes.json',{'cli_pid':target['pid'],'runner_pid':os.getpid(),'observed_descendants':list(seen.values()),'surviving_observed_owned_descendants_or_group':alive,'cleanup':cleanup,'events':events,'limitation':'Snapshots identify observed ancestry and private process-group members; subinterval detached children cannot be exhaustively proved absent.'})
 write('execution.json',{'exit_code':code,'timed_out':timeout,'seconds':elapsed,'error':error,'attempts':1,'result_exists':W.exists(),'stdout_jsonl_bytes':(O/'stdout.jsonl').stat().st_size,'stdout_sha256':sha(O/'stdout.jsonl'),'stderr_bytes':(O/'stderr.raw').stat().st_size,'stderr_sha256':sha(O/'stderr.raw'),'result_sha256':sha(W) if W.exists() else None,'cli_pid':target['pid'],'surviving_observed_owned_processes':len(alive),'completed_utc':datetime.now(timezone.utc).isoformat()})
 print(json.dumps({'exit_code':code,'timed_out':timeout,'seconds':elapsed,'result_exists':W.exists(),'stderr_bytes':(O/'stderr.raw').stat().st_size,'surviving_owned_processes':len(alive)}),flush=True)
