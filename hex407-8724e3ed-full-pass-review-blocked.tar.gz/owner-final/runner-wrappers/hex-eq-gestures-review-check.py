import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-eq-gestures')
spec=importlib.util.spec_from_file_location('hex_eq_gesture_review_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('eq-gesture-review',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','eq_ui_tests::node_gesture_tests::eq_review_','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
