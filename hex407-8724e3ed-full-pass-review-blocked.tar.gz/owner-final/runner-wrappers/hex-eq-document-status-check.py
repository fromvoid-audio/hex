import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-eq-layout')
spec=importlib.util.spec_from_file_location('hex_eq_document_status_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(m.Step('eq-document-status-variants',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','eq_ui_tests::graph_layout_tests::eq_review_new_and_open_empty_projects_retire_only_owned_analyzer_status','--','--nocapture'),uses_cargo_target=True),)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
