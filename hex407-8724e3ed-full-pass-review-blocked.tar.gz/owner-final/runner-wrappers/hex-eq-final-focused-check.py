import importlib.util,sys
from pathlib import Path
root=Path('/workspace/hex-eq-layout')
spec=importlib.util.spec_from_file_location('hex_grid_focused_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=m.QUICK_STEPS+(
 m.Step('eq-ui',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','eq_ui_tests','--','--nocapture'),uses_cargo_target=True),
 m.Step('eq-model',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','eq_panel::','--','--nocapture'),uses_cargo_target=True),
 m.Step('eq-gallery',('cargo','test','-p','hex-ui','--example','layout_review','--features','ui-test-support','--locked','eq_catalog_','--','--nocapture'),uses_cargo_target=True),
 m.Step('shared-widgets',('cargo','test','-p','hex-widgets','--locked','--','--nocapture'),uses_cargo_target=True),
 m.Step('ui-feature-clippy',('cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'),uses_cargo_target=True),
 m.Step('widget-clippy',('cargo','clippy','-p','hex-widgets','--all-targets','--locked','--','-D','warnings'),uses_cargo_target=True),
)
raise SystemExit(m.LocalCiRunner(root,mode='focused',steps=steps).run())
