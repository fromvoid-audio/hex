from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile,difflib
r=Path('/workspace/hex-integration-eq-gestures');v=r/'third_party/gpui';out=Path('/workspace/scratch/integration/407-composition')
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
p=r/'crates/hex-widgets/src/response_graph.rs';s=p.read_text();a=s.index('<<<<<<< HEAD\n');b=s.index('=======\n',a);c=s.index('>>>>>>> origin/main\n',b);s=s[:a]+'        self.finish_scroll(false, cx);\n'+s[b+len('=======\n'):c]+s[c+len('>>>>>>> origin/main\n'):];assert '<<<<<<<' not in s;p.write_text(s)
p=r/'todo.md';s=p.read_text();a=s.index('<<<<<<< HEAD\n');b=s.index('=======\n',a);c=s.index('>>>>>>> origin/main\n',b);s=s[:a]+s[a+len('<<<<<<< HEAD\n'):b]+'\n'+s[b+len('=======\n'):c]+s[c+len('>>>>>>> origin/main\n'):];p.write_text(s)
m=json.loads(git('show','origin/main:third_party/gpui/hex-provenance.json'))
for n in m['patched_files']:m['patched_files'][n]=hashlib.sha256((v/n).read_bytes()).hexdigest()
(v/'hex-provenance.json').write_text(json.dumps(m,indent=2)+'\n')
a=Path('/workspace/scratch/integration/406-gpui-merge/gpui-0.2.2.crate');assert hashlib.sha256(a.read_bytes()).hexdigest()==m['crates_io_sha256'];original={};base=out/'reapplied';base.mkdir()
with tarfile.open(a) as t:
 for x in t.getmembers():
  p=PurePosixPath(x.name);assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='gpui-0.2.2'
  if x.isdir():continue
  assert x.isfile();n=PurePosixPath(*p.parts[1:]).as_posix();b=t.extractfile(x).read();original[n]=b;q=base/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
for n,h in m['original_files'].items():assert hashlib.sha256(original[n]).hexdigest()==h,n
patch=''
for n in sorted(set(m['patched_files'])|set(m['added_files'])):
 old=original.get(n,b'');new=(v/n).read_bytes();patch+='diff --git a/'+n+' b/'+n+'\n';patch+=('new file mode 100644\n' if n in m['added_files'] else '');patch+=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n,n=0))
(v/'hex-patches.diff').write_text(patch)
subprocess.run(['git','apply','--check','--unidiff-zero',str(v/'hex-patches.diff')],cwd=base,check=True);subprocess.run(['git','apply','--unidiff-zero',str(v/'hex-patches.diff')],cwd=base,check=True)
for n in set(m['original_files'])|set(m['added_files']):assert (base/n).read_bytes()==(v/n).read_bytes(),n
proof={'main':git('rev-parse','origin/main').decode().strip(),'source':'c2ceadfadcf68a88eba8ab84faebc7a96006eff5','original':len(m['original_files']),'patched':len(m['patched_files']),'added':len(m['added_files']),'all_reapplied_bytes_match':True,'graph_resolution':'Preserve main raw unclamped node-radius hit ownership and owner finish_scroll; no early axes refusal before edge-node hit.'};(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
