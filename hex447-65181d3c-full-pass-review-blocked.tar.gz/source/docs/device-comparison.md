# shared device a/b comparison

Approved implementation contract for Pulse2845 / PR447. The model and storage checkpoints
implement canonical comparison and pair persistence. Typed service admission and actual
shared UI routes are implemented; final integration and native acceptance remain open. This is not a claim that the end-user feature is qualified. Audited source: main `bc06d7573ffa7f4d989bdff9553ed3108f4f0818`,
canonical intake retained in source checkpoint `38b008c859f3662787f3757a865071eebeec72be`.

## current boundaries

- `hex-project/src/device.rs::Device` owns a stable ID, one authored
  `NativeDeviceState` and a separate bypass flag. Its `state()` is consumed by
  every existing registered instrument/effect, including Return effects.
- `hex-lattice-contract::NativeDeviceState` owns immutable opaque payload and
  asset-reference Arcs plus host input/output trims. Its 4096-byte payload limit
  does not represent PCM, voices, transport, routes or global tuning.
- `hex-session::Session::{preview,commit}_device_parameter` patches only this
  authored state through the class-specific registered definition and existing
  prepared transaction. Failure must precede canonical history/publication.
- `DeviceSnapshot` and the shared project storage Device DTO carry both authored variants and the active slot.
  Generic preset schema2 stores the active and optional inactive class/type/version/payload, deliberately preserves
  the target device's host trims, and refuses asset-bound presets without a
  portable asset manifest. Both slots refuse asset-backed portable presets without a manifest.
- Project automation currently owns track gain envelopes/lanes. This feature
  must not invent a device-parameter automation family or claim one exists.
- `computer_keyboard.rs::NOTE_KEYS` includes plain `p`; device comparison must
  consume it only for the exact device-card focus owner, leaving musical input
  elsewhere. Text, IME, numeric drafts, graph controls and dialogs take priority.

## proposed canonical representation

Keep `Device::state()` as the active authored state. Add one optional inline
comparison record containing the active slot and the inactive authored state.
Absent comparison means A is active and B starts identical. First switch captures
A by immutable state clone; it does not copy PCM or construct another DSP owner.

Parameter edits continue to update the active state through existing commands.
Switch swaps settings, retaining both variants. Copy updates the inactive variant
without switching or changing the audible settings. Both are typed canonical
commands with one Undo entry, admitted through the existing prepared path.
Different-provider replacement resets comparison; moving preserves the pair;
duplicating gets a fresh DeviceId and independent authored edits.

Expose a borrowed control-side iterator over the actual active and inactive
NativeDeviceState fields. Project media-reference validation and media deletion
checks must include both. Inactive references retain catalog identities; they do
not themselves authorize native resource admission or create media copies.

Current/Undo/Redo, project snapshots and the current-format persistence contract
must retain both variants and the active slot. No historical-alpha reader or
migration is required. No existing state-size or resource cap is raised.

## approved settings and remaining writer coordination

1. **Host settings:** the approved contract compares provider payload and asset
   bindings while bypass and host input/output trims remain device-wide, matching
   existing preset semantics. All stored variants must reflect current global
   trims so switching cannot restore stale values. Slot-local host trims are outside the approved comparison contract.
2. **Actual custody:** Source5's current Sampler resource checkpoint `0bbbb7bd` has
   `audio_storage/canonical_state.rs::project_native_states` visiting only
   `device.state()`, including current/Undo/Redo through the retained-project
   iterator. The resource owner must include both actual fields in its existing ledger and
   aggregate before resource-backed A/B can be called integrated. This is not a
   new constructor, parallel ledger, ownership family or admission shortcut.
3. **Asset persistence:** the current outer envelope already preserves active
   bindings through `schema/device_assets.rs::Manifest`, after decoding the base
   Device DTO. The initial DTO-only audit missed this wrapper; that inference was
   corrected before any separate repair. Extend the existing current-format
   manifest to preserve inactive bindings as well. Portable presets still refuse
   asset-bound states without a portable manifest, checking either slot.
   Unmerged Sampler/resource readiness remains separate.

Source1 proposes Project's comparison/model/snapshot/reference hunks, shared
Storage Device/preset codec hunks, bounded Session comparison/preset request
hunks, and a private shared UI module. Source5 owns the Sampler resource/compiler/custody slice and supplied the mechanical
Engine/Audio snapshot adaptation in `6bb1e983`; Source1 consumes that exact commit
without editing Engine/Audio production. Source4 retains Warp/Beats. Source5 also
owns EQ body/filter/response behavior. The future Sampler visitor adaptation is
not imported into this branch: its file is absent here, and its current branch
lacks the comparison model. It needs explicit composed-source resource validation.
Shared UI writes are limited to instrument/effect header actions, existing
ChainWindow focus lookup, module/binding/action wiring; preserve the separate
PR402 neutral-focus and held-delete changes. No second selection owner.

## transaction and focus requirements

A request captures device ID, document generation, revision, provider class/type
and expected active slot. Recheck freshness at the canonical boundary. Existing
numeric/device gestures must commit or visibly refuse before comparison. Do not
silently retry against another device or slot, skip failed gesture admission, or
change both history and a different project after a deferred terminal event.

The active indicator and context menu share one renderer. A shows only
`switch to b` / `copy a to b`; B shows only `switch to a` / `copy b to a`.
Plain P follows the same canonical operation for the exact focused card. No
repeated-key retargeting, text/IME shortcut leak, forced focus on render or loss
of the current selection/context when the menu closes.

Active playback replacement uses existing runtime-inheritance/publication policy.
It must preserve the transport, routing and global tuning. Provider-specific
runtime continuity is tested through the existing handoff, not by copying voices
or creating a comparison-specific callback path. Refusal retains the last valid
sound and both authored states. Copying inactive metadata must not manufacture a
new audible state or native resource owner.

## finite verification plan

- Model: initial identical variants; A-edit/B-edit/repeated switch; direction-
  correct copy without switch; one Undo/Redo per command; same-type edits versus
  different-provider replacement; duplicate/move/remove/stale identity; both-slot
  asset-reference validity and media-deletion protection.
- Storage/presets: both variants and slot survive current-format round trips;
  malformed mismatched-provider state refuses atomically; both-slot asset preset
  refusal preserves existing files; host-trim behavior follows the chosen policy.
- Session: representative registered instrument, track effect and Return effect;
  registered validation and preparation refusal preserve Project/history/audio;
  gesture finalization, stale generation/revision/slot and admission backpressure.
- UI: actual rendered menu/P actions and indicator, text/numeric/IME/dialog/
  musical-keyboard isolation, focus/menu lifecycle and deleted targets, using
  bounded disposable editor fixtures before worker startup.
- Audio: real prepared render and existing inheritance preserve transport and
  held-note/tail behavior where supported, with explicit limits; no callback
  allocation/I/O/lock/owner-drop claims without the corresponding real test.

Sole merger owns prospective-candidate full local CI/review/integration/merge.
Coordinator owns finite native/optimized checks and all user-app delivery. A source
handoff or passing fixture is not installed, visually accepted or user-approved.

## source checkpoint evidence

The actual shared UI route passed nine rendered cases, including fifteen available
catalog roles across native instruments, Track effects and Return effects. These
exercise real title-click then P (also within one dispatch frame), nonselected
badge targeting, independent numeric A/B edits, direction-correct copy/one Undo,
real keyboard Undo after stale menu dismissal, pending/held-key refusal and
text/marked-composition/graph/modal/musical focus isolation. Marked composition is
an injected GPUI input seam, not native OS IME acceptance.

The two Track/Return callback cases passed debug and optimized allocation probes
on UI checkpoint `779348be`: continuing 128-frame PCM is compared to the running
oracle through actual InheritRuntime publication, with unchanged transport and
zero observed callback allocation/deallocation. These are finite component
receipts, not all-provider physical audio or future Sampler custody qualification.
Earlier model, storage and service checkpoints retain their own original receipts;
no report is relabeled as final prospective full CI.
