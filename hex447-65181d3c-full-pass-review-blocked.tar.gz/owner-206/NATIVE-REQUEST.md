# Coordinator-only A/B components and user checks

Pinned 206ce89ac702326da5372e0e7a8c3287ec97ef1d/tree 4feff25042a951faa0e9dee46defe7956a5c9801, never evidence ref. No user-app inputs/install/launch/quit/signals/security/profile/media changes. Existing private serial Mac target/normal configured toolchain/stack; bounded363 fixtures allocate disposable roots before workers. Exact commands/cardinalities (all0ignored) for genuinely NEW A/B:

```sh
cargo test -p hex-project --test device_comparison --locked
# 5
cargo test -p hex-storage --test device_comparison --locked
# 3
cargo test -p hex-session --test device_comparison --locked
# 3 public malformed-inactive refusal cases
cargo test -p hex-session --lib --locked service::device_comparison::tests::
# 3 actual service/admission/catalog cases
cargo test -p hex-session --lib --locked comparison_preset_roundtrip_restores_both_variants_but_not_global_trims_or_bypass
# 1
cargo test -p hex-ui --features ui-test-support --lib --locked device_comparison_tests
# 9 actual rendered cases,15 catalog roles nested
cargo test -p hex-audio --features allocation-probe --test device_comparison --locked
# 2
cargo test -p hex-audio --features allocation-probe --test device_comparison --release --locked
# same2 optimized callback allocation oracles
```

Do not repeat unrelated old whole suites simply for status. Preserve exact source byte/mode/commands/counts/logs/protected state. Existing40201c686fd changed6 native request is separate dependency evidence; old native9 is not proof of new402 fixes. Merger prospective repository fullCI/freshreview required before merge; component checks are not installed acceptance.

Later after coordinator-authorized optimized delivery+normal user save/quit: use disposable current-format project, actual instrument/effect/Return title focus→P, editA/B independently and toggle, contextdirection/copywithoutswitch/no-op/UndoRedo, globalbypass/hosttrims unchanged, save/reopen/preset both variants, invalid asset preset refusal, text/IME/numeric/EQgraph/modal/musical P isolation; playing sustained source switch/copy without transport restart/phase jump, Stop/tails. Sample-backed Sampler actual custody/publication/native/listening remains separate future395 gap. No physical/native claim from Linux rendered tests.
