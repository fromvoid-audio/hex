# Installer2788 / canonical PR394 recovery evidence

This packet concerns the focused installer defect and a qualified normal retry,
not a new feature implementation or a finalize-only protocol. Code candidate
 a60adf63d771772965d4d5511cda1e6fe453ec4e/tree
 e5639cac4d9e163dcb58cc835dd254ee6b5a0bef, digest
 0988506bfcbcf9b6a3c12e8e1efc3bb068a6f45a3c7b81bc8ed81f030f8840c6.
Read qualification.json and merge-provenance.json for actual terminal status and
chosen build source; never infer qualification from a file name or old receipt.

RECOVERY-REQUEST.md provides source/mode reproduction, finite native checks,
current partial-state preconditions, existing normal bundle/adoption command,
precise cleanup boundaries and read-only postflight comparisons. Commands are
for coordinator scheduling in the sole existing Mac lane, never cloud dispatch.
USER-TEST.md retains finite prior UI/EQ acceptance and new EQ390 response check;
no GUI/listening/user quit/launch is requested while the user is away. Already
accepted spinner2760/EQ2729 gestures remain accepted. No installed app/files,
keychain/TCC/settings/profile/media were changed by cloud work.

Original cloud receipts/logs are copied verbatim in separately named directories.
cloud-initial-target-refusal is the first b101 target-ownership refusal (7/20;
no Cargo workspace tests ran); cloud-b101-historical is the subsequent legitimate
b101 full20 PASS. Neither qualifies a60, whose original final receipt and all
logs are in cloud-a60-final after terminal pass. No original summary is edited,
renamed as another candidate's pass, or replaced. Failed actual Mac PhaseB and
old/new app receipts remain Mac-local and referenced by original hashes in
history.json; they are not fabricated as recovered packet bytes.

before-fix-* proves the original394 after-custody-deletion cutpoint. The separate
review-race-proof preserves b101 first-rmdir ENOTEMPTY (including final committed
test-fixture reproduction); review-records.json preserves initial independent P2
and reported resolved a60 followup, static review only. The late portable cases
use real durable release-owner guard/lock/READY/PENDING with compiler/metadata/
native external tools substituted. Real installed pending394 recovery/signing
and fresh actual native original evidence remain separate dependencies.

source-inputs.json lists all1839 source inputs/order/bytes/Gitblob/modes/execute
bits; a new isolated umask077 checkout reproduces launch0700. Do not chmod old
or primary source, weaken guards or edit old reports. included-test-revisions.json
preserves prior44 canonical heads and adds390+a60head394 (46 ancestral heads);
open352/353/389 excluded. tooling-identity.json distinguishes new installer from
unchanged local-ci/release guard, bundle wrapper and signing configuration.

Preserve the installed signed394 app/old sidecardfa/PENDING394/sole regular Finder
file until fresh inspection plus qualifying checks and coordinator scheduling.
The supported recovery rebuilds/installs NEW qualified source via ordinary
bundle --adopt-release-target, not old394 with copied new tooling. There is no
previous.app rollback custody now. Overall exit0 and strict matching app/sealed/
adjacent/READY/executable/source evidence is required; partial output is not success.

This immutable Git transport is EVIDENCE ONLY: fetch/show/archive extraction and
verify file-manifest.json sizes/hashes; NEVER checkout/build/merge its Git ref.
Build only the explicitly pinned CODE source. Earlier private evidence refs,
original98 qualification, old327 failure and installed-cohort signoffs retain their
historical meaning. Physical/GPU/listening/WAV identical-binary relaunch OPEN.
