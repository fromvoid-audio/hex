# Installer2788 merged delivery — source qualification PASS; native acceptance OPEN

Chosen new build/tooling source f4d631248c2ae02db31f07c8a7e882e80a550913,
treee5639cac4d9e163dcb58cc835dd254ee6b5a0bef. Original cloud AND native full20
report candidate a60adf63d771772965d4d5511cda1e6fe453ec4e. Actual merged tree
matches that checked/reviewed candidate exactly; source digest0988506bfcbcf9b6a3c12e8e1efc3bb068a6f45a3c7b81bc8ed81f030f8840c6.
Included46 canonical heads = prior44 plus EQ390/a821ccc69ab089aaf671ada680c8361dd740ba8f
and installer394/a60adf63d771772965d4d5511cda1e6fe453ec4e. Open352/353/389 excluded.
No old receipt is repurposed. qualification.json preserves authentic new report
identities; actual original native bytes remain Mac-local. Local native merged
source guard must accept the originala60 report before scheduled recovery.

This is NOT an installed delivery claim. Current signed app394/build961506323
has OLDdfa adjacent receipt/PENDING394 owner/regular Finder metadata: incomplete
publication, unchanged by cloud. Coordinator schedules normal qualified retry,
with fresh app/process/owner verification, via RECOVERY-REQUEST.md. This rebuilds
and installs the NEW chosen source, not frozen394 using copied tooling.

After successful recovery, record actual installed/running source/build, sealed+
adjacent receipts, READY owner and signed executable hash before manual checks.
User away/locked: no GUI, screenshot, normal quit, launch or listening requested
now. Preserve projects/media. Existing spinner2760 and EQ gesture2729 signoffs
stand; no broad/manual spinner repeat approval gate. Physical/GPU/listening/WAV
same-executable relaunch remain OPEN. Use disposable current-format projects.

## New UI cases


1. **PR376:** focus a header by its name and its blank background; Command-R,
   edit and Enter. Verify one Undo/Redo. Open another draft and Escape. Arrow
   focus to another header and repeat; clip-header Command-R must still edit the
   clip name. Search and numeric-input focus must retain their keys.
2. **PR377:** click first clip, Shift-click fifth; check all five. Reverse the
   range and repeat Shift-clicks around the original anchor. Command-toggle a
   member, Command-Shift union, then Shift-click another track (new anchor).
   Clear in a lane, then Command-click: no hidden old members may return. Check
   ordinary header dragging and body time selection still behave normally.
3. **PR378:** header-select one clip, Command-C, click another time/track and
   Command-V. Repeat with several clips. Verify complete contents and original
   gaps, repeated paste, one atomic Undo/Redo, and source retention. Copy/paste
   text in search, return to the Arrangement and paste again: its whole-clip
   payload must remain. Keep accepted multi-source-track stable-owner semantics;
   no new cross-track remapping is expected.
4. **PR335:** inspect single/multiple selected audio and MIDI borders, hover,
   toggle a middle member while the endpoint stays selected, and deselect. Pan
   until clips are cropped at either viewport boundary. Drag/cancel ordinary
   trim/fade affordances and check selected preview borders, original clip colors,
   text, waveform/notes and usable edge hit areas. No source/time geometry change
   is expected.
5. Save/reopen only the disposable project to check renamed tracks and pasted
   whole content persist. This does not require saving/quitting the user's current
   app/project. Never force-quit or discard unsaved data.


## EQ remaining cases (preserve accepted gestures)


Use two independently audible tones/tracks, a Return and sparse EQ. Record PASS/FAIL/UNRUN with exact cohort SHA, device/rate/buffer, screenshots/listening notes and available callback/underrun telemetry. Do not reopen the accepted2729 gesture signoff.

1. Dual spectra: conspicuous EQ plus host trims produces real distinct input/output curves; input is before entry input trim, output after effect/output trim. Hide input independently. Check ordinary/Return EQ, bypass, silence/anti-phase stereo, stopping/keyboard monitoring and reopen.
2. Quality/layout: inspect bass readability, capture-driven decay and fixed−96..0dbfs display without claiming extra FFT resolution or exact Prism parity. At880x540 and1500x650, full labels/actions/readouts, response/automation rows and graph remain usable and unclipped.
3. Backspace: focused selected EQ node removes only that node/automation; Undo/Redo restores identities. Empty/held/pending/stale/automation-point cases preserve track/clip isolation; numeric/text editing retains its keys.
4. Project signals: no selection shows real Master; one/two/ALL256 selected canonical tracks produce independent correctly assigned-color layers plus Master, never a selected-track sum or silent prefix cap. Color edits, reorder/removal/reselection and project/output replacement clear stale/reused identities.
5. Tap semantics: each track is actual direct post-device/post-fader/balance output including owned tails; Master includes Returns/master gain before monitor-only metronome/browser preview. Vary effects/faders/mute/bypass/Return/master gain; nonlinear bus output is not claimed to equal the sum of track curves.
6. Lifecycle/input/GPU: collapse stops new project capture/analysis after bounded queued work drains; expand starts fresh. Resize outside release commits view height; Escape/focus/window/context change cancels without project Undo. Compact live header retains ALL layers at constrained populated details, restores preferred height in larger windows, and leaves Auto Pan/Operator/Return details and timeline usable.
7. Callback/profile bounds:33 fixed packet owners,32 forward/33 return slots, at most263168 stereo contribution frames/callback, whole-window refusal on exhaustion, no callback allocation/final-drop/lock/log/FFT. Worker uses the existing thread, max2 packets/8 stereo layers per turn. Caps30Hz/100ms up to32 tracks,10Hz/250ms for33–128,5Hz/400ms for129–256. Exercise selection churn/collapse/output restart and all256 layers at the supported rate plus one other available rate. Record real-device sustained audio/deadline and GPU responsiveness separately from worker profile. If a256-track fixture or telemetry is unavailable, mark that item UNRUN and report the bounded fixture/instrumentation need.

Return one finite result table, exact source/build/signature identity, minimum-window screenshots, raw profile/callback evidence and listening observations. Installation/merge is not human/native acceptance. Failures return to the owning canonical scope; unrun checks stay pending with the coordinator, without new source-feature scope or forced immediate Mac work.


Preparation API373 is included source provenance, not completed sampler389/tuning352/MTS353. Record one short regression smoke for existing ordinary playback/import/browser preview/Undo without changing user media; no new feature scope. Preserve prior resize/waveform/BPM/Shift/Command-T behavior; report a concrete regression rather than restarting all accepted manual work. Real WAV access and identical-executable relaunch acceptance are separate. Mark unavailable256-track fixtures or deadline telemetry UNRUN, retain bounded need; no source/native parity claims from cloud checks.

## Source392/393 and prior-cohort preservation

392 heap-constructs fixed257-layer publications/owners. Current factory-owned
payload26419596 bytes;32MiB cap excludes caller UI copies and total process/UI
memory.393 corrects two fixture caller frames without behavior/workload changes.
Those cases and installer394 regressions passed the NEW exacta60 full20 on both
platforms; actual Mac stack was unset/default. No new human approval gate or away-
user crash reproduction/quit/screenshot is required. Historical98/b101 reports
remain historical and are not relabeled. Current actual native original is
run20261017T203315Z-f7ceb696/SHA024fde063cd9255d6d1d80d3935b583e6bf12d84200a8f41680503eb58f9cd28.


After coordinator-scheduled recovery installs the verified new app and the user normally launches it, retain a bounded ordinary trim/fade/Warp/BPM/browser smoke: affected/control samples, normal left/right edges and lower fade handles, raw/Warp-on/processed-Warp-off, crop/reveal/loops and two zooms; no disappearing waveform/stale border. Lower fade free by default/Command snap and stationary modifier behavior; Escape/focus/outside-release cancellation, source retention and one UndoRedo. Shift stretch/BPM live preview remains coherent. Browser hover/progress/click-seek and sample-result double-click must not accidentally insert clips. Preserve accepted spinner/EQ gesture behavior; no repeated signoff gate.


## Added EQ390 response check

On the later qualified running app, inspect a narrow high-Q bell/notch and both
sides of its center, including disabled/out-of-bank nodes, overlapped bands and
narrow viewport. Authored response must retain narrow features without treating
it as an animated/automated response or promising reference-plugin parity.
Preserve accepted direct-value/drag gestures and test text/selection isolation.

## Evidence that remains separate

The finite ignored EQ maximum profile PASSED historically on qualified394
(Pulse2745/20958, log SHA2aa34bd3d5c0947dd0996a4565e5b2af8dc2abffc42af9e68a7119faef572df8).
Do not relabel it as a new candidate result. This focused installer fix and390
response-display sampling do not change its capture/worker ownership or caps;
no broad profile replay is requested solely for installer cleanup. Actual device
DSP/GPU deadlines and total UI memory remain unverified.
Physical/native input, listening and sample access remain OPEN. With user present,
preview a real WAV; after a NORMAL user save/quit, explicitly --open the SAME
installed executable and preview again. Verify hashes before/after. Default
./launch fetches/builds latest main and is not identical-binary relaunch evidence.
--test remains opt-in; do not run another launcher concurrently.
