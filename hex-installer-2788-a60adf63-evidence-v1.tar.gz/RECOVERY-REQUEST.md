# Coordinator-only native fixture and ordinary recovery request

## Immutable source / qualifications

CHOSEN BUILD/TOOLING SOURCE f4d631248c2ae02db31f07c8a7e882e80a550913,
actual PR394 merge; original report/candidate remains a60 below. Actual complete
merge tree equals the native/cloud checked tree; candidate is ancestral.
Original full20 reports are not relabeled as fresh merge CI.


Canonical Pulse2788 / PR394 head a60adf63d771772965d4d5511cda1e6fe453ec4e,
treee5639cac4d9e163dcb58cc835dd254ee6b5a0bef; physical sourceguard digest
 0988506bfcbcf9b6a3c12e8e1efc3bb068a6f45a3c7b81bc8ed81f030f8840c6.
All1839 selected source inputs match Git blobs; source-inputs.json records order,
raw bytes/hash/mode/exec bits. Prior44 included heads preserved verbatim;390 and394
make46 ancestral heads. Excluded open352/353/389 remain excluded.

Create NEW isolated source under umask077 (never chmod primary/frozen old source):

    git fetch origin f4d631248c2ae02db31f07c8a7e882e80a550913
    (umask 077; git worktree add --detach NEW_UNUSED_SOURCE f4d631248c2ae02db31f07c8a7e882e80a550913)

Require clean HEAD, exact tree and ACTUAL repository guard digest above; launch
must materialize0700/executemask64, other regular execute masks0. Use ledger for
any mismatch and STOP, no report/guard normalization. Never build evidence refs.

## Phase A COMPLETE: native full20 passed; no rerun requested

Actual coordinator-dispatched sole verifier completed exacta60 full20 once,
run20261017T203315Z-f7ceb696, native original SHA024fde063cd9255d6d1d80d3935b583e6bf12d84200a8f41680503eb58f9cd28.
See qualification.json/Pulse2788note21067: all114runner tests/36installer cases/
2actual native certificate fixtures PASS, no skips. Original summary/alllogs
remain Mac-local; cloud did not recover or edit those bytes. The completed
checks used existing
PRIVATE CI target (not shared pending release target); retain all original failed
PhaseB/triage evidence. Re-read app/process/lock state before execution. User app
can remain closed/as-found; no native GUI needed, no app launch/quit/signing-key
configuration change. Normal Mac test stack UNSET, existing toolchain, jobs2:

    env -u RUST_MIN_STACK HEX_TEST_SIGNING_IDENTITY=4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=EXISTING_PRIVATE_CI_TARGET python3 scripts/local-ci.py

The above is the reproducible completed-check context, NOT a request to rerun.
Checks ran from NEW qualified source. Its runner-tests stage includes actual production
assembly cutpoint and immediate-rmdir metadata injection (one retry maximum), unknown/symlink/directory refusal, ordinary
retry/idempotence, running-app guard and real configured Developer ID signing
fixture (including stable requirement across two executables). Test fixtures use
TEMPORARY apps only, never the real stable target. No extra broad manual spinner
work or GUI interaction is required. Keep actual native original full20 summary,
all20logs, command/stack/jobs, source byte/mode proof and report SHA; accept only
exit0/full/all20pass/clean/stale=false/start=end. STOP on failure; no auto restart.
Cloud proof is separate; original98/older327 reports cannot qualify edited code.

## Native read-only merge/source/report guard before scheduled recovery

From NEW clean actualf4d checkout, use the unchanged repository guard and retain
actual output/exit. No tests/build/target adoption/installer execution occurs:

```python
import importlib.util, json, sys
from pathlib import Path
root=Path.cwd()
spec=importlib.util.spec_from_file_location('native_merge_guard',root/'scripts/hex-test-build.py')
d=importlib.util.module_from_spec(spec);sys.modules[spec.name]=d;spec.loader.exec_module(d)
report=Path('/Users/portalsurfer/Documents/Codex/2026-10-17/yield-serial-mac-verification/work/hex-installer-b101/source/artifacts/local-ci/20261017T203315Z-f7ceb696/summary.json')
assert d.sha(report)=='024fde063cd9255d6d1d80d3935b583e6bf12d84200a8f41680503eb58f9cd28'
r=d.ci.LocalCiRunner(root)
d.validate_ci(report,r,'a60adf63d771772965d4d5511cda1e6fe453ec4e')
assert r.summary['start_tree']['commit']=='f4d631248c2ae02db31f07c8a7e882e80a550913'
assert r.summary['start_tree']['content_sha256']=='0988506bfcbcf9b6a3c12e8e1efc3bb068a6f45a3c7b81bc8ed81f030f8840c6'
print(json.dumps({'native_actual_merge_guard_accepted':True,'source':r.summary['start_tree']},indent=2))
```

STOP on actual refusal/mismatch; no report relabel, source/guard patch, primary
chmod or silent fallback. The originala60 report stays unchanged. Cloud actual
merged-source guard already accepted originala60 CLOUD report, separately.

## Phase B: later coordinator-scheduled ordinary retry, BUILDS AND INSTALLS

This packet does not execute or self-dispatch Mac work. Coordinator reviews
original native pass, source identity and exact source-bound recovery before
scheduling. No manual sidecar/owner write, rm-rf, report relabel or script copy
into frozen394 is permitted. No finalize-only API exists or was added.

Fresh preconditions: inspect exact current app/process state, advisory locks and
all actual receipts. If user opened Hex, normal save/quit must be coordinated;
never force quit or replace a running app. Do not infer closed state from an old
snapshot. Preserve primary checkout/settings/TCC/keychain/profile/media. Verify
current partial app with the repository verify(app), strict configured Developer
ID cert/team/deep seal and stable requirement. Expected frozen app source394,
build961506323, installed SIGNED exe29215200B SHA
169f85c4c4bca689041dad268d30c573ed7ac9a4d8fcafa01958ee340f9d6a29;
pre-sign input SHAda70bf364c71ecd7deda0e8dae3e678af649a16699d3a8ac9db7eb4594221317.
Expected old adjacent receiptdfa; PENDING release owner394 rawSHA
b42a4fe14b7c24dae4aec1bd5ae2f8aad3c4afce2dc7a91461a3b1934d3945a1;
workspace ONLY regular .DS_Store6148B SHA
e4250ab0a382f6559b0b58185ed1927a9cf5f7bde20fb4372df4df8dad7aca16,
no stage.app/previous.app. Unknown changed ownership/data/signature stops for
inspection. Previous app custody is gone; do not promise an old rollback copy.

Use the actual repository validate_ci(original NEW PASSED native a60 report,
runner,candidate a60) before build. Source can be actual PR394 merge ONLY if
complete actual tree equalse5639cac4d9e163dcb58cc835dd254ee6b5a0bef, a60 ancestor, physical digest exact and
actual guard accepts; otherwise use explicitly qualified a60 or qualify changed
source separately, never relabel. Replace placeholders with actual absolute
verified paths, retain the actual command/log/exit. Set hex_installer_packet to
the absolute extracted verified packet directory. From chosen qualified source:

First bind the EXISTING inspected pending target from the verified sealed receipt,
not from a guessed fresh-worktree default. This preflight only reads/verifies;
run from chosenf4d after the native guard above and fresh lock/job audit:

```sh
(
set -eu
: "${hex_installer_packet:?set absolute verified packet directory}"
hex_recovery_release_target=$(python3 - <<'PYTARGET'
import importlib.util, json, sys
from pathlib import Path
root=Path.cwd()
spec=importlib.util.spec_from_file_location('recovery_preflight',root/'scripts/hex-test-build.py')
d=importlib.util.module_from_spec(spec);sys.modules[spec.name]=d;spec.loader.exec_module(d)
app=Path('/Users/portalsurfer/dev/hex/artifacts/hex.app')
d.assert_inactive(app)
sealed=d.verify(app)
assert sealed['source']=='394f6c130bb87fe5c8c49cfd82f4c52cb6049533'
assert d.sha(app/'Contents/MacOS/hex')=='169f85c4c4bca689041dad268d30c573ed7ac9a4d8fcafa01958ee340f9d6a29'
adjacent=json.loads((app.parent/'hex-test-build-receipt.json').read_text())
assert adjacent['source']=='dfa21f5aed2186781e6aa985a053f85d9e51b75d'
workspace=d.install_workspace(app)
d.check_install_workspace(workspace,apps=False)
assert sorted(p.name for p in workspace.iterdir())==['.DS_Store']
assert (workspace/'.DS_Store').stat().st_size==6148
assert d.sha(workspace/'.DS_Store')=='e4250ab0a382f6559b0b58185ed1927a9cf5f7bde20fb4372df4df8dad7aca16'
owner_path=Path(sealed['release_target_ownership']['owner_path'])
assert not owner_path.is_symlink()
assert d.sha(owner_path)=='b42a4fe14b7c24dae4aec1bd5ae2f8aad3c4afce2dc7a91461a3b1934d3945a1'
owner=json.loads(owner_path.read_text())
assert owner['state']=='pending' and owner['source']['commit']==sealed['source']
assert owner['target_directory']==sealed['target_directory']==sealed['release_target_ownership']['target_directory']
print(owner['target_directory'])
PYTARGET
)
# STOP on nonzero preflight; shell assignment must succeed before scheduling
# the mutating retry. No installer is run by the preflight above.
CARGO_TARGET_DIR="$hex_recovery_release_target" sh scripts/bundle-macos.sh \
      --ci-report /Users/portalsurfer/Documents/Codex/2026-10-17/yield-serial-mac-verification/work/hex-installer-b101/source/artifacts/local-ci/20261017T203315Z-f7ceb696/summary.json \
      --candidate a60adf63d771772965d4d5511cda1e6fe453ec4e \
      --included "$hex_installer_packet/included-test-revisions.json" \
      --checklist "$hex_installer_packet/USER-TEST.md" \
      --adopt-release-target
)
```

This explicit adoption is ONLY for the inspected known pending shared-release
owner/target, after coordinator schedules; not permission to adopt arbitrary
unknown/malformed targets. Preserve the original marker and failure evidence
before running. No standalone nonactivating artifact helper here: unchanged
helper uses adopt=False and legitimately refuses pending release ownership.

Recovery runs under existing activation lock FIRST. It verifies inactive stable
app, inspects fixed workspace, deletes only the regular Finder file and empty
workspace (or fixed stage/previous apps in other unambiguous owned states).
Then release guard acquires its existing target-wide lock. Explicit adoption
checks package name/version scope, writes pending, and selectively Cargo-cleans
current workspace RELEASE products (cargo clean --profile release --target-dir
<resolved-target> --manifest-path <qualified-root>/Cargo.toml --package <each
current workspace package spec>). Dependencies/dev cache/user files/historical
apps are not a recursive cleanup target. Then normal optimized build/sign/stage/
verify/activation/adjacent-receipt publication proceeds. This rebuilds NEW fixed
app source; it does not simply finalize frozen394. Never edit original98 reports.

Success requires OVERALL installer exit0, strict re-verification of stable app,
Info.plist source/build matching new sealed receipt AND matching adjacent receipt
(including artifact inventory and native signature), original NEW native CI hash,
all46 heads/checklist, actual signed exe size/hash and READY owner with exact new
source/digest and actual UNSIGNED Cargo artifact hash. Source guard still clean
unchanged. No .hex-install or lingering activation/target locks/owned jobs.
A JSON receipt printed before final guard exit alone is insufficient. Preserve
all failures/partial receipts and STOP on any mismatch; do not fake delivered.
Stable identity org.portalsurfer.hex.dev/path
/Users/portalsurfer/dev/hex/artifacts/hex.app, configured cert4EDF56.../teamDKTKQ8U5T8.
No app launch is part of this command; no GUI/listening/native acceptance claim.

Later USER-TEST.md remains finite/pending and user-driven. Prior spinner/EQ gesture
signoffs stand. Native WAV and identical-executable normal relaunch are separate.

## Read-only postflight evidence (after overall installer exit0 only)

From the exact chosen qualified source, this uses repository verification and
compares publication records; it neither launches nor edits the installed app:

```python
import importlib.util, json, plistlib, subprocess, sys
from pathlib import Path
root = Path.cwd()
spec = importlib.util.spec_from_file_location('recovery_postflight', root/'scripts/hex-test-build.py')
d = importlib.util.module_from_spec(spec); sys.modules[spec.name] = d; spec.loader.exec_module(d)
app = Path('/Users/portalsurfer/dev/hex/artifacts/hex.app')
d.assert_inactive(app)
sealed = d.verify(app)
adjacent = json.loads((app.parent/'hex-test-build-receipt.json').read_text())
head = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
assert sealed['source'] == adjacent['source'] == head
assert all(adjacent.get(key) == value for key, value in sealed.items())
assert adjacent['artifact_files'] == d.inventory(app, include_receipt=True)
assert adjacent['native_signature'] == d.native_signature(app/'Contents/MacOS/hex')
info = plistlib.loads((app/'Contents/Info.plist').read_bytes())
assert info['HexSourceRevision'] == head
assert info['CFBundleVersion'] == str(int(head[:8], 16))
owner_path = Path(sealed['release_target_ownership']['owner_path'])
assert not owner_path.is_symlink()
owner = json.loads(owner_path.read_text())
assert owner['state'] == 'ready' and owner['source']['commit'] == head
assert owner['source']['content_sha256'] == sealed['source_sha256'] == '0988506bfcbcf9b6a3c12e8e1efc3bb068a6f45a3c7b81bc8ed81f030f8840c6'
assert owner['artifact']['sha256'] == d.sha(Path(owner['artifact']['path'])) == sealed['input_executable_sha256']
assert not d.install_workspace(app).exists()
print(json.dumps({'source':head, 'signed_executable_bytes':(app/'Contents/MacOS/hex').stat().st_size,
 'signed_executable_sha256':d.sha(app/'Contents/MacOS/hex'), 'sidecar_sha256':d.sha(app.parent/'hex-test-build-receipt.json'),
 'sealed_receipt_sha256':d.sha(app/'Contents/Resources/test-build.json'), 'owner_sha256':d.sha(owner_path),
 'source_digest':sealed['source_sha256'], 'installed_on_disk':True, 'launched_by_check':False}, indent=2))
```

Retain raw postflight output and exit status with full installer log. Still check
actual lock/job release separately. Any assertion failure is a real blocker;
never write a replacement receipt/owner to force consistency.
