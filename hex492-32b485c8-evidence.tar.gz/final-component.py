import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-workspace-tab-489');spec=importlib.util.spec_from_file_location('hex_ci_492',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(
 m.Step('architecture',('python3','scripts/check-architecture.py')),
 m.Step('ui-style',('python3','scripts/check-ui-style.py')),
 m.Step('gpui-patch',('python3','scripts/check-gpui-patch.py')),
 m.Step('device-layout',('python3','scripts/check-device-layout.py')),
 m.Step('touched-fmt',('rustfmt','--edition','2024','--check','crates/hex-ui/src/editor/tracks.rs','crates/hex-ui/src/editor/clip_name.rs','crates/hex-ui/src/editor/waveform.rs')),
 m.Step('diff-check',('git','diff','--check')),
 m.Step('paint-and-overlap',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','editor::tracks::overlap_tests::','--','--nocapture')),
 m.Step('drag-controls',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','editor::clip_drag_ui_test::','--','--nocapture')),
 m.Step('group-controls',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','editor::drag::group_drag_ui_test::','--','--nocapture')),
 m.Step('name-controls',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','editor::clip_name::','--','--nocapture')),
 m.Step('header-body-controls',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','waveform_header_ui_test::','--','--nocapture')),
 m.Step('strict-default',('cargo','clippy','-p','hex-ui','--all-targets','--locked','--','-D','warnings')),
 m.Step('strict-feature',('cargo','clippy','-p','hex-ui','--features','ui-test-support','--all-targets','--locked','--','-D','warnings')),
)
raise SystemExit(m.LocalCiRunner(root=root,mode='quick',steps=steps).run())
