# Metadata-only pending v1: frozen98 cohort

**NOT QUALIFIED / NO EXECUTION OR INSTALLATION AUTHORITY IN THIS PACKET.**
Source98b644301fa762f7ef3b6120e16f85469ae602c8;
treec8e93e2c431f0ac21de8cbb6a3258fc34dd3ac72;
parentsfccca328b557804d471b0b661108a87281f14b0d +
c7ac95edb8b2981f065649fb02a10d79d9ee935a.44 heads verified ancestral, including
the original42 unchanged plus39296ee313a15111b9dded9dd456632d8b288dda515 and39398.
Open352/353/389 are EXCLUDED. Do not wait for them or absorb later main.

## 1. Existing check owners finish; do not start duplicates

Cloud full20 is already running on exact98, report20261017T194255Z-3417055c,
using EXISTING configured cloud RUST_MIN_STACK16777216. Default-stack exact98
engine527/release2/audio-allocation216 supplements passed with that variable
UNSET; they do not constitute full20. Source392's earlier20/20 applies to392 only.

The sole existing Mac verifier01a149f8-d4e8-7c91-82b9-5bdea69929a0 already runs
full20 on exact98 with normal Mac stack UNSET/private CI target. Original3crash
cases are logged PASS within stage9; later full stages are PENDING. Do NOT rerun,
restart because of elapsed time or launch another local owner. Shared originals
belong to source/EQ owner and coordinator, Pulse2787. This packet contains no
passing Mac report, log set, executable or build receipt.

The next dependency is terminal completion of BOTH existing full pipelines and
review/actual PR393 merge evidence, not a new command. Coordinator/source owner
must add the ORIGINAL NEW PASSED MAC98 summary+all20logs, report byte count/SHA256,
actual full argv/status/exit0, exact source/tree/clean start=end digest/stale=false,
hardware/toolchain/stack environment and source-input comparison. Preserve all
failed/partial reports and diagnostics. Store these in a NEW version/addendum;
never edit/relabel older reports or overwrite immutable metadata v1.327Mac failed
workspace9; its original704ef84c transport stays history, not qualification.

## 2. Reproducible source identity — no primary chmod

Observed clean isolated cloud source has1837 tracked inputs, no untracked inputs,
all file bytes matching Git blobs. Actual guard digest:
e105f71fcb486dfff1c172b19598c14c2032e61bdd64443ee123c9bc0d58cad6.
launch permissions0700/execute-mask64, all other execute masks0. Canonical0755
launch produces DIFFERENT20d68dde740595b0046e522941e32007d5fff12c489813a209b1c5290c784abd.
source-inputs.json records every relative path/order/size/SHA256/Git blob/mode and
actual lstat/execute bits. This is read-only metadata, NOT a new CI receipt.

Reuse the ongoing exact Mac checkout when it matches. Do not recreate or alter
it during its active check run. If a NEW isolated task-owned checkout is later
needed, use an absent path and explicit creation umask:

    git fetch origin 98b644301fa762f7ef3b6120e16f85469ae602c8
    (umask 077; git worktree add --detach <NEW-ISOLATED-PATH> 98b644301fa762f7ef3b6120e16f85469ae602c8)

Verify actual guard/all input modes and original NEW Mac report digest; stop on
differences. No primary/existing checkout chmod, guard normalization, altered
report bytes or bypass. No source/module/helper edits. Primary and installed
app modes/settings/media/READY release owner remain untouched.

## 3. Actual source eligibility and future report identity

PR393 is OPEN at metadata capture; speculative GitHub merge_commit_sha is not an
actual merge. If actual393 merge has identical complete tree/digest and98 ancestry,
use the existing repository validate_ci with ORIGINAL98 report/candidate98; record
actual checkout/merge mapping. If actual tree differs, separate qualification is
required. Do not chase moving main or silently certify changed source. This
packet freezes98 and makes no final-green393/native-full/merged claim.

No327/335 report may satisfy98. After NEW Mac98 full report is available, all
future commands use --candidate98 and that exact unchanged passed report. If an
identical actual merge is deliberately chosen for checkout, --source becomes
its explicitly recorded SHA while --candidate/report remain98. A changed tree
cannot inherit this. Do not silently rewrite this v1 source identity.

## 4. Future artifact/profile commands — not authorized now

Only after coordinator dispatch following the terminal dependencies above, fresh
app/process/build/lock audit, immutable source and valid READY release owner:

    python3 <EXISTING-VERIFIED-2001-BYTE-HELPER> \
      --source 98b644301fa762f7ef3b6120e16f85469ae602c8 \
      --candidate 98b644301fa762f7ef3b6120e16f85469ae602c8 \
      --ci-report <ORIGINAL-NEW-PASSED-MAC98-SUMMARY.json>

helper-identity.json identifies the unchanged native-reviewed helper2001bytes,
SHA256f94d8eab81d891b52cac3dedb7d0cd3a96b852ecf108fd34a9f8ba3169d2d98c,
already held by the verifier from prior6c897a37 evidence. No helper source is
edited or newly introduced in this metadata-only packet; underlying repository
delivery/local-CI modules are unchanged. Unknown/pending/malformed ownership or
package-layout refusal must STOP; no auto-adopt/recovery. Guard can clean owned
release products only during later valid handoff, never install/activate here.
Accept only overall helper exit0, final owner.state=ready/source98/digest matching
new Mac report, and actual executable hash. artifact-only.json is written BEFORE
guard exit; its early --source check alone does not certify completion.

Then, still in the same future serial slot and same ready-owned source, bounded
ignored profile (no concurrent Cargo, installer or release handoff):

    cargo test -p hex-audio --release --lib --features allocation-probe profile_project_spectrum_maximum --locked -- --ignored --nocapture

This remains PENDING, not executed here. Fixed0/32/128/256 tracks;7trials each,
2warmups,16 capture blocks and bounded worker turns. Keep raw results/outliers,
hardware/rate/buffer/workload. Current payload26419596B;32MiB cap is factory-owned
only, excluding caller UI copies/total process memory. No broad claim about all
UI memory, driver/DSP/GPU deadlines or native physical acceptance. Return any
failure to the existing owner/coordinator; no silent source repair/new PR.

## 5. Future signed stable-path delivery — separate authority required

NO INSTALL/ACTIVATION AUTHORIZED. Installed app remains reporteddfa21f5a /
build3751944026 at /Users/portalsurfer/dev/hex/artifacts/hex.app. Do not touch,
replace, launch or quit it. User is away; screenshot cancelled, no GUI/input or
normal quit requested. When coordinator later schedules delivery with fresh app
state and normal USER SAVE/QUIT if necessary, supported command is:

    sh scripts/bundle-macos.sh \
      --ci-report <ORIGINAL-NEW-PASSED-MAC98-SUMMARY.json> \
      --candidate 98b644301fa762f7ef3b6120e16f85469ae602c8 \
      --included <VERIFIED-METADATA>/included-test-revisions.json \
      --checklist <VERIFIED-METADATA>/USER-TEST.md

It BUILDS AND INSTALLS; no dry-run interpretation. Stable org.portalsurfer.hex.dev,
configured existing certificate4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E and
teamDKTKQ8U5T8, same path, source/executable/seal/signature/receipt remain mandatory.
No forcequit, settings/media/TCC/keychain/profile changes, new app identity or
unsaved loss. Installed receipts/executable hashes come from coordinator/local
verifier after successful authorized work, never fabricated by this packet.

USER-TEST.md preserves rename/range/paste/borders/EQ349 plus normal fade/Warp/
browser cohort checks and accepted spinner2760/EQ2729.392/393 stack regressions
are automated, not new human gates. Physical/GPU/listening/real-WAV same-binary
normal --open relaunch remain OPEN. Default ./launch still builds latest main
without tests and is not an identical-binary relaunch proof; --test is opt-in.
