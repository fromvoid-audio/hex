# Pinned98 UI/EQ checklist — QUALIFICATION PENDING, metadata v1

Candidate98b644301fa762f7ef3b6120e16f85469ae602c8; treec8e93e2c431f0ac21de8cbb6a3258fc34dd3ac72. Both current full qualification pipelines are pending at this metadata snapshot. No actual passed Mac98 report or app build is supplied here. Record ACTUAL running source/build/receipt; current installeddfa is not this candidate. User presence/manual input/listening is required. Use disposable current-format projects; preserve original media/current user project. Do not force quit or replace/launch current app from this checklist. Existing launcher spinner and EQ2729 gesture signoffs stand.

## New UI cases


1. **PR376:** focus a header by its name and its blank background; Command-R,
   edit and Enter. Verify one Undo/Redo. Open another draft and Escape. Arrow
   focus to another header and repeat; clip-header Command-R must still edit the
   clip name. Search and numeric-input focus must retain their keys.
2. **PR377:** click first clip, Shift-click fifth; check all five. Reverse the
   range and repeat Shift-clicks around the original anchor. Command-toggle a
   member, Command-Shift union, then Shift-click another track (new anchor).
   Clear in a lane, then Command-click: no hidden old members may return. Check
   ordinary header dragging and body time selection still behave normally.
3. **PR378:** header-select one clip, Command-C, click another time/track and
   Command-V. Repeat with several clips. Verify complete contents and original
   gaps, repeated paste, one atomic Undo/Redo, and source retention. Copy/paste
   text in search, return to the Arrangement and paste again: its whole-clip
   payload must remain. Keep accepted multi-source-track stable-owner semantics;
   no new cross-track remapping is expected.
4. **PR335:** inspect single/multiple selected audio and MIDI borders, hover,
   toggle a middle member while the endpoint stays selected, and deselect. Pan
   until clips are cropped at either viewport boundary. Drag/cancel ordinary
   trim/fade affordances and check selected preview borders, original clip colors,
   text, waveform/notes and usable edge hit areas. No source/time geometry change
   is expected.
5. Save/reopen only the disposable project to check renamed tracks and pasted
   whole content persist. This does not require saving/quitting the user's current
   app/project. Never force-quit or discard unsaved data.


## EQ remaining cases (preserve accepted gestures)


Use two independently audible tones/tracks, a Return and sparse EQ. Record PASS/FAIL/UNRUN with exact cohort SHA, device/rate/buffer, screenshots/listening notes and available callback/underrun telemetry. Do not reopen the accepted2729 gesture signoff.

1. Dual spectra: conspicuous EQ plus host trims produces real distinct input/output curves; input is before entry input trim, output after effect/output trim. Hide input independently. Check ordinary/Return EQ, bypass, silence/anti-phase stereo, stopping/keyboard monitoring and reopen.
2. Quality/layout: inspect bass readability, capture-driven decay and fixed−96..0dbfs display without claiming extra FFT resolution or exact Prism parity. At880x540 and1500x650, full labels/actions/readouts, response/automation rows and graph remain usable and unclipped.
3. Backspace: focused selected EQ node removes only that node/automation; Undo/Redo restores identities. Empty/held/pending/stale/automation-point cases preserve track/clip isolation; numeric/text editing retains its keys.
4. Project signals: no selection shows real Master; one/two/ALL256 selected canonical tracks produce independent correctly assigned-color layers plus Master, never a selected-track sum or silent prefix cap. Color edits, reorder/removal/reselection and project/output replacement clear stale/reused identities.
5. Tap semantics: each track is actual direct post-device/post-fader/balance output including owned tails; Master includes Returns/master gain before monitor-only metronome/browser preview. Vary effects/faders/mute/bypass/Return/master gain; nonlinear bus output is not claimed to equal the sum of track curves.
6. Lifecycle/input/GPU: collapse stops new project capture/analysis after bounded queued work drains; expand starts fresh. Resize outside release commits view height; Escape/focus/window/context change cancels without project Undo. Compact live header retains ALL layers at constrained populated details, restores preferred height in larger windows, and leaves Auto Pan/Operator/Return details and timeline usable.
7. Callback/profile bounds:33 fixed packet owners,32 forward/33 return slots, at most263168 stereo contribution frames/callback, whole-window refusal on exhaustion, no callback allocation/final-drop/lock/log/FFT. Worker uses the existing thread, max2 packets/8 stereo layers per turn. Caps30Hz/100ms up to32 tracks,10Hz/250ms for33–128,5Hz/400ms for129–256. Exercise selection churn/collapse/output restart and all256 layers at the supported rate plus one other available rate. Record real-device sustained audio/deadline and GPU responsiveness separately from worker profile. If a256-track fixture or telemetry is unavailable, mark that item UNRUN and report the bounded fixture/instrumentation need.

Return one finite result table, exact source/build/signature identity, minimum-window screenshots, raw profile/callback evidence and listening observations. Installation/merge is not human/native acceptance. Failures return to the owning canonical scope; unrun checks stay pending with the coordinator, without new source-feature scope or forced immediate Mac work.


Preparation API373 is included source provenance, not completed sampler389/tuning352/MTS353. Record one short regression smoke for existing ordinary playback/import/browser preview/Undo without changing user media; no new feature scope. Preserve prior resize/waveform/BPM/Shift/Command-T behavior; report a concrete regression rather than restarting all accepted manual work. Real WAV access and identical-executable relaunch acceptance are separate. Mark unavailable256-track fixtures or deadline telemetry UNRUN, retain bounded need; no source/native parity claims from cloud checks.

## Source392/393 and prior-cohort preservation

392 heap-constructs fixed257-layer publications/owners. Current factory-owned payload26419596 bytes;32MiB cap excludes caller-owned UI copies and total process/UI memory.393 corrects two existing fixture caller frames without changing behavior/assertions/workloads. The default-stack cases are automated qualification, NOT new human approval gates. Do not ask the away user to reproduce crashes, quit or take screenshots. All3 original crash cases reported PASS inside ongoing Mac workspace stage is not a full20 PASS.

After a separately approved new app is actually running, retain a bounded ordinary trim/fade/Warp/BPM/browser smoke: affected/control samples, normal left/right edges and lower fade handles, raw/Warp-on/processed-Warp-off, crop/reveal/loops and two zooms; no disappearing waveform/stale border. Lower fade free by default/Command snap and stationary modifier behavior; Escape/focus/outside-release cancellation, source retention and one UndoRedo. Shift stretch/BPM live preview remains coherent. Browser hover/progress/click-seek and sample-result double-click must not accidentally insert clips. Preserve accepted spinner/EQ gesture behavior; no repeated signoff gate.

The ignored maximum ProjectCapture/ProjectWorker profile remains NOT RUN in this packet: later serial optimized execution at0/32/128/256 selected tracks, seven trials each/two warmups,16 capture blocks and bounded turns. Record raw output/hardware/rate/buffer/workload/outliers/current payload26419596. It does not establish physical CoreAudio/DSP/GPU deadlines or total UI memory bounds. Native physical/input/GPU/listening and real WAV access across IDENTICAL-executable normal --open relaunch remain OPEN. No GUI, user quit, launch, install or screenshot is requested by metadata preparation.
