from pathlib import Path
import importlib.util,sys
root=Path('/workspace/hex-integration-active');sp=importlib.util.spec_from_file_location('ci439owning',root/'scripts/local-ci.py');c=importlib.util.module_from_spec(sp);sys.modules[sp.name]=c;sp.loader.exec_module(c)
steps=(
 c.Step('actual-header-delete-trace',('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--locked','track_name::delete_tests::','--','--nocapture'),uses_cargo_target=True,requires_tests=True),
)
r=c.LocalCiRunner(root,mode='component',run_id='439-29ca-header-delete-diagnostic',steps=steps,min_free_bytes=2*1024**3)
raise SystemExit(r.run())
