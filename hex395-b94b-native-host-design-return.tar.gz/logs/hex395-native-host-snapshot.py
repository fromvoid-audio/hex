from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil,os
r=Path('/workspace/hex-sampler-aggregate');out=Path('/tmp/hex395-b94b-native-host-design-return');out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
def sha(b):return hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();assert head=='b94b0e2f6fbec0932d422c00d4584739c192cb9a'
changed=sorted(set(git('diff','--name-only').decode().splitlines()+git('ls-files','-o','--exclude-standard').decode().splitlines()));rows=[]
for n in changed:
 p=r/n;assert p.is_file() and not n.startswith('artifacts/')
 b=p.read_bytes();target=out/'source'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 try:before=git('show','HEAD:'+n)
 except subprocess.CalledProcessError:before=None
 row=dict(path=n,before_sha256=sha(before) if before is not None else None,after_sha256=sha(b),bytes=len(b),mode=oct(p.stat().st_mode&0o777));rows.append(row)
 if before is not None:
  target=out/'before'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before)
assert len(rows)==11,rows
names=sorted(set(git('ls-files','-co','--exclude-standard').decode().splitlines()));h=hashlib.sha256()
for n in names:
 p=r/n
 if p.is_file() and not n.startswith('artifacts/'):
  h.update(n.encode()+b'\0'+p.read_bytes()+b'\0')
(out/'SOURCE.json').write_text(json.dumps(dict(base_head=head,base_tree=git('rev-parse','HEAD^{tree}').decode().strip(),dirty=True,source_digest=h.hexdigest(),paths=rows,snapshot_only=True,canonical_not_updated=True),indent=2));(out/'TRACKED_SOURCE.diff').write_bytes(git('diff','--binary'));(out/'STATUS.txt').write_bytes(git('status','--porcelain=v1'))
context=['crates/hex-audio/src/candidate_custody.rs','crates/hex-audio/src/candidate_custody/eligible.rs','crates/hex-audio/src/candidate_custody/eligible/publication/active.rs','crates/hex-audio/src/candidate_custody/eligible/publication/resources.rs','crates/hex-audio/src/prepared.rs','crates/hex-audio/src/prepared/eligible_publication.rs','crates/hex-audio/src/native_callback_owner.rs','crates/hex-audio/src/native_callback_owner/resources.rs','crates/hex-audio/src/native_callback_owner/ring_storage.rs','crates/hex-engine/src/audio_candidate.rs','crates/hex-engine/src/audio_candidate/claimed.rs','crates/hex-engine/src/audio_candidate/storage.rs','crates/hex-engine/src/audio_candidate/preparation_operations.rs','crates/hex-engine/src/audio_candidate/preparation/original_resources.rs','crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs','crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile/complete.rs','crates/hex-engine/src/audio_storage.rs','crates/hex-engine/src/sampler_host_fields/physical.rs','crates/hex-desktop/src/native_audio/main_control_file.rs','crates/hex-desktop/src/native_audio/tests/main_file.rs']
for n in context:
 p=out/'context'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,p)
logs=out/'logs';logs.mkdir()
for p in Path('/tmp').glob('hex395-native-host-*'):
 if p.is_file() and p.suffix in {'.log','.json','.py'}:shutil.copy2(p,logs/p.name)
text=Path('/tmp/hex395-native-host-first-tests.log').read_text();assert '3 passed; 0 failed; 0 ignored' in text
strict=Path('/tmp/hex395-native-host-first-strict.log').read_text();assert 'struct `NativePreparationHost` is never constructed' in strict and 'items after a test module' in strict
procs=[]
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  try:
   cmd=(p/'cmdline').read_bytes().split(b'\0');exe=Path(os.readlink(p/'exe')).name
   if exe.startswith(('cargo','rustc','clippy')) or (exe.startswith('python') and any(b'hex395-native-host' in a for a in cmd[1:])):
    procs.append(dict(pid=int(p.name),exe=exe,argv=[a.decode(errors='replace') for a in cmd if a]))
  except (OSError,ProcessLookupError):pass
other=[p for p in procs if p['pid']!=os.getpid()];assert not other,other
(out/'TERMINAL.json').write_text(json.dumps(dict(sessions=[dict(id=96835,operation='cargo check Audio tests allocation-probe',terminal=True,exit=0),dict(id=2331,operation='first focused native host tests',terminal=True,exit=0,passed=3,ignored=0),dict(id=90661,operation='strict Engine/Audio all-targets allocation-probe',terminal=True,exit=101),dict(id=29021,operation='architecture after local placement/policy correction',terminal=True,exit=0),dict(id=68275,operation='read-only source hashing',terminal=True,exit=0)],owned_compile_test_processes_now=other,probe_pid=os.getpid(),limits='Focused3 were BEFORE exhaustive host patterns and draft item-placement repair; no qualification relabeled for current snapshot; strict negative preserved; no reruns after Root stop.'),indent=2))
(out/'QUESTION.md').write_text('''# Exact native live-owner seam, snapshot ONLY

Canonical395 stays b94b;11dirtypaths snapshotted (initial10 plus own custody policy guard-only audit addition). No newcanonicalcommit; no ready/fullCI/native/wholeSampler claim. 3 actual focused tests passed before later exhaustive patterns/placement changes; original log unmodified. Strict90661 failed NEWunused private facade + new draftimplaftertestmodule. Trivial draft placement repaired afterward; no strict rerun/unused guard suppression. Architecture29021 passes current source. Local guard policy permits only actual CustodyMutexGuard references in new privatehost, rejects newMutex/spin/control-lock fields, adds samehost to finite no-wait source scan; sensitivity tests not rerun. All jobs terminal. Current exactsource/beforeafter hashes in SOURCE; base/binding source/failures preserved.

Implemented prototype: Engine finite NativeFields actual Root/shared metadata+5guardedbodies containment+real Slot/runtime/archive/5Work Vec capacities and perindex preparation/Life/domains, exhaustive collecting preparation/custody/source/draft children. Audio privateNativePreparationHost acquires EACHactual5guard viaONEtry, distinguishes poisonUnknown from contentionPending, validates realroot/slot/incarnation/reservedphase and actualcelladdress. No owner extraction/swap/unsafe/newlock; Engine inspection reference loans prevent mutable samecell reborrow until ledger drops. Test actualnonemptyresident source/sparecapacity inspection0alloc/free then samecell mutable reborrow, EACHfiveotherthreadcontention, stale/wrongcell, and ACTUALanchored nativeconstructor Some(boundary)->Unknown/invalidledger->normalcancel/retire. It does NOT claim loadedSampler, fullconstructor budgets, mixedcurrent graph, normalService or admission. Unsupported occupants refuse explicitly, not fakeNone.

Concrete missing counterpart: Callback itself owns active/deferred_eligible/held_retirement/domain_pages and incoming/return/command ring endpoints (prepared.rs833). Active ownsBox<State>, State runtime/retired_runtime own Send-only ClaimedAudioCandidateRuntime->Box<ClaimedState>->RuntimeOwner/Playback (active.rs5/publication.rs193/Engineclaimed.rs56). These actual owners are in GuardState::Live Box<NativeCallbackOwner> captured by native callback, not in the five Root guards. RootNativeBank.native stores constructor NativeCandidateBoundary/carrier/channel receipts; owner_ref is available ONLY on the actual Guard, and WorkerRootView has no liveGuard borrow. reserve_native_worker binds boundary then transfers actualGuard to native closure. Terminal/enqueue Rootbank barrier serializes close vs queuecommit, not callback.render mutable state. Rtrb capacity/queued count and constructor ChannelStorage totals do not expose retained payload fields or supply lifetime-bound physical Vec/Box references.

The test keeps real bank.nativeSome and refuses; replacing it with None/body/count certificate is forbidden. Existing ledger Owner lifetime-bound actual field identities cannot be populated later from a saved address/byte descriptor without a new concrete constructor-coupled ownership/storage contract. A raw activePlayback borrow cannot cross to Service safely: runtime is Send-only, actualGuard is on callback thread, callback may not lock/wait. I have NOT introduced such a protocol or enabled dispatch.

Root question: select smallest concrete EXISTING-custodian counterpart for current/queued/deferred/held native payloads. A constructor-coupled immutable physical-allocation/retention representation in existing RuntimeSlot/State, maintained across actual handoff/return, appears necessary unless an existing synchronous safe native-owner inspection API can be identified. It must bind actual constructor owners/allocations and mutation lifetime (not scalar totals/ID authority), count descendants and exact alias fields, preserve callback0alloc/free/no-family-lock and native/reaper once-retirement. If a phase-bound actualGuard borrow is intended instead, identify how live callback access is safely excluded without callbackwait/Sync widening/unsafe. This is NOT reopening publicprojection audited-producer visibility or asking for genericframework; it is the actual mutablecurrent-owner gap demonstrated by normal constructor. No runtime ownership changes pending Root decision.

Also still open independently: actual closed host compiler preflight/normal bothcaps incl File/family/current/capturedhistory, originalLedger immutable loan ending before samecell mutation, constructor in-progress latch/error/cancel handling, Rootfactory aggregate beforebirth union, qualified firststartup/Event/exportseek, realMonoStereoSamplerPCM/ACK/replace/export/native/library. Prototype's unused production warning honestly marks that these are not wired; no dead_code allowance added to claim strictgreen. Preserve baseline b94/f73 accepted packets; don't build evidence ref or compare archive bytes to installed app.
''')
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file():
  b=p.read_bytes();manifest.append(dict(path=str(p.relative_to(out)),bytes=len(b),sha256=sha(b)))
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));a=Path(str(out)+'.tar.gz')
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(a) as t:
 m=t.getmembers();assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in m)
 for row in manifest:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
blob=git('hash-object','-w',str(a)).decode().strip();tree=subprocess.check_output(['git','mktree'],cwd=r,input=f'100644 blob {blob}\t{a.name}\n',text=True).strip();commit=git('commit-tree',tree,'-m','Evidence only: dirty native host actual current-owner decision return').decode().strip();ref='refs/heads/evidence/hex-sampler-2789-b94b-native-host-return';subprocess.run(['git','update-ref',ref,commit],cwd=r,check=True)
result=dict(archive=str(a),bytes=a.stat().st_size,sha256=sha(a.read_bytes()),safe_members=len(m),payloads=len(manifest),evidence_commit=commit,ref=ref,source_base=head,dirty_digest=h.hexdigest(),dirty_paths=len(rows));Path('/tmp/hex395-native-host-snapshot-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
