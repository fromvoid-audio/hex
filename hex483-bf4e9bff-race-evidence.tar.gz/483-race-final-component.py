import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-workspace-tab-489')
spec=importlib.util.spec_from_file_location('hex_ci_483_race',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
steps=(
 m.Step('architecture',('python3','scripts/check-architecture.py')),
 m.Step('ui-style',('python3','scripts/check-ui-style.py')),
 m.Step('gpui-patch',('python3','scripts/check-gpui-patch.py')),
 m.Step('device-layout',('python3','scripts/check-device-layout.py')),
 m.Step('touched-fmt',('rustfmt','--edition','2024','--check','crates/hex-ui/src/editor/arrangement_seek.rs','crates/hex-ui/src/editor/arrangement_seek_tests.rs','crates/hex-ui/src/editor/controller.rs','crates/hex-ui/src/editor/device_panel/tests/eq_held_pointer_tests.rs')),
 m.Step('diff-check',('git','diff','--check')),
 m.Step('ui-owning-controls',('cargo','test','-p','hex-ui','--lib','--features','ui-test-support','--locked','--','--nocapture','eq_ui_tests','arrangement_seek::tests','device_comparison_tests','shortcut_text_tests')),
 m.Step('session-retirement-controls',('cargo','test','-p','hex-session','--lib','--locked','arrangement_seek::tests','--','--nocapture')),
 m.Step('actual-callback-cancellation-CAS',('cargo','test','-p','hex-audio','--lib','--locked','--','--nocapture','cancellation_and_final_apply_cas_have_one_winner','cancelled_fresh_publication_returns_candidate_and_allows_successor')),
 m.Step('conditional-callback-allocation',('cargo','test','-p','hex-audio','--features','allocation-probe','--test','callback_allocations','--locked','conditional_fresh_runtime_publication_paths_are_callback_allocation_free','--','--nocapture')),
 m.Step('allocation-probe-calibration',('cargo','test','-p','hex-audio','--features','allocation-probe','--test','allocation_probe_calibration','--locked','--','--nocapture')),
 m.Step('strict-default',('cargo','clippy','-p','hex-ui','--all-targets','--locked','--','-D','warnings')),
 m.Step('strict-feature',('cargo','clippy','-p','hex-ui','--features','ui-test-support','--all-targets','--locked','--','-D','warnings')),
)
raise SystemExit(m.LocalCiRunner(root=root,mode='quick',steps=steps).run())
