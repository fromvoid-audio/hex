//! Sole owning Session producer for original-Sampler construction writers.
use super::*;
use std::cell::RefMut;

/// Held writers cannot escape their actual Session, and inspection cannot
/// return borrowed records across a mutable construction reborrow.
/// ```compile_fail
/// let session = hex_session::Session::new(48000, 16, 1024).unwrap();
/// let loan = session.original_sampler_session_loan_on_control().unwrap();
/// let escaped = loan.with_inventory(|inventory| Ok(inventory));
/// ```
pub struct OriginalSamplerSessionLoan<'a> {
    session: &'a Session,
    waveforms: RefMut<'a, SortedEntries<ClipId, AudioClipWaveform>>,
    transaction: hex_engine::audio_transform::OriginalSamplerTransaction<'a>,
}
impl Session {
    /// Existing order: waveform then cache/pending/tempo, before native guards.
    /// No allocation, pending write or candidate mutation during acquisition.
    pub fn original_sampler_session_loan_on_control(
        &self,
    ) -> Result<OriginalSamplerSessionLoan<'_>, AudioStorageError> {
        let waveforms = self
            .audio_clip_waveforms
            .try_borrow_mut()
            .map_err(|_| AudioStorageError::ExternalReadersPending)?;
        let transaction = self
            .audio_transforms
            .original_sampler_transaction_on_control()?;
        Ok(OriginalSamplerSessionLoan {
            session: self,
            waveforms,
            transaction,
        })
    }
}
impl<'a> OriginalSamplerSessionLoan<'a> {
    /// Actual media/history/waveform/transform fields under the SAME writers.
    /// The inspection result is never constructor authority: the selected
    /// constructor still performs mandatory normal binding and both cap checks.
    pub fn with_inventory<T>(
        &self,
        visit: impl for<'scope> FnOnce(
            &'scope ResidentPcmInventory<'scope>,
        ) -> Result<T, AudioStorageError>,
    ) -> Result<T, AudioStorageError> {
        let transforms = self.transaction.inventory();
        let inventory = ResidentPcmInventory {
            session: self.session,
            waveforms: &self.waveforms,
            transforms: &transforms,
        };
        visit(&inventory)
    }
    /// Sole private Audio construction consumer; source policy restricts this
    /// internal integration accessor. No owner is extracted and no guard ends.
    pub fn original_sampler_writer_on_control(
        &mut self,
    ) -> &mut hex_engine::audio_transform::OriginalSamplerTransaction<'a> {
        &mut self.transaction
    }
}
