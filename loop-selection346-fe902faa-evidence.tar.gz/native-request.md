# bounded native request — coordinator single lane only

Source fe902faa8b422d604075c3e94596934d9d927cee
Tree 8de4e71e622cdef0a47f3112e0711f090937dc07

Checks-only, locked screen compatible, no app/GUI/unlock/install/build delivery:

cargo test -p hex-ui --features ui-test-support --locked editor::loop_selection_ui_test:: -- --nocapture

Expected exactly 4 selected / 4 passed / 0 failed / 0 ignored; capture actual filtered count, cargo exit and raw stdout/stderr. Real Service worker/prepared engine + GPUI test windows, mouse header events, simulated L/Undo/Redo. Cases: single audio, MIDI, additive clips/gaps; reverse explicit range and main proxy; current-format snapshot, one Undo despite repeated L; stale range/clip, empty/pending; browser search, numeric widget, header rename, MIDI child, musical keyboard; Session toggle; MIDI end spanning tempo change 72000..144000. Cloud targeted broader selector editor::loop_ produced10passed/0failed/0ignored/724filtered at exact source; do not label these native results or FULL20.

Optional only if a concrete adjacent concern: cargo test -p hex-ui --features ui-test-support --locked editor::loop_rail_ui_test::loop_rail_click_activates_resizable_ends_preserve_enable_and_toolbar_disables -- --exact --nocapture (exactly1). Other unchanged loop tests do not need native repetition.

Root-owned physical optimized acceptance remains open: verify exact candidate provenance, audio/MIDI/additive loop visible endpoints; reverse body selection precedence, repeated L enabled, one Undo/Redo, Save/reopen; text/numeric/rename/browser/widget/lower editor focus, musical L note, Session/toolbar toggle and Command-L single audio. No start/stop change, clip contents/selection preserved. UI/display/physical keyboard/audio/GPU/listening/optimized app delivery are not established by headless CLI. Source5 constructor seam and334 capacity are independent patches for merger, absent here.
