# bounded fixture correction native request — coordinator single lane only

source e89d8f2d667d9c7dd5cd43004c0ff8b75c3756d4
tree 7a0b37ea869360885f5affd1cc9291f4b2c84339
parent de33458c2047e98e9990ca86280de557f410199d

cargo test -p hex-ui --features ui-test-support --locked editor::loop_selection_ui_test::loop_review_ -- --nocapture

Expect EXACTLY2positive/0fail0ignored, actualfiltered/cargoexit/source/tree/dirty/defaultnativestack/rawreport+SHA. Audit fixture first: commonfixture creates unique RAII BatchFiles root/samples BEFORE constructor; existing363 new_for_test_with_browser_directory takes private root and owns browser/recent/theme/derived cache paths. It asserts actual initial directory and places exactly root/samples. RAII guard retained through each of eight test bodies. No ambient HOME/Music startup; no global helper/constructor/mod/production edits, no process HOME changes. All Service/Engine/GPUI input/graph and assertion bodies retained. Native preflightabd was BLOCKED BEFORE Cargo perPulse24228, not a product failure and not a green test; raw root reportSHA2e2e1b30af6e452c6f6f26e851d3481a4c7dadd3b2943b248706a84750825628 preserved root-side. Do not relabel old5a2/fe9 4 native or abdcloud8 as newe89 native. No unchanged native4/2/full20 repeat requested.

Source contract remains the two review repairs: canonical Session cell-selection entry method + actual mode toolbar and keys; controlled valid browser/native payload begin with retained editor focus + actual CommandL/plainL. Not an ordinary Session mouse-cell/browser-row click reproduction claim. Physical input/focus/drop/visibleloop/save-reopen/GPU/audio/listening/optimized app remains OPEN/root-owned. Merger final combined FULL20/review/merge; no app/GUI/unlock/permissions/install/launch/quit/backend/user-data actions.
