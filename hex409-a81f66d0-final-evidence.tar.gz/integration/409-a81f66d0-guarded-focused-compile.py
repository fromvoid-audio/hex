import importlib.util
import pathlib
import sys

root = pathlib.Path('/workspace/hex-integration-group-drag')
spec = importlib.util.spec_from_file_location('hex_local_ci', root / 'scripts/local-ci.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
runner = module.LocalCiRunner(
    root,
    mode='component',
    run_id='409-a81f66d0-focused-compile-handoff',
    adopt_target=True,
    min_free_bytes=2 * 1024 * 1024 * 1024,
    steps=(module.Step('project-ui-test-target-compile', (
        'cargo', 'test', '-p', 'hex-project', '-p', 'hex-ui',
        '--features', 'hex-ui/ui-test-support', '--lib', '--locked', '--no-run',
    )),),
)
result = runner.run()
print('FOCUSED_COMPILE_ONLY_SUMMARY', runner.summary_path)
raise SystemExit(result)
