from pathlib import Path
import subprocess,json,hashlib,time
repo=Path('/dev/shm/hex-group-409-fixture');out=Path('/dev/shm/hex-409-fixture-evidence')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip()
names=['group_outside_lane_clears_all_previews_and_restores_originals', 'group_vertical_autoscroll_invalidates_all_previews_before_repaint', 'group_capture_checks_source_allocation_and_selection_epoch', 'group_capture_profiles_actual_redraw_separately_from_projection', 'group_capture_reenters_valid_lane_and_commits_only_current_projection', 'group_escape_and_actual_gpui_capture_loss_never_commit_any_member']
steps=[('final-ui-nine',['cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','--','group_fixture_',*names,'--nocapture'],9),('affected-default-five',['cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','browser_test_environment_','--','--nocapture'],5),('strict-ui',['cargo','clippy','-p','hex-ui','--all-targets','--features','ui-test-support','--locked','--','-D','warnings'],None)]
steps += [(g,['python3','scripts/check-'+g+'.py'],None) for g in ['architecture','gpui-patch','dependency-patches','ui-style','device-layout']]
steps += [('format',['cargo','fmt','--all','--check'],None)]
rows=[]
for name,argv,count in steps:
 log=out/(name+'.log');start=time.monotonic()
 with log.open('xb') as f: result=subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 passed=result.returncode==0
 if count is not None: passed &= f'{count} passed; 0 failed; 0 ignored;' in log.read_text()
 rows.append(dict(name=name,argv=argv,expected=count,exit=result.returncode,passed=passed,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 report=dict(head=head,tree=tree,steps=rows,status='PASS' if len(rows)==len(steps) and all(x['passed'] for x in rows) else 'INCOMPLETE_OR_FAIL',source_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=repo))
 (out/'candidate-checks.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,result.returncode,passed,flush=True)
 if not passed: raise SystemExit(1)
