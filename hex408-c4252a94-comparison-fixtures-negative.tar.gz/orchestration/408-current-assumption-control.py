from pathlib import Path
import importlib.util,sys
root=Path('/workspace/hex-integration-active');spec=importlib.util.spec_from_file_location('ci408risk',root/'scripts/local-ci.py');ci=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ci;spec.loader.exec_module(ci)
step=ci.Step('existing-comparison-callback-controls',('cargo','test','-p','hex-ui','--features','ui-test-support','--locked','--lib','editor::device_panel::tests::device_comparison_tests::device_comparison_metadata_','--','--nocapture'),uses_cargo_target=True,requires_tests=True)
r=ci.LocalCiRunner(root,mode='component',run_id='408-c4252a94-existing-comparison-controls',steps=(step,),min_free_bytes=2*1024**3)
raise SystemExit(r.run())
