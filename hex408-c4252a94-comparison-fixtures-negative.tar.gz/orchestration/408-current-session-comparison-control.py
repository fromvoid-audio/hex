from pathlib import Path
import importlib.util,sys
root=Path('/workspace/hex-integration-active');spec=importlib.util.spec_from_file_location('ci408session',root/'scripts/local-ci.py');ci=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ci;spec.loader.exec_module(ci)
step=ci.Step('existing-session-comparison-controls',('cargo','test','-p','hex-session','--test','device_comparison','--locked','--','--nocapture'),uses_cargo_target=True,requires_tests=True)
r=ci.LocalCiRunner(root,mode='component',run_id='408-c4252a94-existing-session-comparison',steps=(step,),min_free_bytes=2*1024**3)
raise SystemExit(r.run())
