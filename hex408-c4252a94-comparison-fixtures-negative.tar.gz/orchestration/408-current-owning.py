from pathlib import Path
import importlib.util,sys
root=Path('/workspace/hex-integration-active');spec=importlib.util.spec_from_file_location('ci408',root/'scripts/local-ci.py');ci=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ci;spec.loader.exec_module(ci)
step=ci.Step('empty-track-model-service-storage',('cargo','test','-p','hex-project','-p','hex-session','-p','hex-storage','--test','empty_track_creation','--locked','--','--nocapture'),uses_cargo_target=True,requires_tests=True)
r=ci.LocalCiRunner(root,mode='component',run_id='408-c4252a94-owning',steps=(step,),min_free_bytes=2*1024**3)
raise SystemExit(r.run())
