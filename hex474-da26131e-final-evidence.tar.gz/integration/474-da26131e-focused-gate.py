from pathlib import Path
import json,re,subprocess,hashlib
r=Path('/workspace/hex-integration-warning-cleanup');run=r/'artifacts/local-ci/474-da26131e-guarded-focused';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']=='da26131e1d75d7815ca92ec74d58b2ded464d435' and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and not s['dirty'] and s['start_tree']==s['end_tree']
assert len(s['steps'])==5 and all(t['status']=='passed' and t['exit_code']==0 for t in s['steps'])
assert not Path('/proc/1498757').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
logs=[(r/t['log']).read_text(errors='replace') for t in s['steps']]
assert re.findall(r'Ran (\d+) tests',logs[0])==['4'] and re.search(r'^OK$',logs[0],re.M) and not re.search(r'skipped|expected failure',logs[0],re.I)
assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',logs[1])==[('5','0','0')]
inventory=[]
for t,raw in zip(s['steps'],logs):
 text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',raw)
 warnings=[{'line':i,'text':line} for i,line in enumerate(text.splitlines(),1) if re.match(r'^\s*(?:warning(?:\[|:)|cargo:warning=)',line)]
 for line in text.splitlines():
  try:d=json.loads(line)
  except ValueError:continue
  if isinstance(d,dict) and d.get('reason')=='compiler-message' and d.get('message',{}).get('level')=='warning':warnings.append({'json_compiler_warning':d})
 assert not warnings,(t['step_id'],warnings)
 inventory.append({'step':t['step_id'],'argv':t['argv'],'warning_count':0,'log':t['log'],'sha256':hashlib.sha256((r/t['log']).read_bytes()).hexdigest()})
assert s['source_identity']['content_sha256']=='e510c6437f981cb6e6294611790144a6c95078a8c70e04dee3a5d27f25c1239a'
p={'head':s['commit'],'source':s['source_identity']['content_sha256'],'all5passed':True,'actual_python_buildscript_tests':4,'actual_pcm_tests':5,'total_targeted_unique':9,'ignored_or_skipped':0,'zero_warning_inventory':inventory,'duration_seconds':s['duration_seconds'],'summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest(),'scope':'Actual Linux currentcandidate Python4/PCM5/deniedABI+macroconsumer/workspacealltargettest-build/defaultstrict; no nativeMac/compilerCPUdeadline or optimizedintegrationreleaseclaim'}
(r/'artifacts/integration/474-da26131e-focused-gate.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2))
