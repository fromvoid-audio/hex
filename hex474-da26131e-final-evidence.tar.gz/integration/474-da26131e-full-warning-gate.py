from pathlib import Path
import json,re,hashlib
r=Path('/workspace/hex-integration-warning-cleanup');run=r/'artifacts/local-ci/20261019T172947Z-f113ee1b';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']=='da26131e1d75d7815ca92ec74d58b2ded464d435' and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and s['start_tree']==s['end_tree'] and len(s['steps'])==21
inventory=[];count=0
for t in s['steps']:
 assert t['status']=='passed' and t['exit_code']==0
 p=r/t['log'];text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',p.read_text(errors='replace'))
 ws=[{'line':i,'text':line} for i,line in enumerate(text.splitlines(),1) if re.match(r'^\s*(?:warning(?:\[|:)|cargo:warning=)',line)]
 for line in text.splitlines():
  try:d=json.loads(line)
  except ValueError:continue
  if isinstance(d,dict) and d.get('reason')=='compiler-message' and d.get('message',{}).get('level')=='warning':ws.append({'json_compiler_warning':d})
 count+=len(ws);inventory.append({'step':t['step_id'],'argv':t['argv'],'raw_log':t['log'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'warning_count':len(ws),'warnings':ws})
out={'source':s['commit'],'tree':'f4d7cca0b7ae4ae4dab7ecf476dc2b5c2d5b6d95','full_summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest(),'all21_compiler_warning_count':count,'inventory':inventory,'scope':'Actual complete current-candidate Linux full21 rawplain andJSON compiler diagnostics; logs unfiltered/retained. Mac and integratedoptimizedrelease not executed; ownerb1optimizedsource-scoped separately.'}
(r/'artifacts/integration/474-da26131e-full-warning-inventory.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'source':out['source'],'all21_compiler_warning_count':count,'full_summary_sha256':out['full_summary_sha256']},indent=2));assert count==0, 'Do not merge warningcleanup with unaddressed compilerdiagnostics'
