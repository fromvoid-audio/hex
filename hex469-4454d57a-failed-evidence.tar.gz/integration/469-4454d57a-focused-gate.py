from pathlib import Path
import json,re,subprocess,hashlib
r=Path('/workspace/hex-integration-captured-release');run=r/'artifacts/local-ci/469-4454d57a-guarded-focused';s=json.loads((run/'summary.json').read_bytes())
assert s['commit']=='4454d57a9c1cd14b06cc334f3332f2c2e0026419' and s['status']=='passed' and s['exit_code']==0 and not s['stale'] and not s['dirty'] and s['start_tree']==s['end_tree']
assert len(s['steps'])==4 and all(t['status']=='passed' and t['exit_code']==0 for t in s['steps']) and not Path('/proc/1453640').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
counts=[]
for t,expected in zip(s['steps'],[22,24,9,6]):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(r/t['log']).read_text(errors='replace'));assert rows==[(str(expected),'0','0')],rows;counts.append(expected)
p={'head':s['commit'],'source':s['source_identity']['content_sha256'],'all4passed':True,'counts':counts,'unique_tests':sum(counts),'ignored':0,'duration_seconds':s['duration_seconds'],'summary_sha256':hashlib.sha256((run/'summary.json').read_bytes()).hexdigest()};assert p['source']=='1184dddc37128c580a453468242a8f38290ca1ecb6b54b7c405f38156f3c8c04'
(r/'artifacts/integration/469-4454d57a-focused-gate.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2))
