from pathlib import Path
import subprocess,hashlib,json
p=Path('crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs');before=p.read_bytes();s=before.decode()
a='''        ledger.root(self.preparation, AudioStorageRole::Current)?;
        self.preparation
            .visit_audio_storage(ledger, AudioStorageRole::Current)?;'''
b='''        ledger.borrow_custody_on_control(self.preparation, AudioStorageRole::Current)?;'''
assert a in s;s=s.replace(a,b)
a='''            ledger.require_original_inputs_bound(self.original)?;'''
assert a in s;s=s.replace(a,'''            if false { ledger.require_original_inputs_bound(self.original)?; }''')
try:
 p.write_text(s)
 patch=subprocess.check_output(['git','diff','--binary']);Path('/tmp/hex395-parent-bound-sensitivity.patch').write_bytes(patch)
 Path('/tmp/hex395-parent-bound-sensitivity-source.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'path':str(p),'before_sha256':hashlib.sha256(before).hexdigest(),'negative_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'purpose':'Two negative controls only: restore nested public custody wrapper; disable mandatory original binding. Source restored after terminal.'},indent=2)+'\n')
 with open('/tmp/hex395-parent-bound-sensitivity.log','wb') as out:
  result=subprocess.run(['cargo','test','-p','hex-engine','--lib','--locked','parent_bound','--','--nocapture'],stdout=out,stderr=subprocess.STDOUT)
 print('negative cargo exit',result.returncode)
 assert result.returncode==101
 log=Path('/tmp/hex395-parent-bound-sensitivity.log').read_text()
 assert '6 passed; 2 failed; 0 ignored' in log,log[-8000:]
 assert 'parent_bound_nonempty_success_owns_context_and_children_from_birth_through_cleanup ... FAILED' in log
 assert 'parent_bound_original_unrelated_parent_or_data_cannot_supply_cleanup_binding ... FAILED' in log
finally:
 p.write_bytes(before)
 assert p.read_bytes()==before
 subprocess.run(['git','diff','--exit-code'],check=True)
print('both independent negative controls sensitive; final source restored exactly')
