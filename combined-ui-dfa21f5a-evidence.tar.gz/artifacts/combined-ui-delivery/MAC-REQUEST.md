# Pinned combined UI cohort: coordinator-owned Phase A

Source/candidate: dfa21f5aed2186781e6aa985a053f85d9e51b75d.
Actual Git tree: 622dcee50829b2beaf503bc6ff0e92a18003e103.
Content SHA256: 337d104fd8642271d550a32cc9765fbc3033b6e9fc6b179f4459e3463f55e865.
Report: artifacts/local-ci/20261017T172516Z-877e855e/summary.json.
Qualification status/report hash are authoritative in final-verification.json.
Do not execute this handoff unless that proof records full20 PASS and the original
report/file manifest hashes have been verified. This is a Linux full report,
not a Mac/native result. No report commit/platform labels are rewritten.

## Source provenance and prerequisites

GitHub PR372 is actually merged as this source; actual first parent is
93d22ab0e0dd1a31a993eaa62e5575d7d69e6115 (PR351), second parent is reviewed
504d9b3cfe7658b366c01c12bd6de232c3d320c8 (PR372). The actual tree is DIFFERENT
from PR372's checked tree57ba6db29f5e1a9edde2be6a88b6adef22211fea. Therefore
the old504d report is not used for packaging: the supplied report checks actual
dfa source. Freeze this source; do not chase later main or checkout evidence ref.

included-test-revisions.json records36 ancestral reviewed PR heads, including
launcher359/364/368, signing355, resize330, browser384/385/386, waveforms388/372,
lower-free383, BPM/Shift387, Command-T375, fixture381 and incidental runtime351.
Existing344/348/350 and borrowed-PCM kernel296 are included provenance, not claims
of completed native acceptance. Exclusions are explicit in cohort-state.json:
349/352/353/373/389/376/377/378/335 and full sampler/native goals are outside
this pin and do not gate it. Subsequent main merges (including373) are not
absorbed and do not change this frozen source or qualification. No historical alpha format migration/conversion is required;
preserve current-format integrity and all user files.

Coordinator dispatches ONLY existing serial verifier
01a149f8-d4e8-7c91-82b9-5bdea69929a0. Read-only preparation already completed (Pulse2745note20453); do not repeat it
as a new broad gate. Its no-Hex/no-heavy-build audit was17:21UTC and is historical.
No cloud-triggered local job. Re-read current app/process state before build. Check its
current availability, no competing compiler/launcher/target owner and sufficient
disk. Use the existing managed Mac toolchain and a clean exact-source checkout.
Do not overwrite unpublished source; coordinate checkout ownership first.
Pinned dfa delivery/local-CI modules and their launch/progress/packaging test files
were compared with the native-preparation1879 checkout and are unchanged. Existing
API inspection remains applicable; this is not a new native runtime PASS.
Original full20 report must be clean, unchanged, stale=false; all required step
commands must match the pinned scripts/local-ci.py. A changed source does not
inherit this result. No new broad Mac full20 solely to repeat portable checks.

## Phase A: no app mutation or user quit required

1. Fresh READ-ONLY audit: exact HEAD/tree/clean state, content/report identity,
   existing stable-app receipt/source/executable hash and current process state.
   Earlier1879e018 audit is historical and says nothing about today's process.
   Hex/Ableton may remain open. Do not launch/quit/replace the app or access user
   media, profile, TCC or keychain. Do not infer installed source from repo HEAD.
2. Optional optimized artifact-only build via the documented existing helper:

       python3 <verified-extracted-evidence>/artifacts/combined-ui-delivery/prepare-optimized-artifact.py \
         --source dfa21f5aed2186781e6aa985a053f85d9e51b75d \
         --candidate dfa21f5aed2186781e6aa985a053f85d9e51b75d \
         --ci-report <verified-extracted-evidence>/artifacts/local-ci/20261017T172516Z-877e855e/summary.json

   Run from the clean pinned Mac checkout. This small orchestration script calls
   scripts/hex-test-build.py optimized_artifact(runner,adopt=False), preserves
   repository target/source/disk guards, copies while holding ownership and
   records hash/source/report/ownership under ignored artifacts/local-ci/. It
   does NOT assemble/sign/install/activate/recover/launch an app or touch keychain.
   Cloud review covered syntax and source/API inspection, not native execution.
   The helper bytes match the previously transported/native-reviewed plan; no
   silent helper changes. Preserve immutable isolated checkout throughout.
   Preflight must REQUIRE a valid READY owner (as in the last read-only audit).
   Unknown/pending/malformed ownership is a bounded blocker: do not invoke the
   helper in that state, no automatic adoption,
   target deletion or bypass with raw Cargo. Report actual owner/error first.
3. artifact-only.json is written BEFORE guard exit: it alone is not success.
   Accept the artifact only after overall process exit0, ready release ownership,
   actual copied executable hash/source verification and final ownership source
   equal to pinned dfa. The initial --source check precedes the guard; use an
   immutable isolated checkout and verify final ownership/source, not only that
   initial check. Guard may selectively clean owned release products and write
   ready ownership. IMPORTANT API detail: existing guarded_release permits a valid
   pending marker to enter a cleanup/handoff path; do not assume it inherently
   refuses pending. The coordinator preflight must stop on pending/unknown/
   malformed markers BEFORE helper invocation, preserving the requested fail-closed
   policy with no helper/source changes or automatic recovery/adoption.
   Return command/exit, actual source/tree/digest, original-report hash, release
   log and artifact-only JSON, executable hash and release ownership completion,
   current installed/process audit and unchanged stable-app evidence. Report
   failure truthfully and stop; no automatic retry with source changes.

## Phase B: later, separately coordinated installation and user acceptance

Phase A grants NO installer replacement or app launch. Only after fresh app-state
readback, coordinated user normal save/quit and serial dispatch, use supported:

    sh scripts/bundle-macos.sh \
      --ci-report <verified-extracted-evidence>/artifacts/local-ci/20261017T172516Z-877e855e/summary.json \
      --candidate dfa21f5aed2186781e6aa985a053f85d9e51b75d \
      --included <verified-extracted-evidence>/artifacts/combined-ui-delivery/included-test-revisions.json \
      --checklist <verified-extracted-evidence>/artifacts/combined-ui-delivery/USER-TEST.md

This command builds AND INSTALLS; it is not a dry run. Retain stable
org.portalsurfer.hex.dev, /Users/portalsurfer/dev/hex/artifacts/hex.app,
Contents/MacOS/hex, configured certificate4EDF56A7ADD0B4786C2EEE23A50D61620BCE7E4E
and teamDKTKQ8U5T8. No forcequit or revision-named app. Preserve signing/seal/
receipt/source/executable hashes and process guards. Keychain signing uses the
existing configured identity only under that later dispatch; no policy changes.

After successful authorized delivery the user can use ./launch --open for the
installed build. Plain ./launch fetches/builds latest main WITHOUT tests and may
produce a different source; --test explicitly opts in. Preserve accepted behavior.
Disk activation does not establish loaded/native acceptance: user performs finite
USER-TEST.md browser/waveform/Shift/lower-handle/resize/Command-T cases and reports
actual running source, settings, capture and listening results. User spinner
signoff stands; no repeated broad spinner gate.

Actual native signing fixture results from8c036790 are historical (Pulse2745
note19740); packaging scripts are unchanged in this cohort, but this report is
not a newly executed native fixture. Real sample WAV access/audible preview across
normal IDENTICAL-executable --open relaunch remains a separate user-owned task,
not inferred from signatures or UI source completion. No TCC reset, blanket
permissions, profile/media changes, unsaved loss or automatic app actions.
