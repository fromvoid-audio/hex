# Combined UI cohort: finite user checks

Source dfa21f5aed2186781e6aa985a053f85d9e51b75d; tree622dcee50829b2beaf503bc6ff0e92a18003e103.
Included/excluded revisions and cloud evidence are supplied alongside this file.

Use a disposable current-format project, original sample copies and an unaffected
control. Alpha history migration is not required; no conversion/deletion of files.

1. Browser: stable audition waveform/hover and progress; click early/middle/late
   waveform positions for audible bounded seek/progress; double-click sample
   results without accidental track insertion; deliberate drag insertion works.
2. Ordinary waveform edges: affected/control stereo samples, raw/Warp on/off and
   processed-Warp-off, crop/partial/loop sources, wide/close zoom and offscreen
   reveal. Continuous left/right resize retains visible peaks and unchanged
   interior landmarks instead of disappearing or redistributing them.
3. Both lower handles: free motion by default, Command snap opt-in, stationary
   modifier press/release matches final release. Correct crop/fade preview and
   one Undo/Redo; no timing/selection regression. Record bounded held-drag capture.
4. Sample BPM/Shift: source60/project120 two-second->one-second example, fractional
   and invalid input/cancel, both Shift edges, live remap before release including
   stationary Shift, trimmed/looped/marker/autoscroll cases. Escape/focus/stale
   cancel restores preview without history; release gives one Undo/Redo. Playback,
   seek/export duration, pitch/attacks/loop seams need user listening evidence.
5. Track sizing: shared header-left width and individual bottom heights, existing
   minima/maxima, empty/pinned main, controls/sends, row/lane/ruler/overview/frame
   alignment, mixed-height scroll/keyboard, final outside release and Escape/
   focus/window cancellation. Resizing itself adds no project dirty/Undo change.
6. Command-T: editor-focused new track through existing action; text/numeric/search
   focus must preserve normal input and not unexpectedly create tracks. Record
   selection/scroll result and existing Undo behavior; no shortcut redesign.

Prior spinner user acceptance stands; no repeated broad spinner gate. Native
signing fixture, installed/running source and physical waveform/browser/resize/
shortcut acceptance remain pending until actual evidence. Sample-folder permission
and audible real WAV preview across normal identical-executable --open relaunch
remain a distinct user-driven acceptance; no TCC reset/broad permission/keychain
or profile changes, no permission-persistence claim from signing alone.


Incidental merged PR351 runtime is included: native sine/FM4/Operator now consume project tuning in Arrangement/Session/keyboard/export. PR352 editor/audition and353 MTS are NOT included. On a disposable current-format project, record ordinary neutral-tuning playback and, if an existing non-neutral current-format fixture is available, held/released notes, seek/export and pitch/listening outcome. No fixture conversion, profile/media changes or full unfinished tuning/sampler acceptance is implied. Real-time deadlines and sonic parity are not established by Linux checks.
