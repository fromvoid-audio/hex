from pathlib import Path
p=Path('crates/hex-engine/src/audio_preparation/arrangement_clips/root.rs');s=p.read_text();s=s.replace('#[derive(Default)]\npub(super) struct ArrangementRootAssembly', '''/// Disposal routing only; actual fields/receipts remain storage authority.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum ContextLifecycle {
    #[default]
    None,
    LegacyProducer,
    CompilerOwned,
    RetirementPending,
    RetirementComplete,
}
#[derive(Default)]
pub(super) struct ArrangementRootAssembly''');s=s.replace('    contexts: Option<OwnedShared<SharedAnalyticContextTable>>,','    contexts: Option<OwnedShared<SharedAnalyticContextTable>>,\n    context_lifecycle: ContextLifecycle,',1);s=s.replace('    pub(super) panic_after_metadata_take: bool,','    pub(super) panic_after_metadata_take: bool,\n    #[cfg(test)]\n    pub(super) panic_after_context_take: bool,');s=s.replace('            && !self.metadata_drop_pending\n            && self.feed.has_no_owned_storage()', '            && !self.metadata_drop_pending\n            && self.context_lifecycle != ContextLifecycle::RetirementPending\n            && self.feed.has_no_owned_storage()',1);s=s.replace('self.project.is_none() && self.contexts.is_none() && !self.metadata_drop_pending','self.project.is_none()\n            && self.contexts.is_none()\n            && !self.metadata_drop_pending\n            && self.context_lifecycle == ContextLifecycle::None',1);needle='    pub(super) fn compiler_destinations(\n';s=s.replace(needle,'''    pub(super) fn begin_compiler_context(&mut self) -> Result<(), AudioStorageError> {
        if !self.compiler_destinations_vacant() {
            return Err(AudioStorageError::SourceMismatch);
        }
        self.context_lifecycle = ContextLifecycle::CompilerOwned;
        Ok(())
    }
    pub(super) fn legacy_context_at<'a>(
        &'a self, external: Option<&'a Project>,
    ) -> Option<&'a OwnedShared<SharedAnalyticContextTable>> {
        if self.context_lifecycle == ContextLifecycle::CompilerOwned { None }
        else { self.context_at(external) }
    }
    pub(super) fn clear_context_retirement(&mut self) -> Result<(), AudioStorageError> {
        if self.context_lifecycle == ContextLifecycle::RetirementPending {
            return Err(AudioStorageError::UnknownStorage);
        }
        if self.project.is_some() || self.contexts.is_some()
            || self.context_lifecycle == ContextLifecycle::CompilerOwned {
            return Err(AudioStorageError::Capacity);
        }
        if self.context_lifecycle == ContextLifecycle::RetirementComplete {
            self.context_lifecycle = ContextLifecycle::None;
        }
        Ok(())
    }
'''+needle);s=s.replace('if self.metadata_drop_pending {\n            return Err(AudioStorageError::UnknownStorage);','if self.metadata_drop_pending\n            || self.context_lifecycle == ContextLifecycle::RetirementPending\n        {\n            return Err(AudioStorageError::UnknownStorage);');s=s.replace('        shared.commit_arrangement_transfer(&mut self.contexts);','        shared.commit_arrangement_transfer(&mut self.contexts);\n        self.context_lifecycle = ContextLifecycle::LegacyProducer;');s=s.replace('''        if self.context_at(None).is_some() {
            shared.preflight_arrangement_restore()?;
        }''','''        match self.context_lifecycle {
            ContextLifecycle::CompilerOwned => {
                if let Some(context) = self.context_at(None) {
                    context.refuse_opaque_control_drop()?;
                }
            }
            ContextLifecycle::LegacyProducer => shared.preflight_arrangement_restore()?,
            ContextLifecycle::None | ContextLifecycle::RetirementComplete => {
                if self.context_at(None).is_some() {
                    return Err(AudioStorageError::SourceMismatch);
                }
            }
            ContextLifecycle::RetirementPending => return Err(AudioStorageError::UnknownStorage),
        }''');s=s.replace('        shared.restore_arrangement(&mut self.contexts);','''        if self.context_lifecycle == ContextLifecycle::LegacyProducer {
            shared.restore_arrangement(&mut self.contexts);
            self.context_lifecycle = ContextLifecycle::None;
        }''');s=s.replace('''        self.metadata_drop_pending
            || self.tempo_map.is_some()''','''        self.metadata_drop_pending
            || matches!(self.context_lifecycle, ContextLifecycle::CompilerOwned | ContextLifecycle::RetirementPending)
            || self.tempo_map.is_some()''');s=s.replace('''            || self.contexts.is_some()
        {
            return Err(AudioStorageError::Capacity);
        }
        if self
            .topology''','''            || (self.contexts.is_some() && self.context_lifecycle != ContextLifecycle::CompilerOwned)
        {
            return Err(AudioStorageError::Capacity);
        }
        if self.context_lifecycle == ContextLifecycle::CompilerOwned {
            if let Some(context) = &self.contexts {
                context.refuse_opaque_control_drop()?;
            }
            self.context_lifecycle = ContextLifecycle::RetirementPending;
            drop(self.contexts.take());
            #[cfg(test)]
            assert!(!self.panic_after_context_take, "persistent Arrangement context drop panic");
            self.context_lifecycle = ContextLifecycle::RetirementComplete;
            return Ok(());
        }
        if self
            .topology''');s=s.replace('            contexts: _,\n            tempo_map,','            contexts: _,\n            context_lifecycle: _,\n            tempo_map,');s=s.replace('                panic_after_metadata_take: _,','                panic_after_metadata_take: _,\n            #[cfg(test)]\n                panic_after_context_take: _,');s=s.replace('''        let view = self.view_at(external)?;
        l.vec(tracks)?;''','''        let view = self.view_at(external)?;
        if self.context_lifecycle == ContextLifecycle::CompilerOwned {
            if let Some(context) = self.context_at(external) {
                crate::shared_analytic::resource_storage::visit_table_contents(context, l)?;
            }
        }
        l.vec(tracks)?;''');p.write_text(s)
p=Path('crates/hex-engine/src/audio_preparation/arrangement_clips/sampler_compile.rs');s=p.read_text().replace('''        let result = transforms.compile_transaction(|| {
            let (destination, contexts)''','''        let result = transforms.compile_transaction(|| {
            self.root.begin_compiler_context().map_err(|_| crate::Invalid("sampler context destination is occupied"))?;
            let (destination, contexts)''');p.write_text(s)
p=Path('crates/hex-engine/src/audio_preparation/arrangement_clips.rs');s=p.read_text().replace('''        !matches!(self.phase, Phase::Vacant | Phase::Complete) || self.root.has_metadata_disposal()''','''        !matches!(self.phase, Phase::Vacant | Phase::Complete)
            || self.preview.has_next() || self.returns.has_next() || self.tracks.has_next()
            || self.root.has_metadata_disposal()''');s=s.replace('''        if self.phase == Phase::Vacant {
            return Ok(());
        }
        if self.phase != Phase::Complete''','''        if self.phase == Phase::Vacant && !self.has_next() {
            self.root.clear_context_retirement()?;
            self.preview.clear_disposed()?;
            self.returns.clear_disposed()?;
            self.tracks.clear_disposed()?;
            return Ok(());
        }
        if self.phase != Phase::Complete''');s=s.replace('''        self.preview.clear_disposed()?;
        self.returns.clear_disposed()?;
        self.tracks.clear_disposed()?;
        self.rows.clear();''','''        self.root.clear_context_retirement()?;
        self.preview.clear_disposed()?;
        self.returns.clear_disposed()?;
        self.tracks.clear_disposed()?;
        self.rows.clear();''');s=s.replace('        Ok(root.context_at(project))','        Ok(root.legacy_context_at(project))');p.write_text(s)
