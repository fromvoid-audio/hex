# Root-only finite changed-behavior checks
No app/backend build/install/launch/quit or data/permissions changes.
Use exact339d5a4227888ba4a75dcd229317b5eb0325f594, normal native stack and isolated legitimate target. Preserve original receipts and source identity.
1. `cargo test -p hex-session --test track_gain_gesture verified_streaming_refuses_track_gain_begin_without_preview_or_history_change --locked -- --exact` : exactly1new actor test. Full source-specific actor8 cloud pass; no old receipt relabel.
2. `cargo test -p hex-ui --features ui-test-support --lib editor::track_gain::tests --locked` : exactly4 own header tests; now bounded constructor, retained disposable browser/recent/theme paths BEFORE workers, assert owned samples/places. Geometry audio/MIDI narrow/expanded, real resident actor drag/cancel/text/automation, streaming +/-.
3. `cargo test -p hex-ui --features ui-test-support --lib header_volume_begin_obeys_recording_fence_even_before_next_render --locked` : exactly1 own bounded recording admission race.
Require counts/nozero-match/noignore and actual original status/logs/source/tree/digest. No broad unchanged callback/widget/native suites solely for this repair. Old original82nativeUI5 withdrawn; these NEW source-specific selector boundaries are ready for coordinator review/dispatch, no native PASS claimed.
Physical optimized held-drag audibility/continuity/input-to-applied latency, user controls/Escape/Undo/save/reopen remain docs/track-header-volume.md; actual VerifiedStreaming held preview remains2792/398, not this source.
