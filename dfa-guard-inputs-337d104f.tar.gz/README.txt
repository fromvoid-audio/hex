READ-ONLY SOURCE-GUARD COMPARISON; NOT SOURCE OR BUILD EVIDENCE.
Source dfa21f5aed2186781e6aa985a053f85d9e51b75d, tree622dcee50829b2beaf503bc6ff0e92a18003e103.
All1821 selected tracked paths and materialized bytes match pinned Git blobs; no untracked inputs.
Only difference: launch actual permissions0700, Git canonical100755. Guard serializes actual st_mode&0111 as decimal ASCII64 versus canonical73.
Actual guard remains337d104fd8642271d550a32cc9765fbc3033b6e9fc6b179f4459e3463f55e865.
Independent Git blob+canonical-mode calculation equals Mac748a806e56ff162e468c3764493ea0306e6101205c2e777bc78f55740be6db1f.
Algorithm per sorted raw path: 8byte big-endian path-byte length, path bytes, file-NUL, raw file bytes, decimal ASCII execute-mask. Symlink uses symlink-NUL+raw link-target bytes instead.
No chmod/normalization/report rewrite/source fix/test/build occurred. Original16ad39aa evidence is unchanged. Never checkout/build/merge this evidence-only ref.
The cause of historical0700 creation is not inferred. No permission/revalidation repair is authorized by this comparison.
