"""Read-only pinned-source guard input comparison; never normalizes permissions."""
from pathlib import Path
import base64
import hashlib
import importlib.util
import io
import json
import os
import stat
import subprocess
import sys

root=Path.cwd()
out=root/'artifacts/dfa-source-input-comparison'
out.mkdir(exist_ok=True)
source='dfa21f5aed2186781e6aa985a053f85d9e51b75d'
def git(*args):
    return subprocess.check_output(['git',*args])
assert git('rev-parse','HEAD').decode().strip()==source
assert git('status','--porcelain=v1','--untracked-files=all')==b''
paths=sorted(p for p in git('ls-files','--cached','--others','--exclude-standard','-z').split(b'\0') if p)
tree={}
for record in git('ls-tree','-r','-z',source).split(b'\0'):
    if record:
        meta,path=record.split(b'\t',1)
        mode,kind,oid=meta.split()
        tree[path]=(mode,kind,oid)
assert paths==sorted(tree)
objects=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],input=b''.join(tree[p][2]+b'\n' for p in paths)))
actual=hashlib.sha256()
canonical=hashlib.sha256()
rows=[]
for order,relative in enumerate(paths):
    mode,kind,oid=tree[relative]
    header=objects.readline().split()
    assert header[0]==oid and header[1]==b'blob'
    git_bytes=objects.read(int(header[2]));assert objects.read(1)==b'\n'
    path=root/os.fsdecode(relative)
    metadata=path.lstat()
    row=dict(order=order,path=os.fsdecode(relative),path_bytes_base64=base64.b64encode(relative).decode(),
        tracked_mode=mode.decode(),git_blob=oid.decode(),lstat_mode_octal=oct(metadata.st_mode))
    for d in [actual,canonical]:
        d.update(len(relative).to_bytes(8,'big'));d.update(relative)
    if stat.S_ISLNK(metadata.st_mode):
        content=os.fsencode(os.readlink(path));row.update(kind='symlink',symlink_target=os.readlink(path))
        assert mode==b'120000'
        actual.update(b'symlink\0');actual.update(content)
        canonical.update(b'symlink\0');canonical.update(git_bytes)
    else:
        assert stat.S_ISREG(metadata.st_mode) and mode in (b'100644',b'100755')
        content=path.read_bytes();mask=metadata.st_mode&0o111
        git_mask=0o111 if mode==b'100755' else 0
        row.update(kind='file',execute_mask=mask,execute_mask_octal=oct(mask),
            guard_execute_ascii=str(mask),git_canonical_execute_mask=git_mask,
            git_canonical_execute_ascii=str(git_mask))
        actual.update(b'file\0');actual.update(content);actual.update(str(mask).encode('ascii'))
        canonical.update(b'file\0');canonical.update(git_bytes);canonical.update(str(git_mask).encode('ascii'))
    row.update(bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),
        git_blob_bytes=len(git_bytes),git_blob_sha256=hashlib.sha256(git_bytes).hexdigest(),
        materialized_bytes_match_git_blob=content==git_bytes)
    assert row['materialized_bytes_match_git_blob']
    rows.append(row)
assert objects.read()==b''
spec=importlib.util.spec_from_file_location('comparison_ci',root/'scripts/local-ci.py')
ci=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ci;spec.loader.exec_module(ci)
runner=ci.LocalCiRunner(root)
assert runner._capture_repository_state('comparison_tree')
snapshot=runner.summary['comparison_tree']
assert actual.hexdigest()==snapshot['content_sha256']=='337d104fd8642271d550a32cc9765fbc3033b6e9fc6b179f4459e3463f55e865'
assert canonical.hexdigest()=='748a806e56ff162e468c3764493ea0306e6101205c2e777bc78f55740be6db1f'
assert snapshot['commit']==source and not snapshot['dirty']
report=root/'artifacts/local-ci/20261017T172516Z-877e855e/summary.json'
assert hashlib.sha256(report.read_bytes()).hexdigest()=='1d7a66f05763bfd2234a7af4cd007cccc4514e4973046a780e0486f3c658f91e'
differences=[r for r in rows if r.get('execute_mask')!=r.get('git_canonical_execute_mask')]
proof=dict(source=source,tree=git('rev-parse','HEAD^{tree}').decode().strip(),
    inputs=len(rows),selection='sorted raw bytes: git ls-files --cached --others --exclude-standard -z',
    selected_paths_equal_recursive_pinned_git_tree=True,all_materialized_bytes_equal_git_blobs=True,
    untracked_guard_inputs=0,actual_guard_snapshot=snapshot,
    actual_algorithm_recomputed=actual.hexdigest(),canonical_git_blob_and_mode_fingerprint=canonical.hexdigest(),
    mac_reported_digest=canonical.hexdigest(),execute_mask_differences=differences,
    original_full_report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),
    guard_source_sha256=hashlib.sha256((root/'scripts/local-ci.py').read_bytes()).hexdigest(),
    source_or_permissions_modified=False,report_modified=False,tests_or_builds_run=False)
(out/'cloud-inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'comparison-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert git('status','--porcelain=v1','--untracked-files=all')==b''
print(json.dumps(proof,indent=2))
