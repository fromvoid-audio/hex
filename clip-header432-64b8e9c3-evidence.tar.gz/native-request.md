# Coordinator-only optional changed title-color check
Source 64b8e9c30da9137af1636738069fcf60aefb4384
Tree 41011785ca10b42f297ead01166518cf981ed683
No app/build-install/launch/quit/backend/user input operations here.
Default native stack, exact bounded selector:
cargo test -p hex-ui --features ui-test-support --locked --lib editor::clip_name::color_tests::clip_titles_paint_inherited_flavor_colors_through_selection_and_recolor -- --exact --nocapture
Expect ONE positive test, zero ignored/failures, EIGHT `title painted clip=` diagnostics: AudioMuted/MIDIAccent x selected/unselected xCyan/Rose; real worker recolor, actual completed scene background, preserved geometry/selection outline, Command-R/input/Escape and unchanged clip payloads. Private RAII browser/sample/recent/theme paths are created before constructor workers start and actual browser startup paths asserted. Capture exact source/tree/default stack/exit/counts/raw log+SHA. No old rename suite/native FULL20 repeat requested.
Scene proof is not native glyph/framebuffer/physical/listening acceptance. Root eventual optimized visual checklist: compare readable colored titles audio/MIDI/flavor/selection/recolor; header/body grabs+rename focus, independent all4 selection edges with429, and header-only height when431 is integrated. Present source tests current44px minimum only; future tiny-row composition remains OPEN. Console production already inherited correct resolver; no new Console source or actual Console scene test claimed.
Sole merger owns final prospective-tree qualification/review/merge; Pulse stays InProgress until merged. Never checkout/build/merge evidence refs.
