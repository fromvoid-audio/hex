#!/usr/bin/env python3
"""Source guard for app text routing, font selection, and bundle naming."""
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parent.parent
errors = []
# Text children must be normalized centrally; other children are view elements.
widgets = (
    'div(', 'Self::button(', 'Self::with_tooltip(', 'Self::ruler(', 'Self::empty_grid(',
    'self.track(', 'self.mixer_strip(', 'self.mixer(', 'self.transport(', 'self.controller_input_row(', 'self.clip_detail_view(',
    'self.browser(', 'self.inspector(', 'self.status_bar(', 'theme::text(', 'crate::theme::text(',
    'self.icon(', 'self.control_icon(', 'self.control_icon_description(',
    'self.arrangement(', 'self.ruler(', 'self.clip_view(',
    # Clip name components normalize labels or render a native text-input entity.
    'self.clip_name_label(', 'self.clip_name_header(', 'self.track_name_label(', 'edit.input.clone())',
    'button(', 'waveform_view(', 'clip_area)', 'header)', 'bars)', 'cells)',
    'content)', 'rows);', 'track_name_view)', 'track_controls)',
    # Compact Operator composition components keep labels routed through
    # `theme::text` at their component boundary.
    'detail_caption(', 'detail_field(', 'upper_display)', 'envelope_fields)',
    # Companion inspector children are typed controls or already-themed rows.
    'harmonics::tools(', 'restart)', 'oscillator_velocity)', 'quantize)',
    'row.child(', 'loop_cell)',
    'tools)', 'oscillator_fields)', 'link)', 'enabled)', 'hex_widgets::device_segment(',
    'harmonic_range_control)', 'harmonic_repeat_control)', 'harmonic_tools)',
    'view.device_panel.operator_harmonics[&key].entity.clone())',
    'operator_row(', 'operator_label(', 'page_tab(', 'shell)', 'page_tabs)', 'detail)',
    'level)', 'primary)', 'multiplier)', 'fixed_control)', 'section_title(', 'page_tabs(', 'control)',
    'preview::render(', 'fine)', 'toggle(', 'heading)', 'left)', 'select_row)',
    'routing_link(', 'selector(',
    'dials)', 'icon)', 'toggle.entity.clone())', 'selector.entity.clone())',
    'waveform)', 'waveform_preview)', 'phase)', 'velocity)', 'feedback)', 'cycle.unwrap_or_else(', 'graph)',
    'fields)', 'labeled_field(', 'carrier)', 'preset)', 'compact_control(', 'compact_control_with_codec(',
    'routing_header_cell(', 'routing_cell(',
    # Algorithm diagrams have no text; global controls normalize captions.
    'behavior.flex_1()', 'algorithms::selector(', 'global::controls(', 'global::expression_routing(', 'diagram(', 'control.w_full())', 'field)', 'line)',
    'hex_widgets::curve_plot(',
    # Output meter labels are routed through theme::text in the component.
    'crate::output_meter::render(',
    # Generic device layout components accept already-themed child elements.
    'hex_widgets::device_display(', 'hex_widgets::device_body(',
    'hex_widgets::device_section(', 'hex_widgets::device_layout(',
    'hex_widgets::device_rail(', 'hex_widgets::device_grouped_row(',
    'hex_widgets::device_split(',
    # Shared production composition slots are already-bound native view elements.
    'compact_rail(', 'dense_rail(', 'device_compact_section(', 'plot(', 'range)', 'footer)', 'rail)',
    'first)', 'second)', 'preview)', 'tabs)', 'rails)',
    'hex_widgets::device_divider(', 'hex_widgets::device_identity_marker(',
    'main)', 'mixer)', 'lane)', 'row)', 'rows)', 'clips)', 'strips)', 'track_labels)',
    'self.session_grid(', 'workspace)', 'self.session_toolbar(', 'self.session_icon(',
    'self.browser_view(', 'workspace_content.', 'self.browser_icon(', 'channel_controls)',
    # Split browser components normalize every caption at their boundary.
    'self.browser_tag_selector(', 'browser_caption(', 'browser_heading(',
    'picker_label(', 'picker_heading(',
    # Audition row controls normalize labels; miniature waveform contains no text.
    'self.browser_audition_row(', 'mini_waveform(',
    'browser_pending(', 'browser_divider(', 'group)', 'groups)', 'tags.child(',
    'editor)', 'sidebar)', 'panel.w_full(', 'self.browser_sidebar_resize(',
    'super::super::waveform::waveform_summary_view(',
    'self.browser_sections(', 'self.browser_places(', 'self.browser_instrument_row(',
    # Sample source filters route labels through theme::text.
    'self.sample_filters(', 'filters)',

    'folder_dialog)', 'self.browser.search.clone())', 'rows.flex_1()',
    'resize)', 'panel)', 'div().w(px(4.0))', 'canvas(', 'BrowserSearchElement',
    'scene_rows)', 'cell)', 'session_scenes_header()', 'scene_column)',
    'musical_control_row(', 'musical_control_label(', 'super::musical_audio_controls::view(',
    # Beats controls compose themed buttons/labels, not direct text children.
    'beats_controls(', 'choices)',
    'super::musical_audio_controls::warp_header(', 'sample_bpm::field(',
    'super::waveform::prepared_waveform_view_cached(',
    'super::waveform::timeline_waveform_view_cached(',
    'source_adjust_button(', 'gain_adjust_button(',
    'field_row(', 'loop_row(', 'time_ruler(', 'source_marker(', 'source_column)',
    'source_row(', 'details)', 'waveform_panel)', 'canvas_region)', 'roll_area)',
    'status_slot(', 'super::waveform::waveform_view_cached(',
    'super::waveform::waveform_source_segment_view_cached(',
    'super::waveform::waveform_source_segment_gain_view_cached(',
    'toolbar)', 'control)', 'element)', 'controls)', 'clip_view)', 'step_button(', 'control_button(',
    'parameter_control(', 'rendered)', 'add_button)', 'chain)', 'render_add_menu(',
    'mode_control)', 'lane_button(', 'left)', 'compact_selector(', 'graph_entity',
    'section_heading(', 'unavailable(',
    'menu_message(', 'action_button(', 'action_button_sized(', 'text_action_button(', 'entity.clone())', 'control.entity.clone())',
    'super::waveform::waveform_source_segment_view(', 'self.mixer_strip(', 'self.track_volume(', 'detail)', 'ruler_label)',
    'self.title_bar()', 'self.title_bar(cx)', 'self.theme_button(', 'card)',
    'header::title_bar(', 'header::loading_toolbar(',
    'lights)', 'crate::build_info::label()', 'crate::build_info::editor_label()', 'version_label()', 'debug_button()',
    'super::loop_rail::view(', 'render_device_card_target(', 'render_device_end_target(',
    # Device preset header actions reuse themed compact action buttons.
    'super::device_preset::actions(', 'super::device_panel::action_button(',
    'super::super::device_preset::actions(',
    'device_drag_title(', 'render_return_drop_target(', 'uniform_list(',
    'loop_grid_layer(',
    # Track sizing composes non-text pointer handles and capture listeners.
    'self.track_resize_events(', 'self.track_width_resize_handle(',
    'self.return_send_menu(', 'send_adjust_button(', 'super::device_panel::return_send_numeric_control(', 'upper.flex_1().min_h_0()',
    'returns)', 'add)', 'return_button(', 'render_return_effect(',
    'render_return_add_menu(',
    'control(', 'spectrum_toggle(', 'audition_toggle(', 'selected_value)', 'input_heading)', 'output_heading)', 'polarity)',
    'channel)', 'dial)', 'mono)', 'bass)', 'cutoff_row)', 'audition)', 'input)',
    'output)', 'gain)', 'balance)', 'cutoff)', 'mute_dc)', 'mute)', 'dc)',
    # Saturator composition uses typed shared controls and a normalized plot;
    # its axis/error text is routed through theme::text at the panel boundary.
    'plot)', 'plot.id(', 'self.project_spectrum_panel(', 'self.project_spectrum_pointer_events(', 'chooser)', 'drive)', 'wet)',
    # Compressor composition uses shared typed numeric controls and normalized plot.
    'ratio)', 'attack)', 'release)', 'field(',
    # Gate composition contains already-themed compact dial child controls.
    'gate_column(',
    # Device-chain navigator is a typed view component; labels use theme::text.
    'super::device_panel::bottom_bar(', 'overview)',
    # Shared host meter strip supplies lowercase tooltip text through theme::text.
    'gain_meters::render(', 'super::gain_meters::render(',
    # Typed routing/recording components normalize their labels at the boundary.
    'self.routing_controls(', 'gain_row(', 'sources)', 'super::waveform::button(',
    # Audio-event editor components keep their text at the themed boundary.
    'super::audio_event_editor::view(', 'waveform::button(',
    'waveform::waveform_source_segment_gain_view_cached(', 'waveform::waveform_view_cached(',
    'toolbar)', 'body)',
    'binding.entity.clone())', 'super::super::gain_recording::controls(',
    # Fade pointer capture is a typed canvas listener with no rendered text.
    'self.fade_pointer_events(',
    # Tuning components normalize labels at their theme::text boundary.
    'tuning_section(', 'self.tuning_control(', 'self.tuning_library_panel(', 'self.tuning_mts_controls(',
    'pitch)', 'palette)', 'plots::lattice(', 'tuning_name_input.clone())',
    'tuning_nodes)', 'tuning_slots)', 'tuning_reference)', 'settings)', 'right)',
)
for path in (ROOT / 'crates/hex-ui/src').rglob('*.rs'):
    source = path.read_text()
    for match in re.finditer(r'\.child\(\s*', source):
        suffix = source[match.end():]
        # These two typed error components share fragment-normalized text. Keep
        # the exception local: arbitrary self.display_text() is not a text bypass.
        typed_error = (
            path.relative_to(ROOT).as_posix() == 'crates/hex-ui/src/editor/render.rs'
            and suffix.startswith('error.display_text())')
        ) or (
            path.relative_to(ROOT).as_posix() == 'crates/hex-ui/src/editor/display_error.rs'
            and suffix.startswith('self.display_text())')
        )
        if not suffix.startswith(widgets) and not typed_error:
            line = source.count('\n', 0, match.start()) + 1
            errors.append(f'{path.relative_to(ROOT)}:{line}: route text through theme::text or add an explicit view component')
    for match in re.finditer(r'\.font_family\(([^)]*)\)', source):
        if match.group(1).strip() != 'theme::FONT_FAMILY':
            errors.append(f'{path.relative_to(ROOT)}: use the required theme font')
# A generic lowercase pass over either error surface would corrupt source paths.
error_status = (ROOT / 'crates/hex-ui/src/editor/render.rs').read_text()
error_tooltip = (ROOT / 'crates/hex-ui/src/editor/display_error.rs').read_text()
if '.child(error.display_text())' not in error_status or 'ErrorTooltip(message.clone())' not in error_status:
    errors.append('editor/render.rs: status and tooltip must use typed source-preserving error text')
if '.child(self.display_text())' not in error_tooltip or 'self.0.display_text()' not in error_tooltip:
    errors.append('editor/display_error.rs: error tooltip must share source-preserving status text')
for root_view in ('app.rs', 'editor/render.rs'):
    app = (ROOT / 'crates/hex-ui/src' / root_view).read_text()
    if '.font_family(theme::FONT_FAMILY)' not in app:
        errors.append(f'{root_view}: root UI must inherit Ioskeley Mono')
# The shared compact title row reserves balanced space for native controls;
# one EditorView renders both pending-backend startup and the loaded editor.
# The generated demo retains its separate toolbar with the same leading inset.
header = (ROOT / 'crates/hex-ui/src/editor/header.rs').read_text()
if 'crate::build_info::HEADER_INSET.max(theme::TITLEBAR_LEADING_INSET)' not in header or '.px(px(' not in header:
    errors.append('editor/header.rs: center title with balanced native-control insets')
for top_row in ('editor/render.rs',):
    source = (ROOT / 'crates/hex-ui/src' / top_row).read_text()
    if 'header::title_bar' not in source and 'self.title_bar(cx)' not in source and 'self.title_bar()' not in source:
        errors.append(f'{top_row}: use the shared title row')
demo_toolbar = (ROOT / 'crates/hex-ui/src/layout/transport.rs').read_text()
if '.pl(px(theme::TITLEBAR_LEADING_INSET))' not in demo_toolbar:
    errors.append('layout/transport.rs: reserve the shared native titlebar leading inset')
for key in ('CFBundleName', 'CFBundleDisplayName'):
    source = (ROOT / 'scripts/hex-test-build.py').read_text()
    if f'"{key}": "hex"' not in source:
        errors.append(f'{key} must be lowercase hex')
if errors:
    print('\n'.join(errors), file=sys.stderr)
    sys.exit(1)
print('UI style passed: centralized lowercase text, Ioskeley Mono, lowercase bundle name')
