import builtins,runpy,sys
original=builtins.__import__
def no_tomllib(name,*args,**kwargs):
    if name in ('tomllib','tomli'):
        raise ModuleNotFoundError('tomllib is unavailable on Python 3.9', name=name)
    return original(name,*args,**kwargs)
builtins.__import__=no_tomllib
entry=sys.argv[1]
sys.argv=[entry,'--help']
runpy.run_path(entry,run_name='__main__')
