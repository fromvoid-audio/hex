# finite serial native request, coordinator dispatch only

Source owner15bf3b6c/treec29e3c99. After merger integration, use its actual immutable candidate and exact checks; do not relabel this owner tree as integrated. No app build/install/launch/quit or user app inputs authorized by these commands.

With configured toolchain/private legitimate target and bounded test directory source:

cargo test -p hex-ui --features ui-test-support --lib editor::changelog --locked

Expected EXACT5:3 ui_tests and2 parsers,0ignored. Constructors retain disposable sample/preferences directories BEFORE browser workers start (new_for_test_with_browser_directory), no ambient home/discovery. Covers actual button next to Log at960width, click reader+Escape editor focus, long scroll event with offset change and background request guards, actual embedded seven-note data and cmd-shift-l access. Root may select editor::changelog::ui_tests for exact3 if parsers unnecessary; never report zero-match as pass. Native OS accessibility/physical visual acceptance not proved by these fixtures.

Future user-reviewed app delivery: normal save/quit/state checks through root only. At960px and ordinary width, inspect button beside Log, readable coverage notes offline, scroll, close/Escape and keyboard access, no transport/project edit while reader owns focus. Check current notes honestly identify older available coverage, not all later source changes. Accessibility genericbutton role remains a known pinned toolkit limitation; no VoiceOver claim. No new model attempt needed: actual configured Mac route already passed once, cloud failures remain separate.
