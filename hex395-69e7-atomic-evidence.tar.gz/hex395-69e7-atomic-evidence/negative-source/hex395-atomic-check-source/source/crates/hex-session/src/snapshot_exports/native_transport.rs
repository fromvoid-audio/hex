//! Purpose-specific native compiled records for the existing Session family.
//! No queue, registry, lock, raw Arc adoption or admission flag is created here.
//! These methods require exclusive record access supplied by the family; final
//! native transport wiring must provide qualified per-record exclusion.
use super::ExportRecordError as Error;
use hex_engine::{AudioCompiledRevision, AudioRootStorageLedger, AudioStorageError};
use std::{
    any::Any,
    panic::{AssertUnwindSafe, catch_unwind},
};

// Current and constructing compiled references. Export/seek reader fields live
// in their own concrete work records. Exhaustion retains the producer payload.
const COMPILED_RECORDS: usize = 2;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase {
    Vacant,
    Reserved,
    Queued,
    Claimed,
    Completed,
    Retiring,
    Failed,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct CompiledStamp {
    family: u64,
    index: usize,
    generation: u64,
}

struct CompiledRecord {
    generation: u64,
    phase: Phase,
    payload: Option<AudioCompiledRevision>,
    cleanup_pending: bool,
    first_panic: Option<Box<dyn Any + Send>>,
}
impl Default for CompiledRecord {
    fn default() -> Self {
        Self {
            generation: 0,
            phase: Phase::Vacant,
            payload: None,
            cleanup_pending: false,
            first_panic: None,
        }
    }
}

pub(super) struct NativeCompiledRecords {
    family: u64,
    closed: bool,
    records: [CompiledRecord; COMPILED_RECORDS],
}
impl NativeCompiledRecords {
    // Inline record bodies have no backing allocation or hidden OS primitive.
    // The enclosing registered-family constructor must charge this actual size.
    pub(super) const fn inline_bytes() -> usize {
        std::mem::size_of::<Self>()
    }

    pub(super) fn new(family: u64) -> Self {
        Self {
            family,
            closed: false,
            records: std::array::from_fn(|_| CompiledRecord::default()),
        }
    }

    pub(super) fn reserve(&mut self) -> Result<CompiledStamp, Error> {
        if self.closed {
            return Err(Error::Closed);
        }
        let (index, record) = self
            .records
            .iter_mut()
            .enumerate()
            .find(|(_, record)| record.phase == Phase::Vacant)
            .ok_or(Error::Reservation)?;
        if record.payload.is_some() || record.cleanup_pending || record.first_panic.is_some() {
            return Err(Error::Stale);
        }
        let generation = record.generation.checked_add(1).ok_or(Error::Exhausted)?;
        record.generation = generation;
        record.phase = Phase::Reserved;
        Ok(CompiledStamp {
            family: self.family,
            index,
            generation,
        })
    }

    fn record(&self, stamp: CompiledStamp) -> Result<&CompiledRecord, Error> {
        if stamp.family != self.family {
            return Err(Error::Stale);
        }
        self.records
            .get(stamp.index)
            .filter(|record| {
                record.generation == stamp.generation
                    && record.phase != Phase::Vacant
                    && record.phase != Phase::Failed
                    && !record.cleanup_pending
                    && record.first_panic.is_none()
            })
            .ok_or(Error::Stale)
    }

    fn record_mut(&mut self, stamp: CompiledStamp) -> Result<&mut CompiledRecord, Error> {
        self.record(stamp)?;
        Ok(&mut self.records[stamp.index])
    }

    pub(super) fn install(
        &mut self,
        stamp: CompiledStamp,
        source: &mut Option<AudioCompiledRevision>,
    ) -> Result<(), Error> {
        if self.closed {
            return Err(Error::Closed);
        }
        let record = self.record_mut(stamp)?;
        if record.phase != Phase::Reserved || record.payload.is_some() || source.is_none() {
            return Err(Error::Stale);
        }
        // All validation precedes this fixed transfer. No fallible work, clone,
        // callback or allocation can separate payload and state publication.
        record.payload = source.take();
        record.phase = Phase::Queued;
        Ok(())
    }

    pub(super) fn claim(&mut self, stamp: CompiledStamp) -> Result<(), Error> {
        if self.closed {
            return Err(Error::Closed);
        }
        let record = self.record_mut(stamp)?;
        if record.phase != Phase::Queued || record.payload.is_none() {
            return Err(Error::Stale);
        }
        // A claim leaves the actual immutable owner in this inspected field.
        record.phase = Phase::Claimed;
        Ok(())
    }

    pub(super) fn borrowed(&self, stamp: CompiledStamp) -> Result<&AudioCompiledRevision, Error> {
        let record = self.record(stamp)?;
        if !matches!(
            record.phase,
            Phase::Queued | Phase::Claimed | Phase::Completed
        ) {
            return Err(Error::Stale);
        }
        record.payload.as_ref().ok_or(Error::Stale)
    }

    pub(super) fn complete(&mut self, stamp: CompiledStamp) -> Result<(), Error> {
        let record = self.record_mut(stamp)?;
        if record.phase != Phase::Claimed || record.payload.is_none() {
            return Err(Error::Stale);
        }
        record.phase = Phase::Completed;
        Ok(())
    }

    pub(super) fn retire(&mut self, stamp: CompiledStamp) -> Result<(), Error> {
        let record = self.record_mut(stamp)?;
        record.phase = Phase::Retiring;
        Ok(())
    }

    pub(super) fn close(&mut self) {
        self.closed = true;
        for record in &mut self.records {
            if matches!(
                record.phase,
                Phase::Reserved | Phase::Queued | Phase::Claimed | Phase::Completed
            ) {
                record.phase = Phase::Retiring;
            }
        }
    }

    pub(super) fn cleanup_one(&mut self) -> Result<bool, Error> {
        let Some(record) = self
            .records
            .iter_mut()
            .find(|record| record.phase == Phase::Retiring)
        else {
            return Ok(false);
        };
        if record.cleanup_pending || record.first_panic.is_some() {
            return Err(Error::Stale);
        }
        record.cleanup_pending = true;
        match catch_unwind(AssertUnwindSafe(|| drop(record.payload.take()))) {
            Ok(()) => {
                record.phase = Phase::Vacant;
                record.cleanup_pending = false;
                Ok(true)
            }
            Err(payload) => {
                record.first_panic = Some(payload);
                record.phase = Phase::Failed;
                Err(Error::Stale)
            }
        }
    }

    /// The enclosing registered-family body must already be observed. Every
    /// paired handle is visited at its actual current physical field location.
    pub(super) fn visit<'a>(
        &'a self,
        ledger: &mut AudioRootStorageLedger<'a>,
    ) -> Result<(), AudioStorageError> {
        for record in &self.records {
            if record.cleanup_pending
                || record.first_panic.is_some()
                || record.phase == Phase::Failed
            {
                return Err(AudioStorageError::UnknownStorage);
            }
            match (record.phase, &record.payload) {
                (Phase::Vacant | Phase::Reserved, None) => {}
                (
                    Phase::Queued | Phase::Claimed | Phase::Completed | Phase::Retiring,
                    Some(reader),
                ) => reader.visit_shared_storage_on_control(ledger)?,
                (Phase::Retiring, None) => {} // cancelled reservation, no owner was constructed
                _ => return Err(AudioStorageError::UnknownStorage),
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests;
