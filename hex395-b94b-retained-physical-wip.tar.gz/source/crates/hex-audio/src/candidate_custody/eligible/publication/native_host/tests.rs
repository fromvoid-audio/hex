use super::*;
use hex_engine::{AudioRootStorageLedger, AudioStorageLedgerReservation};
fn limits() -> AudioStorageLedgerReservation {
    AudioStorageLedgerReservation {
        data_rows: 4096,
        handle_rows: 2048,
        root_rows: 16,
        max_retained_bytes: 64 * 1024 * 1024,
        max_construction_peak_bytes: 64 * 1024 * 1024,
    }
}
fn fixture() -> (CandidateRoot, AudioCandidatePreparationToken) {
    let root = CandidateRoot::new(3).unwrap();
    root.configure_publications(
        AudioCandidatePublicationReservation {
            runtime_slots: 2,
            archive_slots: 2,
            member_rows: 4096,
            transfer_rows: 4096,
            receipt_rows: 4,
            data_rows: 4096,
            handle_rows: 2048,
            max_retained_data_bytes: 96 * 1024 * 1024,
            max_construction_peak_data_bytes: 96 * 1024 * 1024,
        },
        0,
    )
    .unwrap();
    let token = root
        .reserve_runtime_preparation(
            AudioCandidatePreparationReservation {
                source_capacity: 3,
                member_rows: 1024,
                transfer_rows: 1024,
                handle_rows: 512,
                storage: hex_engine::AudioStorageReservation {
                    allocation_items: 256,
                    handle_obligations: 512,
                    max_prepared_data_bytes: 16 * 1024 * 1024,
                    max_construction_data_bytes: 16 * 1024 * 1024,
                    caller_retained_bytes: 0,
                    caller_construction_bytes: 0,
                },
            },
            Vec::with_capacity(2),
        )
        .ok()
        .unwrap();
    (root, token)
}
fn asset(name: &str) -> hex_project::AssetId {
    let mut editor =
        hex_project::Editor::new(hex_project::Project::new(48000).unwrap(), 4).unwrap();
    let hex_project::Created::Asset(asset) = editor
        .execute(hex_project::Command::AddAsset {
            path: name.into(),
            sample_rate: 48000,
            frames: 8,
        })
        .unwrap()
    else {
        panic!("asset")
    };
    asset
}
#[test]
fn actual_nonempty_guarded_host_inspects_without_birth_and_reborrows_same_cell_after_ledger_drop() {
    let (root, token) = fixture();
    let audio = hex_engine::Audio::new(48000, vec![[0.25; 2]; 8]).unwrap();
    let first = asset("first.wav");
    root.with_runtime_preparation(token, |cell| {
        cell.operations_on_control()
            .copy_resident_source_on_control(first, &audio)
    })
    .unwrap();
    let mut host = NativePreparationHost::acquire(&root, token).unwrap();
    let address = host.selected_address;
    {
        let mut ledger = AudioRootStorageLedger::try_new_on_control(limits()).unwrap();
        let measured = allocation_counter::measure(|| {
            ledger
                .borrow_sampler_native_fields_on_control(&host)
                .unwrap()
        });
        assert_eq!(
            (
                measured.count_total,
                measured.count_current,
                measured.bytes_total,
                measured.bytes_current
            ),
            (0, 0, 0, 0)
        );
        assert!(ledger.summary().unwrap().data_bytes > root_allocation_bytes().unwrap());
        ledger
            .validate_selected_shared_handles_on_control()
            .unwrap();
        assert!(ledger.summary().unwrap().require_complete().is_err());
    }
    let selected = host.selected_mut().unwrap();
    assert_eq!(std::ptr::from_ref(selected).addr(), address);
    // No extraction/replacement: mutate the same retained actual source vector.
    // Fresh Editor asset IDs are fixture-local; use the next actual ID from one
    // real Editor for this second source.
    let mut editor =
        hex_project::Editor::new(hex_project::Project::new(48000).unwrap(), 4).unwrap();
    for name in ["unused.wav", "second.wav"] {
        let hex_project::Created::Asset(next) = editor
            .execute(hex_project::Command::AddAsset {
                path: name.into(),
                sample_rate: 48000,
                frames: 8,
            })
            .unwrap()
        else {
            panic!("asset")
        };
        if name == "second.wav" {
            selected
                .operations_on_control()
                .copy_resident_source_on_control(next, &audio)
                .unwrap();
        }
    }
    let mut ledger = AudioRootStorageLedger::try_new_on_control(limits()).unwrap();
    ledger
        .borrow_sampler_native_fields_on_control(&host)
        .unwrap();
    ledger
        .validate_selected_shared_handles_on_control()
        .unwrap();
    eprintln!(
        "SUPPORTED actual selected nonempty source+spare native backing traversal0alloc/free; all immutable ledger loans end before SAME persistent cell mutable reborrow; full admission remains refused"
    );
}
#[test]
fn actual_five_guards_each_refuse_immediately_and_wrong_token_or_cell_cannot_reborrow() {
    use crate::candidate_custody::inline_lock_tests::held_on_other_thread;
    let (root, token) = fixture();
    let inspect = || {
        assert!(matches!(
            NativePreparationHost::acquire(&root, token),
            Err(AudioStorageError::ExternalReadersPending)
        ))
    };
    held_on_other_thread(&root.0.bank, inspect);
    held_on_other_thread(&root.0.execution, inspect);
    held_on_other_thread(&root.0.returns, inspect);
    held_on_other_thread(&root.0.eligible.work, inspect);
    held_on_other_thread(&root.0.eligible.bank, inspect);
    let mut stale = token;
    stale.incarnation += 1;
    assert!(matches!(
        NativePreparationHost::acquire(&root, stale),
        Err(AudioStorageError::SourceMismatch)
    ));
    let mut host = NativePreparationHost::acquire(&root, token).unwrap();
    host.selected_address += 1;
    assert!(matches!(
        host.selected_mut(),
        Err(AudioStorageError::SourceMismatch)
    ));
    eprintln!(
        "SUPPORTED same actual five other-thread holds: immediate try refusal/no new wait; stale incarnation/wrong selected-address refuse before mutable loan"
    );
}
#[test]
fn actual_native_constructor_boundary_is_not_hidden_as_absent_fields() {
    let _serial = crate::prepared::candidate_tests::serial();
    let (mut control, data, errors, mut retirement) = crate::prepared::candidate_tests::anchored();
    let root = control.native_candidate_root();
    root.configure_publications(
        AudioCandidatePublicationReservation {
            runtime_slots: 2,
            archive_slots: 2,
            member_rows: 4096,
            transfer_rows: 4096,
            receipt_rows: 4,
            data_rows: 4096,
            handle_rows: 2048,
            max_retained_data_bytes: 96 * 1024 * 1024,
            max_construction_peak_data_bytes: 96 * 1024 * 1024,
        },
        0,
    )
    .unwrap();
    let token = root
        .reserve_runtime_preparation(
            AudioCandidatePreparationReservation {
                source_capacity: 1,
                member_rows: 1024,
                transfer_rows: 1024,
                handle_rows: 512,
                storage: hex_engine::AudioStorageReservation {
                    allocation_items: 256,
                    handle_obligations: 512,
                    max_prepared_data_bytes: 16 * 1024 * 1024,
                    max_construction_data_bytes: 16 * 1024 * 1024,
                    caller_retained_bytes: 0,
                    caller_construction_bytes: 0,
                },
            },
            vec![],
        )
        .ok()
        .unwrap();
    {
        let host = NativePreparationHost::acquire(&root, token).unwrap();
        assert!(
            host.bank.native.is_some(),
            "ACTUAL anchored native constructor, not fake None"
        );
        let mut ledger = AudioRootStorageLedger::try_new_on_control(limits()).unwrap();
        assert_eq!(
            ledger.borrow_sampler_native_fields_on_control(&host),
            Err(AudioStorageError::UnknownStorage)
        );
        assert!(
            ledger.summary().is_err(),
            "refused partial prefix is not reusable"
        );
    }
    root.cancel_runtime_preparation(token);
    drop((data, errors));
    control.reclaim();
    drop(control);
    crate::prepared::candidate_tests::finish(&mut retirement);
    eprintln!(
        "REFUSED actual normal native endpoint boundary requires actual callback/current/queue field bindings; constructor counts cannot become a fake complete host"
    );
}
