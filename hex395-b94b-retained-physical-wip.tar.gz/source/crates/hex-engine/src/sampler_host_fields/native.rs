//! Finite guarded native fields. Producer validation is audited, not a public
//! capability. Unknown occupants must refuse rather than disappear as None.
use super::{BodyRef, SharedMetadataRef, VecRef};
use crate::{AudioCandidatePreparation, AudioRootStorageLedger, AudioStorageError};

pub struct NativeRuntimeFields<'a> {
    pub body: BodyRef<'a>,
    pub life: SharedMetadataRef<'a>,
    pub domains: VecRef<'a>,
}
pub struct NativePreparationFields<'a> {
    pub body: BodyRef<'a>,
    pub domains: VecRef<'a>,
    pub cell: &'a AudioCandidatePreparation,
}
/// All references remain inside the existing five native exclusions. This
/// schema is not proof of absent descendants, retirement or publication.
pub trait NativeFields {
    fn root(&self) -> SharedMetadataRef<'_>;
    fn guarded_bodies(&self) -> [BodyRef<'_>; 5];
    fn outer_slots(&self) -> VecRef<'_>;
    fn outer_slot(&self, index: usize) -> Result<BodyRef<'_>, AudioStorageError>;
    fn domain_signals(&self) -> Result<[SharedMetadataRef<'_>; 2], AudioStorageError>;
    fn runtime_slots(&self) -> VecRef<'_>;
    fn runtime(&self, index: usize) -> Result<NativeRuntimeFields<'_>, AudioStorageError>;
    fn archives(&self) -> VecRef<'_>;
    /// Actual preparations, anchors, executions, failed payloads and bank-drop
    /// backings, in this fixed order. Every occupied child is mandatory below.
    fn work_backings(&self) -> [VecRef<'_>; 5];
    fn preparation(
        &self,
        index: usize,
    ) -> Result<Option<NativePreparationFields<'_>>, AudioStorageError>;
    fn validate_remaining_children(&self) -> Result<(), AudioStorageError>;
}
fn contains(parent: BodyRef<'_>, child: BodyRef<'_>) -> Result<(), AudioStorageError> {
    parent
        .contains(child)
        .then_some(())
        .ok_or(AudioStorageError::SourceMismatch)
}
pub(crate) fn visit_native<'a>(
    fields: &'a dyn NativeFields,
    ledger: &mut AudioRootStorageLedger<'a>,
) -> Result<(), AudioStorageError> {
    fields.validate_remaining_children()?;
    let root = fields.root();
    root.observe(ledger)?;
    let [bank, execution, returns, native_bank, native_work] = fields.guarded_bodies();
    for body in [bank, execution, returns, native_bank, native_work] {
        contains(root.payload(), body)?;
    }
    let slots = fields.outer_slots();
    contains(bank, slots.body())?;
    slots.observe(ledger)?;
    for index in 0..slots.len() {
        if !slots.element(index)?.same(fields.outer_slot(index)?) {
            return Err(AudioStorageError::SourceMismatch);
        }
    }
    for signal in fields.domain_signals()? {
        contains(native_bank, signal.body())?;
        signal.observe(ledger)?;
    }
    let slots = fields.runtime_slots();
    contains(native_bank, slots.body())?;
    slots.observe(ledger)?;
    let archives = fields.archives();
    contains(native_bank, archives.body())?;
    archives.observe(ledger)?;
    for index in 0..slots.len() {
        let runtime = fields.runtime(index)?;
        if !slots.element(index)?.same(runtime.body) {
            return Err(AudioStorageError::SourceMismatch);
        }
        contains(runtime.body, runtime.life.body())?;
        contains(runtime.body, runtime.domains.body())?;
        runtime.life.observe(ledger)?;
        runtime.domains.observe(ledger)?;
    }
    let backings = fields.work_backings();
    for backing in backings {
        contains(native_work, backing.body())?;
        backing.observe(ledger)?;
    }
    for index in 0..backings[0].len() {
        if let Some(preparation) = fields.preparation(index)? {
            contains(backings[0].element(index)?, preparation.body)?;
            contains(preparation.body, preparation.domains.body())?;
            contains(preparation.body, BodyRef::of(preparation.cell))?;
            preparation.domains.observe(ledger)?;
            preparation.cell.visit_sampler_host_children(ledger)?;
        }
    }
    Ok(())
}
impl<'a> AudioRootStorageLedger<'a> {
    /// Guarded actual descendants only. Failure invalidates this entire ledger;
    /// no partially visited prefix may become an approval or be resumed.
    pub fn borrow_sampler_native_fields_on_control(
        &mut self,
        fields: &'a dyn NativeFields,
    ) -> Result<(), AudioStorageError> {
        self.mutate(|ledger| visit_native(fields, ledger))
    }
}
