import importlib.util,pathlib,sys
root=pathlib.Path.cwd();spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='459-34877501-guarded-focused',adopt_target=True,min_free_bytes=2*1024**3,steps=(m.Step('local-ci-regressions',(sys.executable,'-m','unittest','discover','-s','scripts/tests','-p','test_local_ci.py'),uses_cargo_target=True),));sys.exit(r.run())
