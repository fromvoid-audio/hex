import importlib.util,pathlib,sys
root=pathlib.Path('/workspace/hex-integration-workspace-view')
spec=importlib.util.spec_from_file_location('hex_local_ci',root/'scripts/local-ci.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.LocalCiRunner(root,mode='component',run_id='419-458-d0bb8926-guarded-focused',adopt_target=True,min_free_bytes=2*1024**3,steps=(m.Step('format',('cargo','fmt','--all','--','--check')),m.Step('last-owner-gain-pointer-two',('cargo','test','-p','hex-ui','--features','ui-test-support','--lib','--locked','workspace_adb3_returns_','--','--nocapture'))))
code=r.run();print('FOCUSED_ONLY_SUMMARY',r.summary_path);raise SystemExit(code)
