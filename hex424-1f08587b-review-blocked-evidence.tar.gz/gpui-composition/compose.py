from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile,difflib
r=Path('/workspace/hex-integration-project-directory');v=r/'third_party/gpui';out=Path('/workspace/scratch/integration/424-gpui-composition')
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
m=json.loads(git('show','HEAD:third_party/gpui/hex-provenance.json'));name='src/app/test_context.rs';actual=(v/name).read_bytes();m['patched_files'][name]=hashlib.sha256(actual).hexdigest();(v/'hex-provenance.json').write_text(json.dumps(m,indent=2)+'\n')
a=Path('/workspace/scratch/integration/406-gpui-merge/gpui-0.2.2.crate');assert hashlib.sha256(a.read_bytes()).hexdigest()==m['crates_io_sha256']
base=out/'reapplied';assert not base.exists();base.mkdir();original={}
with tarfile.open(a) as t:
 for x in t.getmembers():
  p=PurePosixPath(x.name);assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='gpui-0.2.2'
  if x.isdir():continue
  assert x.isfile();n=PurePosixPath(*p.parts[1:]).as_posix();b=t.extractfile(x).read();original[n]=b;q=base/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
for n,h in m['original_files'].items():assert hashlib.sha256(original[n]).hexdigest()==h,n
s=git('show','HEAD:third_party/gpui/hex-patches.diff').decode();prefix='diff --git a/'+name+' b/'+name+'\n';start=s.index(prefix);end=s.find('\ndiff --git ',start+len(prefix));end=len(s) if end<0 else end+1
patch=prefix+''.join(difflib.unified_diff(original[name].decode().splitlines(keepends=True),actual.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name,n=0))
s=s[:start]+patch+s[end:];assert '<<<<<<<' not in s;(v/'hex-patches.diff').write_text(s)
p=v/'HEX-PATCHES.md';s=p.read_text();aa=s.index('<<<<<<< HEAD\n');bb=s.index('=======\n',aa);cc=s.index('>>>>>>> origin/main\n',bb);s=s[:aa]+s[aa+len('<<<<<<< HEAD\n'):bb]+'\n'+s[bb+len('=======\n'):cc]+s[cc+len('>>>>>>> origin/main\n'):];assert '<<<<<<<' not in s;p.write_text(s)
subprocess.run(['git','apply','--check','--unidiff-zero',str(v/'hex-patches.diff')],cwd=base,check=True);subprocess.run(['git','apply','--unidiff-zero',str(v/'hex-patches.diff')],cwd=base,check=True)
for n in set(m['original_files'])|set(m['added_files']):assert (base/n).read_bytes()==(v/n).read_bytes(),n
for family in ['patched_files','added_files']:
 for n,h in m[family].items():assert hashlib.sha256((v/n).read_bytes()).hexdigest()==h,n
proof={'source_parent':'4737b68e53bb9bf1193880257bfe21474e5754a7','integrated_main':'2eef0cb1ab096445df38c704ed3a1dfe68e4bdb3','archive_sha256':m['crates_io_sha256'],'original_files_verified':len(m['original_files']),'patched_files_verified':len(m['patched_files']),'added_files_verified':len(m['added_files']),'combined_test_context_sha256':m['patched_files'][name],'all_reapplied_bytes_match':True,'scope':'Only cumulative test_context patch/provenance composition and both append-only GPUI documentation entries. Auto-merged actual optional-picker-directory test bridge + existing Mac-font opt-in/picker queue/quad accessor retained; all production/fixture source remains ordinary Git merge result. No guard weakening/feature source changes by merger.'}
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
